#!/usr/bin/env bash
# qa-lib.sh — shared platform probes and managed-config-block helpers for the
# root-owned console helpers in /usr/local/sbin.
#
# SOURCED, NEVER EXECUTED. It defines functions and sets nothing else; it has
# no side effects and no main. access=lib in helpers.list keeps it out of
# sudoers: the web user reaches it only through a helper that sources it, and
# granting it directly would be granting nothing useful anyway.
#
# WHY THIS EXISTS, given that install/ scripts are self-contained by convention.
# That convention is real and worth keeping -- one file per helper is one
# auditable unit for something the web user can invoke as root. qa-update-apply
# cites it for declining to factor out verify_sig(), and that call was correct:
# one 20-line function shared by two scripts does not pay for a new file that
# every installer, the updater and the drift checker must now place and keep in
# step.
#
# Two things here do clear that bar, and neither is a style preference:
#
#   1. PLATFORM PROBES. "Where is the mail log / the Apache log dir / the
#      Dovecot log" was answered independently in four scripts, and the answers
#      had already diverged. qa-blocked-stats.sh:14-17 documents the bug that
#      forced its probe -- a hardcoded EL path made the dashboard silently
#      empty on Ubuntu, no error anywhere. The same bug was still live in
#      qa-siem-config.sh, which defaulted WEB_LOG_DIR to /var/log/httpd and
#      hardcoded /var/log/dovecotlog, so on Debian/Ubuntu the SIEM forwarder
#      shipped imfile inputs for files that do not exist and quietly forwarded
#      no Apache log at all. A probe that is re-typed per consumer is not a
#      convention, it is four chances to get it wrong, and it had already gone
#      wrong twice.
#
#   2. MANAGED BLOCKS. Every append into a shared config file was guarded by
#      grepping for one string from inside the block it was about to write.
#      That guard cannot tell "already applied" from "an admin edited a weight"
#      and it leaves no way to update or remove the block afterwards -- so
#      clearing an Abusix key removed the RBL rules and orphaned their weights
#      in groups.conf permanently. Delimiters fix all three, and they only work
#      if every writer agrees on the same ones, which is precisely the thing a
#      per-script copy cannot guarantee.
#
# There is precedent for the shape: qa-quota-lib.php and
# qa-community-feed-lib.php are already shared libraries in /usr/local/sbin.
# This is the Bash one, named to match.
#
# Callers source it by their own directory, never by PATH and never from an
# environment variable -- these run as root under sudo, so the path must not be
# something a caller can influence:
#
#     . "$(dirname "${BASH_SOURCE[0]}")/qa-lib.sh" || exit 2
#
# In production that resolves to /usr/local/sbin (root-owned); in a checkout it
# resolves to install/ beside the caller. qa-lib.sh is listed FIRST in
# helpers.list so all three install loops place it before anything that sources
# it.

# Guard against double-sourcing: several helpers source this and then call each
# other, and re-running the definitions is harmless but re-running the probe
# caches is not free.
[ -n "${_QA_LIB_LOADED:-}" ] && return 0
_QA_LIB_LOADED=1

# ─── platform probes ──────────────────────────────────────────────────────────
#
# All of these answer "where does this distribution put X", by looking, never by
# branching on /etc/os-release. A host can have Postfix logging somewhere the
# package default does not predict; capability detection survives that and an OS
# guess does not. Results are cached per process -- these are called inside
# loops in qa-audit-log.sh.

# The Postfix/mail log. EL writes /var/log/maillog, Debian/Ubuntu
# /var/log/mail.log. Prints the path; returns 1 and prints nothing if neither is
# readable, so a caller can emit its own empty result rather than reading "".
_QA_MAIL_LOG=
qa_mail_log() {
    if [ -z "$_QA_MAIL_LOG" ]; then
        local c
        for c in /var/log/maillog /var/log/mail.log; do
            [ -r "$c" ] && { _QA_MAIL_LOG="$c"; break; }
        done
    fi
    [ -n "$_QA_MAIL_LOG" ] || return 1
    printf '%s\n' "$_QA_MAIL_LOG"
}

# Apache log directories that actually exist, newline-separated, EL name first.
# Plural on purpose: qa-audit-log.sh reads the same basename out of whichever
# directory is present, and a host that somehow has both should have both read
# rather than silently losing one. Prints nothing and returns 1 if neither
# exists.
_QA_WEB_LOG_DIRS=
qa_web_log_dirs() {
    if [ -z "$_QA_WEB_LOG_DIRS" ]; then
        local d
        for d in /var/log/httpd /var/log/apache2; do
            [ -d "$d" ] && _QA_WEB_LOG_DIRS="${_QA_WEB_LOG_DIRS}${d}"$'\n'
        done
    fi
    [ -n "$_QA_WEB_LOG_DIRS" ] || return 1
    printf '%s' "$_QA_WEB_LOG_DIRS"
}

# The single Apache log directory to write into a generated config, for callers
# that need one path rather than a set (qa-siem-config.sh's imfile inputs). EL
# name is the fallback only when nothing could be probed, which preserves the
# behaviour of the literal it replaced.
qa_web_log_dir() {
    qa_web_log_dirs 2>/dev/null | head -1 | grep . || printf '/var/log/httpd\n'
}

# Dovecot's log file(s). Unlike the two above this has an authoritative answer
# -- Dovecot's own log_path -- so ask doveconf first and fall back to the two
# common filenames only when it cannot say. "syslog" and the empty value both
# mean "not a file", and must not be returned as a path: 10-logging.conf on a
# stock install leaves logging to syslog entirely, where mail.* already carries
# it. Prints existing, readable paths newline-separated; returns 1 if none.
_QA_DOVECOT_LOGS=
qa_dovecot_logs() {
    if [ -z "$_QA_DOVECOT_LOGS" ]; then
        local configured c
        configured="$(doveconf -h log_path 2>/dev/null | head -1)"
        case "$configured" in
            ''|syslog|/dev/stderr) configured="" ;;
        esac
        for c in "$configured" /var/log/dovecotlog /var/log/dovecot.log; do
            [ -n "$c" ] || continue
            [ -r "$c" ] || continue
            # doveconf's answer and a literal candidate can be the same file.
            case $'\n'"$_QA_DOVECOT_LOGS" in
                *$'\n'"$c"$'\n'*) continue ;;
            esac
            _QA_DOVECOT_LOGS="${_QA_DOVECOT_LOGS}${c}"$'\n'
        done
    fi
    [ -n "$_QA_DOVECOT_LOGS" ] || return 1
    printf '%s' "$_QA_DOVECOT_LOGS"
}

# One Dovecot log path for generated config, with the historical literal as the
# fallback so a host where nothing is probeable keeps today's output.
qa_dovecot_log() {
    qa_dovecot_logs 2>/dev/null | head -1 | grep . || printf '/var/log/dovecotlog\n'
}

# ─── managed config blocks ────────────────────────────────────────────────────
#
# A delimited region one tool owns inside a file several tools append to:
#
#     # BEGIN ilexa-managed: abusix-weights
#     ...
#     # END ilexa-managed: abusix-weights
#
# What this buys over `grep -q SOMESYMBOL && return 0` before a `cat >>`:
#
#   · updatable. The old guard matched on a string from inside its own block,
#     so a changed weight could never be rolled out -- the guard saw the old
#     block and returned "already done". Replacing between markers just works.
#   · removable. Clearing an Abusix key deletes the rbl.d slice but had no way
#     to take the weights with it, so groups.conf accumulated symbol
#     definitions for feeds the host no longer queries.
#   · attributable. Two owners already append a `group "rbl"` block to the same
#     groups.conf. Unmarked, nothing says which is whose.
#
# `#` is the comment character in every file these are used on (rspamd UCL,
# rsyslog, Postfix), so one marker syntax covers all of them.
#
# COMPATIBILITY WITH BLOCKS ALREADY ON DISK. Hosts installed before this exists
# carry the same content with no markers. qa_managed_set will not find markers
# there and would append a second copy, so callers pass the legacy sentinel they
# used to grep for as the optional 3rd argument: if that string is present
# outside any managed block, the file is left completely alone. Those hosts keep
# exactly the behaviour they have today and converge the next time the block is
# legitimately rewritten. Nothing here ever edits an unmarked region.

_qa_managed_ok_id() { # id
    case "$1" in
        ''|*[!A-Za-z0-9._-]*) return 1 ;;
    esac
    return 0
}

# Is this file's block for <id> present?
qa_managed_has() { # file id
    local file="$1" id="$2"
    _qa_managed_ok_id "$id" || return 2
    [ -f "$file" ] || return 1
    grep -qF "# BEGIN ilexa-managed: $id" "$file"
}

# Write (create or replace) the block for <id>, content on stdin.
#
#   qa_managed_set /etc/rspamd/local.d/groups.conf abusix-weights <<'EOF'
#   group "rbl" { ... }
#   EOF
#
# Third argument, optional: a legacy sentinel. If it appears in the file while
# no marked block exists, this is a pre-markers host -- return 0 and change
# nothing.
qa_managed_set() { # file id [legacy-sentinel]
    local file="$1" id="$2" legacy="${3:-}" body tmp
    _qa_managed_ok_id "$id" || { echo "qa_managed_set: bad id '$id'" >&2; return 2; }
    [ -n "$file" ] || { echo "qa_managed_set: no file given" >&2; return 2; }
    body="$(cat)"

    if [ -f "$file" ] && [ -n "$legacy" ] && ! qa_managed_has "$file" "$id"; then
        if grep -qF "$legacy" "$file"; then
            return 0
        fi
    fi

    [ -e "$file" ] || : >"$file" || { echo "qa_managed_set: cannot create $file" >&2; return 1; }

    tmp="$(mktemp "${file}.qa-XXXXXX")" || { echo "qa_managed_set: mktemp failed" >&2; return 1; }
    # Match the target's ownership and mode before anything is moved into
    # place. groups.conf is root:_rspamd 0640; a fresh mktemp is root:root 0600,
    # and moving that over it would leave rspamd unable to read its own weights
    # -- a failure that shows up only at the next reload.
    chmod --reference="$file" "$tmp" 2>/dev/null || chmod 0640 "$tmp"
    chown --reference="$file" "$tmp" 2>/dev/null || true

    # Strip any existing block for this id, then append the new one. awk rather
    # than sed: the body is arbitrary text and must never be re-interpreted.
    awk -v b="# BEGIN ilexa-managed: $id" -v e="# END ilexa-managed: $id" '
        $0 == b { skip = 1; next }
        $0 == e { skip = 0; next }
        !skip   { print }
    ' "$file" >"$tmp" || { rm -f "$tmp"; echo "qa_managed_set: rewrite of $file failed" >&2; return 1; }

    {
        printf '\n# BEGIN ilexa-managed: %s\n' "$id"
        printf '%s\n' "$body"
        printf '# END ilexa-managed: %s\n' "$id"
    } >>"$tmp" || { rm -f "$tmp"; echo "qa_managed_set: append to $file failed" >&2; return 1; }

    mv -f "$tmp" "$file" || { rm -f "$tmp"; echo "qa_managed_set: cannot replace $file" >&2; return 1; }
}

# Remove the block for <id>. Absent block is success, not an error: callers use
# this on a disable path that must be safe to run twice. An unmarked legacy
# block is NOT removed -- its boundaries are not knowable, and guessing them in
# a file other owners append to is how one feature deletes another's config.
qa_managed_del() { # file id
    local file="$1" id="$2" tmp
    _qa_managed_ok_id "$id" || { echo "qa_managed_del: bad id '$id'" >&2; return 2; }
    [ -f "$file" ] || return 0
    qa_managed_has "$file" "$id" || return 0

    tmp="$(mktemp "${file}.qa-XXXXXX")" || { echo "qa_managed_del: mktemp failed" >&2; return 1; }
    chmod --reference="$file" "$tmp" 2>/dev/null || chmod 0640 "$tmp"
    chown --reference="$file" "$tmp" 2>/dev/null || true

    awk -v b="# BEGIN ilexa-managed: $id" -v e="# END ilexa-managed: $id" '
        $0 == b { skip = 1; next }
        $0 == e { skip = 0; next }
        !skip   { print }
    ' "$file" >"$tmp" || { rm -f "$tmp"; echo "qa_managed_del: rewrite of $file failed" >&2; return 1; }

    mv -f "$tmp" "$file" || { rm -f "$tmp"; echo "qa_managed_del: cannot replace $file" >&2; return 1; }
}
