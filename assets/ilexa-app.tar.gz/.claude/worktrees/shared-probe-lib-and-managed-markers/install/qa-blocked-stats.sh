#!/bin/bash
#
# Count mail blocked before delivery, per layer, from the Postfix log.
#
# Why a log scraper: the archive (always_bcc) only ever sees mail that was
# ACCEPTED. Everything rejected at SMTP -- virus, blocklist, spam score, DNSBL,
# protocol abuse -- never reaches a mailbox, so the only record is maillog.
# maillog is root-only, hence the sudo helper.
#
# Emits JSON with counts for today and for the trailing 7 days.
#   qa-blocked-stats.sh
set -uo pipefail

# The '{}' keeps the JSON contract the PHP side parses, but say why on stderr
# as well: an empty card with nothing in the log is precisely the shape of
# failure this script's own header complains about.
# shellcheck source-path=SCRIPTDIR source=qa-lib.sh
. "$(dirname "${BASH_SOURCE[0]}")/qa-lib.sh" || {
    echo "qa-blocked-stats: cannot source qa-lib.sh -- reporting no data" >&2
    echo '{}'; exit 0
}

# The mail log is not in the same place on every platform: EL writes
# /var/log/maillog, Debian/Ubuntu /var/log/mail.log. Hardcoding the EL path
# meant this exited '{}' on Ubuntu, which the dashboard reads as "no data" and
# hides the whole "Blokkolt levelek" card with no error anywhere. That probe
# now lives in qa_mail_log() so the other consumers of the mail log cannot
# answer the question differently -- one of them already did.
LOG="$(qa_mail_log)" || { echo '{}'; exit 0; }

# Rotated logs matter: the card reports a 7-day column, but reading only the
# CURRENT file made "7 nap" identical to "Ma" on any host that rotates inside
# that window -- which is every host here. The reference host rotates weekly
# with delaycompress, so at the moment of writing 7 of its last 7 days lived in
# maillog-20260816 (15MB, not yet gzipped) while the live maillog held under
# two hours. Ubuntu rotates daily into mail.log.1. Either way the 7-day figures
# were really 1-day figures.
#
# Collect the current file plus siblings touched in the last 8 days (one day of
# slack past the window the awk below filters to anyway), newest last so output
# order is chronological. -mtime bounds the work: without it a host with
# "rotate 12" would decompress a quarter of a year to answer for one week.
_dir="$(dirname "$LOG")"; _base="$(basename "$LOG")"
LOGS=()
while IFS= read -r _f; do [ -r "$_f" ] && LOGS+=("$_f"); done < <(
  find "$_dir" -maxdepth 1 -type f \( -name "$_base" -o -name "${_base}[-.]*" \) \
       -mtime -8 2>/dev/null | sort
)
[ "${#LOGS[@]}" -gt 0 ] || LOGS=("$LOG")

# .gz siblings appear as soon as delaycompress lets go of them.
read_logs() {
  local _l
  for _l in "${LOGS[@]}"; do
    case "$_l" in
      *.gz) zcat -- "$_l" 2>/dev/null || true ;;
      *)    cat  -- "$_l" 2>/dev/null || true ;;
    esac
  done
}

# Timestamp formats differ too, and fixing only the path would still have
# counted nothing. Traditional syslog writes "Aug 16 00:07:48"; Ubuntu 24.04's
# rsyslog defaults to RFC3339, "2026-08-15T14:10:06.959554+00:00". Build day
# prefixes in BOTH shapes and accept either, so one script serves both without
# needing to know which platform it is on.
days=(); days_iso=()
for i in 0 1 2 3 4 5 6; do
  days+=("$(date -d "-$i days" '+%b %e')")
  days_iso+=("$(date -d "-$i days" '+%Y-%m-%d')")
done
today="${days[0]}"; today_iso="${days_iso[0]}"
week_re="$(printf '%s|' "${days[@]}" "${days_iso[@]}")"; week_re="^(${week_re%|})"

# One pass, classifying each line; far cheaper than a grep per category.
awk -v today="$today" -v today_iso="$today_iso" -v weekre="$week_re" '
function bump(cat) { if (isweek) w[cat]++; if (istoday) t[cat]++ }
{
  istoday = (substr($0,1,6) == today || substr($0,1,10) == today_iso)
  isweek  = ($0 ~ weekre)
  if (!isweek) next

  # warn_if_reject logs the ENTIRE reject text -- "NOQUEUE: reject_warning: ...
  # blocked using <list>" -- and then DELIVERS the mail anyway. This script
  # counts mail that was blocked, so a warning is never a block. Without this
  # guard the warn-only `reject_rhsbl_sender uribl.hrbl.hu` on the reference
  # host contributed
  # 1267 phantom "blocks" over 11 weeks, inflating the DNSBL figure by ~11% and
  # dominating the per-list breakdown -- with legitimate senders behind it,
  # which is precisely why that rule is warn-only. Skip before classifying, so
  # it protects every category and not just the one that happened to hit it.
  if (index($0, "reject_warning:")) next

  # Two spellings, because the stack changed underneath this scraper.
  #   "clamav: virus found"  -- MailScanner/amavis era, retired 2026-08-18
  #   "malware detected"     -- what rspamd force_actions actually rejects with
  #                             today (local.d/force_actions.conf, CLAM_VIRUS)
  # Only the first was matched, so the "Vírus" figure on the dashboard has read
  # zero since the rspamd cutover regardless of how many viruses were blocked.
  # It looked correct only because the reference host happened to block none.
  #
  # milter-reject is required for the rspamd spelling, and that is load-bearing:
  # the same text appears in OUTBOUND postfix/smtp lines when a REMOTE server
  # rejects mail we sent ("host x said: 5.7.1 Message rejected: malware
  # detected"). Counting those would report our own rejected outbound as inbound
  # blocks -- observed for real on the reference host the day this was fixed.
  if (index($0, "clamav: virus found") ||
      (index($0, "milter-reject") && index($0, "malware detected"))) { bump("virus"); next }
  if (index($0, "Sender blocked by administrator")) { bump("blocklist"); next }
  if (index($0, "Spam message rejected"))           { bump("spam_reject"); next }
  # No per-list breakdown is emitted, deliberately. postscreen names exactly ONE
  # list in the reject -- whichever DNS reply arrived FIRST -- so the name is a
  # latency race between the configured lists, not a hit count. Measured on
  # hawking: at rank 6 (zen+mailspike, both matched by definition) 5 rejects
  # named mailspike and 2 named zen. Over 11 weeks the breakdown implied
  # barracuda 3 / hrbl 16 hits when the real listing rates were 37% and 47%.
  # It cannot be made accurate from the log; to measure per-list contribution,
  # re-query the lists for the ranked client IPs instead.
  if (index($0, "blocked using")) { bump("dnsbl"); next }
  if (index($0, "postscreen") && index($0, "PREGREET"))  { bump("pregreet"); next }
  if (index($0, "postscreen") && index($0, "HANGUP"))    { bump("hangup"); next }
  if (index($0, "Greylisted"))                            { bump("greylist"); next }
}
END {
  split("virus blocklist spam_reject dnsbl pregreet hangup greylist", cats, " ")
  printf "{"
  printf "\"today\":{"
  for (i=1; i<=7; i++) printf "%s\"%s\":%d", (i>1?",":""), cats[i], (cats[i] in t ? t[cats[i]] : 0)
  printf "},\"week\":{"
  for (i=1; i<=7; i++) printf "%s\"%s\":%d", (i>1?",":""), cats[i], (cats[i] in w ? w[cats[i]] : 0)
  printf "}}"
}' < <(read_logs)
