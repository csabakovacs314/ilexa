#!/bin/bash
#
# Root-owned reader for privileged log sources the Audit tab needs:
# successful/failed ilexa console logins (Apache access/error logs) and
# failed POP3/IMAP/webmail authentication (Dovecot's log -- Roundcube
# authenticates AS an IMAP client, so a failed Roundcube login already
# shows up here as an imap-login failure, no separate source needed).
#
# All three underlying logs are root-only (0700 containing dir for the
# Apache logs, 0600 for Dovecot's -- and Dovecot recreates that file fresh
# at every rotation, so even a one-time ACL grant on it would silently stop
# working again within a day). A sudo-invoked root-owned reader is the only
# approach here that survives log rotation, unlike a directory ACL.
#
# Usage:
#   qa-audit-log.sh admin-logins          <cookie_path>
#   qa-audit-log.sh admin-login-failures  <cookie_path>
#   qa-audit-log.sh mail-auth-failures
#   qa-audit-log.sh mail-auth-success
#
# Emits raw matching log lines (newest-file-last, original order within a
# file) for the caller to parse -- same "wrapper reads, PHP parses" split
# already used by admin_logins() before this script existed.
set -uo pipefail

die() { echo "qa-audit-log: $*" >&2; exit 2; }

# Sourced by absolute path derived from this script's own location -- never
# from PATH or an environment variable, because this runs as root under sudo.
# Failing loudly is deliberate: this command's output IS the audit data, so a
# silent empty result would read as "no logins", which is worse than an error.
# shellcheck source-path=SCRIPTDIR source=qa-lib.sh
. "$(dirname "${BASH_SOURCE[0]}")/qa-lib.sh" || die "cannot source qa-lib.sh"

# A URL path this app is mounted at -- validated defensively even though it
# only ever comes from this app's own config.php, not request input (every
# other privileged-read wrapper in this app validates its arguments the same
# way, on the principle that a root-run script should never trust its caller
# implicitly just because the caller is "supposed to be" apache).
v_cookie_path() {
    [[ "$1" =~ ^/[A-Za-z0-9_-]+/$ ]] || die "invalid cookie path: $1"
}

# Collect readable candidates for a log "base name" across both log-rotation
# naming conventions this app's installer produces (see modules/50-web.sh):
# plain rotated siblings (ssl_access_log-20260815) and logrotate's dateext
# form, PLUS gzipped older copies. Bounded to files touched in the last 8
# days -- recent failed-auth activity is what an admin actually wants to see;
# scanning a year of rotated logs on every page load is not.
collect() {
    local dir="$1" base="$2" f
    [ -d "$dir" ] || return 0
    while IFS= read -r f; do
        [ -r "$f" ] && printf '%s\n' "$f"
    done < <(find "$dir" -maxdepth 1 -type f \( -name "$base" -o -name "${base}[-.]*" \) \
                   -mtime -8 2>/dev/null | sort)
}

read_matching() {  # dir base grep-pattern [second-pattern]
    local dir="$1" base="$2" pattern="$3" pattern2="${4:-}" f
    while IFS= read -r f; do
        if [ -n "$pattern2" ]; then
            case "$f" in
                *.gz) zgrep -h -- "$pattern" "$f" 2>/dev/null | grep -- "$pattern2" ;;
                *)    grep  -h -- "$pattern" "$f" 2>/dev/null | grep -- "$pattern2" ;;
            esac
        else
            case "$f" in
                *.gz) zgrep -h -- "$pattern" "$f" 2>/dev/null ;;
                *)    grep  -h -- "$pattern" "$f" 2>/dev/null ;;
            esac
        fi
    done < <(collect "$dir" "$base")
}

cmd="${1:-}"; shift || true

case "$cmd" in
    admin-logins)
        [ $# -eq 1 ] || die "usage: admin-logins <cookie_path>"
        v_cookie_path "$1"
        # EL: /var/log/httpd/ssl_access_log*. Debian/Ubuntu: the installer
        # renames the SSL vhost's CustomLog to the same "ssl_access_log"
        # basename (modules/50-web.sh), so one glob covers both. Which of the
        # two directories exists is qa_web_log_dirs()' question, not this
        # command's; collect() already no-ops on a missing directory, so
        # iterating only the ones that exist is the same set of reads.
        while IFS= read -r _wdir; do
            read_matching "$_wdir" "ssl_access_log" "$1"
        done < <(qa_web_log_dirs)
        ;;

    admin-login-failures)
        [ $# -eq 1 ] || die "usage: admin-login-failures <cookie_path>"
        v_cookie_path "$1"
        # error_log has non-auth lines mentioning this same path too (a
        # missing static asset logs an [core:error] AH00035 permission-denied
        # line, for instance) -- filter on the auth_basic module tag AND the
        # cookie path, not the path alone, or those show up as false
        # "login failures". mod_auth_basic logs a failed attempt's URI
        # unquoted (AH01618: "user not found") or quoted (AH01617:
        # "authentication failure"); grep on the bare path, without the
        # quote, matches both shapes.
        while IFS= read -r _wdir; do
            read_matching "$_wdir" "ssl_error_log" "auth_basic:error" "$1"
            # Debian's default-ssl.conf shares the plain vhost's error.log
            # (no ssl_error_log rename exists for ErrorLog, unlike CustomLog)
            read_matching "$_wdir" "error.log" "auth_basic:error" "$1"
        done < <(qa_web_log_dirs)
        ;;

    mail-auth-failures)
        [ $# -eq 0 ] || die "usage: mail-auth-failures"
        # 10-logging.conf sets log_path = /var/log/dovecotlog on this host;
        # stock Dovecot defaults to /var/log/dovecot.log. qa_dovecot_logs()
        # asks doveconf for the configured log_path first and only falls back
        # to those two names, so a host that logs somewhere else entirely is
        # now read correctly instead of silently reporting no auth failures.
        while IFS= read -r _dlog; do
            read_matching "$(dirname "$_dlog")" "$(basename "$_dlog")" "auth failed"
        done < <(qa_dovecot_logs)
        ;;

    mail-auth-success)
        [ $# -eq 0 ] || die "usage: mail-auth-success"
        # Successful IMAP/POP3 logins. Unlike the failure case above, this
        # line is emitted by the login process itself, not gated by
        # auth_verbose (that only controls the auth worker's failure-reason
        # detail) -- so it's present in the same file with no Dovecot config
        # change needed. Same qa_dovecot_logs() source as above.
        #
        # rip=127.0.0.1 is filtered out HERE, not left for the PHP side --
        # Roundcube's own backend connection (always loopback,
        # mail_auth_successes() drops these unconditionally, same as
        # mail_auth_failures() does) reconnects on every webmail session. A
        # real direct IMAP/POP3 client (Thunderbird, a phone) never connects
        # via 127.0.0.1, so this can't drop anything the failure-side
        # equivalent would keep.
        #
        # tail -n 2500 caps the OUTPUT here, unlike every other subcommand
        # in this script. Confirmed live: unlike failures (rare events),
        # every successful poll from every mailbox logs its own line -- this
        # was 25,000+ matching lines/8 days even after the loopback filter
        # above, and no caller needs more than 2000 (the CSV export's own
        # cap). Parsing the unbounded set made a single PHP-side call take
        # ~500ms; nothing upstream of this point uses fewer than 8 days
        # (mail-auth-failures shares the same bound and stays cheap because
        # failures are rare), so the cap belongs here, not in collect()'s
        # shared -mtime -8 window which every other subcommand still needs.
        while IFS= read -r _dlog; do
            read_matching "$(dirname "$_dlog")" "$(basename "$_dlog")" "Login:" \
                | grep -v ' rip=127\.0\.0\.1,\| rip=::1,'
        done < <(qa_dovecot_logs) | tail -n 2500
        ;;

    *)
        die "usage: qa-audit-log.sh {admin-logins|admin-login-failures|mail-auth-failures|mail-auth-success} [args]"
        ;;
esac
exit 0
