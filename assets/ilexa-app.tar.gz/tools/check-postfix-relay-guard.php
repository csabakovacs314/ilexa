#!/usr/bin/env php
<?php
// Relay-control guard for the Postfix restriction-chain editor.
//
// THE BUG CLASS THIS EXISTS FOR. `permit` is in the editor's safe vocabulary,
// and nothing used to check that reject_unauth_destination survived a save.
// Saving smtpd_relay_restrictions = `permit` next to a recipient chain without
// reject_unauth_destination makes an open relay -- or, if neither chain has
// one, an smtpd that refuses to start ("specify at least one working instance
// of reject_unauth_destination ..."): a mail outage. `postfix check` catches
// neither, so the old check-then-reload sequence waved both through.
//
// The rule lives twice -- postfix_relay_guard() in src/postfix.php (for a
// translated UI message) and _restriction_guard in install/qa-postfix-config.sh
// (authoritative: the privilege boundary). Section 1 runs ONE case table
// against both, so they cannot drift apart silently.
//
// Section 2 runs the helper's set-restriction verb end to end with PATH holding
// ONLY stubs for postconf/postfix/systemctl (plus sed and flock): the real
// binaries are unreachable, which is checked before anything runs. Nothing here
// needs root, and nothing touches real Postfix config. Safe on production.
//
//   tools/check-postfix-relay-guard.php [--quiet]

$root   = dirname(__DIR__);
$quiet  = in_array('--quiet', $argv, true);
$helper = "$root/install/qa-postfix-config.sh";

// Hungarian is the source language, so identity is what t() returns there.
if (!function_exists('t')) { function t(string $s): string { return $s; } }
// src/postfix.php is loaded WITHOUT bootstrap: SUDO=':' turns every command it
// could build into a shell no-op, and helper READS go to this fixture instead.
define('SUDO', ':');
$fake_chains = [];
$sudo_reads  = [];
function qa_sudo_read(string $cmd, string $label, ?bool &$ok = null, array $ok_codes = [0]): string {
    global $fake_chains, $sudo_reads;
    $sudo_reads[] = $cmd;
    $ok = true;
    return preg_match("/ get-restriction '(\\w+)'\$/", $cmd, $m) ? json_encode($fake_chains[$m[1]] ?? []) : '';
}
require "$root/src/postfix.php";

$failures = [];
$passed   = 0;

function ok(string $what, bool $cond): void {
    global $failures, $passed, $quiet;
    if ($cond) { $passed++; if (!$quiet) echo "  ok   $what\n"; return; }
    $failures[] = $what;
    echo "  FAIL $what\n";
}

// ---- stub environment ------------------------------------------------------
$tmp = sys_get_temp_dir() . '/qa-relay-guard-test-' . getmypid();
$bin = "$tmp/bin";
if (!@mkdir("$tmp/values", 0700, true) || !@mkdir($bin, 0700)) {
    fwrite(STDERR, "check-postfix-relay-guard: cannot create $tmp\n");
    exit(1);
}
register_shutdown_function(function () use ($tmp) {
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($tmp, FilesystemIterator::SKIP_DOTS),
                                        RecursiveIteratorIterator::CHILD_FIRST);
    foreach ($it as $f) { $f->isDir() && !$f->isLink() ? @rmdir((string) $f) : @unlink((string) $f); }
    @rmdir($tmp);
});

// One stub, three names. Builtins only -- PATH holds nothing else to call.
// Records every invocation; answers `postconf -h NAME` from values/NAME;
// `postfix check` fails while the file check_fails exists.
file_put_contents("$bin/stub", <<<'SH'
#!/bin/bash
printf '%s\n' "${0##*/} $*" >> "$STUB_DIR/calls"
case "${0##*/}" in
  postconf)
    if [ "${1:-}" = -h ]; then
      [ -f "$STUB_DIR/values/$2" ] && printf '%s\n' "$(<"$STUB_DIR/values/$2")"
    fi
    exit 0 ;;
  postfix)
    [ -e "$STUB_DIR/check_fails" ] && { echo "postfix/postfix-script: fatal: stub check failure"; exit 1; }
    exit 0 ;;
esac
exit 0
SH);
chmod("$bin/stub", 0700);
foreach (['postconf', 'postfix', 'systemctl'] as $n) symlink("$bin/stub", "$bin/$n");
foreach (['sed', 'flock'] as $n) {
    $real = trim((string) shell_exec('command -v ' . escapeshellarg($n)));
    if ($real === '' || !symlink($real, "$bin/$n")) {
        fwrite(STDERR, "check-postfix-relay-guard: $n not found\n");
        exit(1);
    }
}
$env = ['PATH' => $bin, 'STUB_DIR' => $tmp, 'LC_ALL' => 'C'];

// Refuse to go on unless every name the helper could write config through
// resolves to a stub. This is the line that makes running it here safe.
$resolved = run(['/bin/bash', '-c', 'command -v postconf postfix systemctl'], '', $env)[1];
$want     = "$bin/postconf\n$bin/postfix\n$bin/systemctl";
if (trim($resolved) !== $want) {
    fwrite(STDERR, "check-postfix-relay-guard: stub PATH does not shadow the real binaries:\n$resolved\n");
    exit(1);
}

// [rc, combined stdout+stderr]
function run(array $cmd, string $stdin, array $env): array {
    $p = proc_open($cmd, [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['redirect', 1]], $pipes, null, $env);
    if (!is_resource($p)) return [-1, 'proc_open failed'];
    fwrite($pipes[0], $stdin);
    fclose($pipes[0]);
    $out = (string) stream_get_contents($pipes[1]);
    fclose($pipes[1]);
    return [proc_close($p), $out];
}
function calls(): string { global $tmp; return (string) @file_get_contents("$tmp/calls"); }
function reset_calls(): void { global $tmp; @unlink("$tmp/calls"); }
function set_value(string $name, ?string $v): void {
    global $tmp;
    if ($v === null) @unlink("$tmp/values/$name"); else file_put_contents("$tmp/values/$name", $v);
}
// The console's own parse of a postconf value (get-restriction): comma-split, trimmed.
function entries(string $v): array {
    return array_values(array_filter(array_map('trim', explode(',', $v)), fn($t) => $t !== ''));
}
// The helper's pure guard, by SOURCING the helper (it returns before its
// dispatch when sourced). null = allowed, else the refusal text.
function sh_guard(string $dir, string $partner, array $proposed): ?string {
    global $helper, $env;
    [$rc, $out] = run(['/bin/bash', '-c', 'source "$1" || exit 99; shift; _restriction_guard "$@"',
                       'guard-test', $helper, $dir, $partner, ...$proposed], '', $env);
    if ($rc === 99) return 'SOURCE FAILED';
    return $rc === 0 ? null : (trim($out) ?: "rc=$rc");
}

// ---- 1. one case table, both implementations -------------------------------
const RELAY = 'smtpd_relay_restrictions';
const RCPT  = 'smtpd_recipient_restrictions';

// The installer's default chains (templates/postfix/main.cf.tmpl, as postconf -h prints them).
$def_relay  = 'permit_mynetworks, permit_sasl_authenticated, reject_unauth_destination';
$def_rcpt   = 'check_recipient_access hash:/etc/postfix/report_auth, permit_mynetworks, permit_sasl_authenticated, '
            . 'reject_unauth_destination, check_policy_service { inet:127.0.0.1:10023, default_action=DUNNO }';
$rcpt_noctl = 'permit_mynetworks, permit_sasl_authenticated, check_policy_service { inet:127.0.0.1:10023, default_action=DUNNO }';
$def_client = 'permit_mynetworks, permit_sasl_authenticated, check_client_access hash:/etc/postfix/access_client, '
            . 'reject_invalid_hostname, check_policy_service unix:private/policy, permit';
$def_helo   = 'permit_mynetworks, permit_sasl_authenticated, reject_unauth_pipelining, '
            . 'check_helo_access hash:/etc/postfix/helo_access, reject_invalid_hostname, warn_if_reject reject_unknown_hostname, permit';

// [label, dir, proposed entries, partner's CURRENT raw value, expect allowed]
$cases = [
    ['relay=permit, recipient has reject_unauth_destination',      RELAY, ['permit'], $def_rcpt, true],
    ['relay without control, recipient has it',                    RELAY, ['permit_mynetworks', 'permit_sasl_authenticated', 'permit'], $def_rcpt, true],
    ['relay=permit, recipient lacks a control',                    RELAY, ['permit'], $rcpt_noctl, false],
    ['recipient without control, relay lacks one too',             RCPT,  entries($rcpt_noctl), 'permit_mynetworks, permit', false],
    ['recipient without control, relay has it',                    RCPT,  entries($rcpt_noctl), $def_relay, true],
    ['permit before reject_unauth_destination in proposed chain',  RELAY, ['permit_mynetworks', 'permit', 'reject_unauth_destination'], $rcpt_noctl, false],
    ['permit before reject_unauth_destination in partner chain',   RELAY, ['permit_mynetworks', 'permit'], 'permit_mynetworks, permit, reject_unauth_destination', false],
    ['permit not last in client chain',                            'smtpd_client_restrictions', ['permit_mynetworks', 'permit', 'reject_unauth_pipelining'], '', false],
    ['permit not last in helo chain',                              'smtpd_helo_restrictions', ['permit', 'reject_invalid_hostname'], '', false],
    ['permit last in client chain',                                'smtpd_client_restrictions', ['reject_unauth_pipelining', 'permit'], '', true],
    ['two permits (first is not last)',                            'smtpd_helo_restrictions', ['permit', 'permit'], '', false],
    ['permit inside a multi-word entry, not last',                 'smtpd_helo_restrictions', ['permit reject_invalid_hostname'], '', false],
    ['reordered safe relay tokens, partner lacks control',         RELAY, ['permit_sasl_authenticated', 'permit_mynetworks', 'reject_unauth_destination'], $rcpt_noctl, true],
    ['reordered safe recipient tokens, relay=permit',              RCPT,  ['reject_non_fqdn_recipient', 'permit_sasl_authenticated', 'permit_mynetworks', 'reject_unauth_destination'], 'permit', true],
    ['defer_unauth_destination in partner counts',                 RCPT,  ['permit_mynetworks', 'permit'], 'permit_mynetworks, permit_sasl_authenticated, defer_unauth_destination', true],
    ['bare reject in partner counts',                              RELAY, ['permit'], 'permit_mynetworks, reject', true],
    ['bare defer in proposed counts',                              RCPT,  ['permit_mynetworks', 'defer'], 'permit', true],
    ['warn_if_reject reject_unauth_destination does not count',    RELAY, ['permit_mynetworks', 'warn_if_reject reject_unauth_destination'], $rcpt_noctl, false],
    ['... nor as two separate entries',                            RELAY, ['permit_mynetworks', 'warn_if_reject', 'reject_unauth_destination'], $rcpt_noctl, false],
    // Postfix keeps the warn flag across consecutive warn_if_reject entries
    // (2026-10-14 review): the second one must not be consumed as "the
    // skipped word" and leave the control after it counted as working.
    ['two warn_if_reject in a row still only warn',                RELAY, ['permit_mynetworks', 'warn_if_reject', 'warn_if_reject', 'reject_unauth_destination'], $rcpt_noctl, false],
    ['... nor as one entry',                                       RELAY, ['permit_mynetworks', 'warn_if_reject warn_if_reject reject_unauth_destination'], $rcpt_noctl, false],
    ['a control after the warned one does count',                  RELAY, ['permit_mynetworks', 'warn_if_reject', 'reject_unknown_hostname', 'reject_unauth_destination'], $rcpt_noctl, true],
    ['a control inside a { } group does not count',                RELAY, ['permit'], 'permit_mynetworks, check_policy_service { inet:127.0.0.1:10023, default_action = reject }', false],
    ['whitespace-separated partner chain is read like Postfix',    RELAY, ['permit'], 'permit_mynetworks permit_sasl_authenticated reject_unauth_destination', true],
    ['unreadable partner (empty) fails closed',                    RELAY, ['permit_mynetworks', 'permit'], '', false],
    ['unreadable partner, proposed chain safe on its own',         RELAY, entries($def_relay), '', true],
    ['unexpanded default relay expression is not trusted',         RCPT,  ['permit_mynetworks', 'permit'],
        '${{$compatibility_level} <level {1} ? {} : {permit_mynetworks, permit_sasl_authenticated, defer_unauth_destination}}', false],
    ['installer default relay chain re-saved unchanged',           RELAY, entries($def_relay), $def_rcpt, true],
    ['installer default recipient chain re-saved unchanged',       RCPT,  entries($def_rcpt), $def_relay, true],
    ['installer default client chain re-saved unchanged',          'smtpd_client_restrictions', entries($def_client), '', true],
    ['installer default helo chain re-saved unchanged',            'smtpd_helo_restrictions', entries($def_helo), '', true],
];

if (!$quiet) echo "1. guard case table (php | helper)\n";
reset_calls();
foreach ($cases as [$label, $dir, $proposed, $partner, $allow]) {
    $php = postfix_relay_guard($dir, $proposed, entries($partner));
    $sh  = sh_guard($dir, $partner, $proposed);
    $want = $allow ? 'allowed' : 'refused';
    ok("php    $want: $label", ($php === null) === $allow);
    ok("helper $want: $label", ($sh === null) === $allow);
}
ok('helper guard is pure (no postconf/postfix/systemctl call while sourced)', calls() === '');

$m = postfix_relay_guard('smtpd_helo_restrictions', ['permit', 'reject_invalid_hostname'], []);
ok('php: permit-not-last message names permit', is_string($m) && str_contains($m, '„permit”'));
$m = postfix_relay_guard(RELAY, ['permit'], []);
ok('php: relay message names reject_unauth_destination', is_string($m) && str_contains($m, 'reject_unauth_destination'));

// Pre-existing behaviour, reached before any shell-out.
ok('php: empty list still refused', postfix_restriction_save(RELAY, []) === [false, 'A lista nem lehet üres.']);
ok('php: blank-only list still refused', postfix_restriction_save(RELAY, ['  ', '']) === [false, 'A lista nem lehet üres.']);
ok('php: unknown directive still refused', postfix_restriction_save('smtpd_data_restrictions', ['permit'])[0] === false);

// The guard is actually wired into postfix_restriction_save(). An allowed save
// reaches the (no-op) set-restriction call and comes back "Nincs kimenet.".
$fake_chains = [RELAY => entries($def_relay), RCPT => entries($rcpt_noctl)];
$sudo_reads  = [];
$r = postfix_restriction_save(RELAY, ['permit']);
ok('php save: refused when partner lacks a control', $r[0] === false && str_contains($r[1], 'reject_unauth_destination'));
ok('php save: partner chain was read', (bool) preg_grep('/get-restriction \'' . RCPT . '\'$/', $sudo_reads));
$fake_chains[RCPT] = entries($def_rcpt);
ok('php save: allowed when partner has one', postfix_restriction_save(RELAY, ['permit']) === [false, 'Nincs kimenet.']);
$fake_chains['smtpd_helo_restrictions'] = entries($def_helo);
$sudo_reads = [];
$r = postfix_restriction_save('smtpd_helo_restrictions', ['permit', 'reject_invalid_hostname']);
ok('php save: permit not last refused', $r[0] === false && str_contains($r[1], '„permit”'));
ok('php save: helo save reads no partner', count($sudo_reads) === 1);

// ---- 2. set-restriction end to end, stubbed --------------------------------
if (!$quiet) echo "2. helper set-restriction, postconf/postfix/systemctl stubbed\n";
function set_restriction(string $dir, array $tokens): array {
    global $helper, $env;
    reset_calls();
    return run(['/bin/bash', $helper, 'set-restriction', $dir], implode("\n", $tokens), $env);
}
function wrote(): bool {
    return (bool) preg_match('/^(postconf -e|postfix check|systemctl)/m', calls());
}

set_value(RELAY, $def_relay);
set_value(RCPT, $def_rcpt);
[$rc, $out] = set_restriction(RELAY, ['permit']);
ok('accepts relay=permit while recipient has reject_unauth_destination', $rc === 0 && trim($out) === 'OK');
ok('... reads the partner chain', str_contains(calls(), 'postconf -h ' . RCPT . "\n"));
ok('... then write, postfix check, reload -- in that order, nothing else',
   substr(calls(), (int) strpos(calls(), 'postconf -e'))
   === 'postconf -e ' . RELAY . "=permit\npostfix check\nsystemctl reload postfix\n");

set_value(RCPT, $rcpt_noctl);
[$rc, $out] = set_restriction(RELAY, ['permit_mynetworks', 'permit']);
ok('refuses relay without control when recipient lacks one too', $rc !== 0 && str_contains($out, 'refused'));
ok('... and writes nothing', !wrote());

set_value(RCPT, null);
[$rc, $out] = set_restriction(RELAY, ['permit_mynetworks', 'permit']);
ok('refuses when the partner chain cannot be read (fail closed)', $rc !== 0 && !wrote());

set_value('smtpd_client_restrictions', $def_client);
[$rc, $out] = set_restriction('smtpd_client_restrictions', ['permit_mynetworks', 'permit', 'reject_unauth_pipelining']);
ok('refuses permit not last in client chain', $rc !== 0 && str_contains($out, "'permit' must be the last"));
ok('... and writes nothing', !wrote());

[$rc, $out] = set_restriction(RELAY, []);
ok('refuses an empty list (existing)', $rc !== 0 && str_contains($out, 'cannot be empty') && !wrote());

set_value(RCPT, $def_rcpt);
[$rc, $out] = set_restriction(RELAY, ['permit_mynetworks', 'reject']);
ok('vocabulary rule unchanged: unknown token refused', $rc !== 0 && str_contains($out, 'token not permitted') && !wrote());

[$rc, $out] = set_restriction(RELAY, ['permit_sasl_authenticated', 'permit_mynetworks', 'reject_unauth_destination']);
ok('accepts reordered safe tokens', $rc === 0 && trim($out) === 'OK');

touch("$tmp/check_fails");
[$rc, $out] = set_restriction(RELAY, ['permit_sasl_authenticated', 'permit_mynetworks', 'reject_unauth_destination']);
ok('failed postfix check still rolls back and never reloads',
   $rc !== 0 && str_contains($out, 'rolled back')
   && str_contains(calls(), 'postconf -e ' . RELAY . '=' . $def_relay)
   && !str_contains(calls(), 'systemctl'));
@unlink("$tmp/check_fails");

if (!$quiet || $failures) {
    echo "\ncheck-postfix-relay-guard: $passed passed, " . count($failures) . " failed\n";
}
exit($failures ? 1 : 0);
