#!/usr/bin/env php
<?php
// Relay-control guard for the Postfix restriction-chain editor.
//
// THE BUG CLASS THIS EXISTS FOR. `permit` is in the editor's safe vocabulary,
// and nothing used to check that reject_unauth_destination survived a save.
// Saving smtpd_relay_restrictions = `permit` next to a recipient chain without
// reject_unauth_destination makes an open relay -- or, if neither chain has
// one, an smtpd that refuses to start ("specify at least one working instance
// of reject_unauth_destination ..."): a mail outage. `postfix check` catches
// neither, so the old check-then-reload sequence waved both through.
//
// The rule lives twice -- postfix_relay_guard() in src/postfix.php (for a
// translated UI message) and _restriction_guard in install/qa-postfix-config.sh
// (authoritative: the privilege boundary). Section 1 runs ONE case table
// against both, so they cannot drift apart silently.
//
// Section 2 runs the helper's set-restriction verb end to end with PATH holding
// ONLY stubs for postconf/postfix/systemctl (plus sed and flock): the real
// binaries are unreachable, which is checked before anything runs. Nothing here
// needs root, and nothing touches real Postfix config. Safe on production.
//
// Sections 3 and 4 do the same for the network card (mynetworks,
// relay_domains): postfix_setting_guard() against the helper's _setting_guard,
// then the helper's `set` verb end to end. Those two settings are an open relay
// the chains cannot see -- permit_mynetworks trusts all of mynetworks, and
// reject_unauth_destination passes every domain relay_domains matches.
//
//   tools/check-postfix-relay-guard.php [--quiet]

$root   = dirname(__DIR__);
$quiet  = in_array('--quiet', $argv, true);
$helper = "$root/install/qa-postfix-config.sh";

// Hungarian is the source language, so identity is what t() returns there.
if (!function_exists('t')) { function t(string $s): string { return $s; } }
// src/postfix.php is loaded WITHOUT bootstrap: SUDO=':' turns every command it
// could build into a shell no-op, and helper READS go to this fixture instead.
define('SUDO', ':');
$fake_chains = [];
$fake_values = [];
$sudo_reads  = [];
function qa_sudo_read(string $cmd, string $label, ?bool &$ok = null, array $ok_codes = [0]): string {
    global $fake_chains, $fake_values, $sudo_reads;
    $sudo_reads[] = $cmd;
    $ok = true;
    if (preg_match("/ get '(\\w+)'\$/", $cmd, $m)) return ($fake_values[$m[1]] ?? '') . "\n";
    return preg_match("/ get-restriction '(\\w+)'\$/", $cmd, $m) ? json_encode($fake_chains[$m[1]] ?? []) : '';
}
require "$root/src/postfix.php";

$failures = [];
$passed   = 0;

function ok(string $what, bool $cond): void {
    global $failures, $passed, $quiet;
    if ($cond) { $passed++; if (!$quiet) echo "  ok   $what\n"; return; }
    $failures[] = $what;
    echo "  FAIL $what\n";
}

// ---- stub environment ------------------------------------------------------
$tmp = sys_get_temp_dir() . '/qa-relay-guard-test-' . getmypid();
$bin = "$tmp/bin";
if (!@mkdir("$tmp/values", 0700, true) || !@mkdir($bin, 0700)) {
    fwrite(STDERR, "check-postfix-relay-guard: cannot create $tmp\n");
    exit(1);
}
register_shutdown_function(function () use ($tmp) {
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($tmp, FilesystemIterator::SKIP_DOTS),
                                        RecursiveIteratorIterator::CHILD_FIRST);
    foreach ($it as $f) { $f->isDir() && !$f->isLink() ? @rmdir((string) $f) : @unlink((string) $f); }
    @rmdir($tmp);
});

// One stub, three names. Builtins only -- PATH holds nothing else to call.
// Records every invocation; answers `postconf -h NAME` from values/NAME;
// `postfix check` fails while the file check_fails exists.
file_put_contents("$bin/stub", <<<'SH'
#!/bin/bash
printf '%s\n' "${0##*/} $*" >> "$STUB_DIR/calls"
case "${0##*/}" in
  postconf)
    if [ "${1:-}" = -h ]; then
      [ -f "$STUB_DIR/values/$2" ] && printf '%s\n' "$(<"$STUB_DIR/values/$2")"
    fi
    exit 0 ;;
  postfix)
    [ -e "$STUB_DIR/check_fails" ] && { echo "postfix/postfix-script: fatal: stub check failure"; exit 1; }
    exit 0 ;;
esac
exit 0
SH);
chmod("$bin/stub", 0700);
foreach (['postconf', 'postfix', 'systemctl'] as $n) symlink("$bin/stub", "$bin/$n");
foreach (['sed', 'flock'] as $n) {
    $real = trim((string) shell_exec('command -v ' . escapeshellarg($n)));
    if ($real === '' || !symlink($real, "$bin/$n")) {
        fwrite(STDERR, "check-postfix-relay-guard: $n not found\n");
        exit(1);
    }
}
$env = ['PATH' => $bin, 'STUB_DIR' => $tmp, 'LC_ALL' => 'C'];

// Refuse to go on unless every name the helper could write config through
// resolves to a stub. This is the line that makes running it here safe.
$resolved = run(['/bin/bash', '-c', 'command -v postconf postfix systemctl'], '', $env)[1];
$want     = "$bin/postconf\n$bin/postfix\n$bin/systemctl";
if (trim($resolved) !== $want) {
    fwrite(STDERR, "check-postfix-relay-guard: stub PATH does not shadow the real binaries:\n$resolved\n");
    exit(1);
}

// [rc, combined stdout+stderr]
function run(array $cmd, string $stdin, array $env): array {
    $p = proc_open($cmd, [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['redirect', 1]], $pipes, null, $env);
    if (!is_resource($p)) return [-1, 'proc_open failed'];
    fwrite($pipes[0], $stdin);
    fclose($pipes[0]);
    $out = (string) stream_get_contents($pipes[1]);
    fclose($pipes[1]);
    return [proc_close($p), $out];
}
function calls(): string { global $tmp; return (string) @file_get_contents("$tmp/calls"); }
function reset_calls(): void { global $tmp; @unlink("$tmp/calls"); }
function set_value(string $name, ?string $v): void {
    global $tmp;
    if ($v === null) @unlink("$tmp/values/$name"); else file_put_contents("$tmp/values/$name", $v);
}
// The console's own parse of a postconf value (get-restriction): comma-split, trimmed.
function entries(string $v): array {
    return array_values(array_filter(array_map('trim', explode(',', $v)), fn($t) => $t !== ''));
}
// The helper's pure guard, by SOURCING the helper (it returns before its
// dispatch when sourced). null = allowed, else the refusal text.
function sh_guard(string $dir, string $partner, array $proposed): ?string {
    global $helper, $env;
    [$rc, $out] = run(['/bin/bash', '-c', 'source "$1" || exit 99; shift; _restriction_guard "$@"',
                       'guard-test', $helper, $dir, $partner, ...$proposed], '', $env);
    if ($rc === 99) return 'SOURCE FAILED';
    return $rc === 0 ? null : (trim($out) ?: "rc=$rc");
}

// ---- 1. one case table, both implementations -------------------------------
const RELAY = 'smtpd_relay_restrictions';
const RCPT  = 'smtpd_recipient_restrictions';

// The installer's default chains (templates/postfix/main.cf.tmpl, as postconf -h prints them).
$def_relay  = 'permit_mynetworks, permit_sasl_authenticated, reject_unauth_destination';
$def_rcpt   = 'check_recipient_access hash:/etc/postfix/report_auth, permit_mynetworks, permit_sasl_authenticated, '
            . 'reject_unauth_destination, check_policy_service { inet:127.0.0.1:10023, default_action=DUNNO }';
$rcpt_noctl = 'permit_mynetworks, permit_sasl_authenticated, check_policy_service { inet:127.0.0.1:10023, default_action=DUNNO }';
$def_client = 'permit_mynetworks, permit_sasl_authenticated, check_client_access hash:/etc/postfix/access_client, '
            . 'reject_invalid_hostname, check_policy_service unix:private/policy, permit';
$def_helo   = 'permit_mynetworks, permit_sasl_authenticated, reject_unauth_pipelining, '
            . 'check_helo_access hash:/etc/postfix/helo_access, reject_invalid_hostname, warn_if_reject reject_unknown_hostname, permit';

// [label, dir, proposed entries, partner's CURRENT raw value, expect allowed]
$cases = [
    ['relay=permit, recipient has reject_unauth_destination',      RELAY, ['permit'], $def_rcpt, true],
    ['relay without control, recipient has it',                    RELAY, ['permit_mynetworks', 'permit_sasl_authenticated', 'permit'], $def_rcpt, true],
    ['relay=permit, recipient lacks a control',                    RELAY, ['permit'], $rcpt_noctl, false],
    ['recipient without control, relay lacks one too',             RCPT,  entries($rcpt_noctl), 'permit_mynetworks, permit', false],
    ['recipient without control, relay has it',                    RCPT,  entries($rcpt_noctl), $def_relay, true],
    ['permit before reject_unauth_destination in proposed chain',  RELAY, ['permit_mynetworks', 'permit', 'reject_unauth_destination'], $rcpt_noctl, false],
    ['permit before reject_unauth_destination in partner chain',   RELAY, ['permit_mynetworks', 'permit'], 'permit_mynetworks, permit, reject_unauth_destination', false],
    ['permit not last in client chain',                            'smtpd_client_restrictions', ['permit_mynetworks', 'permit', 'reject_unauth_pipelining'], '', false],
    ['permit not last in helo chain',                              'smtpd_helo_restrictions', ['permit', 'reject_invalid_hostname'], '', false],
    ['permit last in client chain',                                'smtpd_client_restrictions', ['reject_unauth_pipelining', 'permit'], '', true],
    ['two permits (first is not last)',                            'smtpd_helo_restrictions', ['permit', 'permit'], '', false],
    ['permit inside a multi-word entry, not last',                 'smtpd_helo_restrictions', ['permit reject_invalid_hostname'], '', false],
    ['reordered safe relay tokens, partner lacks control',         RELAY, ['permit_sasl_authenticated', 'permit_mynetworks', 'reject_unauth_destination'], $rcpt_noctl, true],
    ['reordered safe recipient tokens, relay=permit',              RCPT,  ['reject_non_fqdn_recipient', 'permit_sasl_authenticated', 'permit_mynetworks', 'reject_unauth_destination'], 'permit', true],
    ['defer_unauth_destination in partner counts',                 RCPT,  ['permit_mynetworks', 'permit'], 'permit_mynetworks, permit_sasl_authenticated, defer_unauth_destination', true],
    ['bare reject in partner counts',                              RELAY, ['permit'], 'permit_mynetworks, reject', true],
    ['bare defer in proposed counts',                              RCPT,  ['permit_mynetworks', 'defer'], 'permit', true],
    ['warn_if_reject reject_unauth_destination does not count',    RELAY, ['permit_mynetworks', 'warn_if_reject reject_unauth_destination'], $rcpt_noctl, false],
    ['... nor as two separate entries',                            RELAY, ['permit_mynetworks', 'warn_if_reject', 'reject_unauth_destination'], $rcpt_noctl, false],
    // Postfix keeps the warn flag across consecutive warn_if_reject entries
    // (2026-10-14 review): the second one must not be consumed as "the
    // skipped word" and leave the control after it counted as working.
    ['two warn_if_reject in a row still only warn',                RELAY, ['permit_mynetworks', 'warn_if_reject', 'warn_if_reject', 'reject_unauth_destination'], $rcpt_noctl, false],
    ['... nor as one entry',                                       RELAY, ['permit_mynetworks', 'warn_if_reject warn_if_reject reject_unauth_destination'], $rcpt_noctl, false],
    ['a control after the warned one does count',                  RELAY, ['permit_mynetworks', 'warn_if_reject', 'reject_unknown_hostname', 'reject_unauth_destination'], $rcpt_noctl, true],
    ['a control inside a { } group does not count',                RELAY, ['permit'], 'permit_mynetworks, check_policy_service { inet:127.0.0.1:10023, default_action = reject }', false],
    ['whitespace-separated partner chain is read like Postfix',    RELAY, ['permit'], 'permit_mynetworks permit_sasl_authenticated reject_unauth_destination', true],
    ['unreadable partner (empty) fails closed',                    RELAY, ['permit_mynetworks', 'permit'], '', false],
    ['unreadable partner, proposed chain safe on its own',         RELAY, entries($def_relay), '', true],
    ['unexpanded default relay expression is not trusted',         RCPT,  ['permit_mynetworks', 'permit'],
        '${{$compatibility_level} <level {1} ? {} : {permit_mynetworks, permit_sasl_authenticated, defer_unauth_destination}}', false],
    ['installer default relay chain re-saved unchanged',           RELAY, entries($def_relay), $def_rcpt, true],
    ['installer default recipient chain re-saved unchanged',       RCPT,  entries($def_rcpt), $def_relay, true],
    ['installer default client chain re-saved unchanged',          'smtpd_client_restrictions', entries($def_client), '', true],
    ['installer default helo chain re-saved unchanged',            'smtpd_helo_restrictions', entries($def_helo), '', true],
];

if (!$quiet) echo "1. guard case table (php | helper)\n";
reset_calls();
foreach ($cases as [$label, $dir, $proposed, $partner, $allow]) {
    $php = postfix_relay_guard($dir, $proposed, entries($partner));
    $sh  = sh_guard($dir, $partner, $proposed);
    $want = $allow ? 'allowed' : 'refused';
    ok("php    $want: $label", ($php === null) === $allow);
    ok("helper $want: $label", ($sh === null) === $allow);
}
ok('helper guard is pure (no postconf/postfix/systemctl call while sourced)', calls() === '');

$m = postfix_relay_guard('smtpd_helo_restrictions', ['permit', 'reject_invalid_hostname'], []);
ok('php: permit-not-last message names permit', is_string($m) && str_contains($m, '„permit”'));
$m = postfix_relay_guard(RELAY, ['permit'], []);
ok('php: relay message names reject_unauth_destination', is_string($m) && str_contains($m, 'reject_unauth_destination'));

// Pre-existing behaviour, reached before any shell-out.
ok('php: empty list still refused', postfix_restriction_save(RELAY, []) === [false, 'A lista nem lehet üres.']);
ok('php: blank-only list still refused', postfix_restriction_save(RELAY, ['  ', '']) === [false, 'A lista nem lehet üres.']);
ok('php: unknown directive still refused', postfix_restriction_save('smtpd_data_restrictions', ['permit'])[0] === false);

// The guard is actually wired into postfix_restriction_save(). An allowed save
// reaches the (no-op) set-restriction call and comes back "Nincs kimenet.".
$fake_chains = [RELAY => entries($def_relay), RCPT => entries($rcpt_noctl)];
$sudo_reads  = [];
$r = postfix_restriction_save(RELAY, ['permit']);
ok('php save: refused when partner lacks a control', $r[0] === false && str_contains($r[1], 'reject_unauth_destination'));
ok('php save: partner chain was read', (bool) preg_grep('/get-restriction \'' . RCPT . '\'$/', $sudo_reads));
$fake_chains[RCPT] = entries($def_rcpt);
ok('php save: allowed when partner has one', postfix_restriction_save(RELAY, ['permit']) === [false, 'Nincs kimenet.']);
$fake_chains['smtpd_helo_restrictions'] = entries($def_helo);
$sudo_reads = [];
$r = postfix_restriction_save('smtpd_helo_restrictions', ['permit', 'reject_invalid_hostname']);
ok('php save: permit not last refused', $r[0] === false && str_contains($r[1], '„permit”'));
ok('php save: helo save reads no partner', count($sudo_reads) === 1);

// ---- 2. set-restriction end to end, stubbed --------------------------------
if (!$quiet) echo "2. helper set-restriction, postconf/postfix/systemctl stubbed\n";
function set_restriction(string $dir, array $tokens): array {
    global $helper, $env;
    reset_calls();
    return run(['/bin/bash', $helper, 'set-restriction', $dir], implode("\n", $tokens), $env);
}
function wrote(): bool {
    return (bool) preg_match('/^(postconf -e|postfix check|systemctl)/m', calls());
}

set_value(RELAY, $def_relay);
set_value(RCPT, $def_rcpt);
[$rc, $out] = set_restriction(RELAY, ['permit']);
ok('accepts relay=permit while recipient has reject_unauth_destination', $rc === 0 && trim($out) === 'OK');
ok('... reads the partner chain', str_contains(calls(), 'postconf -h ' . RCPT . "\n"));
ok('... then write, postfix check, reload -- in that order, nothing else',
   substr(calls(), (int) strpos(calls(), 'postconf -e'))
   === 'postconf -e ' . RELAY . "=permit\npostfix check\nsystemctl reload postfix\n");

set_value(RCPT, $rcpt_noctl);
[$rc, $out] = set_restriction(RELAY, ['permit_mynetworks', 'permit']);
ok('refuses relay without control when recipient lacks one too', $rc !== 0 && str_contains($out, 'refused'));
ok('... and writes nothing', !wrote());

set_value(RCPT, null);
[$rc, $out] = set_restriction(RELAY, ['permit_mynetworks', 'permit']);
ok('refuses when the partner chain cannot be read (fail closed)', $rc !== 0 && !wrote());

set_value('smtpd_client_restrictions', $def_client);
[$rc, $out] = set_restriction('smtpd_client_restrictions', ['permit_mynetworks', 'permit', 'reject_unauth_pipelining']);
ok('refuses permit not last in client chain', $rc !== 0 && str_contains($out, "'permit' must be the last"));
ok('... and writes nothing', !wrote());

[$rc, $out] = set_restriction(RELAY, []);
ok('refuses an empty list (existing)', $rc !== 0 && str_contains($out, 'cannot be empty') && !wrote());

set_value(RCPT, $def_rcpt);
[$rc, $out] = set_restriction(RELAY, ['permit_mynetworks', 'reject']);
ok('vocabulary rule unchanged: unknown token refused', $rc !== 0 && str_contains($out, 'token not permitted') && !wrote());

[$rc, $out] = set_restriction(RELAY, ['permit_sasl_authenticated', 'permit_mynetworks', 'reject_unauth_destination']);
ok('accepts reordered safe tokens', $rc === 0 && trim($out) === 'OK');

touch("$tmp/check_fails");
[$rc, $out] = set_restriction(RELAY, ['permit_sasl_authenticated', 'permit_mynetworks', 'reject_unauth_destination']);
ok('failed postfix check still rolls back and never reloads',
   $rc !== 0 && str_contains($out, 'rolled back')
   && str_contains(calls(), 'postconf -e ' . RELAY . '=' . $def_relay)
   && !str_contains(calls(), 'systemctl'));
@unlink("$tmp/check_fails");

// ---- 3. network card: one case table, both implementations -----------------
if (!$quiet) echo "3. network-card guard (php | helper)\n";
// The helper's pure functions, by sourcing it. [rc, output]
function sh_call(string $fn, string ...$args): array {
    global $helper, $env;
    [$rc, $out] = run(['/bin/bash', '-c', 'source "$1" || exit 99; shift; fn="$1"; shift; "$fn" "$@"',
                       'guard-test', $helper, $fn, ...$args], '', $env);
    return [$rc, $out];
}
function sh_setting_guard(string $key, string $cur, string $val): ?string {
    [$rc, $out] = sh_call('_setting_guard', $key, $cur, $val);
    if ($rc === 99) return 'SOURCE FAILED';
    return $rc === 0 ? null : (trim($out) ?: "rc=$rc");
}
reset_calls();

// Address parsing: PHP uses inet_pton, the helper its own parser. They must
// agree on every address, valid or not, bit for bit.
$addrs = ['::', '::1', '1::', '1:2:3:4:5:6:7::', '::2:3:4:5:6:7:8', '2001:db8::ff00:42:8329', '::ffff:192.0.2.128',
          '1:2:3:4:5:6:1.2.3.4', 'fe80::1', 'FFFF:ffff:FFFF:ffff:ffff:ffff:ffff:ffff', '0:0:0:0:0:0:0:1',
          '1::2::3', ':1::2', '1::2:', '1:2:3:4:5:6:7:8:9', '12345::', '1:2:3:4:5:6:7', 'g::1', '::1.2.3',
          '1:2:3:4:5:6:7:1.2.3.4', '::ffff:256.1.1.1', '::ffff:01.2.3.4', ':::', '1:::2', ':', '::1.2.3.4:5'];
foreach ($addrs as $a) {
    $bin = @inet_pton($a);
    $php = '';
    if ($bin !== false && strlen($bin) === 16) foreach (str_split($bin) as $c) $php .= sprintf('%08b', ord($c));
    [$rc, $out] = sh_call('_ip6_bits', $a);
    ok("ipv6 parse agrees: $a" . ($php === '' ? ' (invalid)' : ''), ($rc === 0 ? $out : '') === $php);
}
foreach (['0.0.0.0', '255.255.255.255', '192.0.2.1', '256.0.0.1', '01.2.3.4', '1.2.3', '1.2.3.4.5', '1.02.3.4'] as $a) {
    $bin = @inet_pton($a);
    $php = '';
    if ($bin !== false && strlen($bin) === 4) foreach (str_split($bin) as $c) $php .= sprintf('%08b', ord($c));
    [$rc, $out] = sh_call('_ip4_bits', $a);
    ok("ipv4 parse agrees: $a" . ($php === '' ? ' (invalid)' : ''), ($rc === 0 ? $out : '') === $php);
}

// One mynetworks entry -> expected refusal code (null = allowed).
$mynet = [
    '127.0.0.0/8' => null, '[::1]/128' => null, '[::ffff:127.0.0.0]/104' => null, '[::1]' => null,
    '10.0.0.0/8' => null, '172.16.0.0/12' => null, '192.168.0.0/16' => null, '192.168.1.0/24' => null,
    '100.64.0.0/10' => null, '169.254.0.0/16' => null,
    '203.0.113.5' => null, '203.0.113.5/32' => null, '198.51.100.0/24' => null, '198.51.0.0/16' => null,
    '0.0.0.0/0' => 'too-broad', '0.0.0.0/1' => 'too-broad', '128.0.0.0/1' => 'too-broad',
    '8.0.0.0/8' => 'too-broad', '198.48.0.0/15' => 'too-broad', '10.0.0.0/7' => 'too-broad',
    '172.16.0.0/11' => 'host-bits', '10.1.2.3/8' => 'host-bits', '192.168.1.1/24' => 'host-bits',
    '999.1.1.1' => 'invalid', '1.2.3.4/33' => 'invalid', '010.0.0.1' => 'invalid', '1.2.3' => 'invalid',
    'example.com' => 'invalid', 'hash:/etc/postfix/mynetworks' => 'table', '/etc/postfix/mynetworks' => 'table',
    '!192.0.2.1' => 'table', 'cdb:/etc/postfix/mynet' => 'table',
    // Every bracketed spelling Postfix's cidr_match_parse accepts is judged as
    // an address (2026-10-16 review: [0.0.0.0]/0 and [::/0] were "not an
    // address" and so kept when already present).
    '[1.2.3.4]' => null, '[192.0.2.0]/24' => null, '[192.0.2.0/24]' => null, '[2001:db8::/48]' => null,
    '[0.0.0.0]/0' => 'too-broad', '[0.0.0.0/0]' => 'too-broad', '[::/0]' => 'too-broad', '[10.1.2.3/8]' => 'host-bits',
    '[1.2.3.4/33]' => 'invalid', '[1.2.3.4/24]/24' => 'invalid', '[01.2.3.4]' => 'invalid', '[]' => 'invalid',
    '::1/128' => 'ipv6-brackets', '2001:db8::/32' => 'ipv6-brackets', '::/0' => 'ipv6-brackets',
    '[2001:db8::]/48' => null, '[2001:DB8:1::]/48' => null, '[2001:db8::]/32' => 'too-broad',
    '[::]/0' => 'too-broad', '[2001:db8::1]/48' => 'host-bits', '[fc00::]/7' => null,
    '[fd12:3456:789a::]/48' => null, '[fe80::]/10' => null, '[fe80::]/9' => 'too-broad',
    '[::ffff:0:0]/96' => 'too-broad', '[::ffff:0.0.0.0]/96' => 'too-broad', '[::ffff:10.0.0.0]/104' => null,
    '[::ffff:203.0.113.0]/120' => null, '[::ffff:203.0.0.0]/104' => 'too-broad',
    '[::]/80' => 'all-ipv4', '[::]/64' => 'all-ipv4',
    '[64:ff9b::]/96' => 'too-broad', '[64:ff9b::c000:200]/120' => null,
    '[1:2:3:4:5:6:7::]/128' => null, '[::1.2.3.4]/128' => null,
    '[1::2::3]' => 'invalid', '[:1::2]' => 'invalid', '[12345::]' => 'invalid', '[::ffff:1.2.3]' => 'invalid',
    '[2001:db8::]/129' => 'invalid',
];
foreach ($mynet as $tok => $want) {
    $tok = (string) $tok;
    [, $sh] = sh_call('_mynet_token_code', $tok);
    $php = _postfix_mynet_token($tok);
    $w = $want ?? 'allowed';
    ok("php    mynetworks $tok -> $w", $php === $want);
    ok("helper mynetworks $tok -> $w", ($sh === '' ? null : $sh) === $want);
}

$relay = [
    '$mydestination' => null, '${mydestination}' => null, '$(mydestination)' => null,
    'example.com' => null, '.example.com' => null, 'a.b' => null,
    'xn--bcher-kva.example' => null, 'mail-backup.example.org' => null,
    'com' => 'tld', '.com' => 'tld', 'hu' => 'tld',
    'static:all' => 'not-domain', '*' => 'not-domain', '*.example.com' => 'not-domain',
    '/etc/postfix/relay_domains' => 'not-domain', 'hash:/etc/postfix/relay' => 'not-domain',
    '$myhostname' => 'not-domain', '!example.com' => 'not-domain', 'example..com' => 'not-domain',
    '-example.com' => 'not-domain', 'example.com.' => 'not-domain', '1.2.3.4' => 'not-domain',
    str_repeat('a.', 127) . 'com' => 'not-domain',
];
foreach ($relay as $tok => $want) {
    $tok = (string) $tok;
    [, $sh] = sh_call('_relay_domain_code', $tok);
    $php = _postfix_relay_domain_token($tok);
    $w = $want ?? 'allowed';
    $l = strlen($tok) > 40 ? substr($tok, 0, 20) . '...(' . strlen($tok) . ')' : $tok;
    ok("php    relay_domains $l -> $w", $php === $want);
    ok("helper relay_domains $l -> $w", ($sh === '' ? null : $sh) === $want);
}

// Whole values: [label, key, current, proposed, expect allowed]
$pf_default_rd = '${{$compatibility_level} <level {2} ? {$mydestination} : {}}';
$values = [
    ['installer default mynetworks',                 'mynetworks', '127.0.0.0/8', '127.0.0.0/8', true],
    ['installer IPv6 mynetworks (comma, brackets)',   'mynetworks', '127.0.0.0/8, [::1]/128', '127.0.0.0/8, [::1]/128', true],
    ['office host added',                            'mynetworks', '127.0.0.0/8', '127.0.0.0/8 203.0.113.5/32', true],
    ['0.0.0.0/0 among good entries',                 'mynetworks', '127.0.0.0/8', '127.0.0.0/8 0.0.0.0/0', false],
    ['two halves of the internet',                   'mynetworks', '127.0.0.0/8', '0.0.0.0/1, 128.0.0.0/1', false],
    ['line break smuggling a second parameter',      'mynetworks', '127.0.0.0/8', "127.0.0.0/8\nrelayhost = evil.example", false],
    ['tab inside the value',                         'mynetworks', '127.0.0.0/8', "127.0.0.0/8\t10.0.0.0/8", false],
    ['separators only',                              'mynetworks', '127.0.0.0/8', ', ,', false],
    ['existing table kept',                          'mynetworks', 'cidr:/etc/postfix/mynet.cidr 127.0.0.0/8',
                                                     'cidr:/etc/postfix/mynet.cidr 127.0.0.0/8 10.0.0.0/8', true],
    ['new table refused',                            'mynetworks', '127.0.0.0/8', '127.0.0.0/8 cidr:/etc/postfix/mynet.cidr', false],
    ['table refused when current unreadable',        'mynetworks', '', 'cidr:/etc/postfix/mynet.cidr', false],
    ['a broad range already present is not kept',    'mynetworks', '0.0.0.0/0', '0.0.0.0/0', false],
    ['... nor a bracketed one',                      'mynetworks', '[0.0.0.0]/0', '127.0.0.0/8 [0.0.0.0]/0', false],
    ['... nor [::/0]',                               'mynetworks', '[::/0]', '127.0.0.0/8 [::/0]', false],
    ['a malformed entry already present is not kept', 'mynetworks', '999.1.1.1', '127.0.0.0/8 999.1.1.1', false],
    ['an existing negation kept',                    'mynetworks', '!192.168.1.5 192.168.0.0/16', '!192.168.1.5 192.168.0.0/16 127.0.0.0/8', true],
    ['Postfix computed default (subnet style)',      'mynetworks', '', '127.0.0.0/8 158.220.80.0/20 [fe80::]/64', true],
    // Whole-value cap: public entries together cover at most one /16 (IPv6: /48).
    ['one public /16',                               'mynetworks', '', '127.0.0.0/8 198.51.0.0/16', true],
    ['two public /16s',                              'mynetworks', '', '198.51.0.0/16 203.0.0.0/16', false],
    ['a public /16 plus a /24',                      'mynetworks', '', '198.51.0.0/16 192.0.2.0/24', false],
    ['60 public /24s (within one /16)',              'mynetworks', '',
        implode(' ', array_map(fn($i) => "203.0.$i.0/24", range(0, 59))), true],
    ['65 entries',                                   'mynetworks', '',
        implode(' ', array_map(fn($i) => "10.0.$i.0/24", range(0, 64))), false],
    ['private ranges do not count toward the cap',   'mynetworks', '', '10.0.0.0/8 172.16.0.0/12 192.168.0.0/16 198.51.0.0/16', true],
    ['IPv4-mapped entries count as IPv4',            'mynetworks', '', '198.51.0.0/16 [::ffff:203.0.113.0]/120', false],
    ['one public IPv6 /48',                          'mynetworks', '', '127.0.0.0/8 [::1]/128 [2001:db8::]/48', true],
    ['two IPv6 /49s (one /48 worth)',                'mynetworks', '', '[2001:db8::]/49 [2001:db8:0:8000::]/49', true],
    ['overlapping entries are counted twice',        'mynetworks', '', '[2001:db8::]/48 [2001:db8::1]/128', false],
    ['two public IPv6 /48s',                         'mynetworks', '', '[2001:db8::]/48 [2001:db8:1::]/48', false],
    ['a public /16 and a public /48 (separate caps)', 'mynetworks', '', '198.51.0.0/16 [2001:db8::]/48', true],
    ['a bare IPv6 already present is not kept',      'mynetworks', '::1/128', '127.0.0.0/8 ::1/128', false],
    ['installer default relay_domains',              'relay_domains', '$mydestination', '$mydestination', true],
    ['backup-MX domains added',                      'relay_domains', '$mydestination', '$mydestination, example.com .example.org', true],
    ['static:all',                                   'relay_domains', '$mydestination', 'static:all', false],
    ['a whole TLD',                                  'relay_domains', '$mydestination', '$mydestination com', false],
    ['line break smuggling a second parameter',      'relay_domains', '$mydestination', "example.com\nmynetworks = 0.0.0.0/0", false],
    ['existing SQL table kept, domain added',        'relay_domains', 'proxy:mysql:/etc/postfix/sql/relay.cf',
                                                     'proxy:mysql:/etc/postfix/sql/relay.cf example.com', true],
    ['Postfix default expression re-saved',          'relay_domains', $pf_default_rd, $pf_default_rd, true],
    ['new lookup table refused',                     'relay_domains', '$mydestination', '$mydestination regexp:/etc/postfix/relay.re', false],
    ['65 relay domains',                             'relay_domains', '$mydestination',
        implode(' ', array_map(fn($i) => "d$i.example.com", range(0, 64))), false],
    ['other keys are not judged here',               'relayhost', '', '[smtp.example.com]:587', true],
];
foreach ($values as [$label, $key, $cur, $val, $allow]) {
    $php  = postfix_setting_guard($key, $val, $cur);
    $sh   = sh_setting_guard($key, $cur, $val);
    $want = $allow ? 'allowed' : 'refused';
    ok("php    $want: $label", ($php === null) === $allow);
    ok("helper $want: $label", ($sh === null) === $allow);
}
ok('helper network guard is pure (no postconf/postfix/systemctl call while sourced)', calls() === '');

// The caller's locale reaches the helper through sudo's env_keep; it must not
// widen [A-Za-z] or [0-9] (2026-10-16 review: under en_US.UTF-8 bash accepted
// 'példa.hu'). The helper pins LC_ALL=C itself.
$have_loc = array_map(fn($l) => strtolower(str_replace('-', '', $l)),
                      preg_split('/\s+/', (string) shell_exec('locale -a 2>/dev/null'), -1, PREG_SPLIT_NO_EMPTY));
$locs = array_filter(['en_US.UTF-8', 'hu_HU.UTF-8', 'en_GB.iso885915'],
                     fn($l) => in_array(strtolower(str_replace('-', '', $l)), $have_loc, true));
ok('at least one non-C locale is installed to test against', $locs !== []);
foreach ($locs as $loc) {
    [$rc, $out] = run(['/bin/bash', '-c', 'source "$1" || exit 99; shift; _relay_domain_code "$1"; printf "|"; _mynet_token_code "$2"',
                       'guard-test', $helper, 'példa.hu', '١٢٧.0.0.1'], '', ['LC_ALL' => $loc] + $env);
    ok("helper under LC_ALL=$loc: non-ASCII domain and digits refused", $rc === 0 && $out === 'not-domain|invalid');
}

$m = postfix_setting_guard('mynetworks', '0.0.0.0/0', '');
ok('php: too-broad message names the entry and the limit', is_string($m) && str_contains($m, '0.0.0.0/0') && str_contains($m, '/16'));
$m = postfix_setting_guard('relay_domains', 'static:all', '$mydestination');
ok('php: relay_domains message names the entry', is_string($m) && str_contains($m, 'static:all'));

// Wired into postfix_setting_save(): the current value is read, then judged.
$fake_values = ['mynetworks' => '127.0.0.0/8', 'relay_domains' => '$mydestination'];
$sudo_reads  = [];
$r = postfix_setting_save('mynetworks', '127.0.0.0/8 0.0.0.0/0');
ok('php save: broad mynetworks refused', $r[0] === false && str_contains($r[1], '0.0.0.0/0'));
ok('php save: current value was read', (bool) preg_grep("/ get 'mynetworks'\$/", $sudo_reads));
ok('php save: allowed mynetworks reaches the helper call', postfix_setting_save('mynetworks', '127.0.0.0/8, [::1]/128') === [false, 'Nincs kimenet.']);
$r = postfix_setting_save('relay_domains', 'static:all');
ok('php save: relay_domains table refused', $r[0] === false && str_contains($r[1], 'static:all'));
$sudo_reads = [];
ok('php save: relayhost unaffected', postfix_setting_save('relayhost', '[smtp.example.com]:587') === [false, 'Nincs kimenet.']);
ok('php save: relayhost reads no current value', $sudo_reads === []);

// ---- 4. helper `set`, end to end, stubbed ----------------------------------
if (!$quiet) echo "4. helper set (network card), postconf/postfix/systemctl stubbed\n";
function set_setting(string $key, string $val): array {
    global $helper, $env;
    reset_calls();
    return run(['/bin/bash', $helper, 'set', $key, $val], '', $env);
}

set_value('mynetworks', '127.0.0.0/8');
[$rc, $out] = set_setting('mynetworks', '127.0.0.0/8, [::1]/128');
ok('set mynetworks: installer IPv6 form accepted', $rc === 0 && trim($out) === 'OK');
ok('... reads current, writes, checks, reloads -- in that order',
   calls() === "postconf -h mynetworks\npostconf -h mynetworks\npostconf -e mynetworks=127.0.0.0/8, [::1]/128\n"
             . "postfix check\nsystemctl reload postfix\n");

foreach (['0.0.0.0/0', '127.0.0.0/8 [::ffff:0:0]/96', "127.0.0.0/8\nrelayhost = evil.example", '::1/128', '10.1.2.3/8'] as $v) {
    [$rc, $out] = set_setting('mynetworks', $v);
    ok('set mynetworks refused: ' . addcslashes($v, "\n"), $rc !== 0 && !wrote());
}

set_value('relay_domains', 'hash:/etc/postfix/relay');
[$rc, $out] = set_setting('relay_domains', 'hash:/etc/postfix/relay example.com');
ok('set relay_domains: existing table kept, domain added', $rc === 0 && trim($out) === 'OK');
foreach (['static:all', 'com', "example.com\nmynetworks = 0.0.0.0/0", 'hash:/etc/postfix/other'] as $v) {
    [$rc, $out] = set_setting('relay_domains', $v);
    ok('set relay_domains refused: ' . addcslashes($v, "\n"), $rc !== 0 && !wrote());
}
set_value('relay_domains', null);
[$rc, $out] = set_setting('relay_domains', 'hash:/etc/postfix/relay');
ok('set relay_domains: unreadable current value fails closed', $rc !== 0 && !wrote());

set_value('relayhost', '');
[$rc, $out] = set_setting('relayhost', '[smtp.example.com]:587');
ok('set relayhost: unchanged path, no extra read',
   $rc === 0 && calls() === "postconf -h relayhost\npostconf -e relayhost=[smtp.example.com]:587\n"
                            . "postfix check\nsystemctl reload postfix\n");

if (!$quiet || $failures) {
    echo "\ncheck-postfix-relay-guard: $passed passed, " . count($failures) . " failed\n";
}
exit($failures ? 1 : 0);
