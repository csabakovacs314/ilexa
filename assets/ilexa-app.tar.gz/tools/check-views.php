#!/usr/bin/env php
<?php
// Renders every view and fails on ANY PHP diagnostic.
//
// THE GAP THIS FILLS. `php -l` proves a file parses; it says nothing about
// what happens when it runs. Every bug of the shape count(null),
// "Undefined variable", "Trying to access array offset on null" or a bad
// string offset parses perfectly and only appears at render time. Two of
// those shipped on 2026-08-18 alone and were found by eye, not by a gate.
//
// WHY THE EMPTY STATE IS THE FIXTURE. index.php initialises every dataset
// holder to [] (see its "Shared holders" block) and only then populates the
// ones the requested view needs. So a view is ALWAYS entered with empty
// arrays for every dataset belonging to some other view -- and with empty
// arrays for its own, whenever the database is down, a helper failed, or a
// query simply matched nothing. That degraded path is both realistic and
// the exact place null/empty bugs live, and it needs no database or
// fixtures to reproduce. This mirrors index.php's holder block deliberately;
// if that block gains a variable, add it here too.
//
// Diagnostics are captured with a handler rather than display_errors,
// because notices routed into the output buffer would be swallowed by the
// very ob_start() used to render the page.
//
// Usage: tools/check-views.php [--quiet] [--view NAME]

$root  = dirname(__DIR__);
$quiet = in_array('--quiet', $argv, true);
$only  = null;
if (($i = array_search('--view', $argv, true)) !== false && isset($argv[$i + 1])) {
    $only = $argv[$i + 1];
}

// The console's own bootstrap needs a web-ish context; supply the minimum
// rather than faking the whole request lifecycle.
$_SERVER['REQUEST_METHOD'] = 'GET';
$_SERVER['REQUEST_URI']    = '/';
$_SERVER['SCRIPT_NAME']    = '/index.php';
$_SERVER['REMOTE_ADDR']    = '127.0.0.1';
$_SERVER['PHP_AUTH_USER']  = 'admin';
$_SERVER['HTTP_HOST']      = 'localhost';

chdir($root);
// The app's own bootstrap, not a hand-picked list of requires: it defines the
// constants (COOKIE_PATH, SUDO, ...) that src/ depends on, and loading the
// modules in a different order than production does would test a shape that
// never runs.
require $root . '/src/bootstrap.php';

// ---- diagnostics collector -------------------------------------------------
$diagnostics = [];
set_error_handler(function ($no, $str, $file, $line) use (&$diagnostics, $root) {
    // Everything, including notices and deprecations -- a deprecation today
    // is a fatal on the next PHP major, and this codebase spans two distros'
    // PHP versions.
    $diagnostics[] = [
        'level' => match (true) {
            (bool)($no & (E_ERROR | E_USER_ERROR | E_RECOVERABLE_ERROR)) => 'ERROR',
            (bool)($no & (E_WARNING | E_USER_WARNING))                   => 'WARNING',
            (bool)($no & E_DEPRECATED)                                   => 'DEPRECATED',
            default                                                      => 'NOTICE',
        },
        'msg'  => $str,
        'file' => str_replace("$root/", '', $file),
        'line' => $line,
    ];
    return true; // handled: do not also print it
});
error_reporting(E_ALL);
ini_set('display_errors', '0');

// ---- fixtures --------------------------------------------------------------
// Two layers, mirroring index.php exactly:
//
//   base()  the "Shared holders" block -- every dataset initialised empty,
//           plus the $is_* page flags. This is what a view genuinely sees
//           for datasets belonging to OTHER views.
//
//   load()  the per-view data loading, calling the SAME loader functions
//           index.php calls. This matters: a view is never entered with its
//           own dataset unset, so testing that state would report bugs that
//           cannot happen. What the loaders DO legitimately return is an
//           empty-but-well-formed structure (no rows, helper failed, DB
//           down), and running the real loaders is the only way to test
//           against the real shape contract rather than a guess at it.
function view_base(string $view): array {
    $flags = ['is_quar','is_block','is_white','is_archive','is_about','is_admin',
              'is_sysconfig','is_ioc','is_campaigns','is_pfa','is_dash'];
    $f = array_fill_keys($flags, false);
    $map = ['quarantine'=>'is_quar','lists'=>'is_block','archive'=>'is_archive',
            'about'=>'is_about','admin'=>'is_admin','admin_system'=>'is_sysconfig',
            'ioc'=>'is_ioc','campaigns'=>'is_campaigns','postfixadmin'=>'is_pfa',
            'dashboard'=>'is_dash'];
    if (isset($map[$view])) $f[$map[$view]] = true;
    if (!isset($map[$view])) $f['is_dash'] = true;   // layout partials render on the default page

    return $f + [
        'results' => [], 'page_results' => [], 'search_time' => 0,
        'total' => 0, 'total_pages' => 1, 'page' => 1, 'per_page' => QA_PER_PAGE,
        'audit_rows' => [], 'audit_error' => '', 'admin_logins' => [],
        'archive_rows' => [], 'archive_error' => '',
        'dash' => [], 'domains' => [], 'domain_users' => [],
        'filter_hidden' => '', 'dropped_uids' => [],
        'admin_settings' => [], 'admin_fts' => [], 'admin_sysinfo' => [],
        'admin_users' => [], 'admin_feeds' => [], 'breach_data' => [],
        'admin_clamav' => [], 'blocked_stats' => [], 'feed_sources' => [],
        'ioclookup_sources' => [], 'dnsbl_sites' => [], 'geoblock_countries' => '',
        'postfix_settings' => [], 'postfix_restrictions' => [],
        'folder_counts' => [], 'da_failures' => [], 'do_search' => false,
        'audit_tab' => 'ops', 'audit_open' => false,
        'f_domain' => '', 'f_user' => '', 'f_folder' => 'Spam',
        'f_since' => date('Y-m-d', strtotime('-7 days')), 'f_before' => '',
        'f_from' => '', 'f_subject' => '',
        'pfilters' => ['domain'=>'','user'=>'','folder'=>'Spam','since'=>'',
                       'before'=>'','from'=>'','subject'=>''],
        'af' => parse_af(),
        'ADMIN_TAB' => 'sysconfig=1',
    ];
}

// Calls the same loaders index.php does for this view. Any that need a
// database or a sudo helper return their own empty-but-well-formed default
// when it is unavailable, which is exactly the degraded shape worth testing.
function view_load(string $view): array {
    switch ($view) {
        case 'admin':
            return ['admin_settings' => admin_settings_load(),
                    'admin_sysinfo'  => admin_system_info(),
                    'admin_users'    => admin_users_list()];
        case 'admin_system':
            [$all_ops, $tot] = audit_ops_all();
            return ['admin_fts' => admin_fts_list(), 'admin_feeds' => admin_feeds_status(),
                    'admin_clamav' => admin_clamav_status(), 'feed_sources' => admin_feed_sources(),
                    'geoblock_countries' => admin_geoblock_get_countries(),
                    'postfix_settings' => postfix_settings_load(),
                    'dnsbl_sites' => postfix_dnsbl_sites(),
                    'audit_rows' => array_slice($all_ops, 0, QA_PER_PAGE),
                    'total' => $tot, 'total_pages' => max(1, (int)ceil($tot / QA_PER_PAGE))];
        case 'dashboard':
            return ['dash' => dashboard_data(), 'admin_sysinfo' => admin_system_info(),
                    'admin_feeds' => admin_feeds_status(), 'admin_clamav' => admin_clamav_status(),
                    'breach_data' => admin_breach_status(), 'blocked_stats' => admin_blocked_stats()];
        case 'archive':
            $af = parse_af();
            [$rows, $tot, $err] = archive_search($af, 1, QA_PER_PAGE);
            return ['domains' => get_domains(), 'archive_rows' => $rows,
                    'total' => $tot, 'archive_error' => $err,
                    'total_pages' => max(1, (int)ceil($tot / QA_PER_PAGE))];
        case 'quarantine':
            return ['domains' => get_domains()];
        default:
            return [];   // ioc/campaigns/lists load their own data inside the view
    }
}

$views = $only ? [$only] : [
    'layout_head', 'layout_header', 'icons',
    'dashboard', 'quarantine', 'archive', 'lists', 'admin', 'admin_system',
    'ioc', 'campaigns', 'about', 'postfixadmin', 'audit',
    'layout_foot',
];

$failed = 0;
$rendered = 0;
foreach ($views as $v) {
    $file = "$root/views/$v.php";
    if (!is_file($file)) { echo "  VIEW MISSING: views/$v.php\n"; $failed++; continue; }

    $diagnostics = [];
    // Pristine per view: a view must not depend on residue another left behind.
    extract(view_base($v), EXTR_SKIP);
    extract(view_load($v), EXTR_OVERWRITE);

    ob_start();
    try {
        include $file;
        $html = ob_get_clean();
    } catch (Throwable $e) {
        ob_end_clean();
        $html = '';
        $diagnostics[] = ['level' => 'THROWN', 'msg' => get_class($e) . ': ' . $e->getMessage(),
                          'file' => str_replace("$root/", '', $e->getFile()), 'line' => $e->getLine()];
    }
    $rendered++;

    if ($diagnostics) {
        $failed++;
        foreach ($diagnostics as $d) {
            echo "  VIEW {$d['level']}: views/$v.php -> {$d['msg']}  ({$d['file']}:{$d['line']})\n";
        }
    } elseif (!$quiet) {
        printf("  %-16s %6d bytes, clean\n", "$v.php", strlen($html));
    }
}

restore_error_handler();

if ($failed) {
    echo "check-views: $rendered views rendered, $failed with diagnostics, FAILED\n";
    exit(1);
}
// Always print the one-line verdict, even under --quiet: lint-all.sh shows
// the last line of each check as its summary, and a check that prints
// nothing on success is indistinguishable from one that did not run.
echo "check-views: $rendered views rendered against the real loaders, no diagnostics, clean\n";
exit(0);
