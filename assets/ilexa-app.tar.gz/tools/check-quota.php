#!/usr/bin/env php
<?php
// Unit tests for install/qa-quota-lib.php -- the shared external-API request
// budget.
//
// THE BUG CLASS THIS EXISTS FOR. Unlike most gates in tools/, this is a real
// unit suite rather than a consistency check, because the thing being tested
// is arithmetic over time and its failures are silent. Two of them have
// already happened for real:
//
//   * a ledger that permits one request too many looks exactly like one that
//     does not, until the provider withdraws access;
//   * a ledger that models ONE of the provider's three published limits looks
//     exactly like one that models all three -- the XposedOrNot sweep threw
//     away 75% of its daily budget every night for months, reporting "daily
//     quota exhausted" at request 26 of 100 and looking healthy doing it.
//
// Section 5 is the regression test for the second one.
//
// Runs entirely against a temp tree; makes no network calls and never touches
// the real ledger under /var/lib/ilexa.
//
//   tools/check-quota.php [--quiet]

$root  = dirname(__DIR__);
$quiet = in_array('--quiet', $argv, true);

$tmp = sys_get_temp_dir() . '/qa-quota-test-' . getmypid();
@mkdir($tmp . '/quota', 0755, true);
define('QA_QUOTA_DIR',  $tmp . '/quota');
define('QA_QUOTA_CONF', $tmp . '/quota.conf');
require "$root/install/qa-quota-lib.php";

$failures = [];
$passed   = 0;

function ok(string $what, bool $cond): void {
    global $failures, $passed, $quiet;
    if ($cond) { $passed++; if (!$quiet) echo "  ok   $what\n"; return; }
    $failures[] = $what;
    echo "  FAIL $what\n";
}
function reset_ledger(string $p = 'xposedornot'): void {
    @unlink(qa_quota_path($p));
}
/**
 * Spend as much as the provider will allow across a span of time, advancing
 * the clock by $step between attempts. Returns [taken, last_result].
 * Mirrors how the sweep actually behaves: attempt, get refused, move on.
 */
function spend(string $provider, string $caller, int $from, int $to, int $step): array {
    $taken = 0; $last = null;
    for ($t = $from; $t <= $to; $t += $step) {
        $last = qa_quota_take($provider, $caller, $t);
        if (!empty($last['allowed'])) $taken++;
    }
    return [$taken, $last];
}

$T = 1756300000;   // fixed clock; every assertion is relative to it

// ---- 1. an absent ledger is the first request, not a failure --------------
reset_ledger();
$s = qa_quota_status('xposedornot', $T);
ok('absent ledger reads as empty', ($s['used'] ?? -1) === 0 && ($s['remaining'] ?? -1) === 100);
ok('absent ledger has no reset_at', array_key_exists('reset_at', $s) && $s['reset_at'] === null);
ok('headline figures describe the DAY window', ($s['window'] ?? 0) === 86400);
ok('every configured window is reported',
   array_keys($s['windows'] ?? []) === ['second', 'hour', 'day']);

$r = qa_quota_take('xposedornot', 'interactive', $T);
ok('first take on an absent ledger is allowed', !empty($r['allowed']) && $r['reason'] === 'ok');
ok('first take is counted', $r['used'] === 1 && $r['remaining'] === 99);

// ---- 2. the count survives a restart -------------------------------------
$s = qa_quota_status('xposedornot', $T);
ok('take is persisted to disk', $s['used'] === 1);

$out = shell_exec(escapeshellarg(PHP_BINARY) . ' -r ' . escapeshellarg(
    'define("QA_QUOTA_DIR", ' . var_export($tmp . '/quota', true) . ');'
  . 'define("QA_QUOTA_CONF", ' . var_export($tmp . '/quota.conf', true) . ');'
  . 'require ' . var_export("$root/install/qa-quota-lib.php", true) . ';'
  . 'echo json_encode(qa_quota_status("xposedornot", ' . $T . '));') . ' 2>&1');
$sub = json_decode((string)$out, true);
ok('a separate process sees the same count', is_array($sub) && ($sub['used'] ?? -1) === 1);

$mode = fileperms(qa_quota_path('xposedornot')) & 0777;
ok('ledger is mode 0644 (the console reads it directly)', $mode === 0644);

// ---- 3. the per-second window paces a burst ------------------------------
// XposedOrNot documents 2/sec. Hammering at one timestamp must be refused by
// the SECOND window, not silently allowed because the day has room.
reset_ledger();
$burst = 0; $last = null;
for ($i = 0; $i < 10; $i++) {
    $last = qa_quota_take('xposedornot', 'interactive', $T);
    if (!empty($last['allowed'])) $burst++;
}
ok('a same-second burst is capped at 2', $burst === 2);
ok('the per-second window is named as the blocker', ($last['blocked_window'] ?? '') === 'second');
ok('a short-window refusal is rate_limited, not quota_exhausted',
   ($last['reason'] ?? '') === 'rate_limited');
ok('a rate_limited refusal says when to retry', !empty($last['retry_at']));
ok('the day window is untouched by a paced refusal',
   qa_quota_status('xposedornot', $T)['windows']['day']['used'] === 2);

// ---- 4. the hourly window ------------------------------------------------
reset_ledger();
[$taken, $last] = spend('xposedornot', 'interactive', $T, $T + 3500, 5);
ok('the hour caps at 22', $taken === 22);
ok('the hourly cap is named as the blocker', ($last['blocked_window'] ?? '') === 'hour');
ok('an hourly refusal is rate_limited, NOT quota_exhausted',
   ($last['reason'] ?? '') === 'rate_limited');
ok('a refused take records nothing', qa_quota_status('xposedornot', $T + 3500)['used'] === 22);

// ---- 5. THE REGRESSION TEST ----------------------------------------------
// The exact scenario that was broken. Spend across a whole day, an hour at a
// time. The old single-window ledger would have stopped at 25 for good; the
// hourly cap must refill and the DAY total must reach its 100.
reset_ledger();
$total = 0;
for ($h = 0; $h < 6; $h++) {
    [$n, ] = spend('xposedornot', 'interactive', $T + $h * 3600, $T + $h * 3600 + 3500, 5);
    $total += $n;
}
ok('the hourly window refills each hour', $total > 25);
ok('six hours of spending reaches the daily cap of 100', $total === 100);
$s = qa_quota_status('xposedornot', $T + 5 * 3600 + 3500);
ok('the day window is what finally stops it',
   $s['windows']['day']['used'] === 100 && $s['windows']['day']['remaining'] === 0);
[, $last] = spend('xposedornot', 'interactive', $T + 6 * 3600, $T + 6 * 3600 + 100, 5);
ok('once the day is full the reason becomes quota_exhausted',
   ($last['reason'] ?? '') === 'quota_exhausted' && ($last['blocked_window'] ?? '') === 'day');

// ---- 6. the reserve guards the DAY window only ---------------------------
// A batch caller must be stopped 20 short of the daily 100 -- but must NOT be
// stopped 20 short of the hourly 22, which is pacing, not budget.
reset_ledger();
[$n, ] = spend('xposedornot', 'batch', $T, $T + 3500, 5);
ok('the reserve does not shrink the hourly window', $n === 22);

reset_ledger();
$total = 0; $last = null;
for ($h = 0; $h < 6; $h++) {
    [$n, $last] = spend('xposedornot', 'batch', $T + $h * 3600, $T + $h * 3600 + 3500, 5);
    $total += $n;
}
ok('a batch caller stops at the daily limit minus the reserve', $total === 80);
ok('the batch denial names the reserve', ($last['reason'] ?? '') === 'reserved_for_interactive');
$r = qa_quota_take('xposedornot', 'interactive', $T + 6 * 3600);
ok('interactive may still spend the reserve', !empty($r['allowed']) && $r['used'] === 81);

// ---- 7. windows roll independently ---------------------------------------
// spend() fills the hour as fast as the per-second window allows, so all 22
// hits land in the first ~105 seconds (T, T+5 … T+105) -- NOT spread over the
// hour. The roll therefore starts 3600s after the FIRST hit, not after the
// last attempt. Getting this wrong is how you write a test that passes for
// the wrong reason.
reset_ledger();
spend('xposedornot', 'interactive', $T, $T + 3500, 5);          // fill the hour
$s = qa_quota_status('xposedornot', $T + 3600);
ok('at exactly one hour the oldest hit is still counted',
   $s['windows']['hour']['used'] === 22);
$s = qa_quota_status('xposedornot', $T + 3601);
ok('a second later the oldest hourly slot has freed', $s['windows']['hour']['used'] === 21);
ok('the day still counts every one of them', $s['windows']['day']['used'] === 22);
$s = qa_quota_status('xposedornot', $T + 3600 + 106);
ok('once the whole burst is an hour old the hour is empty',
   $s['windows']['hour']['used'] === 0 && $s['windows']['day']['used'] === 22);
$s = qa_quota_status('xposedornot', $T + 86400 + 106);
ok('a day later everything has aged out of every window', $s['used'] === 0);

// ---- 8. fail closed on a corrupt ledger ----------------------------------
reset_ledger();
file_put_contents(qa_quota_path('xposedornot'), "{ this is not json\n");
$r = qa_quota_take('xposedornot', 'interactive', $T);
ok('a corrupt ledger denies the request', empty($r['allowed']) && $r['reason'] === 'ledger corrupt');
ok('a corrupt ledger reports an error rather than zero usage',
   isset(qa_quota_status('xposedornot', $T)['error']));

file_put_contents(qa_quota_path('xposedornot'), json_encode(['used' => 3]));
$r = qa_quota_take('xposedornot', 'interactive', $T);
ok('a ledger with no hit list is corrupt, not empty',
   empty($r['allowed']) && $r['reason'] === 'ledger corrupt');

file_put_contents(qa_quota_path('xposedornot'), '');
ok('an empty ledger file is treated as unreadable',
   isset(qa_quota_status('xposedornot', $T)['error']));

// ---- 9. unknown provider / caller ----------------------------------------
reset_ledger();
$r = qa_quota_take('nosuchprovider', 'interactive', $T);
ok('an unbudgeted provider is denied, never unlimited',
   empty($r['allowed']) && $r['reason'] === 'unknown_provider');
$r = qa_quota_take('xposedornot', 'sideways', $T);
ok('an unknown caller class is denied',
   empty($r['allowed']) && $r['reason'] === 'unknown_caller');
ok('rejected callers record nothing', qa_quota_status('xposedornot', $T)['used'] === 0);

// ---- 10. the other two providers -----------------------------------------
$s = qa_quota_status('leakcheck', $T);
ok('leakcheck is budgeted at 1/sec with no daily cap',
   ($s['windows']['second']['limit'] ?? 0) === 1 && count($s['windows']) === 1);
reset_ledger('leakcheck');
$r1 = qa_quota_take('leakcheck', 'batch', $T);
$r2 = qa_quota_take('leakcheck', 'batch', $T);
ok('leakcheck allows one request per second', !empty($r1['allowed']) && empty($r2['allowed']));
$r3 = qa_quota_take('leakcheck', 'batch', $T + 2);
ok('leakcheck frees up again', !empty($r3['allowed']));
ok('leakcheck has no reserve to starve a sweep with',
   qa_quota_status('leakcheck', $T + 2)['reserve'] === 0);

// A PROVIDER WITH NO BUDGET WINDOW CAN ONLY EVER SAY "NOT YET".
// This shipped wrong for about ten minutes and was caught by a live call, not
// by these tests: with only a per-second window, inferring the budget as "the
// longest window" made a one-second wait report as an exhausted daily quota.
// The sweep would then have stopped for the DAY the first time two lookups
// landed in the same second.
ok('leakcheck declares no budget window', qa_quota_status('leakcheck', $T)['budget'] === null);
ok('a leakcheck refusal is rate_limited, NOT quota_exhausted',
   ($r2['reason'] ?? '') === 'rate_limited');
ok('a leakcheck refusal names the pacing window',
   ($r2['blocked_window'] ?? '') === 'second' && !empty($r2['retry_at']));
ok('xposedornot, by contrast, DOES declare a budget window',
   qa_quota_status('xposedornot', $T)['budget'] === 'day');

// A reserve is meaningless without a budget window, so it must not be able to
// starve a rate-limited-only provider.
reset_ledger('leakcheck');
$rb = qa_quota_take('leakcheck', 'batch', $T);
ok('batch is not penalised on a provider with no budget window', !empty($rb['allowed']));

reset_ledger('hudsonrock');
[$n, $last] = spend('hudsonrock', 'batch', $T, $T + 9, 1);
ok('hudsonrock allows a generous burst', $n === 10);
$hits = 0;
for ($i = 0; $i < 60; $i++) if (!empty(qa_quota_take('hudsonrock', 'batch', $T + 5)['allowed'])) $hits++;
ok('hudsonrock caps its 10-second window at 40',
   qa_quota_status('hudsonrock', $T + 5)['windows']['burst']['used'] === 40);

// ---- 11. operator override -----------------------------------------------
file_put_contents(QA_QUOTA_CONF, "# comment\nxposedornot|hour|5\nxposedornot|reserve|90\n");
$s = qa_quota_status('xposedornot', $T);
ok('override changes a named window', $s['windows']['hour']['limit'] === 5);
ok('override leaves other windows alone', $s['windows']['day']['limit'] === 100);
ok('override sets the reserve', $s['reserve'] === 90);
reset_ledger();
[$n, ] = spend('xposedornot', 'interactive', $T, $T + 3500, 5);
ok('the overridden hourly limit is enforced', $n === 5);

file_put_contents(QA_QUOTA_CONF, "xposedornot|day|999999\nxposedornot|nosuchwindow|5\n");
$s = qa_quota_status('xposedornot', $T);
ok('an out-of-range override is ignored, not applied', $s['windows']['day']['limit'] === 100);
ok('an unknown window name is not invented', !isset($s['windows']['nosuchwindow']));

file_put_contents(QA_QUOTA_CONF, "xposedornot|reserve|100\n");
ok('a reserve at or above the limit is dropped rather than starving batch',
   qa_quota_status('xposedornot', $T)['reserve'] === 0);
@unlink(QA_QUOTA_CONF);

// ---- 12. ensure() seeds a renderable ledger without spending -------------
reset_ledger();
$s = qa_quota_ensure('xposedornot', $T);
ok('ensure creates the ledger', file_exists(qa_quota_path('xposedornot')));
ok('ensure records no request', $s['used'] === 0);
ok('ensure is idempotent', qa_quota_ensure('xposedornot', $T)['used'] === 0);

// ---- teardown ------------------------------------------------------------
foreach (glob($tmp . '/quota/*') ?: [] as $f) @unlink($f);
@unlink(QA_QUOTA_CONF);
@rmdir($tmp . '/quota');
@rmdir($tmp);

if (!$quiet || $failures) {
    echo "\ncheck-quota: $passed passed, " . count($failures) . " failed\n";
}
exit($failures ? 1 : 0);
