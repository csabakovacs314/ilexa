#!/usr/bin/env php
<?php
// Audit-page consistency gate + unit tests for src/audit.php's page model.
//
// THE BUG CLASS THIS EXISTS FOR. Audit codes are written in ~80 audit_log()
// call sites across src/ and labelled/categorised in ONE table,
// audit_action_catalog(). Two places that must agree and nothing linking them
// is how the Audit page came to print raw codes (arc-ham, view-policy,
// update_check_now...) with config changes filed under "Spam műveletek".
//
//   1. every audit_log() code under src/ and the repo-root entry points has a
//      catalogue entry (a real label, not the raw-code fallback) and a
//      category; a dynamic code ('prefix' . $x) must be expanded in
//      $DYNAMIC below, so a new one fails here until someone does
//   2. every catalogue entry is still written somewhere (catches a typo in
//      the catalogue that (1) would report only as "missing")
//   3. audit_ops_page() paging, clamping, filtering, ordering and row
//      normalisation, against a synthetic TSV in a private temp dir --
//      never the real AUDIT_LOG
//
// Standalone: t() is stubbed to the identity (Hungarian source strings), so
// no bootstrap, config.php or database is needed.
//
//   tools/check-audit-labels.php [--quiet]

$root  = dirname(__DIR__);
$quiet = in_array('--quiet', $argv, true);

$tmp = sys_get_temp_dir() . '/qa-audit-test-' . getmypid() . '-' . bin2hex(random_bytes(4));
if (!@mkdir($tmp, 0700)) { fwrite(STDERR, "check-audit-labels: cannot create $tmp\n"); exit(2); }
define('AUDIT_LOG', $tmp . '/audit.log');

function t(string $s): string { return $s; }
require "$root/src/audit.php";

$failures = [];
$passed   = 0;
function ok(string $what, bool $cond): void {
    global $failures, $passed, $quiet;
    if ($cond) { $passed++; if (!$quiet) echo "  ok   $what\n"; return; }
    $failures[] = $what;
    echo "  FAIL $what\n";
}

// ---- 1. collect every code audit_log() is called with ----------------------
// Dynamic first arguments, keyed by their whitespace-normalised source text.
// Add the expansion here when you add a dynamic call site.
$DYNAMIC = [
    "\$which.'-add'"                                     => ['block-add', 'white-add'],
    "\$which.'-remove'"                                  => ['block-remove', 'white-remove'],
    "'rspamd_module_'.(\$on?'on':'off')"                 => ['rspamd_module_on', 'rspamd_module_off'],
    "'hu_classify_'.(\$on?'on':'off')"                   => ['hu_classify_on', 'hu_classify_off'],
    "'fts_optimize_'.(\$on?'on':'off')"                  => ['fts_optimize_on', 'fts_optimize_off'],
    "'feed-'.(\$on?'enable':'disable')"                  => ['feed-enable', 'feed-disable'],
    "'ioclookup-'.(\$on?'enable':'disable')"             => ['ioclookup-enable', 'ioclookup-disable'],
    "'brand-'.(\$on?'enable':'disable')"                 => ['brand-enable', 'brand-disable'],
    "'brand-lure-'.(\$on?'enable':'disable')"            => ['brand-lure-enable', 'brand-lure-disable'],
    "'psdnsbl-'.\$verb"                                  => ['psdnsbl-add', 'psdnsbl-set-weight'],
    "'neural-'.\$mode"                                   => ['neural-promote', 'neural-shadow'],
    // two call sites share this text: brand_lure_add/remove, and
    // brand_{variant,domain}_{add,remove} rewritten to add-variant etc.
    "'brand-'.\$verb"                                    => ['brand-lure-add', 'brand-lure-remove',
                                                             'brand-add-variant', 'brand-remove-variant',
                                                             'brand-add-domain', 'brand-remove-domain'],
];

$files = array_merge(glob("$root/src/*.php") ?: [], glob("$root/*.php") ?: []);
$codes = [];            // code => "file:line"
$dynUsed = [];
foreach ($files as $f) {
    $toks = token_get_all((string) file_get_contents($f));
    $n = count($toks);
    for ($i = 0; $i < $n; $i++) {
        $tk = $toks[$i];
        if (!is_array($tk) || $tk[0] !== T_STRING || $tk[1] !== 'audit_log') continue;
        $prev = $i - 1; while ($prev >= 0 && is_array($toks[$prev]) && $toks[$prev][0] === T_WHITESPACE) $prev--;
        if ($prev >= 0 && is_array($toks[$prev]) && $toks[$prev][0] === T_FUNCTION) continue;   // the definition
        $j = $i + 1; while ($j < $n && is_array($toks[$j]) && $toks[$j][0] === T_WHITESPACE) $j++;
        if (($toks[$j] ?? null) !== '(') continue;
        $where = basename($f) . ':' . $tk[2];

        // First argument: tokens up to the first top-level ',' or ')'.
        $depth = 0; $arg = []; $concat = false;
        for ($k = $j + 1; $k < $n; $k++) {
            $x = $toks[$k];
            if ($x === '(' || $x === '[') $depth++;
            if ($x === ')' || $x === ']') { if ($depth === 0) break; $depth--; }
            if ($x === ',' && $depth === 0) break;
            if ($x === '.') $concat = true;
            if (is_array($x) && in_array($x[0], [T_WHITESPACE, T_COMMENT], true)) continue;
            $arg[] = $x;
        }
        $lits = [];
        foreach ($arg as $x) {
            if (is_array($x) && $x[0] === T_CONSTANT_ENCAPSED_STRING) $lits[] = stripcslashes(substr($x[1], 1, -1));
        }
        if (!$concat && $lits) {
            // a literal, or a ternary between literals
            foreach ($lits as $c) $codes[$c] ??= $where;
            continue;
        }
        $src = implode('', array_map(fn($x) => is_array($x) ? $x[1] : $x, $arg));
        if (isset($DYNAMIC[$src])) {
            $dynUsed[$src] = true;
            foreach ($DYNAMIC[$src] as $c) $codes[$c] ??= $where;
        } else {
            ok("dynamic audit_log() code at $where is expanded in \$DYNAMIC ($src)", false);
        }
    }
}
foreach (array_keys($DYNAMIC) as $src) {
    ok("\$DYNAMIC entry is still used: $src", isset($dynUsed[$src]));
}
ok('found a plausible number of audit codes (' . count($codes) . ')', count($codes) >= 60);

$catalog = audit_action_catalog();
foreach ($codes as $code => $where) {
    $label = audit_action_label($code);
    $cat   = audit_action_category($code);
    ok("label+category for '$code' ($where)",
       isset($catalog[strtolower($code)]) && $label !== '' && $label !== $code
       && in_array($cat, ['ops', 'config'], true));
}

// ---- 2. no orphan catalogue entries ----------------------------------------
$written = array_change_key_case(array_flip(array_keys($codes)), CASE_LOWER);
foreach (array_keys($catalog) as $code) {
    ok("catalogue entry '$code' is written by some audit_log() call", isset($written[$code]));
    ok("catalogue key '$code' is lower-case [a-z0-9_-] (index.php's action_f filter)",
       (bool) preg_match('/^[a-z0-9_-]{1,40}$/', $code));
}
ok("release/delete are 'ops'", audit_action_category('release') === 'ops' && audit_action_category('delete') === 'ops');
ok("postfix-setting/view-policy are 'config'",
   audit_action_category('postfix-setting') === 'config' && audit_action_category('view-policy') === 'config');
ok('unknown code: raw label, config category',
   audit_action_label('Mystery-Op') === 'Mystery-Op' && audit_action_category('mystery-op') === 'config');
ok('historic "arc-resend:<rcpt>" resolves to arc-resend', audit_action_code('arc-resend:a@b.hu') === 'arc-resend');
ok('codes match case-insensitively', audit_action_code('arc-resend-FAIL') === 'arc-resend-fail');

// ---- 3. audit_ops_page() against a synthetic log ---------------------------
$T0 = 1760000000;
$lines = [];
$ops_ts = []; $cfg_ts = [];
$add = function (int $ts, string $code, string $u, string $f, string $id, bool $ops) use (&$lines, &$ops_ts, &$cfg_ts) {
    $lines[] = implode("\t", [$ts, '192.0.2.7', 'admin', $code, $u, $f, $id]);
    if ($ops) $ops_ts[] = $ts; else $cfg_ts[] = $ts;
};
// 37 ops rows: 20 arc-ham, 10 release, 5 delete, 2 arc-resend-FAIL
for ($i = 0; $i < 37; $i++) {
    $code = $i < 20 ? 'arc-ham' : ($i < 30 ? 'release' : ($i < 35 ? 'delete' : 'arc-resend-FAIL'));
    $add($T0 + $i * 10, $code, "user$i@example.hu", 'Spam', (string) (1000 + $i), true);
}
// config rows
$add($T0 + 1000, 'postfix-setting', 'smtpd_tls_security_level', 'may', 'ok', false);
$add($T0 + 1001, 'postfix-setting', 'message_size_limit', '52428800', 'err', false);
$add($T0 + 1002, 'view-policy', 'FAILED:all', '', 'none', false);
$add($T0 + 1003, 'view-policy', 'spam', '', 'none', false);
$add($T0 + 1004, 'update_apply', 'started', '', '1.0.29', false);
$add($T0 + 1005, 'update_apply', 'rolled_back', '1.0.28', '1.0.29', false);
$add($T0 + 1006, 'mystery-op', 'x', 'y', 'z', false);
$add($T0 + 1007, 'abusix_key', 'set', '', '', false);
$add($T0 + 1008, 'psdnsbl-set-weight', 'zen.spamhaus.org', 'weight=3', 'ok', false);
// ops rows with special shapes
$add($T0 + 2000, 'arc-ioc-add', 'archive@x.hu', 'INBOX', '123:4', true);
$add($T0 + 2001, 'block-add', 'spam.example', 'address', '', true);
$add($T0 + 2002, 'arc-resend:old@x.hu', 'archive@x.hu', 'INBOX', '77', true);
$long = str_repeat('Á', 1000);
$add($T0 + 2003, 'quar-lookup', $long, 'Spam', '5', true);
$add($T0 + 2004, 'release', "bad\xC3\x28utf8@x.hu", 'Spam', '6', true);
$add($T0 + 2005, 'signin-high-risk', 'u@x.hu', '198.51.100.9', '91', true);
$newest_ops = $T0 + 2005;
// noise that must be skipped or tolerated
$lines[] = '';
$lines[] = "1\t2\t3";
$lines[] = implode("\t", [$T0 + 3000, '192.0.2.7', 'admin', 'list-lookup', 'pat', "with\ttab", 'address', '2']);  // 8 fields
$ops_ts[] = $T0 + 3000; $newest_ops = $T0 + 3000;

file_put_contents(AUDIT_LOG, implode("\n", $lines) . "\n");
$n_ops = count($ops_ts); $n_cfg = count($cfg_ts);

$p = audit_ops_page('ops', '', 1, 10);
ok("ops total = $n_ops", $p['total'] === $n_ops);
ok('ops page 1 has 10 rows', count($p['rows']) === 10);
ok('newest first', $p['rows'][0]['time'] === $newest_ops && $p['rows'][0]['time'] >= $p['rows'][1]['time']);
ok('pages = ceil(total/per_page)', $p['pages'] === (int) ceil($n_ops / 10));
ok('not unreadable', $p['unreadable'] === false);
ok('every ops row is category ops', !array_filter($p['rows'], fn($r) => $r['category'] !== 'ops'));

$p2 = audit_ops_page('ops', '', 2, 10);
$all = audit_ops_page('ops', '', 1, 500);
ok('page 2 = rows 11..20 of the full newest-first list',
   array_column($p2['rows'], 'time') === array_column(array_slice($all['rows'], 10, 10), 'time'));
$hi = audit_ops_page('ops', '', 999, 10);
ok('page above range clamps to last page', $hi['page'] === $hi['pages'] && count($hi['rows']) === $n_ops - ($hi['pages'] - 1) * 10);
ok('page 0 clamps to 1', audit_ops_page('ops', '', 0, 10)['page'] === 1);
ok('negative page clamps to 1', audit_ops_page('ops', '', -5, 10)['page'] === 1);
ok('per_page 0 clamps to 1', audit_ops_page('ops', '', 1, 0)['per_page'] === 1);
ok('per_page 10000 clamps to 500', audit_ops_page('ops', '', 1, 10000)['per_page'] === 500);

$c = audit_ops_page('config', '', 1, 100);
ok("config total = $n_cfg", $c['total'] === $n_cfg);
ok('bogus category treated as ops', audit_ops_page('bogus', '', 1, 10)['category'] === 'ops');

$f = audit_ops_page('ops', 'arc-ham', 1, 100);
ok('filter arc-ham: 20 rows, all arc-ham', $f['total'] === 20 && !array_filter($f['rows'], fn($r) => $r['code'] !== 'arc-ham'));
ok('filter keeps effective action', $f['action'] === 'arc-ham');
$f = audit_ops_page('ops', 'ARC-RESEND-FAIL', 1, 100);
ok('filter is case-insensitive (arc-resend-FAIL x2)', $f['total'] === 2 && $f['action'] === 'arc-resend-fail');
$f = audit_ops_page('ops', 'arc-resend', 1, 100);
ok('historic arc-resend:<rcpt> row counted as arc-resend', $f['total'] === 1);
$f = audit_ops_page('ops', 'postfix-setting', 1, 100);
ok('other-tab filter is ignored', $f['action'] === '' && $f['total'] === $n_ops);
$f = audit_ops_page('config', 'mystery-op', 1, 100);
ok('unknown code present in log is filterable on config', $f['total'] === 1 && $f['action'] === 'mystery-op');
$f = audit_ops_page('config', 'user_add', 1, 100);
ok('catalogued but absent code: 0 rows, filter kept, listed in actions',
   $f['total'] === 0 && $f['action'] === 'user_add' && isset($f['actions']['user_add']));
$f = audit_ops_page('config', 'nonexistent-x', 1, 100);
ok('uncatalogued, absent code: filter dropped', $f['action'] === '' && $f['total'] === $n_cfg);
$f = audit_ops_page('config', '"><script>', 1, 100);
ok('hostile filter value is dropped', $f['action'] === '' && $f['total'] === $n_cfg);

ok('ops actions are ops codes only', !array_filter(array_keys($p['actions']), fn($k) => audit_action_category($k) !== 'ops'));
ok('config actions list the unknown code with its raw label', ($c['actions']['mystery-op'] ?? '') === 'mystery-op');
$labels = array_values($c['actions']);
$sorted = $labels; usort($sorted, 'strnatcasecmp');
ok('actions sorted by label', $labels === $sorted);

// normalisation
$by = [];
foreach (array_merge($all['rows'], $c['rows']) as $r) $by[$r['code'] . '@' . $r['time']] = $r;
$r = $by['postfix-setting@' . ($T0 + 1000)];
ok('postfix-setting: target=key, detail=value, result ok',
   $r['target'] === 'smtpd_tls_security_level' && $r['detail'] === 'may' && $r['result_state'] === 'ok' && $r['user'] === '');
ok('postfix-setting err -> err state', $by['postfix-setting@' . ($T0 + 1001)]['result_state'] === 'err');
$r = $by['view-policy@' . ($T0 + 1002)];
ok('view-policy FAILED:all -> "none → all", err', $r['detail'] === 'none → all' && $r['result_state'] === 'err');
ok('view-policy ok -> "none → spam", ok', $by['view-policy@' . ($T0 + 1003)]['detail'] === 'none → spam'
   && $by['view-policy@' . ($T0 + 1003)]['result_state'] === 'ok');
$r = $by['update_apply@' . ($T0 + 1004)];
ok('update_apply (started) -> target=version', $r['target'] === '1.0.29' && $r['detail'] === '' && $r['result_state'] === '');
$r = $by['update_apply@' . ($T0 + 1005)];
ok('update_apply (rolled_back) -> "1.0.28 → 1.0.29", err', $r['detail'] === '1.0.28 → 1.0.29' && $r['result_state'] === 'err');
ok('abusix_key two-argument row -> result ok', $by['abusix_key@' . ($T0 + 1007)]['result_state'] === 'ok');
ok('psdnsbl weight=3 -> "Súly: 3"', $by['psdnsbl-set-weight@' . ($T0 + 1008)]['detail'] === 'Súly: 3');
$r = $by['arc-ioc-add@' . ($T0 + 2000)];
ok('arc-ioc-add "123:4" -> uid 123, note 4', $r['uid'] === '123' && $r['note'] === '4 indikátor' && $r['target'] === '');
$r = $by['block-add@' . ($T0 + 2001)];
ok('block-add -> pattern in user, type as note, no folder', $r['user'] === 'spam.example' && $r['folder'] === '' && $r['note'] === 'Cím');
$r = $by['quar-lookup@' . ($T0 + 2003)];
ok('long field clipped to 200 chars', mb_strlen($r['user']) === 200 && str_ends_with($r['user'], '…'));
$r = $by['release@' . ($T0 + 2004)];
ok('invalid UTF-8 scrubbed, not blanked', mb_check_encoding($r['user'], 'UTF-8') && $r['user'] !== ''
   && htmlspecialchars($r['user'], ENT_QUOTES, 'UTF-8') !== '');
$r = $by['signin-high-risk@' . ($T0 + 2005)];
ok('signin-high-risk -> IP and score in note, not in folder/uid', $r['folder'] === '' && $r['uid'] === ''
   && str_contains($r['note'], '198.51.100.9') && str_contains($r['note'], '91%'));
$r = $by['list-lookup@' . ($T0 + 3000)];
ok('8-field line kept (extra field joined, not dropped)', $r !== null && $r['user'] === 'pat');
ok('every row carries every key', !array_filter(array_merge($all['rows'], $c['rows']), fn($r) =>
   array_diff(['time','ip','admin','code','label','category','user','folder','uid','note','target','detail','result','result_state'], array_keys($r))));

// missing / unreadable
unlink(AUDIT_LOG);
$m = audit_ops_page('ops', '', 1, 10);
ok('missing log: empty, NOT unreadable', $m['total'] === 0 && $m['rows'] === [] && $m['unreadable'] === false);
mkdir(AUDIT_LOG, 0700);
$m = audit_ops_page('ops', '', 1, 10);
ok('log path not a readable file: unreadable', $m['unreadable'] === true && $m['total'] === 0);
rmdir(AUDIT_LOG);
if (function_exists('posix_geteuid') && posix_geteuid() !== 0) {
    file_put_contents(AUDIT_LOG, $lines[0] . "\n");
    chmod(AUDIT_LOG, 0000);
    ok('permission-denied log: unreadable', audit_ops_page('ops', '', 1, 10)['unreadable'] === true);
    chmod(AUDIT_LOG, 0600);
    @unlink(AUDIT_LOG);
} elseif (!$quiet) {
    echo "  skip permission-denied case (running as root, which bypasses file modes)\n";
}

// ---- teardown ----------------------------------------------------------------
@unlink(AUDIT_LOG);
@rmdir($tmp);

if (!$quiet || $failures) {
    echo "\ncheck-audit-labels: " . count($codes) . " codes, $passed passed, " . count($failures) . " failed\n";
} else {
    echo "check-audit-labels: " . count($codes) . " audit codes labelled, $passed checks passed, clean\n";
}
exit($failures ? 1 : 0);
