<?php
// Find Hungarian text that reaches the screen without passing through t().
//
// Why this exists: tools/check-i18n.php verifies that every t() call has a
// lang/en.php entry. It cannot see a string that never asked to be translated
// -- a bare <h2>Jelentett spam</h2>, or 'clamd fut' echoed directly. Those
// render Hungarian in the middle of an English console, and nothing failed.
// Seven such strings shipped before an English demo render exposed them.
//
// Uses PHP's own tokenizer rather than regex: T_COMMENT and T_DOC_COMMENT are
// separate token types, so the Hungarian prose in this project's (extensive)
// comments is skipped for free rather than fought with.
//
//   tools/check-hu-literals.php [--quiet]
declare(strict_types=1);
$root = dirname(__DIR__);
$quiet = in_array('--quiet', $argv, true);

// Hungarian diacritics, plus the common words that carry none -- a
// diacritic-only test misses exactly the strings that bit us ("oldal",
// "Mappa", "clamd fut", "motor", "indexek").
const HU_CHARS = '/[áéíóöőúüűÁÉÍÓÖŐÚÜŰ]/u';
// Deliberately excludes words that collide with English -- "all", "fut",
// "motor", "index", "elem", "sor". Those produced more noise than signal; the
// three real cases they once caught are fixed and the diacritic test carries
// the rest. Add a word here only if it cannot appear in English output.
const HU_WORDS = '/\b(oldal|oldalak|oldalt|mappa|nincs|nincsenek|ismeretlen|sikertelen|'
               . 'osszes|elemek|sorok|indexek|jelentett|kereses|szures|torles|mentes|'
               . 'erteke|darab|felhasznalo|beallitas)\b/iu';

// Log/diagnostic sinks: Hungarian there is server-side, never rendered.
const LOG_FNS = ['error_log','learn_log','audit_log','syslog','trigger_error','assert'];

function is_hu(string $s): bool {
    $s = trim($s);
    if ($s === '' || mb_strlen($s) < 3) return false;
    if (preg_match('/^[\s\W\d]+$/u', $s)) return false;
    return (bool) (preg_match(HU_CHARS, $s) || preg_match(HU_WORDS, $s));
}

$files = [];
foreach (['views', 'src'] as $dir) {
    foreach (glob("$root/$dir/*.php") ?: [] as $f) $files[] = $f;
}
$files[] = "$root/index.php";

$findings = [];
foreach ($files as $file) {
    $src = file_get_contents($file);
    if ($src === false) continue;
    $rel = ltrim(str_replace($root, '', $file), '/');

    // ---- pass 1: literal page output -------------------------------------
    // Blank out PHP blocks, script bodies and style bodies, keeping byte
    // offsets so line numbers stay true. CSS and JS comments in this project
    // are written in Hungarian by the hundred and never reach a user; scanning
    // them buries the handful of real findings.
    $blank = function (array $m): string { return preg_replace('/[^\n]/', ' ', $m[0]); };
    // Build the literal-output view from T_INLINE_HTML tokens rather than by
    // regex: a src/*.php file never closes its PHP tag, so an open-tag/close-tag
    // mask matches nothing there and the whole file would be read as HTML.
    $vis = '';
    foreach (token_get_all($src) as $tk) {
        $txt = is_array($tk) ? $tk[1] : $tk;
        $vis .= (is_array($tk) && $tk[0] === T_INLINE_HTML)
              ? $txt
              : preg_replace('/[^\n]/', ' ', $txt);
    }
    $vis = preg_replace_callback('#<script\b[^>]*>.*?</script>#is', $blank, $vis);
    $vis = preg_replace_callback('#<style\b[^>]*>.*?</style>#is',   $blank, $vis);
    $vis = preg_replace_callback('/<!--.*?-->/s', $blank, $vis);

    // (a) text nodes
    foreach (preg_split('/(<[^>]*>)/', $vis, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_OFFSET_CAPTURE) as $chunk) {
        [$piece, $off] = $chunk;
        if ($piece === '' || $piece[0] === '<') continue;
        foreach (preg_split('/\R/', $piece) as $i => $lineTxt) {
            if (is_hu($lineTxt)) {
                $findings[] = [$rel, substr_count(substr($vis, 0, $off), "\n") + 1 + $i, 'text', trim($lineTxt)];
            }
        }
    }
    // (b) user-visible attribute values -- placeholder/title/alt/aria-label/
    //     data-label all render to the reader just as text nodes do.
    if (preg_match_all('/\b(placeholder|title|alt|aria-label|data-label)\s*=\s*"([^"]*)"/i',
                       $vis, $mm, PREG_OFFSET_CAPTURE | PREG_SET_ORDER)) {
        foreach ($mm as $m) {
            if (is_hu($m[2][0])) {
                $findings[] = [$rel, substr_count(substr($vis, 0, $m[0][1]), "\n") + 1,
                               'attr:' . strtolower($m[1][0]), trim($m[2][0])];
            }
        }
    }

    // ---- pass 2: PHP string literals not wrapped in t() ------------------
    $toks = token_get_all($src);
    $flat = [];
    foreach ($toks as $t) {
        if (is_array($t) && in_array($t[0], [T_WHITESPACE, T_COMMENT, T_DOC_COMMENT], true)) continue;
        $flat[] = $t;
    }
    // Some maps hold Hungarian source strings on purpose and are translated at
    // the point of render instead -- the sidebar labels, ROLE_LABELS,
    // SIGNIN_REASON_LABELS. Bracket those with i18n-deferred-start/end so this
    // check stays silent about them without going blind to the file.
    $deferred = [];
    $lines = preg_split('/\R/', $src);
    $open = null;
    foreach ($lines as $i => $ln) {
        if (str_contains($ln, 'i18n-deferred-start')) $open = $i + 1;
        elseif (str_contains($ln, 'i18n-deferred-end') && $open !== null) {
            $deferred[] = [$open, $i + 1]; $open = null;
        }
    }
    $isDeferred = function (int $line) use ($deferred): bool {
        foreach ($deferred as [$a, $b]) if ($line >= $a && $line <= $b) return true;
        return false;
    };

    $pos = -1;
    foreach ($toks as $t) {
        if (is_array($t) && in_array($t[0], [T_WHITESPACE, T_COMMENT, T_DOC_COMMENT], true)) continue;
        $pos++;
        if (!is_array($t) || $t[0] !== T_CONSTANT_ENCAPSED_STRING) continue;
        if ($isDeferred($t[2])) continue;
        $lit = substr($t[1], 1, -1);
        $lit = str_replace(["\\'", '\\"'], ["'", '"'], $lit);
        if (!is_hu($lit)) continue;
        $p1 = $flat[$pos - 1] ?? null;
        $p2 = $flat[$pos - 2] ?? null;
        $callee = ($p1 === '(' && is_array($p2) && $p2[0] === T_STRING) ? strtolower($p2[1]) : '';
        if ($callee === 't') continue;
        if (in_array($callee, LOG_FNS, true)) continue;
        $findings[] = [$rel, $t[2], 'literal', $lit];
    }
}

if (!$findings) {
    echo "check-hu-literals: no untranslated Hungarian reaching output -- clean\n";
    exit(0);
}
$byFile = [];
foreach ($findings as $f) $byFile[$f[0]][] = $f;
foreach ($byFile as $rel => $rows) {
    echo "\n  $rel (" . count($rows) . ")\n";
    foreach ($rows as [$r, $line, $kind, $txt]) {
        printf("    %-5d %-8s %s\n", $line, $kind, mb_substr($txt, 0, 78));
    }
}
printf("\ncheck-hu-literals: %d untranslated Hungarian string(s) reach output, FAILED\n", count($findings));
exit(1);
