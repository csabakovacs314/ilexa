#!/usr/bin/env php
<?php
// Fixture tests for the three email-exposure response parsers in
// install/qa-ioc-lookup.php: XposedOrNot, LeakCheck and Hudson Rock.
//
// THE BUG CLASS THIS EXISTS FOR. These parsers all have the same catastrophic
// failure mode: returning "nothing found" for a response they did not
// understand, which is indistinguishable from a genuine clean answer. On a
// dashboard whose whole job is telling an admin which mailboxes are exposed,
// that turns "we could not read the answer" into "this user is fine".
//
// It is not hypothetical. XposedOrNot has THREE response shapes in the wild
// (current ExposedBreaches, older BreachMetrics, and a bare name list) and
// which one you get is not something the request controls. LeakCheck answers
// "Not found" both for a clean address AND for a malformed one. Hudson Rock
// signals "not infected" with a populated message and an EMPTY list.
//
// Every fixture below was captured from a live response on 2026-08-27, so
// checking a shape costs nothing here rather than one of 100 daily requests
// the mailbox sweep also needs.
//
// Makes no network calls: the gateway is required with QA_IOC_LOOKUP_LIB_ONLY
// defined, which stops it before it reads argv.
//
//   tools/check-breach-parsers.php [--quiet]

$root  = dirname(__DIR__);
$quiet = in_array('--quiet', $argv, true);

define('QA_IOC_LOOKUP_LIB_ONLY', true);
// The gateway starts with a shebang line, which require() echoes as text.
ob_start();
require "$root/install/qa-ioc-lookup.php";
ob_end_clean();

$failures = [];
$passed   = 0;

function ok(string $what, bool $cond): void {
    global $failures, $passed, $quiet;
    if ($cond) { $passed++; if (!$quiet) echo "  ok   $what\n"; return; }
    $failures[] = $what;
    echo "  FAIL $what\n";
}

// ══ XposedOrNot ══════════════════════════════════════════════════════════

// ---- 1. current API shape ------------------------------------------------
[$b, $y] = xon_parse_breaches([
    'ExposedBreaches' => ['breaches_details' => [
        ['breach' => 'Adobe',    'xposed_date' => '2013', 'xposed_data' => 'Email;Password'],
        ['breach' => 'LinkedIn', 'xposed_date' => '2016', 'xposed_data' => 'Email;Password'],
    ]],
]);
ok('current shape: both breaches parsed', count($b) === 2);
ok('current shape: names kept', $b[0]['name'] === 'Adobe' && $b[1]['name'] === 'LinkedIn');
ok('current shape: years parsed', $b[0]['year'] === 2013 && $b[1]['year'] === 2016);
ok('current shape: data classes kept', $b[0]['data'] === 'Email;Password');
ok('current shape: latest year is the max', $y === 2016);

// ---- 2. older API shape --------------------------------------------------
[$b, $y] = xon_parse_breaches([
    'BreachMetrics' => ['breaches_details' => [
        ['name' => 'Dropbox', 'year' => 2012, 'details' => 'Email'],
    ]],
]);
ok('older shape: parsed via BreachMetrics', count($b) === 1 && $b[0]['name'] === 'Dropbox');
ok('older shape: year via the alternate key', $b[0]['year'] === 2012 && $y === 2012);

// an EMPTY ExposedBreaches must fall through to BreachMetrics, not win
[$b, $y] = xon_parse_breaches([
    'ExposedBreaches' => ['breaches_details' => []],
    'BreachMetrics'   => ['breaches_details' => [['name' => 'Tumblr', 'year' => 2013]]],
]);
ok('an empty current-shape block falls through to the older one',
   count($b) === 1 && $b[0]['name'] === 'Tumblr');

// ---- 3. bare name list ---------------------------------------------------
[$b, $y] = xon_parse_breaches(['breaches' => [['Adobe', 'LinkedIn']]]);
ok('bare list: names parsed', count($b) === 2 && $b[1]['name'] === 'LinkedIn');
ok('bare list: no year is 0, not invented', $b[0]['year'] === 0 && $y === 0);

[$b, ] = xon_parse_breaches(['breaches' => ['Adobe']]);
ok('bare list: un-nested variant also parsed', count($b) === 1 && $b[0]['name'] === 'Adobe');

// ---- 4. genuine negatives ------------------------------------------------
foreach ([
    'Error member'        => ['Error' => 'Not found'],
    'status Not found'    => ['status' => 'Not found'],
    'empty object'        => [],
    'null body'           => null,
    'scalar body'         => 'nonsense',
] as $label => $fixture) {
    [$b, $y] = xon_parse_breaches($fixture);
    ok("negative: $label yields no breaches", $b === [] && $y === 0);
}

// ---- 5. hostile / malformed provider data --------------------------------
// Everything below is provider-controlled. None of it may crash the parser,
// and none of it may become a breach with an empty name.
[$b, ] = xon_parse_breaches([
    'ExposedBreaches' => ['breaches_details' => [
        'not-an-array',
        ['breach' => ''],                       // empty name: skipped
        ['xposed_date' => '2020'],              // no name at all: skipped
        ['breach' => ['nested']],               // wrong type: skipped
        ['breach' => 'Real', 'xposed_date' => 'not-a-year'],
        ['breach' => 'Neg',  'xposed_date' => '-5'],
    ]],
]);
ok('malformed rows are skipped, not turned into nameless breaches', count($b) === 2);
ok('a non-numeric year becomes 0 rather than garbage', $b[0]['year'] === 0);
ok('a negative year is rejected', $b[1]['year'] === 0);

// ---- 6. bounds -----------------------------------------------------------
$many = [];
for ($i = 0; $i < 200; $i++) $many[] = ['breach' => "B$i", 'xposed_date' => '2020'];
[$b, ] = xon_parse_breaches(['ExposedBreaches' => ['breaches_details' => $many]]);
ok('breach count is capped at 60', count($b) === 60);

[$b, ] = xon_parse_breaches(['ExposedBreaches' => ['breaches_details' => [
    ['breach' => str_repeat('N', 500), 'xposed_data' => str_repeat('D', 900), 'xposed_date' => '2020'],
]]]);
ok('a long breach name is bounded to 80', mb_strlen($b[0]['name']) === 80);
ok('a long data-class string is bounded to 200', mb_strlen($b[0]['data']) === 200);

$long = [];
for ($i = 0; $i < 200; $i++) $long[] = "N$i";
[$b, ] = xon_parse_breaches(['breaches' => [$long]]);
ok('the bare-list path is capped too', count($b) === 60);

// markup is preserved verbatim (the views escape; the parser must not
// half-sanitise and leave something that looks safe but is not)
[$b, ] = xon_parse_breaches(['ExposedBreaches' => ['breaches_details' => [
    ['breach' => '<script>x</script>', 'xposed_date' => '2020'],
]]]);
ok('markup is passed through unaltered for the view to escape',
   $b[0]['name'] === '<script>x</script>');

// ---- 7. multibyte safety -------------------------------------------------
[$b, ] = xon_parse_breaches(['ExposedBreaches' => ['breaches_details' => [
    ['breach' => str_repeat('á', 200), 'xposed_date' => '2020'],
]]]);
ok('bounding counts characters, not bytes', mb_strlen($b[0]['name']) === 80);

// ══ LeakCheck ════════════════════════════════════════════════════════════

// ---- 8. the found shape --------------------------------------------------
[$b, $y, $rec, $cls] = leakcheck_parse([
    'success' => true, 'found' => 1366,
    'fields'  => ['profile_name', 'password', 'ip1'],
    'sources' => [
        ['name' => 'Mathway.com',  'date' => '2020-01'],
        ['name' => 'LiveJournal',  'date' => '2017-01'],
        ['name' => 'arthritis.com.au', 'date' => ''],
    ],
]);
ok('leakcheck: every source becomes a breach', count($b) === 3);
ok('leakcheck: names kept', $b[0]['name'] === 'Mathway.com');
ok('leakcheck: YYYY-MM dates become years', $b[0]['year'] === 2020 && $b[1]['year'] === 2017);
ok('leakcheck: an empty date is 0, not invented', $b[2]['year'] === 0);
ok('leakcheck: latest year is the max', $y === 2020);
// The single most dangerous confusion this API invites.
ok('leakcheck: "found" is carried as a RECORD count, separate from the breaches',
   $rec === 1366 && count($b) === 3);
ok('leakcheck: exposed field types are captured', $cls === ['profile_name', 'password', 'ip1']);
ok('leakcheck: per-breach data is left empty, because the API gives no'
 . ' per-source attribution', $b[0]['data'] === '');

// ---- 9. the negative shape -----------------------------------------------
[$b, $y, $rec, $cls] = leakcheck_parse(['success' => false, 'error' => 'Not found']);
ok('leakcheck: a not-found answer yields no breaches', $b === [] && $y === 0);
ok('leakcheck: a not-found answer has no record count', $rec === 0 && $cls === []);

foreach ([
    'null body'      => null,
    'scalar body'    => 'nonsense',
    'empty object'   => [],
    'success absent' => ['found' => 5, 'sources' => [['name' => 'X']]],
] as $label => $fx) {
    [$b, ] = leakcheck_parse($fx);
    ok("leakcheck: $label yields no breaches", $b === []);
}

// ---- 10. malformed and hostile rows --------------------------------------
[$b, ] = leakcheck_parse(['success' => true, 'sources' => [
    'not-an-array',
    ['date' => '2020-01'],                 // no name: skipped
    ['name' => ''],                        // empty name: skipped
    ['name' => ['nested']],                // wrong type: skipped
    ['name' => 'Real', 'date' => 'garbage'],
    ['name' => 'Real2', 'date' => 12345],  // wrong type: year stays 0
]]);
ok('leakcheck: malformed rows are skipped, never nameless breaches', count($b) === 2);
ok('leakcheck: an unparseable date becomes 0', $b[0]['year'] === 0 && $b[1]['year'] === 0);

$many = [];
for ($i = 0; $i < 213; $i++) $many[] = ['name' => "S$i", 'date' => '2020-01'];
[$b, ] = leakcheck_parse(['success' => true, 'sources' => $many]);
// 213 sources came back for one real address, so this cap is load-bearing.
ok('leakcheck: the source list is capped at 60', count($b) === 60);

[$b, , , $cls] = leakcheck_parse(['success' => true,
    'sources' => [['name' => str_repeat('N', 400), 'date' => '2020-01']],
    'fields'  => array_fill(0, 90, str_repeat('f', 90))]);
ok('leakcheck: a long source name is bounded to 80', mb_strlen($b[0]['name']) === 80);
ok('leakcheck: the field list is bounded in count and length',
   count($cls) === 30 && mb_strlen($cls[0]) === 40);

// ══ Hudson Rock ══════════════════════════════════════════════════════════

// ---- 11. the infected shape ----------------------------------------------
$st = hudsonrock_parse([
    'message'  => 'This email address is associated with a computer that was infected...',
    'stealers' => [
        ['date_compromised' => '2026-08-20T00:00:00.000Z', 'computer_name' => 'DESKTOP-A1',
         'operating_system' => 'Windows 11', 'antiviruses' => ['Defender'],
         'ip' => '45.243.***.***', 'top_passwords' => ['hunter2'],
         'top_logins' => ['a@b.com']],
        ['date_compromised' => '2025-01-02T00:00:00.000Z', 'computer_name' => 'Not Found',
         'operating_system' => 'Windows 10', 'antiviruses' => []],
    ],
    'total_corporate_services' => 699, 'total_user_services' => 32482,
]);
ok('hudsonrock: an infection is reported', $st !== null && $st['infected'] === true);
ok('hudsonrock: every stealer record becomes an infection', count($st['infections']) === 2);
ok('hudsonrock: the machine and OS are kept',
   $st['infections'][0]['computer'] === 'DESKTOP-A1'
   && $st['infections'][0]['os'] === 'Windows 11');
ok('hudsonrock: antivirus list is kept', $st['infections'][0]['antivirus'] === ['Defender']);
ok('hudsonrock: latest is the most recent compromise',
   strpos($st['latest'], '2026-08-20') === 0);
ok('hudsonrock: service totals are carried',
   $st['corporate_services'] === 699 && $st['user_services'] === 32482);

// THE PRIVACY ASSERTION. The API returns partially-masked passwords, logins
// and the victim's IP. None of it may reach the payload: masked credential
// material is still credential material, the operator's action ("force a
// password reset") needs none of it, and once it is in a cache file something
// downstream will eventually start depending on it.
$flat = json_encode($st);
ok('hudsonrock: passwords are NEVER carried through', strpos($flat, 'hunter2') === false);
ok('hudsonrock: top_logins are NEVER carried through', strpos($flat, 'a@b.com') === false);
ok('hudsonrock: the victim IP is NEVER carried through', strpos($flat, '45.243') === false);
foreach (['top_passwords', 'top_logins', 'ip'] as $k) {
    ok("hudsonrock: no '$k' key survives into the payload", strpos($flat, $k) === false);
}

// ---- 12. the not-infected shape ------------------------------------------
ok('hudsonrock: an empty stealers list is a clean answer, not a failure',
   hudsonrock_parse(['message' => 'This email address is not associated...',
                     'stealers' => [], 'total_corporate_services' => 0,
                     'total_user_services' => 0]) === null);
foreach (['null' => null, 'scalar' => 'x', 'empty object' => [],
          'stealers not a list' => ['stealers' => 'nope'],
          'stealers of junk' => ['stealers' => ['a', 42, null]]] as $label => $fx) {
    ok("hudsonrock: $label yields no infection", hudsonrock_parse($fx) === null);
}

// ---- 13. the API's literal "Not Found" string is not data ----------------
$st = hudsonrock_parse(['stealers' => [
    ['date_compromised' => '2026-01-01T00:00:00.000Z',
     'computer_name' => 'Not Found', 'operating_system' => 'not found',
     'malware_path' => 'Not Found'],
]]);
ok('hudsonrock: the literal "Not Found" placeholder becomes an empty string,'
 . ' not a machine called Not Found',
   $st['infections'][0]['computer'] === '' && $st['infections'][0]['os'] === '');

// ---- 14. bounds ----------------------------------------------------------
$many = [];
for ($i = 0; $i < 50; $i++) $many[] = ['date_compromised' => '2026-01-0' . ($i % 9 + 1) . 'T00:00:00.000Z'];
$st = hudsonrock_parse(['stealers' => $many]);
ok('hudsonrock: the infection list is capped at 20', count($st['infections']) === 20);

$st = hudsonrock_parse(['stealers' => [[
    'date_compromised' => '2026-01-01T00:00:00.000Z',
    'computer_name'    => str_repeat('C', 500),
    'antiviruses'      => array_fill(0, 40, str_repeat('a', 90)),
]]]);
ok('hudsonrock: a long machine name is bounded', mb_strlen($st['infections'][0]['computer']) === 100);
ok('hudsonrock: the antivirus list is bounded in count and length',
   count($st['infections'][0]['antivirus']) === 8
   && mb_strlen($st['infections'][0]['antivirus'][0]) === 40);

$st = hudsonrock_parse(['stealers' => [[
    'date_compromised' => '2026-01-01T00:00:00.000Z',
    'computer_name'    => '<script>alert(1)</script>',
]]]);
ok('hudsonrock: markup passes through unaltered for the view to escape',
   $st['infections'][0]['computer'] === '<script>alert(1)</script>');

if (!$quiet || $failures) {
    echo "\ncheck-breach-parsers: $passed passed, " . count($failures) . " failed\n";
}
exit($failures ? 1 : 0);
