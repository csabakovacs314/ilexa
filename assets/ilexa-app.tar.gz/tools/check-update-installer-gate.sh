#!/bin/bash
# check-update-installer-gate.sh -- an installer-requiring release can never
# be skipped by a one-click update, and the dashboard says so.
#
# Until 1.0.34 the applier checked requires_installer on the TARGET release
# only, so a host on 1.0.31 could one-click an unflagged later release and
# silently miss 1.0.32's and 1.0.33's installer changes. This test covers:
#
#   1. installer_gate() itself, on a fixture manifest (range ends, numeric not
#      lexical ordering, unreadable versions, malformed manifests);
#   2. that the copies in qa-update-apply.sh and qa-update-check.sh are
#      byte-identical (they are kept in two self-contained helpers);
#   3. the applier's real phase_fetch_verify, extracted and run against a stub
#      curl and a throwaway signing key, so the wiring is tested, not just the
#      function;
#   4. qa-update-check.sh end to end, same stubs, reading the cache it writes.
#
# Nothing here touches the network, the live webroot or real state: every
# path the scripts take comes from their QA_* overrides or a scratch dir, and
# mail/sendmail/logger are stubs that record a call and fail the test.
#
# Usage: tools/check-update-installer-gate.sh [--quiet] [apply-script] [check-script]
#        (the script arguments let it run against an older copy, to show the
#        tests fail without the fix)

HERE="$(cd "$(dirname "$0")/.." && pwd)"
QUIET=0
[ "${1:-}" = "--quiet" ] && { QUIET=1; shift; }
APPLY="${1:-$HERE/install/qa-update-apply.sh}"
CHECK="${2:-$HERE/install/qa-update-check.sh}"

W="$(mktemp -d)"
trap 'rm -rf "${W:?}"' EXIT
pass=0; fail=0
ok()  { pass=$((pass + 1)); [ "$QUIET" = 1 ] || echo "  ok   $1"; }
bad() { fail=$((fail + 1)); echo "  FAIL $1"; }
expect() { # label expected actual
    if [ "$2" = "$3" ]; then ok "$1"; else bad "$1 (expected '$2', got '$3')"; fi
}

extract_gate() { awk '/^# installer_gate --/{f=1} f{print} f&&/^}/{exit}' "$1"; }

# ── 2. the two copies agree ────────────────────────────────────────────────
extract_gate "$APPLY" > "$W/gate.apply"
extract_gate "$CHECK" > "$W/gate.check"
if [ -s "$W/gate.apply" ] && cmp -s "$W/gate.apply" "$W/gate.check"; then
    ok "installer_gate is byte-identical in both scripts"
else
    bad "installer_gate missing or different between $(basename "$APPLY") and $(basename "$CHECK")"
fi

# ── 1. the function ────────────────────────────────────────────────────────
mk_manifest() { # file latest "ver:flag ..."   flag 1 = requires_installer
    local out="$1" latest="$2" spec="$3" v f first=1
    { printf '{"serial": 9, "latest": "%s", "releases": [' "$latest"
      for e in $spec; do
          v="${e%%:*}"; f="${e##*:}"
          [ "$first" = 1 ] || printf ','
          first=0
          printf '{"version":"%s","codename":"T","severity":"fix","requires_installer":%s,"min_upgrade_from":"0.0.0","app_tarball":{"path":"assets/ilexa-app.tar.gz","sha256":"00"}}' \
              "$v" "$([ "$f" = 1 ] && echo true || echo false)"
      done
      printf ']}\n'; } > "$out"
}
M="$W/m.json"
mk_manifest "$M" 1.0.35 "1.0.35:0 1.0.34:0 1.0.33:1 1.0.32:1 1.0.31:0 1.0.30:0"
echo 'not json' > "$W/bad.json"
echo '{"latest":"1.0.1"}' > "$W/norel.json"

if [ -s "$W/gate.apply" ]; then
    # shellcheck disable=SC1091
    . "$W/gate.apply"
    g() { installer_gate "$@" 2>/dev/null; echo "rc=$?"; }
    expect "1.0.31 -> 1.0.34 stops at the first flagged release" "1.0.32rc=0" "$(g "$M" 1.0.31 1.0.34 | tr -d '\n')"
    expect "1.0.32 -> 1.0.34 still stops at 1.0.33"              "1.0.33rc=0" "$(g "$M" 1.0.32 1.0.34 | tr -d '\n')"
    expect "1.0.32 -> 1.0.33 includes the target itself"         "1.0.33rc=0" "$(g "$M" 1.0.32 1.0.33 | tr -d '\n')"
    expect "1.0.33 -> 1.0.35 is clear"                           "rc=0"       "$(g "$M" 1.0.33 1.0.35 | tr -d '\n')"
    expect "1.0.30 -> 1.0.31 is clear"                           "rc=0"       "$(g "$M" 1.0.30 1.0.31 | tr -d '\n')"
    expect "same version is clear (installed bound is exclusive)" "rc=0"      "$(g "$M" 1.0.33 1.0.33 | tr -d '\n')"
    expect "empty target means the manifest's latest"            "1.0.32rc=0" "$(g "$M" 1.0.31 "" | tr -d '\n')"
    expect "unreadable installed version gates, never passes"    "1.0.32rc=0" "$(g "$M" garbage 1.0.35 | tr -d '\n')"
    expect "empty installed version gates too"                   "1.0.32rc=0" "$(g "$M" "" 1.0.35 | tr -d '\n')"

    mk_manifest "$W/num.json" 1.0.100 "1.0.100:0 1.0.10:1 1.0.9:0"
    expect "ordering is numeric: 1.0.10 is after 1.0.9"          "1.0.10rc=0" "$(g "$W/num.json" 1.0.9 1.0.100 | tr -d '\n')"
    expect "ordering is numeric: 1.0.100 is after 1.0.10"        "rc=0"       "$(g "$W/num.json" 1.0.10 1.0.100 | tr -d '\n')"

    expect "unparseable manifest is an error"                    "rc=1"       "$(g "$W/bad.json" 1.0.1 1.0.2 | tr -d '\n')"
    expect "manifest without releases is an error"               "rc=1"       "$(g "$W/norel.json" 1.0.1 1.0.2 | tr -d '\n')"
    expect "malformed target is an error"                        "rc=1"       "$(g "$M" 1.0.31 'x;y' | tr -d '\n')"
    printf '{"latest":"1.0.2","releases":["junk",{"version":"../../x","requires_installer":true},{"requires_installer":true},{"version":"1.0.2","requires_installer":false}]}' > "$W/junk.json"
    expect "junk and malformed entries are ignored"              "rc=0"       "$(g "$W/junk.json" 1.0.1 1.0.2 | tr -d '\n')"
else
    bad "installer_gate not found in $(basename "$APPLY") -- function cases skipped"
fi

# ── shared stubs for 3 and 4 ───────────────────────────────────────────────
mkdir -p "$W/bin" "$W/srv"
cat > "$W/bin/curl" <<'EOF'
#!/bin/bash
# Serves $SRV/<basename of the URL>. Honours -o, -D and -w '%{http_code}';
# anything not present answers like a 404 under curl -f.
out=""; hdr=""; wfmt=""; url=""
while [ $# -gt 0 ]; do
    case "$1" in
        -o) out="$2"; shift ;;
        -D) hdr="$2"; shift ;;
        -w) wfmt="$2"; shift ;;
        -H|--max-time|--retry|--max-filesize|--proto) shift ;;
        https://*) url="$1" ;;
    esac
    shift
done
f="$SRV/${url##*/}"
if [ ! -f "$f" ]; then [ -n "$wfmt" ] && printf '404'; exit 22; fi
[ -n "$hdr" ] && printf 'HTTP/2 200\r\netag: "t1"\r\n\r\n' > "$hdr"
cat "$f" > "${out:-/dev/stdout}"
[ -n "$wfmt" ] && printf '200'
exit 0
EOF
for s in mail sendmail logger; do
    printf '#!/bin/sh\necho "%s $*" >> "%s/called"\nexit 0\n' "$s" "$W" > "$W/bin/$s"
done
chmod 0755 "$W/bin/curl" "$W/bin/mail" "$W/bin/sendmail" "$W/bin/logger"

openssl genpkey -algorithm ed25519 -out "$W/key.pem" 2>/dev/null
openssl pkey -in "$W/key.pem" -pubout -out "$W/pub.pem" 2>/dev/null
publish() { # manifest -> served and signed
    cp "$1" "$W/srv/RELEASES.json"
    openssl pkeyutl -sign -inkey "$W/key.pem" -rawin -in "$W/srv/RELEASES.json" -out "$W/srv/RELEASES.json.sig"
}
export SRV="$W/srv"
URL=https://updates.test.invalid/RELEASES.json

# ── 3. the applier's fetch phase ───────────────────────────────────────────
{ awk '/^verify_sig\(\) \{/{f=1} f{print} f&&/^}/{exit}' "$APPLY"
  extract_gate "$APPLY"
  awk '/^phase_fetch_verify\(\) \{/{f=1} f{print} f&&/^}/{exit}' "$APPLY"
} > "$W/fetch.sh"
# The assignments are read by the sourced phase_fetch_verify, and the stubbed
# log/write_run_state/fail are called from it, which shellcheck cannot see.
# shellcheck disable=SC2034,SC2317,SC2030
apply_fetch() { # from target -> the error token, or ERR_TARBALL_FETCH past the gate
    ( PATH="$W/bin:$PATH"
      log() { :; }; write_run_state() { :; }
      fail() { echo "$2"; exit 0; }
      PUBKEY_FILE="$W/pub.pem"; MANIFEST_URL="$URL"; SIG_URL="$URL.sig"
      TARBALL_BASE=https://updates.test.invalid; STAGE_DIR="$W/stage"
      QA_MANIFEST_RETRY_DELAYS=0
      FROM_VERSION="$1"; TARGET_VER="$2"
      # shellcheck disable=SC1091
      . "$W/fetch.sh"
      phase_fetch_verify )
}
if grep -q '^phase_fetch_verify() {' "$W/fetch.sh"; then
    publish "$M"
    # No tarball is served, so getting as far as fetching one means the
    # manifest checks -- the gate among them -- all passed.
    expect "apply 1.0.31 -> unflagged 1.0.34 is refused"   ERR_REQUIRES_INSTALLER "$(apply_fetch 1.0.31 1.0.34)"
    expect "apply 1.0.32 -> 1.0.35 is refused (1.0.33)"    ERR_REQUIRES_INSTALLER "$(apply_fetch 1.0.32 1.0.35)"
    expect "apply 1.0.31 -> flagged target is refused"     ERR_REQUIRES_INSTALLER "$(apply_fetch 1.0.31 1.0.33)"
    expect "apply 1.0.33 -> 1.0.35 passes the gate"        ERR_TARBALL_FETCH      "$(apply_fetch 1.0.33 1.0.35)"
    expect "apply 1.0.30 -> 1.0.31 passes the gate"        ERR_TARBALL_FETCH      "$(apply_fetch 1.0.30 1.0.31)"
    expect "the gate sits after signature verification"    ERR_MANIFEST_SIG \
        "$(printf ' ' >> "$W/srv/RELEASES.json"; apply_fetch 1.0.31 1.0.34; publish "$M")"
else
    bad "phase_fetch_verify not found in $(basename "$APPLY") -- applier cases skipped"
fi

# ── 4. the update check, end to end ────────────────────────────────────────
sed "s#/etc/ilexa/alerts.conf#$W/alerts.conf#g" "$CHECK" > "$W/check.sh"
: > "$W/alerts.conf"
# shellcheck disable=SC2031,SC2016
check_flag() { # installed -> requires_installer from the cache it writes, after its stdout
    rm -rf "$W/cache"; mkdir -p "$W/cache"
    printf '%s\n' "$1" > "$W/VERSION"
    local out
    out="$(PATH="$W/bin:$PATH" QA_CACHE_DIR="$W/cache" QA_VERSION_FILE="$W/VERSION" \
           QA_UPDATE_PUBKEY="$W/pub.pem" QA_UPDATE_MANIFEST_URL="$URL" bash "$W/check.sh" --now 2>&1)"
    printf '%s ' "$out"
    php -r '$c=json_decode((string)@file_get_contents($argv[1]),true); echo is_array($c) ? var_export($c["latest"]["requires_installer"] ?? null, true) : "nocache";' \
        "$W/cache/update-status.cache.json"
}
publish "$M"
expect "check: 1.0.31 with 1.0.32/33 pending says needs installer" "OK true"  "$(check_flag 1.0.31)"
expect "check: 1.0.33 with only unflagged pending does not"        "OK false" "$(check_flag 1.0.33)"
mk_manifest "$W/m2.json" 1.0.33 "1.0.33:1 1.0.32:0"
publish "$W/m2.json"
expect "check: a flagged latest still says needs installer"        "OK true"  "$(check_flag 1.0.32)"
publish "$W/bad.json"
expect "check: unusable manifest is reported, not cached"          "ERR_MANIFEST_SHAPE nocache" "$(check_flag 1.0.31)"

if [ -s "$W/called" ]; then bad "a stub mailer/logger was invoked: $(head -n1 "$W/called")"; else ok "no mail or syslog call was made"; fi

[ "$QUIET" = 1 ] && [ "$fail" = 0 ] && exit 0
echo "check-update-installer-gate: $pass passed, $fail failed"
[ "$fail" = 0 ]
