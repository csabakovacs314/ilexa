#!/usr/bin/env php
<?php
// Static lint over db/migrations/*.sql -- the checks that don't need a live
// database connection (checksum-drift detection needs one and is done at
// runtime by qa-db-migrate.php/migration_checksum_drift(), not here).
//
// Enforces the rules db/migrations/README.md documents:
//   1. every file parses (header present, -- @UP section present)
//   2. filename NNNN matches the header's ilexa-migration: value
//   3. no two files claim the same id
//   4. store is one of mysql|iocs|logins; kind is ddl|data; reversible is yes|no
//   5. mysql migrations only name tables in MIGRATION_MYSQL_TABLE_ALLOWLIST
//      (in particular: never postfix.last_login -- that's Dovecot's table)
//   6. every mysql DDL statement (CREATE/ALTER/DROP TABLE, ADD/DROP COLUMN,
//      ADD/DROP INDEX) is IF NOT EXISTS/IF EXISTS guarded -- MySQL DDL is
//      not transactional, so this guard IS the atomicity story, not a style
//      preference; see README.md
//
// Usage: tools/check-migrations.php [--quiet]
$root = dirname(__DIR__);
$quiet = in_array('--quiet', $argv, true);
require "$root/src/migrate.php";

$errors = [];
$seenIds = [];

foreach (glob(MIGRATIONS_DIR . '/[0-9][0-9][0-9][0-9]_*.sql') ?: [] as $path) {
    $base = basename($path);
    if (!preg_match('/^(\d{4})_/', $base, $m)) {
        $errors[] = "$base: filename does not start with NNNN_";
        continue;
    }
    $fileId = (int)$m[1];
    $raw = file_get_contents($path);
    $parsed = _migration_parse($raw);

    if (!empty($parsed['error'])) { $errors[] = "$base: " . $parsed['error']; continue; }

    $h = $parsed['header'];
    $headerId = $h['ilexa-migration'] ?? null;
    if ($headerId !== $fileId) {
        $errors[] = "$base: filename id $fileId does not match header 'ilexa-migration: " . ($headerId ?? '(missing)') . "'";
    }
    if (isset($seenIds[$fileId])) {
        $errors[] = "$base: duplicate id $fileId (also used by " . basename($seenIds[$fileId]) . ")";
    }
    $seenIds[$fileId] = $path;

    $store = $h['store'] ?? '';
    if (!in_array($store, MIGRATION_STORES, true)) {
        $errors[] = "$base: unknown store '$store' (expected one of " . implode('|', MIGRATION_STORES) . ")";
    }
    if (!in_array($h['kind'] ?? '', ['ddl', 'data'], true)) {
        $errors[] = "$base: kind must be 'ddl' or 'data', got '" . ($h['kind'] ?? '(missing)') . "'";
    }
    if (!in_array($h['reversible'] ?? '', ['yes', 'no'], true)) {
        $errors[] = "$base: reversible must be 'yes' or 'no', got '" . ($h['reversible'] ?? '(missing)') . "'";
    }
    $tables = array_filter(array_map('trim', explode(',', $h['tables'] ?? '')));
    if (!$tables) $errors[] = "$base: 'tables' header is empty";

    if ($store === 'mysql') {
        foreach ($tables as $t) {
            if (!in_array($t, MIGRATION_MYSQL_TABLE_ALLOWLIST, true)) {
                $errors[] = "$base: table '$t' is not in the mysql migration allowlist (" . implode(',', MIGRATION_MYSQL_TABLE_ALLOWLIST) . ") -- see README.md";
            }
        }
        foreach (migration_statements($parsed['up']) as $s) {
            $sql = $s['sql'];
            if ($sql === '' || $sql === ';') continue;
            // DDL keyword present without an IF [NOT] EXISTS guard anywhere
            // in the same statement -- catches the un-idempotent case this
            // check exists for without trying to be a full SQL parser.
            if (preg_match('/\b(CREATE\s+TABLE|ADD\s+COLUMN|DROP\s+COLUMN|ADD\s+INDEX|DROP\s+INDEX|DROP\s+TABLE)\b/i', $sql)
                && !preg_match('/\bIF\s+(NOT\s+)?EXISTS\b/i', $sql)) {
                $errors[] = "$base: mysql DDL statement missing IF [NOT] EXISTS: " . substr(preg_replace('/\s+/', ' ', $sql), 0, 80);
            }
        }
    } else {
        // sqlite: a @GUARD is only meaningful/needed on ALTER TABLE ... ADD
        // COLUMN (the one thing SQLite has no native IF NOT EXISTS for).
        // Flag an ADD COLUMN with no guard as a likely oversight, not a hard
        // error -- CREATE TABLE/INDEX IF NOT EXISTS cover the common case.
        foreach (migration_statements($parsed['up']) as $s) {
            if (preg_match('/\bADD\s+COLUMN\b/i', $s['sql']) && $s['guard'] === null) {
                $errors[] = "$base: ADD COLUMN with no preceding -- @GUARD: comment (SQLite has no native IF NOT EXISTS for this) -- " . substr(preg_replace('/\s+/', ' ', $s['sql']), 0, 80);
            }
        }
    }
}

if ($errors) {
    foreach ($errors as $e) echo "check-migrations: $e\n";
    fwrite(STDERR, "check-migrations: " . count($errors) . " problem(s)\n");
    exit(1);
}
if (!$quiet) echo "check-migrations: " . count($seenIds) . " migration(s) checked -- clean\n";
exit(0);
