#!/usr/bin/env python3
"""Tests for install/check-breaches.py -- the multi-provider mailbox sweep.

THE BUG CLASS THIS EXISTS FOR. The sweep's job is deciding what an answer
means, and its most dangerous failure is quiet: recording a mailbox as clean
when the lookup never actually succeeded. That turns "we could not check this
mailbox" into "this mailbox is fine" on the dashboard, and nothing about the
display would look wrong. Sections 1-7 pin that distinction.

Sections 8-11 cover the merge layer, where the equivalent silent failure is
losing which provider said what -- source attribution is the entire reason a
multi-provider sweep is worth the extra external data flow -- and merging two
breaches that are not the same breach.

Runs the real functions against a stub gateway; makes no network calls and
never touches the live cache file or the real ledger.

  tools/check-breach-sweep.py [--quiet]
"""

import importlib.util
import json
import stat
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
QUIET = '--quiet' in sys.argv

spec = importlib.util.spec_from_file_location(
    'breach_sweep', ROOT / 'install' / 'check-breaches.py')
cb = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cb)

failures = []
passed = 0


def ok(what, cond):
    global passed
    if cond:
        passed += 1
        if not QUIET:
            print(f'  ok   {what}')
        return
    failures.append(what)
    print(f'  FAIL {what}')


tmp = Path(tempfile.mkdtemp(prefix='qa-breach-test-'))


def stub(body, exit_code=0, to_stderr=False, sleep=0):
    """Write a stub gateway that prints `body` and exits with `exit_code`."""
    path = tmp / 'stub-gateway'
    stream = 'stderr' if to_stderr else 'stdout'
    path.write_text(
        '#!/usr/bin/env python3\n'
        'import sys, time\n'
        f'time.sleep({sleep})\n'
        f'sys.{stream}.write({body!r})\n'
        f'sys.exit({exit_code})\n')
    path.chmod(path.stat().st_mode | stat.S_IXUSR)
    cb.LOOKUP = str(path)
    return path


# ---- 1. a successful breach lookup ---------------------------------------
stub(json.dumps({'verdict': 'suspicious', 'detail': '2 breaches',
                 'raw': {'query': 'a@b.com', 'exposed': True, 'latest_breach': 2016,
                         'breaches': [{'name': 'Adobe', 'year': 2013, 'data': 'Email'},
                                      {'name': 'LinkedIn', 'year': 2016, 'data': 'Email'}],
                         'stealer': None}}))
r = cb.check_email('xposedornot', 'a@b.com')
ok('exposed address is SUCCESS', r['status'] == cb.ST_SUCCESS)
ok('exposed flag is set', r['exposed'] is True)
ok('breaches come through', [b['name'] for b in r['breaches']] == ['Adobe', 'LinkedIn'])
ok('a success carries no error key', 'error' not in r)

# ---- 2. a successful lookup with nothing found ---------------------------
stub(json.dumps({'verdict': 'clean', 'detail': 'no known breach',
                 'raw': {'exposed': False, 'breaches': [], 'stealer': None}}))
r = cb.check_email('leakcheck', 'a@b.com')
ok('clean address is NOT_FOUND, not SUCCESS', r['status'] == cb.ST_NOT_FOUND)
ok('clean address is not marked exposed', r['exposed'] is False)

# ---- 3. an infostealer hit is SUCCESS but NOT "exposed" ------------------
# 'exposed' means breach-corpus membership. An infostealer infection is a
# different finding and must not silently inflate the breach count.
stub(json.dumps({'verdict': 'suspicious', 'detail': '1 infostealer infection',
                 'raw': {'exposed': False, 'breaches': [],
                         'stealer': {'infected': True, 'latest': '2026-08-20T00:00:00.000Z',
                                     'infections': [{'date': '2026-08-20T00:00:00.000Z',
                                                     'computer': 'PC1', 'os': 'Windows 11',
                                                     'antivirus': []}],
                                     'corporate_services': 3, 'user_services': 9}}}))
r = cb.check_email('hudsonrock', 'a@b.com')
ok('an infostealer hit is SUCCESS', r['status'] == cb.ST_SUCCESS)
ok('an infostealer hit does NOT set exposed', r['exposed'] is False)
ok('the stealer payload is carried', r['stealer']['infected'] is True)
ok('an infostealer hit adds no breaches', r['breaches'] == [])

# ---- 4. every failure keeps exposed False AND carries an error -----------
cases = [
    ('budget refusal',
     {'error': 'xposedornot: free-tier budget spent (100/100)'}, cb.ST_QUOTA),
    ('interactive reserve',
     {'error': 'xposedornot: remaining budget is reserved for interactive lookups (12 left, reserve 20)'},
     cb.ST_QUOTA),
    # Our own pacing. The message contains the words "rate limited", so this
    # pins that it is NOT read as the provider pushing back -- the distinction
    # the whole hourly-window fix rests on.
    ('local hourly pacing',
     {'error': 'xposedornot: rate limited by the local hour window (22/22)'
               ' - retry after 2026-08-27 14:30:00Z'}, cb.ST_PACED),
    ('local per-second pacing',
     {'error': 'leakcheck: rate limited by the local second window (1/1)'}, cb.ST_PACED),
    ('provider rate limit',
     {'error': 'xposedornot: provider rate-limited us despite the local budget'},
     cb.ST_RATE_LIMITED),
    ('transport failure', {'error': 'no response from leakcheck'}, cb.ST_TIMEOUT),
    ('bad address', {'error': 'invalid email'}, cb.ST_INVALID),
    ('unparseable provider response',
     {'error': 'hudsonrock: invalid response'}, cb.ST_PROVIDER),
    ('missing quota library',
     {'error': 'quota ledger not installed: /usr/local/sbin/qa-quota-lib.php'}, cb.ST_NETWORK),
]
for label, body, want in cases:
    stub(json.dumps(body), exit_code=1)
    r = cb.check_email('xposedornot', 'a@b.com')
    ok(f'{label} -> {want}', r['status'] == want)
    ok(f'{label} is never reported as exposed', r['exposed'] is False)
    ok(f'{label} carries an error', bool(r.get('error')))

# ---- 5. which statuses stop a provider's turn, and which are routine -----
ok('local pacing stops the provider', cb.ST_PACED in cb.STOP_STATUSES)
ok('budget exhaustion stops the provider', cb.ST_QUOTA in cb.STOP_STATUSES)
ok('a provider rate limit stops the provider', cb.ST_RATE_LIMITED in cb.STOP_STATUSES)
ok('an ordinary timeout does NOT stop the provider', cb.ST_TIMEOUT not in cb.STOP_STATUSES)
ok('a provider error does NOT stop the provider', cb.ST_PROVIDER not in cb.STOP_STATUSES)
ok('local pacing is routine, not alarming', cb.ST_PACED not in cb.ALARMING_STATUSES)
ok('daily exhaustion is routine, not alarming', cb.ST_QUOTA not in cb.ALARMING_STATUSES)
ok('the provider overruling our ledger IS alarming',
   cb.ST_RATE_LIMITED in cb.ALARMING_STATUSES)

# ---- 6. the gateway failing outside its own contract ---------------------
for label, body, code in [('non-JSON output', 'this is not json', 1),
                          ('empty stdout', '', 2),
                          ('a JSON array', json.dumps(['unexpected']), 0)]:
    stub(body, exit_code=code)
    r = cb.check_email('leakcheck', 'a@b.com')
    ok(f'{label} is a provider error, not a clean result',
       r['status'] == cb.ST_PROVIDER and bool(r.get('error')))

stub(json.dumps({'verdict': 'clean', 'detail': 'x', 'raw': 'not-an-object'}))
r = cb.check_email('leakcheck', 'a@b.com')
ok('a malformed raw member yields no breaches rather than a crash',
   r['breaches'] == [] and r['status'] == cb.ST_NOT_FOUND)

# ---- 7. missing helper / hung helper -------------------------------------
cb.LOOKUP = str(tmp / 'definitely-not-here')
r = cb.check_email('xposedornot', 'a@b.com')
ok('a missing gateway is a network error, not a clean result',
   r['status'] == cb.ST_NETWORK and bool(r.get('error')))

stub('', sleep=3)
cb.CALL_TIMEOUT = 1
r = cb.check_email('xposedornot', 'a@b.com')
ok('a hung lookup times out rather than blocking the sweep',
   r['status'] == cb.ST_TIMEOUT and bool(r.get('error')))

# ══ merge layer ═══════════════════════════════════════════════════════════

# ---- 8. breach-name normalisation ----------------------------------------
n = cb.normalize_breach
ok('normalise: case is folded', n('Adobe') == n('adobe') == 'adobe')
ok('normalise: a trailing .com is stripped so Adobe == Adobe.com',
   n('Adobe') == n('Adobe.com'))
ok('normalise: multi-part suffixes are handled', n('arthritis.com.au') == 'arthritis')
ok('normalise: punctuation is dropped', n('Last.fm-2012') == 'lastfm2012')
ok('normalise: empty stays empty', n('') == '' and n('   ') == '')
# The deliberate MISS. A suffix not at the end is not stripped, so this stays
# a separate row rather than being fuzzily folded into "Twitter".
ok('normalise: a mid-string suffix is NOT stripped, so near-misses stay separate',
   n('Twitter.com (scraping data)') != n('Twitter'))
ok('normalise: unrelated names never collide', n('Adobe') != n('Adobe Systems'))

# ---- 9. merging across providers -----------------------------------------
merged = cb.merge_row({
    'xposedornot': {'status': cb.ST_SUCCESS, 'checked_at': '2026-08-27 10:00:00',
                    'breaches': [{'name': 'Adobe', 'year': 2013, 'data': 'Email;Password'},
                                 {'name': 'LinkedIn', 'year': 2016, 'data': 'Email'}]},
    'leakcheck':   {'status': cb.ST_SUCCESS, 'checked_at': '2026-08-27 10:01:00',
                    'breaches': [{'name': 'Adobe.com', 'year': 2013, 'data': ''},
                                 {'name': 'LinkedIn', 'year': 2016, 'data': ''},
                                 {'name': 'Dropbox', 'year': 2012, 'data': ''}]},
})
names = [b['name'] for b in merged['breaches']]
ok('merge: three distinct breaches from two providers', len(merged['breaches']) == 3)
ok('merge: the address is exposed', merged['exposed'] is True)
by = {cb.normalize_breach(b['name']): b for b in merged['breaches']}
ok('merge: Adobe and Adobe.com become ONE finding with two sources',
   by['adobe']['sources'] == ['leakcheck', 'xposedornot'])
ok('merge: LinkedIn is corroborated by both',
   by['linkedin']['sources'] == ['leakcheck', 'xposedornot'])
ok('merge: a single-source breach keeps its one source',
   by['dropbox']['sources'] == ['leakcheck'])
ok('merge: the more specific display name wins', by['adobe']['name'] == 'Adobe.com')
# ...but the LINK must be built from XposedOrNot's own spelling, because its
# /breach/<Name> pages use that. This was a live 404: the merged display name
# "000webhost.com" gave /breach/000webhost.com (404) where XposedOrNot's own
# "000webhost" gives 200 -- and it broke exactly the corroborated findings.
ok('merge: XposedOrNot\'s own spelling is kept for its breach URL',
   by['adobe']['url_name'] == 'Adobe')
ok('merge: a leakcheck-only finding has no xposedornot url_name',
   'url_name' not in by['dropbox'])
m1 = cb.merge_row({'xposedornot': {'status': cb.ST_SUCCESS,
                                   'breaches': [{'name': 'Last.fm', 'year': 2012}]}})
ok('merge: a single-source xposedornot finding records its url_name',
   m1['breaches'][0]['url_name'] == 'Last.fm')
ok('merge: data classes survive from whichever provider had them',
   by['adobe']['data'] == 'Email;Password')
ok('merge: latest_breach is the newest year', merged['latest_breach'] == '2016')
ok('merge: newest breach sorts first', names[0] == 'LinkedIn')

# ---- 10. a failed provider contributes NOTHING ---------------------------
# The single most important property here: a timeout must not be able to
# produce, or contribute to, a clean-looking result.
merged = cb.merge_row({
    'xposedornot': {'status': cb.ST_TIMEOUT, 'error': 'no response', 'breaches': []},
    'leakcheck':   {'status': cb.ST_SUCCESS, 'breaches': [{'name': 'Adobe', 'year': 2013}]},
})
ok('merge: a failed provider is not listed as a source',
   merged['breaches'][0]['sources'] == ['leakcheck'])
merged = cb.merge_row({
    'xposedornot': {'status': cb.ST_TIMEOUT, 'error': 'no response', 'breaches': []},
})
ok('merge: only a failure means not exposed, and no breaches invented',
   merged['exposed'] is False and merged['breaches'] == [])
# A failing provider that ALSO carries stale breaches must not resurrect them.
merged = cb.merge_row({
    'leakcheck': {'status': cb.ST_QUOTA, 'error': 'budget spent',
                  'breaches': [{'name': 'Ghost', 'year': 2020}]},
})
ok('merge: breaches attached to a failed result are ignored', merged['breaches'] == [])

# ---- 11. stealer findings stay out of the breach list --------------------
merged = cb.merge_row({
    'hudsonrock': {'status': cb.ST_SUCCESS,
                   'stealer': {'infected': True, 'latest': '2026-08-20T00:00:00.000Z',
                               'infections': [{'date': '2026-08-20T00:00:00.000Z'}]},
                   'breaches': []},
    'leakcheck':  {'status': cb.ST_SUCCESS, 'breaches': [{'name': 'Adobe', 'year': 2013}]},
})
ok('merge: an infostealer finding never becomes a breach', len(merged['breaches']) == 1)
ok('merge: the stealer finding is kept in its own key',
   merged['stealer'] is not None and merged['stealer']['infected'] is True)
ok('merge: the stealer finding records which provider reported it',
   merged['stealer']['source'] == 'hudsonrock')
ok('merge: no stealer means the key is None',
   cb.merge_row({'leakcheck': {'status': cb.ST_NOT_FOUND, 'breaches': []}})['stealer'] is None)

# malformed provider blocks must not crash the merge
for label, bp in [('None', None), ('empty', {}),
                  ('junk values', {'x': 'nope', 'y': 42}),
                  ('junk breaches', {'leakcheck': {'status': cb.ST_SUCCESS,
                                                   'breaches': ['str', None, {}, {'name': ''}]}})]:
    m = cb.merge_row(bp)
    ok(f'merge: {label} yields an empty, non-exposed result',
       m['exposed'] is False and m['breaches'] == [])

# ---- 11b. grouping names that mean the same service ----------------------
# Stage one keys on the exact normalised name. This second pass folds the two
# shapes that actually occur between these providers, and its danger is the
# opposite of stage one's: grouping two things that are NOT the same incident.
m = cb.merge_row({
    'xposedornot': {'status': cb.ST_SUCCESS, 'breaches': [
        {'name': 'CouponMom', 'year': 2014, 'data': 'Email'},
        {'name': 'Twitter-Scraped', 'year': 2021}]},
    'leakcheck': {'status': cb.ST_SUCCESS, 'breaches': [
        {'name': 'CouponMom / ArmorGames', 'year': 2014},
        {'name': 'Twitter.com (scraping data)', 'year': 2022}]},
})
ok('group: six provider names collapse to two services', len(m['breaches']) == 2)
byn = {b['name']: b for b in m['breaches']}
ok('group: a name one provider added to is folded in', 'CouponMom' in byn)
ok('group: the canonical name is the smaller-core one, never invented',
   'CouponMom / ArmorGames' not in byn)
ok('group: a dump-qualifier difference is folded in', 'Twitter-Scraped' in byn)
ok('group: both providers are credited on the grouped finding',
   byn['CouponMom']['sources'] == ['leakcheck', 'xposedornot'])
ok('group: every provider\'s exact wording is preserved',
   sorted(byn['CouponMom']['alias_names']) == ['CouponMom', 'CouponMom / ArmorGames'])
ok('group: each wording records who used it',
   byn['CouponMom']['alias_names']['CouponMom / ArmorGames'] == ['leakcheck'])
ok('group: the earliest year wins', byn['Twitter-Scraped']['year'] == 2021)
ok('group: latest_breach is recomputed from what actually survived',
   m['latest_breach'] == '2021')

# THE FALSE-POSITIVE GUARDS. First-token matching would also have passed the
# cases above and is a trap; these are the ones it would get wrong.
def names_of(pairs):
    return sorted(b['name'] for b in cb.merge_row(
        {'p': {'status': cb.ST_SUCCESS,
               'breaches': [{'name': n, 'year': y} for n, y in pairs]}})['breaches'])

ok('group: Last.fm and LastPass are NOT the same service',
   names_of([('Last.fm', 2012), ('LastPass', 2015)]) == ['Last.fm', 'LastPass'])
ok('group: two unrelated services sharing a word stay apart',
   names_of([('Adobe', 2013), ('Adobe Reader Forum', 2019)]) != ['Adobe'])
ok('group: a name whose tokens are ALL qualifiers is not collapsed with others',
   len(names_of([('Combolist', 2020), ('Dump', 2021)])) == 2)

# A single finding must not sprout alias baggage.
m1 = cb.merge_row({'p': {'status': cb.ST_SUCCESS,
                         'breaches': [{'name': 'Adobe', 'year': 2013}]}})
ok('group: a single-source finding carries no alias_names',
   'alias_names' not in m1['breaches'][0])

# Grouping must not resurrect a failed provider's data.
m2 = cb.merge_row({
    'xposedornot': {'status': cb.ST_TIMEOUT, 'error': 'x',
                    'breaches': [{'name': 'CouponMom', 'year': 2014}]},
    'leakcheck': {'status': cb.ST_SUCCESS,
                  'breaches': [{'name': 'CouponMom / ArmorGames', 'year': 2014}]},
})
ok('group: a failed provider contributes no name to the group',
   m2['breaches'][0]['sources'] == ['leakcheck']
   and 'alias_names' not in m2['breaches'][0])

# ---- 12. schema-1 rows upgrade on read -----------------------------------
old = {'exposed': True, 'latest_breach': '2020', 'checked_at': '2026-08-26 02:00:01',
       'breaches': [{'name': 'Adobe', 'year': 2013, 'data': 'Email'}]}
up = cb.upgrade_row(old)
ok('upgrade: a schema-1 row gains a by_provider block',
   'xposedornot' in up['by_provider'])
ok('upgrade: its breaches are attributed to xposedornot',
   up['by_provider']['xposedornot']['breaches'][0]['name'] == 'Adobe')
ok('upgrade: an exposed schema-1 row becomes SUCCESS',
   up['by_provider']['xposedornot']['status'] == cb.ST_SUCCESS)
ok('upgrade: the original flat fields are preserved for the dashboard',
   up['exposed'] is True and up['checked_at'] == '2026-08-26 02:00:01')
m = cb.merge_row(up['by_provider'])
ok('upgrade: the upgraded row re-merges to the same finding',
   len(m['breaches']) == 1 and m['breaches'][0]['sources'] == ['xposedornot'])

clean_old = {'exposed': False, 'breaches': [], 'checked_at': '2026-08-26 02:00:01'}
ok('upgrade: a clean schema-1 row becomes NOT_FOUND',
   cb.upgrade_row(clean_old)['by_provider']['xposedornot']['status'] == cb.ST_NOT_FOUND)
err_old = {'exposed': False, 'breaches': [], 'error': 'HTTP 500',
           'checked_at': '2026-08-26 02:00:01'}
up = cb.upgrade_row(err_old)
ok('upgrade: an errored schema-1 row does NOT become a clean answer',
   up['by_provider']['xposedornot']['status'] == cb.ST_PROVIDER)
ok('upgrade: and therefore contributes nothing to the merge',
   cb.merge_row(up['by_provider'])['breaches'] == [])
ok('upgrade: a never-checked row gets an empty provider block',
   cb.upgrade_row({})['by_provider'] == {})
ok('upgrade: a schema-2 row is returned untouched',
   cb.upgrade_row({'by_provider': {'leakcheck': {'status': cb.ST_NOT_FOUND}}})
   ['by_provider'] == {'leakcheck': {'status': cb.ST_NOT_FOUND}})
ok('upgrade: a non-dict row does not crash', cb.upgrade_row('nonsense')['by_provider'] == {})

# ---- teardown ------------------------------------------------------------
for f in tmp.iterdir():
    f.unlink()
tmp.rmdir()

if not QUIET or failures:
    print(f'\ncheck-breach-sweep: {passed} passed, {len(failures)} failed')
sys.exit(1 if failures else 0)
