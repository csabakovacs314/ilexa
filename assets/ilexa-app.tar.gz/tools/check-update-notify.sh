#!/usr/bin/env bash
# Security-release notifier: notify_security_release() from
# install/qa-update-check.sh, run in isolation against a synthetic cache.
#
# The bug class it guards: the notice silently not being sent while the
# once-per-version latch records it as sent. That is what happened from the
# day the notifier shipped -- the script runs under LC_ALL=C, s-nail refuses a
# non-ASCII body in that locale, and the latch was written regardless.
#
# Nothing here can send real mail. PATH holds only stubs plus links to the few
# tools the function needs; the one case that runs the real s-nail pins its
# MTA to a stub with -S mta=. The alerts.conf path is redirected to a scratch
# file, so the host's own recipient is never read.
#
#   tools/check-update-notify.sh [--quiet] [path/to/qa-update-check.sh]
set -uo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
quiet=0
[ "${1:-}" = "--quiet" ] && { quiet=1; shift; }
SCRIPT="${1:-$HERE/install/qa-update-check.sh}"

W="$(mktemp -d)"
trap 'rm -rf "$W"' EXIT
pass=0; fail=0
ok() { # what cond-exit-status [detail]
    if [ "$2" = 0 ]; then pass=$((pass+1)); [ "$quiet" = 1 ] || echo "  ok   $1"
    else fail=$((fail+1)); echo "  FAIL $1${3:+  -- $3}"; fi
}

awk '/^notify_security_release\(\) \{/{f=1} f{print} f&&/^}/{exit}' "$SCRIPT" \
    | sed "s#/etc/ilexa/alerts.conf#$W/alerts.conf#g" > "$W/fn.sh"
if ! grep -qs '^notify_security_release() {' "$W/fn.sh"; then
    echo "check-update-notify: notify_security_release() not found in $SCRIPT"; exit 1
fi

# Tools the function needs, and nothing that can reach a real MTA.
mkdir -p "$W/base" "$W/cache"
for t in php cat grep head tr mktemp rm; do
    p="$(command -v "$t")" || { echo "check-update-notify: $t not found"; exit 1; }
    ln -s "$p" "$W/base/$t"
done
cat > "$W/base/logger" <<EOF
#!/bin/sh
shift 2; printf '%s\n' "\$*" >> "$W/log"
EOF
cat > "$W/base/hostname" <<'EOF'
#!/bin/sh
echo mx.test.invalid
EOF
cat > "$W/mta" <<EOF
#!/bin/sh
{ echo "ARGS: \$*"; cat; } > "$W/mta.out"
EOF
chmod +x "$W/base/logger" "$W/base/hostname" "$W/mta"

# Per-case stubs. mail: ok | fail | snail (the real s-nail, stub MTA) | absent.
# sendmail: ok | fail | absent. locale: real | none (no UTF-8 locale listed).
make_bin() { # mail sendmail locale
    rm -rf "${W:?}/bin"; mkdir -p "$W/bin"
    case "$1" in
        ok)    printf '#!/bin/sh\n{ echo "ARGS: $*"; echo "LC_ALL=$LC_ALL"; cat; } > %s/mail.out\n' "$W" > "$W/bin/mail" ;;
        fail)  printf '#!/bin/sh\ncat >/dev/null; echo "mail: stub failure" >&2; exit 4\n' > "$W/bin/mail" ;;
        snail) printf '#!/bin/sh\nexec %s -S mta=%s/mta -S DEAD=%s/dead "$@"\n' "$SNAIL" "$W" "$W" > "$W/bin/mail" ;;
    esac
    case "$2" in
        ok)    printf '#!/bin/sh\n{ echo "ARGS: $*"; cat; } > %s/sendmail.out\n' "$W" > "$W/bin/sendmail" ;;
        fail)  printf '#!/bin/sh\ncat >/dev/null; echo "sendmail: stub failure" >&2; exit 75\n' > "$W/bin/sendmail" ;;
    esac
    [ "$3" = none ] && printf '#!/bin/sh\nprintf "C\\nPOSIX\\n"\n' > "$W/bin/locale"
    # Only the stubs written above -- chmod through a symlink would reach the
    # real binary.
    find "$W/bin" -type f -exec chmod +x {} +
    [ "$3" = none ] || ln -s "$(command -v locale)" "$W/bin/locale"
}

write_cache() { # severity update_available
    printf '{"latest":{"version":"1.0.30","severity":"%s","notes_en":"Notes with \\u00e9 and a \\u2014 dash."},"update_available":%s}\n' \
        "$1" "$2" > "$W/cache/update-status.cache.json"
}

run() { # mail sendmail locale [MAILTO]
    make_bin "$1" "$2" "$3"
    rm -f "$W/mail.out" "$W/sendmail.out" "$W/mta.out" "$W/log"
    ( export PATH="$W/bin:$W/base" HOME="$W" LC_ALL=C MAILRC=/dev/null
      if [ -n "${4:-}" ]; then export MAILTO="$4"; else unset MAILTO; fi
      # Read by the sourced function.
      # shellcheck disable=SC2034
      CACHE_DIR="$W/cache"
      # shellcheck disable=SC2034
      CACHE_FILE="$W/cache/update-status.cache.json"
      # shellcheck disable=SC2034
      installed_version=1.0.29
      # shellcheck disable=SC1091
      . "$W/fn.sh"
      notify_security_release ) > "$W/stdout" 2> "$W/stderr"
}
latch() { cat "$W/cache/update-security-notified" 2>/dev/null; }
has() { [ -s "$1" ]; }

SNAIL="$(command -v s-nail || true)"
UTF8="$(locale -a 2>/dev/null | grep -m1 -iE '^c\.utf-?8$' || true)"
TO=ops@example.invalid
write_cache security true

# 1. The bug itself: the real s-nail under LC_ALL=C with a UTF-8 body.
if [ -n "$SNAIL" ] && [ -n "$UTF8" ]; then
    rm -f "$W/cache/update-security-notified"
    run snail absent real "$TO"
    ok "real s-nail: message reaches the MTA" "$(has "$W/mta.out"; echo $?)" "$(head -c 200 "$W/stderr")"
    ok "real s-nail: declares a charset" "$(grep -qsi '^content-type: text/plain; charset=utf-8' "$W/mta.out"; echo $?)"
    ok "real s-nail: latched" "$([ "$(latch)" = 1.0.30 ]; echo $?)"
    ok "real s-nail: journal says notified" "$(grep -qs 'notified ops@' "$W/log"; echo $?)"
    ok "real s-nail: stdout empty" "$([ ! -s "$W/stdout" ]; echo $?)"
else
    [ "$quiet" = 1 ] || echo "  skip real s-nail case (s-nail or a C.UTF-8 locale not installed)"
fi

# 2. No UTF-8 locale: s-nail fails, the sendmail fallback carries the notice.
if [ -n "$SNAIL" ]; then
    rm -f "$W/cache/update-security-notified"
    run snail ok none "$TO"
    ok "no UTF-8 locale: falls back to sendmail" "$(has "$W/sendmail.out"; echo $?)"
    ok "no UTF-8 locale: latched" "$([ "$(latch)" = 1.0.30 ]; echo $?)"
fi

# 3. Both senders fail: nothing latched, the journal says why.
rm -f "$W/cache/update-security-notified"
run fail fail real "$TO"
ok "both fail: NOT latched" "$([ -z "$(latch)" ]; echo $?)" "latch=$(latch)"
ok "both fail: journal says NOT sent with the reason" "$(grep -qs 'NOT sent (rc=75): sendmail: stub failure' "$W/log"; echo $?)" "$(cat "$W/log" 2>/dev/null)"
ok "both fail: stdout empty" "$([ ! -s "$W/stdout" ]; echo $?)"

# 4. ...and the next check retries and succeeds.
run ok ok real "$TO"
ok "retry after failure: sent by mail(1)" "$(has "$W/mail.out"; echo $?)"
ok "retry after failure: latched" "$([ "$(latch)" = 1.0.30 ]; echo $?)"
ok "mail(1) succeeded: sendmail not also called" "$([ ! -e "$W/sendmail.out" ]; echo $?)"
if [ -n "$UTF8" ]; then
    ok "mail(1) runs under a UTF-8 locale" "$(grep -qsiE '^LC_ALL=c\.utf-?8$' "$W/mail.out"; echo $?)" "$(grep -s LC_ALL "$W/mail.out")"
fi

# 5. mail(1) absent (stock Ubuntu/EL): sendmail with its own MIME headers.
rm -f "$W/cache/update-security-notified"
run absent ok real "$TO"
ok "no mail(1): sent by sendmail" "$(has "$W/sendmail.out"; echo $?)"
for h in 'To: ops@example.invalid' 'MIME-Version: 1.0' 'Content-Type: text/plain; charset=UTF-8' \
         'Content-Transfer-Encoding: 8bit' 'Auto-Submitted: auto-generated' 'X-Ilexa-Alert: update-security'; do
    ok "sendmail header: $h" "$(grep -qsxF "$h" "$W/sendmail.out"; echo $?)"
done
ok "sendmail: envelope sender and -t" "$(grep -qsxF 'ARGS: -t -f root@mx.test.invalid' "$W/sendmail.out"; echo $?)"
ok "sendmail: UTF-8 body intact" "$(grep -qsF "$(printf 'Notes with \303\251 and a \342\200\224 dash.')" "$W/sendmail.out"; echo $?)"
ok "sendmail: latched" "$([ "$(latch)" = 1.0.30 ]; echo $?)"

# 6. Nothing to send: already latched, not security, not newer, no recipient.
run ok ok real "$TO"
ok "already latched: no second notice" "$([ ! -e "$W/mail.out" ]; echo $?)"
rm -f "$W/cache/update-security-notified"
write_cache feature true;  run ok ok real "$TO"
ok "feature release: no notice" "$([ ! -e "$W/mail.out" ] && [ -z "$(latch)" ]; echo $?)"
write_cache security false; run ok ok real "$TO"
ok "not newer than installed: no notice" "$([ ! -e "$W/mail.out" ] && [ -z "$(latch)" ]; echo $?)"
write_cache security true
rm -f "$W/alerts.conf"; run ok ok real ""
ok "no recipient: no notice, not latched" "$([ ! -e "$W/mail.out" ] && [ -z "$(latch)" ]; echo $?)"
printf '# comment\n\nalerts@example.invalid\n' > "$W/alerts.conf"; run ok ok real ""
ok "recipient from alerts.conf" "$(grep -qs '^ARGS: .*alerts@example.invalid' "$W/mail.out"; echo $?)"

echo "check-update-notify: $pass passed, $fail failed"
[ "$fail" = 0 ]
