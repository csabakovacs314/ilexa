#!/usr/bin/php
<?php
/**
 * Fails if a translated string is emitted RAW into JavaScript.
 *
 * Why this check exists: views/layout_foot.php emitted t() directly inside
 * confirm('...') and innerHTML '...' literals. That is invisible in Hungarian,
 * because t() returns the KEY for the source language and no Hungarian key
 * contains an apostrophe. Switching the console to English substituted "the
 * recipient's Inbox", the apostrophe closed the JS literal early, and the
 * SyntaxError killed the ENTIRE inline script -- every handler on the page
 * became undefined and message content could no longer be opened, with a
 * perfectly healthy server behind it.
 *
 * The bug is therefore invisible to: PHP linting, the i18n key checker, any
 * test run in the source language, and any test that does not parse the
 * rendered JavaScript. Only this shape check catches it cheaply.
 *
 * Rule: inside <script>, translated output must go through jsq() (escapes for
 * a single-quoted JS literal) or json_encode() (emits its own quoted literal).
 */
$root = dirname(__DIR__);
$bad  = [];
foreach (glob($root . '/views/*.php') ?: [] as $f) {
    $lines    = file($f);
    $inScript = false;
    foreach ($lines as $i => $line) {
        $low = strtolower($line);
        if (str_contains($low, '<script'))  $inScript = true;
        if ($inScript && preg_match('/<\?=\s*t\(/', $line)) {
            $bad[] = sprintf('%s:%d: raw t() inside <script> -- use jsq(t(...)) or json_encode(t(...))%s    %s',
                basename($f), $i + 1, PHP_EOL, trim(substr($line, 0, 100)));
        }
        if (str_contains($low, '</script')) $inScript = false;
    }
}
if ($bad) {
    echo implode(PHP_EOL, $bad), PHP_EOL;
    echo 'check-js-i18n: ', count($bad), " raw translation(s) in JavaScript -- FAILED", PHP_EOL;
    exit(1);
}
echo 'check-js-i18n: no raw translations in JavaScript, clean', PHP_EOL;
exit(0);
