<?php
// i18n consistency gate. Two checks, both of which have caught real bugs here:
//
//  1. Every t('...') literal in the tree has a lang/en.php entry. Missing ones
//     silently render Hungarian to an English-language admin.
//  2. Placeholder parity between each key and its translation. A reordered
//     translation MUST use positional markers (%1$s, %2$d); without them
//     sprintf silently swaps the arguments, which broke a shipped feature once.
//     Counting must therefore treat "%s" and "%1$s" as the same placeholder --
//     a naive substring count reports the CORRECT positional form as a
//     mismatch (it did, on the one key in this file that uses it).
//
// Exits non-zero on either failure. Run from the repo root.
$root = dirname(__DIR__);
$en   = require $root . '/lang/en.php';

function ph_count(string $s, string $type): int {
    // %s / %d plus positional %N$s / %N$d
    preg_match_all('/%(?:\d+\$)?' . $type . '/', $s, $m);
    return count($m[0]);
}

$fail = 0;

// ---- 1. coverage -----------------------------------------------------------
// views/partials/*.php was never included -- a real gap, found 2026-08-25
// while adding views/partials/update_card.php: its t() calls went entirely
// unchecked until this line was added, silently exactly the failure class
// this tool exists to catch.
$files = array_merge(glob($root . '/src/*.php'), glob($root . '/views/*.php'),
                      glob($root . '/views/partials/*.php'), glob($root . '/*.php'));
$missing = [];
foreach ($files as $f) {
    $toks = token_get_all((string) file_get_contents($f));
    $n = count($toks);
    for ($i = 0; $i < $n; $i++) {
        $t = $toks[$i];
        if (!is_array($t) || $t[0] !== T_STRING || $t[1] !== 't') continue;
        $j = $i + 1; while (isset($toks[$j]) && is_array($toks[$j]) && $toks[$j][0] === T_WHITESPACE) $j++;
        if (($toks[$j] ?? null) !== '(') continue;
        $k = $j + 1; while (isset($toks[$k]) && is_array($toks[$k]) && $toks[$k][0] === T_WHITESPACE) $k++;
        $lit = $toks[$k] ?? null;
        if (!is_array($lit) || $lit[0] !== T_CONSTANT_ENCAPSED_STRING) continue;
        $raw = $lit[1]; $q = $raw[0]; $val = substr($raw, 1, -1);
        $val = $q === "'" ? str_replace(["\\'", '\\\\'], ["'", '\\'], $val) : stripcslashes($val);
        if (!isset($en[$val])) $missing[$val] = basename($f) . ':' . $lit[2];
    }
}
foreach ($missing as $s => $where) {
    echo "MISSING en.php entry ($where): " . mb_substr($s, 0, 70) . "\n";
    $fail = 1;
}

// ---- 2. placeholder parity -------------------------------------------------
foreach ($en as $k => $v) {
    if (!is_string($v)) continue;
    foreach (['s', 'd'] as $type) {
        $a = ph_count($k, $type); $b = ph_count($v, $type);
        if ($a !== $b) {
            printf("PLACEHOLDER %%%s mismatch (hu=%d en=%d): %s\n", $type, $a, $b, mb_substr($k, 0, 70));
            $fail = 1;
        }
    }
    // A translation that reorders same-type placeholders needs positional
    // markers. Flag only the actual hazard: 2+ same-type placeholders in the
    // key, none positional in the translation.
    foreach (['s', 'd'] as $type) {
        if (ph_count($k, $type) >= 2 && !preg_match('/%\d+\$/', $v)) {
            // not fatal -- correct as long as order matches -- but report it
            printf("note: %%%s appears %dx unnumbered, order-sensitive: %s\n",
                   $type, ph_count($k, $type), mb_substr($k, 0, 60));
        }
    }
}

printf("check-i18n: %d en.php entries, %d missing, %s\n",
       count($en), count($missing), $fail ? 'FAILED' : 'clean');
exit($fail);
