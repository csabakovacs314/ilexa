#!/usr/bin/env php
<?php
// Consistency gate for the IOC-lookup service registry.
//
// THE BUG CLASS THIS EXISTS FOR, twice over and documented in the code it
// checks. A lookup service has to be named in five unrelated places before it
// works end to end: the type map that decides when to run it, the weight table
// the confidence score reads, the shell script that stores its enabled flag,
// the admin allow-list that lets the toggle POST through, and the label maps
// the two views render it with. yaraify shipped missing two of them and showed
// "hiányzik" next to a set-key form that could only fail; threatfox was fixed
// pre-emptively in the same commit for the same reason. views/ioc.php still
// carries a comment about a count that was wrong "and was NOTE'd as 6 when 8
// existed".
//
// Nothing failed loudly in any of those cases -- the service just quietly did
// less than it looked like it was doing. That is what this catches.
//
//   tools/check-lookup-services.php [--quiet]

$root  = dirname(__DIR__);
$quiet = in_array('--quiet', $argv, true);
$errors = [];

function slurp(string $f): string {
    $s = @file_get_contents($f);
    if ($s === false) { fwrite(STDERR, "check-lookup-services: cannot read $f\n"); exit(2); }
    return $s;
}

// ---- the registry itself, from the source of truth -------------------------
// src/ioc_lookup.php is consts + functions with no top-level execution, so it
// can be required on its own without the app bootstrap.
require "$root/src/ioc_lookup.php";
$registry = array_keys(IOC_LOOKUP_SERVICE_TYPES);

// ---- the four places that must agree with it -------------------------------
$adminSrc = slurp("$root/src/admin.php");
if (!preg_match('/const\s+IOCLOOKUP_SOURCES\s*=\s*\[(.*?)\]\s*;/s', $adminSrc, $m)) {
    $errors[] = 'src/admin.php: IOCLOOKUP_SOURCES not found';
    $adminList = [];
} else {
    preg_match_all("/'([a-z0-9_-]+)'/", $m[1], $mm);
    $adminList = $mm[1];
}

$shSrc = slurp("$root/install/qa-ioclookup-config.sh");
if (!preg_match('/^SOURCES=\((.*?)^\)/ms', $shSrc, $m)) {
    $errors[] = 'install/qa-ioclookup-config.sh: SOURCES array not found';
    $shList = [];
} else {
    preg_match_all('/"([a-z0-9_-]+)\|/', $m[1], $mm);
    $shList = $mm[1];
}

// Both views build a service => display-name map. A service missing from one
// renders with its raw slug, which looks like a bug rather than a label.
$labelMaps = [];
foreach (['views/ioc.php', 'views/admin_system.php'] as $view) {
    $src = slurp("$root/$view");
    if (!preg_match('/\$_il_label\s*=\s*\[(.*?)\]\s*;/s', $src, $m)) {
        $errors[] = "$view: \$_il_label map not found";
        $labelMaps[$view] = [];
        continue;
    }
    preg_match_all("/'([a-z0-9_-]+)'\s*=>/", $m[1], $mm);
    $labelMaps[$view] = $mm[1];
}

// ---- compare ---------------------------------------------------------------
$checks = [
    'src/admin.php IOCLOOKUP_SOURCES'                  => $adminList,
    'install/qa-ioclookup-config.sh SOURCES'           => $shList,
    'views/ioc.php $_il_label'                         => $labelMaps['views/ioc.php'],
    'views/admin_system.php $_il_label'                => $labelMaps['views/admin_system.php'],
];

foreach ($checks as $where => $have) {
    foreach ($registry as $svc) {
        if (!in_array($svc, $have, true)) {
            $errors[] = "$svc is in IOC_LOOKUP_SERVICE_TYPES but missing from $where";
        }
    }
    foreach ($have as $svc) {
        if (!in_array($svc, $registry, true)) {
            $errors[] = "$svc appears in $where but is not a registered lookup service";
        }
    }
}

// ---- every registered service must declare at least one supported type -----
foreach (IOC_LOOKUP_SERVICE_TYPES as $svc => $types) {
    if (!$types) {
        $errors[] = "$svc declares no supported IOC types, so it can never run";
    }
    foreach ($types as $t) {
        if (!in_array($t, ['ip', 'domain', 'url', 'hash', 'email'], true)) {
            $errors[] = "$svc declares unknown IOC type '$t'";
        }
    }
}

// ---- surface and TTL overrides must name real services ---------------------
foreach (array_keys(IOC_LOOKUP_SERVICE_SURFACES) as $svc) {
    if (!in_array($svc, $registry, true)) {
        $errors[] = "IOC_LOOKUP_SERVICE_SURFACES names unknown service '$svc'";
    }
}
foreach (array_keys(IOC_LOOKUP_TTL_OVERRIDE) as $svc) {
    if (!in_array($svc, $registry, true)) {
        $errors[] = "IOC_LOOKUP_TTL_OVERRIDE names unknown service '$svc'";
    }
}
foreach (array_keys(IOC_CONFIDENCE_WEIGHTS) as $svc) {
    if (!in_array($svc, $registry, true)) {
        $errors[] = "IOC_CONFIDENCE_WEIGHTS names unknown service '$svc'";
    }
}

// ---- the gateway must actually implement every registered service ----------
// A service can be enabled in the console, rendered with a label and a weight,
// and still fall through qa-ioc-lookup.php's dispatch to "unknown service".
$gw = slurp("$root/install/qa-ioc-lookup.php");
foreach ($registry as $svc) {
    if (!preg_match("/case '" . preg_quote($svc, '/') . "':/", $gw)
        && !preg_match("/\\\$service === '" . preg_quote($svc, '/') . "'/", $gw)) {
        $errors[] = "$svc is registered but install/qa-ioc-lookup.php never handles it";
    }
    // The type list the gateway enforces must match the one the console uses
    // to decide when to call it, or the console calls it and is refused.
    if (preg_match("/case '" . preg_quote($svc, '/') . "':\s*\\\$supported\s*=\s*\[(.*?)\];/s", $gw, $m)) {
        preg_match_all("/'([a-z]+)'/", $m[1], $mm);
        $gwTypes = $mm[1];
        sort($gwTypes);
        $regTypes = IOC_LOOKUP_SERVICE_TYPES[$svc];
        sort($regTypes);
        if ($gwTypes !== $regTypes) {
            $errors[] = "$svc type list disagrees: console has ["
                      . implode(',', $regTypes) . '], gateway enforces ['
                      . implode(',', $gwTypes) . ']';
        }
    }
}

// ---- budgeted services must have a budget defined --------------------------
$adminBudgeted = [];
if (preg_match('/const\s+QA_BUDGETED_LOOKUP_SERVICES\s*=\s*\[(.*?)\]\s*;/s', $adminSrc, $m)) {
    preg_match_all("/'([a-z0-9_-]+)'/", $m[1], $mm);
    $adminBudgeted = $mm[1];
}
$quotaSrc = slurp("$root/install/qa-quota-lib.php");
// Matches a QA_QUOTA_DEFAULTS entry: "'name' => [ 'windows' => …". Tied to
// that shape on purpose -- when the shape changed from a single limit to a
// window list this pattern stopped matching and the gate went red, which is
// what a gate anchored to real structure is supposed to do.
preg_match_all("/'([a-z0-9_-]+)'\s*=>\s*\[\s*'windows'\s*=>/", $quotaSrc, $mm);
$quotaProviders = $mm[1];
if (!$quotaProviders) {
    $errors[] = 'install/qa-quota-lib.php: no providers found in QA_QUOTA_DEFAULTS'
              . ' -- the config shape changed and this check needs updating';
}
foreach ($adminBudgeted as $svc) {
    if (!in_array($svc, $quotaProviders, true)) {
        $errors[] = "$svc is shown as budgeted on the Rendszer card but has no"
                  . ' budget in qa-quota-lib.php, so it will always read "no data"';
    }
}
foreach ($quotaProviders as $svc) {
    if (in_array($svc, $registry, true) && !in_array($svc, $adminBudgeted, true)) {
        $errors[] = "$svc has a budget but is not in QA_BUDGETED_LOOKUP_SERVICES,"
                  . ' so the Rendszer card will not show it';
    }
}

// ---- the mailbox sweep's provider list ------------------------------------
// install/check-breaches.py names the providers it sweeps with. Each must be a
// registered lookup service (or the gateway refuses it), must have a budget
// (or it is unpaced), and must have a dashboard label (or the card renders a
// raw slug and no attribution link -- which for LeakCheck is a licence term,
// not a cosmetic detail).
$sweepSrc = slurp("$root/install/check-breaches.py");
$sweepProviders = [];
if (preg_match('/^PROVIDERS\s*=\s*\[(.*?)^\]/ms', $sweepSrc, $m)) {
    preg_match_all("/'name':\s*'([a-z0-9_-]+)'/", $m[1], $mm);
    $sweepProviders = $mm[1];
} else {
    $errors[] = 'install/check-breaches.py: PROVIDERS list not found';
}

$labelled = [];
if (preg_match('/const\s+QA_BREACH_PROVIDER_LABEL\s*=\s*\[(.*?)^\];/ms', $adminSrc, $m)) {
    preg_match_all("/'([a-z0-9_-]+)'\s*=>\s*\[/", $m[1], $mm);
    $labelled = $mm[1];
} else {
    $errors[] = 'src/admin.php: QA_BREACH_PROVIDER_LABEL not found';
}

foreach ($sweepProviders as $svc) {
    if (!in_array($svc, $registry, true)) {
        $errors[] = "$svc is swept by check-breaches.py but is not a registered"
                  . ' lookup service, so the gateway will refuse every request';
    }
    if (!in_array($svc, $quotaProviders, true)) {
        $errors[] = "$svc is swept by check-breaches.py but has no budget in"
                  . ' qa-quota-lib.php, so nothing paces it';
    }
    if (!in_array($svc, $labelled, true)) {
        $errors[] = "$svc is swept by check-breaches.py but has no entry in"
                  . ' QA_BREACH_PROVIDER_LABEL, so the dashboard shows a raw slug'
                  . ' and no attribution link';
    }
    // A swept provider must support the email type or it can never answer.
    if (in_array($svc, $registry, true)
        && !in_array('email', IOC_LOOKUP_SERVICE_TYPES[$svc], true)) {
        $errors[] = "$svc is swept over mailbox addresses but does not declare"
                  . " support for the 'email' type";
    }
}
foreach ($labelled as $svc) {
    if (!in_array($svc, $sweepProviders, true)) {
        $errors[] = "$svc has a dashboard label but is not swept by"
                  . ' check-breaches.py, so the card will show it as never having run';
    }
}

// ---- report ----------------------------------------------------------------
if ($errors) {
    foreach ($errors as $e) echo "LOOKUP-SERVICE DRIFT: $e\n";
    echo 'check-lookup-services: ' . count($errors) . " problem(s), FAILED\n";
    exit(1);
}
if (!$quiet) {
    echo 'check-lookup-services: ' . count($registry)
       . " services, all five registries agree, clean\n";
}
exit(0);
