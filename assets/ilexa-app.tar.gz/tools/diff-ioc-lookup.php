#!/usr/bin/php
<?php
declare(strict_types=1);
/**
 * Differential harness for the qa-ioc-lookup Bash -> PHP port.
 *
 * Runs install/qa-ioc-lookup.sh and install/qa-ioc-lookup.php with identical
 * arguments and compares what the CONSOLE consumes: the error string, the
 * verdict, the detail, and whether a raw payload came back. The raw payload
 * itself is not compared field-by-field -- two live API calls a second apart
 * legitimately differ (scan dates, pulse ordering) -- so the harness asserts
 * that both produced one, and nothing more.
 *
 * There are no expected values baked in: the whole point is that whatever
 * the live service says, both implementations must read it the same way.
 *
 *   tools/diff-ioc-lookup.php --offline   validation/error paths only, no network
 *   tools/diff-ioc-lookup.php             the above plus live lookups
 *   tools/diff-ioc-lookup.php --only otx  restrict the live set to one service
 *
 * The operator-defined DNS-zone branch has no built-in case (the zones are
 * site-specific). Point the harness at one that exists in
 * /etc/ilexa/ioc_lookup_custom.conf:
 *
 *   QA_DIFF_CUSTOM_SERVICE=myzone tools/diff-ioc-lookup.php --only myzone
 *   tools/diff-ioc-lookup.php --offline --as-web-user
 *                                         the offline set plus the "no api key
 *                                         configured" path, run through sudo as
 *                                         the web user (as the console does)
 *
 * Live cases cost real API quota. VirusTotal's free tier allows 4 requests a
 * minute and every case here costs TWO (one per implementation), so the VT
 * cases are spaced deliberately -- see $slowServices.
 */

$root = dirname(__DIR__);
// Overridable so the comparison still works once install/qa-ioc-lookup.sh is
// reduced to a shim: point QA_DIFF_SH at a copy of the last full Bash
// version (git show <tag>:install/qa-ioc-lookup.sh > /var/tmp/legacy.sh).
$SH   = getenv('QA_DIFF_SH')  ?: "$root/install/qa-ioc-lookup.sh";
$PHP  = getenv('QA_DIFF_PHP') ?: "$root/install/qa-ioc-lookup.php";

// install/qa-ioc-lookup.sh is a shim that execs the PHP implementation, so
// comparing it against that same implementation compares a process with
// itself and passes no matter what. Say so rather than printing a green
// wall of meaningless ok lines.
if (!getenv('QA_DIFF_SH') && is_readable($SH) && strpos((string)file_get_contents($SH), 'exec "$TARGET"') !== false) {
    fwrite(STDERR,
        "diff-ioc-lookup: install/qa-ioc-lookup.sh is the shim, not an independent\n"
      . "implementation. Point QA_DIFF_SH at the last full Bash version:\n"
      . "  git show eb6d5e4:install/qa-ioc-lookup.sh > /var/tmp/legacy.sh && chmod 755 /var/tmp/legacy.sh\n"
      . "  (eb6d5e4 is what RELEASES.json records for 1.0.15, the last release\n"
      . "   carrying the full Bash version -- this repo carries no version tags)\n"
      . "  QA_DIFF_SH=/var/tmp/legacy.sh tools/diff-ioc-lookup.php\n");
    exit(2);
}

$offline = in_array('--offline', $argv, true);
// The console reaches these helpers through sudo as the web user, which
// cannot read /etc/ilexa/secrets. Re-running the offline set under that
// identity checks the keyless path -- the single most common real-world
// error on a fresh box -- without spending any API quota.
$asWeb   = in_array('--as-web-user', $argv, true);
$WEB_USER = getenv('QA_WEB_USER') ?: (posix_getpwnam('apache') ? 'apache' : 'www-data');

// The repo lives under /root (0750), which the web user cannot traverse, so
// running the checkout copies directly as that user fails before the script
// starts -- silently, since both implementations then produce nothing and
// "nothing == nothing" would look like agreement. Stage readable copies
// instead, the way /usr/local/sbin holds them in production.
function stage_for_web(string $src): string {
    $dst = '/var/tmp/ioc-lookup-diff.' . basename($src);
    if (!@copy($src, $dst)) {
        fwrite(STDERR, "cannot stage $src for the web user\n");
        exit(2);
    }
    chmod($dst, 0755);
    return $dst;
}
$only    = null;
foreach ($argv as $i => $a) {
    if ($a === '--only' && isset($argv[$i + 1])) $only = $argv[$i + 1];
}

// Services whose free tier will throttle a rapid A/B pair.
$slowServices = ['virustotal' => 32];

if ($asWeb) {
    $SH  = stage_for_web($SH);
    $PHP = stage_for_web($PHP);
    register_shutdown_function(function () use ($SH, $PHP) { @unlink($SH); @unlink($PHP); });
}

// ---- cases ---------------------------------------------------------------
// Each case is a plain argv list. Offline cases must never touch the network.

$offlineCases = [
    ['virustotal'],                                   // too few arguments
    ['virustotal', 'ip'],                             // too few arguments
    ['virustotal', 'ip', '1.2.3.4', '5', 'extra'],    // too many arguments
    ['virustotal', 'ip', 'not-an-ip'],
    ['virustotal', 'domain', 'not_a_domain'],
    ['virustotal', 'domain', 'nodot'],
    ['virustotal', 'url', 'ftp://example.com/x'],
    ['virustotal', 'url', 'http://exa mple.com/'],
    ['virustotal', 'hash', 'abcdef'],
    ['virustotal', 'hash', 'zzd88612fea8a8f36de82e1278abb02f'],
    ['mailspike', 'domain', 'example.com'],           // unsupported type
    ['urlhaus', 'ip', '8.8.8.8'],                     // unsupported type
    ['yaraify', 'domain', 'example.com'],             // unsupported type
    ['definitely-not-a-service', 'ip', '8.8.8.8'],    // unknown service
    ['../../etc/passwd', 'ip', '8.8.8.8'],            // unknown service, path-ish
    ['virustotal', 'ip', '8.8.8.8', '0'],             // timeout below range
    ['virustotal', 'ip', '8.8.8.8', '61'],            // timeout above range
    ['virustotal', 'ip', '8.8.8.8', 'abc'],           // timeout not digits
    ['virustotal', 'ip', '8.8.8.8', '-5'],            // timeout not digits
    ['mailspike', 'ip', '2001:db8::1'],               // ipv6 rejected by zone
    ['hrbl', 'ip', '2001:db8::1'],
];

// Only meaningful under --as-web-user: as root these would be live lookups.
$keylessCases = [
    ['virustotal', 'ip',   '8.8.8.8'],
    ['urlhaus',    'domain', 'example.com'],
    ['otx',        'ip',   '8.8.8.8'],
    ['threatfox',  'ip',   '8.8.8.8'],
];

// Live cases. Values are chosen to be boring and stable: a public resolver, a
// documentation domain, and the EICAR test file's hashes.
$eicarMd5    = '44d88612fea8a8f36de82e1278abb02f';
$eicarSha256 = '275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f';

$liveCases = [
    ['hrbl',       'ip',     '127.0.0.2'],
    ['hrbl',       'ip',     '8.8.8.8'],
    ['hrbl',       'domain', 'example.com'],
    ['mailspike',  'ip',     '8.8.8.8'],
    ['mailspike',  'ip',     '185.220.101.1'],
    ['mailspike',  'ip',     '127.0.0.2'],
    ['otx',        'ip',     '8.8.8.8'],
    ['otx',        'domain', 'example.com'],
    ['otx',        'url',    'http://example.com/a?b=c&d=e'],
    ['otx',        'hash',   $eicarSha256],
    ['urlhaus',    'domain', 'example.com'],
    ['urlhaus',    'hash',   $eicarSha256],
    ['urlhaus',    'url',    'http://example.com/a?b=c&d=e'],
    ['threatfox',  'ip',     '8.8.8.8'],
    ['threatfox',  'domain', 'example.com'],
    ['threatfox',  'hash',   $eicarSha256],
    ['yaraify',    'hash',   $eicarSha256],
    ['yaraify',    'hash',   $eicarMd5],
    ['urlvet',     'domain', 'example.com'],
    ['urlvet',     'url',    'https://example.com/'],
    ['otx',        'ip',     '2001:4860:4860::8888'],
    // A non-resolving host is url.vet's slow path (~31s); with a 6s budget
    // both implementations must give up and say so identically.
    ['urlvet',     'domain', 'nx-ilexa-does-not-exist-9f2c.example', '6'],
    // 1s is under url.vet's floor for any answer, so this one reliably
    // exercises the give-up path and its message.
    ['urlvet',     'domain', 'ilexa-timeout-probe-4b1e.example', '1'],
    ['virustotal', 'ip',     '8.8.8.8'],
    ['virustotal', 'url',    'http://example.com/a?b=c&d=e'],
    // Shape-valid but absurd: the regex lets it through, so the SERVICE gets
    // to reject it and both implementations must relay that identically.
    ['virustotal', 'ip',     '999.999.999.999'],
    ['virustotal', 'hash',   $eicarMd5],
];

// Operator-defined DNS zone, if the caller named one. 127.0.0.2 is the
// conventional "always listed" probe for a DNSBL and 8.8.8.8 the negative
// control; the harness does not care which way the zone answers, only that
// both implementations read the answer the same way.
$customService = getenv('QA_DIFF_CUSTOM_SERVICE') ?: '';
if ($customService !== '') {
    $liveCases[] = [$customService, 'ip', '127.0.0.2'];
    $liveCases[] = [$customService, 'ip', '8.8.8.8'];
    $liveCases[] = [$customService, 'ip', '2001:db8::1'];
    $liveCases[] = [$customService, 'domain', 'example.com'];
}

// ---- runner --------------------------------------------------------------

function run(string $bin, array $args): array {
    global $asWeb, $WEB_USER;
    $cmd = ($asWeb ? 'sudo -u ' . escapeshellarg($WEB_USER) . ' ' : '') . escapeshellcmd($bin);
    foreach ($args as $a) $cmd .= ' ' . escapeshellarg($a);
    $out = [];
    $rc  = 0;
    exec($cmd . ' 2>/dev/null', $out, $rc);
    $txt = implode("\n", $out);
    return ['rc' => $rc, 'json' => json_decode($txt, true), 'text' => $txt];
}

// The one legitimate textual difference: each implementation names itself in
// its usage line.
function norm(?string $s): ?string {
    return $s === null ? null : str_replace('qa-ioc-lookup.php', 'qa-ioc-lookup.sh', $s);
}

function shape(array $r): array {
    $j = is_array($r['json']) ? $r['json'] : null;
    return [
        'rc'      => $r['rc'],
        'parsed'  => $j !== null,
        'error'   => $j !== null && isset($j['error'])   ? norm((string)$j['error'])   : null,
        'verdict' => $j !== null && isset($j['verdict']) ? (string)$j['verdict'] : null,
        'detail'  => $j !== null && isset($j['detail'])  ? (string)$j['detail']  : null,
        'has_raw' => $j !== null && array_key_exists('raw', $j),
    ];
}

// [args, is_live] -- the throttle applies to live cases only. An offline
// case names a service too (that is how it reaches the validation it is
// testing), so keying the sleep on the service name alone made a no-network
// argument check wait 16 seconds.
$cases = [];
foreach ($offlineCases as $c) $cases[] = [$c, false];
if ($asWeb) foreach ($keylessCases as $c) $cases[] = [$c, false];
if (!$offline) {
    foreach ($liveCases as $c) {
        if ($only !== null && $c[0] !== $only) continue;
        $cases[] = [$c, true];
    }
}

$pass = 0; $fail = 0; $lastLive = null;
foreach ($cases as [$args, $live]) {
    $svc  = $args[0] ?? '';
    $slow = $live && isset($slowServices[$svc]);
    if ($slow && $lastLive === $svc) sleep($slowServices[$svc]);

    // A live pair is re-run once on mismatch: an external API that answers
    // one of the two calls with an empty body (OTX did exactly that during
    // development) would otherwise be reported as a porting bug. A real
    // difference reproduces; a flake does not.
    $attempts = $live ? 2 : 1;
    for ($try = 1; $try <= $attempts; $try++) {
        $a = shape(run($SH,  $args));
        if ($slow) sleep((int)ceil($slowServices[$svc] / 2));
        $b = shape(run($PHP, $args));
        if ($a === $b) break;
        if ($try < $attempts) sleep($slow ? $slowServices[$svc] : 3);
    }
    $lastLive = $live ? $svc : null;

    $label = implode(' ', $args);
    if (!$a['parsed'] && !$b['parsed']) {
        // Both silent. The contract is one JSON object on EVERY path, so this
        // is a broken harness case (or a broken helper), never a pass.
        $fail++;
        printf("  NOJSON %s -- neither implementation printed JSON\n", $label);
        continue;
    }
    if ($a === $b) {
        $pass++;
        printf("  ok    %-52s %s\n", $label,
            $a['error'] !== null ? 'error: ' . $a['error'] : $a['verdict'] . ' / ' . $a['detail']);
        continue;
    }
    $fail++;
    printf("  DIFF  %s\n", $label);
    foreach (['rc', 'parsed', 'error', 'verdict', 'detail', 'has_raw'] as $k) {
        if (($a[$k] ?? null) === ($b[$k] ?? null)) continue;
        printf("        %-8s sh=%s\n        %-8s php=%s\n",
            $k, var_export($a[$k], true), '', var_export($b[$k], true));
    }
}

printf("\n  %d passed, %d differing (%d cases)\n", $pass, $fail, count($cases));
exit($fail === 0 ? 0 : 1);
