#!/bin/bash
#
# Console smoke tests: render every top-level request path through the REAL
# stack (bootstrap -> RBAC -> view dispatch -> live shell-outs) and assert
# each one completes without PHP errors and contains its view's marker
# string. Complements tools/lint-all.sh: lint proves the code parses and the
# i18n/helper tables agree; this proves the pages actually render against
# the live config, database, and sudo helpers.
#
# Runs against the DEPLOYED webroot, not the repo: config.php lives only in
# the webroot, and /root (where the repo lives) is unreadable by the web
# user. So this is a post-deploy verification -- deploy.sh runs it as its
# final step -- and equally a standalone health check at any other time:
#
#   bash tools/smoke-test.sh              # test /var/www/html/quarantine-admin
#   bash tools/smoke-test.sh /some/path   # test another deployed tree
#
# Must be started as root (it drops to the web user per test -- rendering as
# root would leave root-owned cache/session files that 500 PHP-FPM later) or
# directly as the web user.
#
# GET paths only, plus one deliberately-tokenless POST to prove the CSRF
# gate refuses it. State-changing paths are all POST+CSRF in this app, so
# nothing here mutates anything beyond the app's own caches -- the same
# writes any real page view performs.
set -uo pipefail

DST="${1:-/var/www/html/quarantine-admin}"
RENDER="$DST/tools/smoke/render-route.php"
[ -f "$RENDER" ] || { echo "smoke: $RENDER not found -- deploy first" >&2; exit 2; }

# Same web-user detection as deploy.sh: EL runs FPM as apache, Debian-family
# as www-data. WEB_USER= overrides for anything exotic.
WEB_USER="${WEB_USER:-}"
if [[ -z "$WEB_USER" ]]; then
    for _u in apache www-data; do
        id -u "$_u" >/dev/null 2>&1 && { WEB_USER="$_u"; break; }
    done
fi
[[ -n "$WEB_USER" ]] || { echo "smoke: cannot determine the web user; set WEB_USER=" >&2; exit 2; }

as_web_user() {
    if [[ "$(id -un)" == "$WEB_USER" ]]; then "$@"
    elif [[ "$(id -u)" == 0 ]]; then runuser -u "$WEB_USER" -- "$@"
    else echo "smoke: must run as root or $WEB_USER" >&2; exit 2
    fi
}

# CLI php shares FPM's session.save_path, which may not be writable by the
# web user from a CLI context on every distro -- give each run its own.
SESS_DIR="$(mktemp -d)"
chown "$WEB_USER" "$SESS_DIR" 2>/dev/null || true
trap 'rm -rf "$SESS_DIR"' EXIT

# name|user|query|method|must-contain|must-not-contain
# Markers are stable Hungarian source strings / element ids from each view --
# t() keys, so they appear verbatim regardless of the active UI language
# only when the language is Hungarian; the console defaults to Hungarian and
# CLI has no per-user language cookie, so that is what renders here.
# An empty must-not-contain field skips that check.
TESTS=(
  'dashboard|admin|-|GET|id="incidensek"|'
  'quarantine|admin|quar=1|GET|spamnek jelölt levelek|'
  'blocklist|admin|block=1|GET|Blokklista|'
  'archive|admin|arc=1|GET|Archívum|'
  'ioc|admin|ioc=1|GET|Indikátor hozzáadása|'
  'campaigns|admin|campaigns=1|GET|kampány|'
  'audit-ops|admin|audit=ops|GET|Spam műveletek|'
  # The logins tab renders the failed-login aggregation (ilexa/POP3/IMAP/
  # webmail sources) -- a real parse over live logs, worth smoking separately.
  'audit-logins|admin|audit=logins|GET|id="af-section"|'
  'about|admin|about=1|GET|API-kulcsok beszerzése|'
  'admin-runtime|admin|admin=1|GET|Futtatókörnyezet beállításai|'
  'sysconfig|admin|sysconfig=1|GET|Bayes-tanulás|'
  # Negative: no REMOTE_USER at all -> the 401 gate, and nothing else.
  'auth-required|-|-|GET|401 Unauthorized|<html'
  # Negative: an account with no roles.json entry defaults to viewer; asking
  # for the admin-gated IOC page must silently land on the dashboard (this is
  # index.php's documented behaviour), never render the IOC view.
  'rbac-viewer-ioc|smoke-viewer|ioc=1|GET|</html>|Indikátor hozzáadása'
  # Negative: a POST with no CSRF token, marked XHR, must get the JSON
  # refusal -- not a rendered page, not a 500.
  'csrf-tokenless|admin|-|POST-XHR|"ok":false|<html'
)

pass=0; fail=0
for t in "${TESTS[@]}"; do
    IFS='|' read -r name user query method want unwant <<<"$t"
    out_f="$(mktemp)"; err_f="$(mktemp)"
    # display_errors=stderr keeps the HTML clean on stdout and makes PHP
    # diagnostics separable; 60s cap because quar/dashboard do real doveadm
    # and status shell-outs.
    as_web_user timeout 60 php -d display_errors=stderr -d error_reporting=E_ALL \
        -d session.save_path="$SESS_DIR" \
        "$RENDER" "$user" "$query" "$method" >"$out_f" 2>"$err_f"
    rc=$?

    problems=()
    [[ $rc -eq 0 ]] || problems+=("exit $rc")
    if grep -qE "PHP (Warning|Notice|Fatal|Parse|Deprecated)" "$err_f"; then
        problems+=("php diagnostics: $(grep -m1 -E 'PHP (Warning|Notice|Fatal|Parse|Deprecated)' "$err_f")")
    fi
    grep -qF "Fatal error" "$out_f" && problems+=("fatal error in body")
    grep -qF -- "$want" "$out_f" || problems+=("missing marker: $want")
    if [[ -n "$unwant" ]] && grep -qF -- "$unwant" "$out_f"; then
        problems+=("forbidden content present: $unwant")
    fi

    if [[ ${#problems[@]} -eq 0 ]]; then
        printf 'PASS  %s\n' "$name"; pass=$((pass+1))
    else
        printf 'FAIL  %s\n' "$name"; fail=$((fail+1))
        for p in "${problems[@]}"; do printf '      - %s\n' "$p"; done
        # Bounded context, never the whole page (the body can be 100KB+).
        head -c 300 "$err_f" | sed 's/^/      stderr: /'
    fi
    rm -f "$out_f" "$err_f"
done

echo "smoke: $pass passed, $fail failed"
[[ $fail -eq 0 ]]
