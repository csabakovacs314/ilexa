#!/usr/bin/env php
<?php
// Verifies install/helpers.list against every place that must agree with it.
//
// THE BUG CLASS THIS EXISTS FOR. The set of root-owned helper scripts was
// written out by hand in three places, and they drifted repeatedly. Every
// drift produced the same failure: a console panel or cron job shelling out
// to a script the installer never placed. The panel looks broken and says
// nothing useful about why. This happened to qa-abusix.sh, to the two
// classifier measurement tools, and to qa-hu-classify-report.py inside a
// single week -- the third time by shipping a cron entry that referenced a
// file no installer had ever copied.
//
// helpers.list is now the single source. This checks that:
//
//   1. every source=list helper exists at install/<name>          (nothing named that is not shipped)
//   2. every source=tmpl helper exists at install/<name>.tmpl
//   3. both install loops still DERIVE their names from helpers.list, rather
//      than having been reverted to a hardcoded list (and if one has been,
//      that list is compared element by element)
//   4. sudoers.example grants exactly the access=sudo set         (no missing grant, no stray grant)
//   5. the argspec matches                                        (a '*' script granted bare fails at runtime;
//                                                                  a bare script granted '*' widens the grant)
//   6. no access=cron helper appears in sudoers                   (the web user must not reach cron-only tools)
//
// Exits non-zero on any mismatch, so deploy.sh refuses to ship one.
//
// Usage: tools/check-helpers.php [--quiet]

$root = dirname(__DIR__);
$quiet = in_array('--quiet', $argv, true);
$errors = [];

// ---- parse helpers.list ----------------------------------------------------
$listFile = "$root/install/helpers.list";
if (!is_readable($listFile)) {
    fwrite(STDERR, "check-helpers: cannot read $listFile\n");
    exit(2);
}
$helpers = [];
foreach (file($listFile, FILE_IGNORE_NEW_LINES) as $n => $line) {
    $line = trim($line);
    if ($line === '' || $line[0] === '#') continue;
    $p = preg_split('/\s+/', $line);
    if (count($p) < 3) { $errors[] = "helpers.list line " . ($n+1) . ": expected '<name> <access> <source> [argspec]'"; continue; }
    [$name, $access, $source] = $p;
    $arg = $p[3] ?? '-';
    if (!in_array($access, ['sudo','cron'], true)) { $errors[] = "helpers.list: $name has unknown access '$access'"; continue; }
    if (!in_array($source, ['list','tmpl'], true)) { $errors[] = "helpers.list: $name has unknown source '$source'"; continue; }
    $helpers[$name] = ['access' => $access, 'source' => $source, 'arg' => $arg];
}

// ---- 1 & 2: the files actually exist ---------------------------------------
foreach ($helpers as $name => $h) {
    $path = $h['source'] === 'tmpl' ? "$root/install/$name.tmpl" : "$root/install/$name";
    if (!is_file($path)) {
        $errors[] = "listed but missing from the repo: install/" . basename($path);
    }
}

// ---- 3: both install loops name exactly the source=list set ----------------
// Read the `for h in ... ; do` block out of each installer rather than
// duplicating the list here -- the point is to compare what they really say.
$expectList = array_keys(array_filter($helpers, fn($h) => $h['source'] === 'list'));
sort($expectList);

$loops = [
    'install-console.sh'               => "$root/install-console.sh",
    'ilexa-installer/modules/55-ilexa.sh' => dirname($root) . '/ilexa-installer/modules/55-ilexa.sh',
];
foreach ($loops as $label => $file) {
    if (!is_readable($file)) {
        // The installer repo is not always checked out beside the app; that is
        // not this gate's problem to fail on.
        if (!$quiet) echo "check-helpers: skipping $label (not present)\n";
        continue;
    }
    $src = file_get_contents($file);
    if (!preg_match('/for h in (.*?);\s*do/s', $src, $m)) {
        $errors[] = "$label: could not find the 'for h in ...; do' helper loop";
        continue;
    }
    $loop = $m[1];

    // Preferred shape: the loop DERIVES the names from helpers.list, so the
    // two installers cannot drift from it or from each other by
    // construction. Then there is nothing to compare -- only to confirm it
    // still reads the single source rather than having been reverted to a
    // hardcoded list.
    if (strpos($loop, 'helpers.list') !== false) {
        continue;
    }

    // Fallback: a literal list. Still supported, but it is the shape that
    // drifted three times in a week, so it gets compared element by element.
    $got = preg_split('/\s+/', trim(preg_replace('/\\\\\s*/', ' ', $loop)));
    $got = array_values(array_filter($got));
    sort($got);
    $errors[] = "$label: uses a hardcoded helper list; it should read install/helpers.list instead";
    foreach (array_diff($expectList, $got) as $miss) {
        $errors[] = "$label: does not install '$miss' (it is in helpers.list)";
    }
    foreach (array_diff($got, $expectList) as $extra) {
        $errors[] = "$label: installs '$extra', which is not in helpers.list";
    }
}

// ---- 4, 5, 6: sudoers.example agrees ---------------------------------------
$sudoFile = "$root/install/sudoers.example";
if (!is_readable($sudoFile)) {
    $errors[] = "cannot read install/sudoers.example";
} else {
    $sudo = file_get_contents($sudoFile);
    // Collect every granted path and whether it carries a wildcard.
    preg_match_all('#/usr/local/sbin/([a-z0-9._-]+)(\s+\*)?#i', $sudo, $mm, PREG_SET_ORDER);
    $granted = [];
    foreach ($mm as $g) {
        $n = $g[1];
        $wild = isset($g[2]) && trim($g[2]) === '*';
        // A script may be granted twice (bare AND wildcard) -- qa-doveadm.sh
        // is, deliberately. Wildcard wins for comparison purposes.
        $granted[$n] = ($granted[$n] ?? false) || $wild;
    }
    foreach ($helpers as $name => $h) {
        if ($h['access'] === 'sudo') {
            if (!array_key_exists($name, $granted)) {
                $errors[] = "sudoers.example: no grant for '$name' (helpers.list says access=sudo)";
                continue;
            }
            $wantWild = $h['arg'] === '*';
            if ($granted[$name] !== $wantWild) {
                $errors[] = $wantWild
                    ? "sudoers.example: '$name' is granted without '*', but helpers.list says it takes arguments (it will fail at runtime)"
                    : "sudoers.example: '$name' is granted with '*', but helpers.list says it takes none (this widens the grant)";
            }
        } else {
            if (array_key_exists($name, $granted)) {
                $errors[] = "sudoers.example: grants '$name', but helpers.list marks it cron-only (the web user should not reach it)";
            }
        }
    }
    foreach ($granted as $name => $_) {
        if (!isset($helpers[$name])) {
            $errors[] = "sudoers.example: grants '$name', which is not in helpers.list at all";
        }
    }
}

// ---- report ----------------------------------------------------------------
if ($errors) {
    echo "\n";
    foreach ($errors as $e) echo "  HELPER MISMATCH: $e\n";
    echo "check-helpers: " . count($helpers) . " helpers, " . count($errors) . " problem(s), FAILED\n";
    exit(1);
}
if (!$quiet) {
    $n_sudo = count(array_filter($helpers, fn($h) => $h['access'] === 'sudo'));
    echo "check-helpers: " . count($helpers) . " helpers ($n_sudo sudo-reachable), all lists agree, clean\n";
}
exit(0);
