<?php
// Render one console request path in-process and print the response body.
//
// This is the workhorse of tools/smoke-test.sh: it fakes the minimum
// $_SERVER surface Apache+htpasswd would provide (REMOTE_USER, method,
// query string) and includes the real index.php, so the whole real stack
// runs -- bootstrap, RBAC, view dispatch, the actual shell-outs. One route
// per process, because bootstrap.php define()s constants and index.php
// exits on several paths; re-including in one process is impossible.
//
// Usage: php render-route.php <user|-> <query-string|-> [GET|POST-XHR]
//   user "-"  = anonymous (tests the 401 gate)
//   query "-" = no query string (the dashboard)
//   POST-XHR  = REQUEST_METHOD=POST + X-Requested-With, with NO CSRF token
//               (tests that the CSRF gate answers {"ok":false} JSON)
//
// SECURITY: CLI only, enforced below. This script sets REMOTE_USER itself,
// which over HTTP would be an authentication bypass for whoever could reach
// it -- tools/ is deployed to the webroot (deploy.sh does not exclude it),
// behind the same htpasswd as everything else, but "behind the same
// htpasswd" is exactly the population RBAC exists to constrain, so an
// authenticated viewer must not be able to render admin views through this
// file. Web SAPIs die immediately.
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit("not available\n");
}
// Never as root either: any cache/session file this run creates would be
// root-owned, and PHP-FPM then 500s on it forever after (the documented
// chown-after-edit landmine). The runner switches to the web user; this
// guard is for someone invoking the script by hand.
if (function_exists('posix_getuid') && posix_getuid() === 0) {
    fwrite(STDERR, "render-route: refusing to run as root -- run as the web user (see tools/smoke-test.sh)\n");
    exit(2);
}

$user   = $argv[1] ?? '';
$query  = $argv[2] ?? '-';
$method = strtoupper($argv[3] ?? 'GET');
if ($user === '' || !in_array($method, ['GET', 'POST-XHR'], true)) {
    fwrite(STDERR, "usage: render-route.php <user|-> <query-string|-> [GET|POST-XHR]\n");
    exit(2);
}
if ($query === '-') $query = '';

// The minimum request surface the app actually reads. REMOTE_ADDR matters:
// the audit trail records it, and a missing one would be a warning in every
// test. HTTPS=on matches production (the console is TLS-only) so cookie
// parameters set for a secure context don't warn in a fake plain one.
$_SERVER['REQUEST_METHOD'] = $method === 'POST-XHR' ? 'POST' : 'GET';
$_SERVER['QUERY_STRING']   = $query;
$_SERVER['REQUEST_URI']    = '/quarantine-admin/' . ($query !== '' ? "?$query" : '');
$_SERVER['SCRIPT_NAME']    = '/quarantine-admin/index.php';
$_SERVER['HTTP_HOST']      = 'localhost';
$_SERVER['REMOTE_ADDR']    = '127.0.0.1';
$_SERVER['HTTPS']          = 'on';
if ($user !== '-') $_SERVER['REMOTE_USER'] = $user;
if ($method === 'POST-XHR') $_SERVER['HTTP_X_REQUESTED_WITH'] = 'XMLHttpRequest';

parse_str($query, $_GET);
$_POST = [];   // deliberately empty on POST-XHR: no _csrf is the point

$approot = dirname(__DIR__, 2);
chdir($approot);
require $approot . '/index.php';
