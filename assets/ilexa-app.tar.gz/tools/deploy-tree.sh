#!/usr/bin/env bash
# deploy-tree.sh <src> <dst> -- rsync a console tree into a live webroot with
# correct ownership/permissions. Extracted from deploy.sh so it and
# install/qa-update-apply.sh's Phase 4 (the self-update apply path) share
# exactly ONE copy of this logic instead of two that can drift -- this app's
# own helpers.list header describes the failure shape that happens when a
# rule like this gets hand-copied a second time.
#
# Two hard-won rules live here, do not lose them re-copying this elsewhere:
#   1. install/ (and a few docroot-inappropriate files) must never reach a
#      web-writable directory -- install/ holds root-owned host scripts.
#   2. assets/ needs directory-755/file-644, never a blanket `chmod 644
#      assets/*` -- that glob also matches subdirectories and strips their
#      execute bit, turning "auth required" into a silent 403 the moment the
#      first assets/ subdirectory (assets/flags/) existed.
#
# Caller is responsible for lint/drift checks and any pre-image capture
# (deploy.sh's own drift refusal, qa-update-apply.sh's Phase 2 snapshot) --
# this script only ever writes forward into $DST, never reads $DST first.
set -euo pipefail

SRC="${1:?usage: deploy-tree.sh <src> <dst>}"
DST="${2:?usage: deploy-tree.sh <src> <dst>}"

# Deliberately not deployed: INSTALL.md/README.md/docs/ would expose infra
# paths and design internals over HTTP; .superpowers/ and .claude/ are SDD
# execution scratch; index.php.bak-* is a pre-refactor backup that lives
# only in the webroot; install/ holds host scripts that belong in
# /usr/local/sbin, never in a web-writable directory.
EXCLUDES=(--exclude='.git' --exclude='.gitignore' --exclude='INSTALL.md'
          --exclude='README.md' --exclude='deploy.sh' --exclude='install/'
          --exclude='docs/' --exclude='.superpowers/' --exclude='.claude/')

rsync -a "${EXCLUDES[@]}" "$SRC/" "$DST/"

# PHP-FPM cannot read root-owned 640 files, which is how the editor tools
# leave them; assets must stay world-readable for Apache.
#
# The web user is NOT the same everywhere: EL runs PHP-FPM as "apache",
# Debian/Ubuntu as "www-data". Detect it, preferring an explicit override.
WEB_USER="${WEB_USER:-}"
if [[ -z "$WEB_USER" ]]; then
    for _u in apache www-data; do
        if id -u "$_u" >/dev/null 2>&1; then WEB_USER="$_u"; break; fi
    done
fi
[[ -n "$WEB_USER" ]] || { echo "deploy-tree: cannot determine the web user (tried apache, www-data); set WEB_USER=" >&2; exit 1; }
WEB_GROUP="${WEB_GROUP:-$(id -gn "$WEB_USER")}"
echo "deploy-tree: web user: ${WEB_USER}:${WEB_GROUP}"

find "$DST" -name '*.php' -exec chown "$WEB_USER:$WEB_GROUP" {} + -exec chmod 640 {} +
if [[ -d "$DST/assets" ]]; then
  chown -R "$WEB_USER:$WEB_GROUP" "$DST/assets"
  find "$DST/assets" -type d -exec chmod 755 {} +
  find "$DST/assets" -type f -exec chmod 644 {} +
fi
# parse_email.py is executed, not served - it stays root-owned and executable.
if [[ -f "$DST/parse_email.py" ]]; then
  chown root:root "$DST/parse_email.py" && chmod 755 "$DST/parse_email.py"
fi

echo "deploy-tree: deployed $SRC -> $DST"
