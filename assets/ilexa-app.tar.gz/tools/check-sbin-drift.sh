#!/usr/bin/env bash
# Report drift between this repo's install/ directory and the helper scripts
# actually deployed at /usr/local/sbin.
#
# Why this exists: deploy.sh manages the webroot and refuses to run while the
# webroot holds work the repo does not -- but it does NOT deploy install/*.sh
# or install/*.php at all. Those belong in /usr/local/sbin, are copied there by
# hand (or by the installer, on a fresh build), and drift silently in both
# directions: a hotfix applied live never makes it back into the repo, and a
# repo change never reaches the running system. deploy.sh has printed a static
# "they drift silently - diff them separately" reminder for a while, which is
# true but useless at the moment it matters: it does not say WHICH of the ~40
# helpers drifted, or in which direction, so nobody diffs them.
#
# This is the same class of failure helpers.list itself was created to stop
# (three drifts in one week, each shipping a panel or cron job that called a
# script no installer had placed) -- just at the other end of the pipe.
#
# Usage:
#   tools/check-sbin-drift.sh            report drift, exit 1 if any
#   tools/check-sbin-drift.sh --quiet    only print problems (for deploy.sh)
#
# Host-specific by nature (it reads /usr/local/sbin), so it is deliberately
# NOT part of tools/lint-all.sh: that sweep is repo-internal and must stay
# runnable on any checkout, including CI, where these paths do not exist.
set -uo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SRC="$HERE/install"
DST=/usr/local/sbin
LIST="$SRC/helpers.list"
quiet=0
[[ "${1:-}" == "--quiet" ]] && quiet=1

say() { [ "$quiet" = 1 ] || printf '%s\n' "$*"; }

[ -r "$LIST" ] || { echo "check-sbin-drift: cannot read $LIST" >&2; exit 2; }
[ -d "$DST" ]  || { say "check-sbin-drift: $DST does not exist -- skipping (not a deployment host)"; exit 0; }

drift=0 missing=0 checked=0 skipped=0

# source=list entries only. The three source=tmpl helpers (qa-doveadm.sh,
# fts-manage.sh, htpasswd-manage.sh) are RENDERED with site values -- the
# archive mailbox, the htpasswd path -- so the deployed file is supposed to
# differ from install/<name>.tmpl byte-for-byte. Comparing those would report
# permanent false drift, which is worse than not checking them: a check that
# always complains gets ignored, and takes the real findings down with it.
while read -r name; do
    [ -n "$name" ] || continue

    if [ ! -f "$SRC/$name" ]; then
        # helpers.list names a file this repo does not carry. check-helpers.php
        # owns list-vs-sudoers consistency; this is list-vs-repo, so report it
        # here rather than assuming the other check covers it.
        printf '  SBIN NO-SOURCE: %s (listed in helpers.list, absent from install/)\n' "$name"
        drift=1
        continue
    fi

    if [ ! -f "$DST/$name" ]; then
        printf '  SBIN NOT INSTALLED: %s (the panel or cron job calling it will fail)\n' "$name"
        missing=1
        continue
    fi

    checked=$((checked + 1))
    if ! diff -q "$SRC/$name" "$DST/$name" >/dev/null 2>&1; then
        # Direction matters for the fix: "live is newer" means someone hotfixed
        # the running system and the repo is behind (port it back, do not
        # clobber it); "repo is newer" means a committed change never reached
        # the host (reinstall it). Saying which saves the reader a stat.
        if [ "$DST/$name" -nt "$SRC/$name" ]; then
            printf '  SBIN DRIFT: %s -- LIVE is newer (hotfixed on the host? port it back into install/ before redeploying)\n' "$name"
        else
            printf '  SBIN DRIFT: %s -- REPO is newer (committed but never installed: install -m … install/%s %s/)\n' "$name" "$name" "$DST"
        fi
        drift=1
    fi
done < <(awk '$1 !~ /^#/ && NF >= 3 && $3 == "list" { print $1 }' "$LIST")

skipped=$(awk '$1 !~ /^#/ && NF >= 3 && $3 == "tmpl" { n++ } END { print n+0 }' "$LIST")

if [ "$drift" = 0 ] && [ "$missing" = 0 ]; then
    say "check-sbin-drift: $checked helpers match $DST ($skipped templated, not comparable) -- clean"
    exit 0
fi

echo "check-sbin-drift: $checked helpers compared, drift found (see above)" >&2
exit 1
