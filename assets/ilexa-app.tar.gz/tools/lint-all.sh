#!/usr/bin/env bash
# Repo-wide PHP syntax gate: php -l over every file under src/, views/,
# lang/, plus the repo-root PHP entry points.
#
# Historically this was manual and per-file, run by hand only for whatever
# file a session happened to touch (see docs/superpowers/plans/*.md) -- never
# swept across the whole tree, and never enforced before a deploy. deploy.sh
# now runs this first and refuses to deploy on any failure.
#
#   tools/lint-all.sh            run the full sweep
#   tools/lint-all.sh --quiet    only print failures (for use from deploy.sh)
set -uo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$HERE"

quiet=0
[ "${1:-}" = "--quiet" ] && quiet=1

# install/ carries root-run PHP helpers (qa-db-migrate.php, qa-ioc-lookup.php,
# the cron jobs) that deploy.sh does not touch -- they are copied to
# /usr/local/sbin by hand or by the installer. Nothing else syntax-checks them,
# so a broken one used to ship and only fail at 3am from cron.
mapfile -t files < <(find src views lang install -type f -name '*.php' 2>/dev/null | sort; find . -maxdepth 1 -type f -name '*.php' | sort)

fail=0
for f in "${files[@]}"; do
  out="$(php -l "$f" 2>&1)"
  if ! grep -q "No syntax errors detected" <<<"$out"; then
    echo "PHP SYNTAX ERROR: $f"
    echo "$out"
    fail=1
  fi
done

# i18n coverage + placeholder parity. Separate script because it is an
# AST/semantic check rather than a syntax one; see its header for the two bug
# classes it guards (untranslated strings rendering Hungarian to an English
# admin, and sprintf silently swapping reordered arguments).
i18n_out="$(php tools/check-i18n.php 2>&1)"
i18n_rc=$?
# Raw t() inside <script> is a language-dependent SyntaxError waiting to
# happen -- see tools/check-js-i18n.php for the outage that motivated it.
js_out="$(php "$HERE/tools/check-js-i18n.php" 2>&1)"; js_rc=$?
# Hungarian text that reaches the screen without ever calling t(). The i18n
# check above verifies that every t() HAS a translation; it cannot see a
# literal that never asked for one, which is how seven Hungarian strings
# shipped into the English console undetected.
hul_out="$(php "$HERE/tools/check-hu-literals.php" 2>&1)"; hul_rc=$?
# Helper-list consistency: install/helpers.list vs both installers' loops and
# sudoers.example. Guards the bug class that has cost the most time in this
# project -- a panel or cron job calling a root helper the installer never
# placed, which fails at runtime and explains nothing about why.
# Render every view and fail on any PHP diagnostic. This is the gap php -l
# cannot cover: count(null), undefined variables and array-offset-on-null all
# parse fine and only appear at render time -- two shipped on 2026-08-18 and
# were found by eye.
views_out="$(php "$HERE/tools/check-views.php" --quiet 2>&1)"; views_rc=$?
if [ "$views_rc" != 0 ]; then
  echo "$views_out"
  fail=1
elif [ "$quiet" != 1 ]; then
  echo "$views_out" | tail -1
fi
helpers_out="$(php "$HERE/tools/check-helpers.php" 2>&1)"; helpers_rc=$?
if [ "$helpers_rc" != 0 ]; then
  echo "$helpers_out"
  fail=1
elif [ "$quiet" != 1 ]; then
  echo "$helpers_out" | tail -1
fi
# DB migration static checks: header parity, table allowlist, and the
# IF NOT EXISTS/IF EXISTS guard MySQL's non-transactional DDL depends on for
# safe replay. See db/migrations/README.md.
migrations_out="$(php "$HERE/tools/check-migrations.php" 2>&1)"; migrations_rc=$?
if [ "$migrations_rc" != 0 ]; then
  echo "$migrations_out"
  fail=1
elif [ "$quiet" != 1 ]; then
  echo "$migrations_out" | tail -1
fi
# Lookup-service registry consistency: a service has to be named in five
# unrelated places before it works end to end, and the two times one was not,
# nothing failed loudly -- the service just quietly did less than it looked
# like it was doing. See the script's header.
lookupsvc_out="$(php "$HERE/tools/check-lookup-services.php" 2>&1)"; lookupsvc_rc=$?
if [ "$lookupsvc_rc" != 0 ]; then
  echo "$lookupsvc_out"
  fail=1
elif [ "$quiet" != 1 ]; then
  echo "$lookupsvc_out" | tail -1
fi
# External-API budget arithmetic. Unit tests rather than a consistency check:
# a ledger that permits one request too many looks exactly like one that does
# not, until the provider withdraws access.
quota_out="$(php "$HERE/tools/check-quota.php" --quiet 2>&1)"; quota_rc=$?
if [ "$quota_rc" != 0 ]; then
  echo "$quota_out"
  fail=1
fi
# All three email-exposure parsers share one catastrophic failure mode:
# returning "nothing found" for a response they did not understand, which is
# indistinguishable from a genuine clean answer on a dashboard whose job is
# saying which mailboxes are exposed. Also asserts that Hudson Rock's masked
# passwords, logins and victim IP never reach our payload.
parsers_out="$(php "$HERE/tools/check-breach-parsers.php" --quiet 2>&1)"; parsers_rc=$?
if [ "$parsers_rc" != 0 ]; then
  echo "$parsers_out"
  fail=1
fi
# The breach sweep's most dangerous failure is recording an address as clean
# when the lookup never succeeded.
sweep_out="$(python3 "$HERE/tools/check-breach-sweep.py" --quiet 2>&1)"; sweep_rc=$?
if [ "$sweep_rc" != 0 ]; then
  echo "$sweep_out"
  fail=1
fi
if [ "$js_rc" != 0 ]; then
  echo "$js_out"
  fail=1
elif [ "$quiet" != 1 ]; then
  echo "$js_out" | tail -1
fi

if [ "$i18n_rc" != 0 ]; then
  echo "$i18n_out" | grep -vE '^note:'
  fail=1
elif [ "$quiet" != 1 ]; then
  echo "$i18n_out" | tail -1
fi

if [ "$hul_rc" != 0 ]; then
  echo "$hul_out"
  fail=1
elif [ "$quiet" != 1 ]; then
  echo "$hul_out" | tail -1
fi

[ "$quiet" = 1 ] || echo
echo "lint-all: ${#files[@]} PHP files checked -- $([ "$fail" = 0 ] && echo clean || echo 'FAILURES ABOVE')"

[ "$fail" = 1 ] && exit 1
exit 0
