<?php
// On-demand reputation lookup for a single quarantined message: checks both
// the sender domain (parsed from hdr_from) and the connecting IP
// (parse_fetch()'s sender_ip). Reuses the shared list_lookups cache/scoring
// stack (src/list_lookup.php, src/ioc_lookup.php) wholesale -- this file adds
// no new lookup mechanism, only the message-row -> indicator resolution and
// the two-indicator scoring/JSON shape the quarantine ("Jelentett") page
// needs.

// Resolves one fetched message row (the associative-array shape fetch_uids()
// returns) to the domain/IP indicators worth checking, plus why either is
// absent when it is. Used by BOTH handle_quar_lookup_action() below and
// (a later task) the quarantine view, so a row's rendered state and what
// actually gets looked up can never disagree.
function quar_row_indicators(array $msg): array {
    $out = ['domain' => null, 'ip' => null, 'skip' => ['domain' => null, 'ip' => null]];

    // Isolate the bare address before taking "the part after the last @".
    // hdr_from is routinely `"Name" <user@domain>`; naively taking the last
    // '@' of the RAW header would return "domain>" for that common shape and
    // fail validation for almost every row. Take the LAST "<...>" group, not
    // the first: RFC 5322 puts the real mailbox in the final angle-addr, and
    // a sender-controlled display-name/quoted-string earlier in the header
    // can itself contain "<...>"-shaped text (e.g.
    // `"click <phish@evil.com>" <user@real.example>`) -- matching the first
    // occurrence would resolve to, cache, and spend shared VT/OTX quota
    // checking a domain the attacker chose, not the true sender's. A header
    // with no angle brackets at all falls through to the raw string.
    $from = decode_subject((string) ($msg['hdr_from'] ?? ''));
    $from_email = $from;
    if (preg_match_all('/<([^>]+)>/', $from, $fm) && $fm[1]) {
        $from_email = end($fm[1]);
    }
    $at = strrpos($from_email, '@');
    if ($at === false) {
        $out['skip']['domain'] = 'missing';
    } else {
        // Lowercase + trim: list_lookups is keyed on (type, value), so an
        // un-canonicalised case/whitespace difference would fragment the
        // shared 24h cache the Blokkolás/Fehérlista pages also read, and
        // spend real VirusTotal/OTX quota re-checking something already
        // known under a different-case key.
        $domain = strtolower(trim(substr($from_email, $at + 1)));
        if ($domain === '' || !_ioc_valid_value('domain', $domain)) {
            $out['skip']['domain'] = 'invalid';
        } elseif (in_array($domain, array_map('strtolower', get_domains()), true)) {
            // Locally hosted sender domain: explicit decision, not an
            // oversight. Spam routinely forges From: to one of this
            // server's own domains, so showing that domain's reputation
            // next to such a message would be misleading.
            // (all_users()/get_domains() failing open to [] on a doveadm
            // hiccup just means nothing matches here -- no local domain
            // gets skipped in that case, not a silent block.)
            $out['skip']['domain'] = 'local';
        } else {
            $out['domain'] = $domain;
        }
    }

    // sender_ip is already the public-only, topmost-Received:-derived
    // literal parse_fetch() computes; re-validate defensively rather than
    // trust the field blindly (it may be absent on rows not built by
    // fetch_uids() -- e.g. a future view-side caller), and lowercase for the
    // same cache-key reason as the domain above (IPv6 hex literals can vary
    // in case). Use qa_is_public_ip(), not a bare
    // filter_var(...NO_PRIV_RANGE|NO_RES_RANGE...): those flags alone do not
    // recognise the IPv4-mapped-IPv6 form ("::ffff:10.0.0.1"), which they
    // pass as "public" even though the embedded IPv4 address is private
    // (src/ioc.php, fixed there for the same reason in commit b9edfb8 on
    // this branch).
    $ip = strtolower(trim((string) ($msg['sender_ip'] ?? '')));
    if ($ip === '') {
        $out['skip']['ip'] = 'missing';
    } elseif (!qa_is_public_ip($ip)) {
        $out['skip']['ip'] = 'private';
    } else {
        $out['ip'] = $ip;
    }

    return $out;
}

// Mirrors handle_list_lookup_action()'s AJAX/JSON contract (src/list_lookup.php),
// nested by indicator instead of flat.
//
// $caller is a test-only seam: it is threaded straight through to the two
// lookup_run_value() calls below and is NEVER populated from request input
// (no POST field maps to it) -- production always calls with the default,
// which resolves to _ioc_lookup_call()'s real sudo+qa-ioc-lookup.sh path. It
// exists so a test harness can drive this function through a real POST
// request (auth, validation, indicator derivation, scoring all exercised as
// written) while stubbing out the actual external VT/OTX/etc. calls that
// would otherwise spend shared quota and write into the live shared cache.
function handle_quar_lookup_action(?callable $caller = null): void {
    $isAjax = ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'XMLHttpRequest';

    $deny = function (string $msg, ?int $status = null) use ($isAjax): void {
        if ($isAjax) {
            header('Content-Type: application/json; charset=utf-8');
            if ($status !== null) http_response_code($status);
            echo json_encode(['ok' => false, 'indicators' => null, 'confidence' => null,
                               'errors' => ['_' => $msg]]);
            exit;
        }
        header('Location: ?'); exit;
    };

    // Endpoint-level authorization: hiding the button is not a control. Same
    // permission handle_list_lookup_action() gates on, so both lookup entry
    // points stay in lockstep. A 302 here would trip the AJAX client's
    // r.json() and its .catch() would re-submit -- return JSON 403 instead
    // (the handle_view() pattern, src/actions.php:19-23).
    if (!can('lists')) {
        $deny(t('Nincs jogosultság ehhez a művelethez.'), 403);
        return; // $deny() always exits; belt-and-braces so a future edit to
                // its body can't turn this gate into a silent fall-through.
    }

    $user   = (string) ($_POST['msg_user']   ?? '');
    $folder = (string) ($_POST['msg_folder'] ?? '');
    $uid    = (string) ($_POST['msg_uid']    ?? '');

    if (!valid_user($user) || !valid_folder($folder) || !valid_uid($uid)) {
        $deny(t('Érvénytelen paraméterek'));
        return;
    }

    // Mandatory and new for a read path: $domain_restricted only filters the
    // *view*, so without this check a domain_admin could read (and spend
    // shared external-API quota checking) any mailbox's headers, not just
    // their assigned domain's.
    if (!qa_domain_allowed($user)) {
        $deny(t('Nincs jogosultság ehhez a művelethez.'), 403);
        return;
    }

    // The server re-derives both indicators itself from the real message.
    // The client sends only user/folder/uid -- if it could supply the
    // domain/IP directly, any authenticated user could spend shared VT/OTX
    // quota checking arbitrary strings and poison the shared list_lookups
    // cache the Blokkolás/Fehérlista pages read.
    $rows = fetch_uids($user, $folder, [$uid]);
    if (!$rows) {
        $deny(t('A levél nem található.'));
        return;
    }

    $ind = quar_row_indicators($rows[0]);

    if ($ind['domain'] === null && $ind['ip'] === null) {
        // Nothing checkable -- no external call, and nothing worth an audit
        // trail entry either (no lookup was attempted).
        $deny(t('Ehhez a levélhez nincs ellenőrizhető adat.'));
        return;
    }

    $indicators = ['domain' => null, 'ip' => null];
    $best       = null; // ['pct'=>int,'tier'=>string] -- the higher of the two indicator confidences

    foreach (['domain', 'ip'] as $type) {
        $value = $ind[$type];
        if ($value === null) continue;

        $r    = lookup_run_value($type, $value, $caller, 'quarantine');
        $conf = ioc_lookup_confidence($r['results']);
        $indicators[$type] = [
            'value' => $value, 'results' => $r['results'], 'errors' => $r['errors'], 'confidence' => $conf,
        ];
        // Surface the HIGHER pct as the top-level confidence, carrying that
        // winner's tier. Do NOT merge the two service maps: virustotal/otx/
        // hrbl apply to both indicators, so array_merge() would drop one
        // verdict and count the weight once, and re-keying (e.g.
        // "virustotal@ip") would make IOC_CONFIDENCE_WEIGHTS[$service] ?? 0
        // return 0 for every entry -> total 0 -> null -> every row blank.
        // "domain clean, IP malicious" is the most actionable pattern on
        // this page and must stay visible, so worst-verdict-wins was also
        // rejected. On an exact tie, the indicator processed first (domain)
        // wins, which is an arbitrary but deterministic and harmless choice.
        if ($conf !== null && ($best === null || $conf['pct'] > $best['pct'])) {
            $best = $conf;
        }
    }

    // All four fields are already validated (valid_user/valid_folder/
    // valid_uid, plus qa_domain_allowed()), so no newline-sanitisation
    // question arises here.
    audit_log('quar-lookup', $user, $folder, $uid);

    $out = ['ok' => true, 'indicators' => $indicators, 'confidence' => $best, 'errors' => []];

    if ($isAjax) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($out);
        exit;
    }
    header('Location: ?'); exit;
}
