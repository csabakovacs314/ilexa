<?php
// Successful POP3/IMAP/webmail authentication -- the counterpart to
// mail_auth_failures() in audit.php, and the ingestion source for
// login-anomaly scoring (see plans/zany-napping-sunrise.md). Merged from the
// same two sources for the same reason:
//
// - Dovecot's own log: every direct IMAP/POP3 client success, real source
//   IP. Roundcube's OWN successful logins ALSO land here (Roundcube
//   authenticates as an IMAP client), but with rip=127.0.0.1 -- Dovecot only
//   ever sees Roundcube's own server-side connection, never the browser's
//   real IP -- so those rows are dropped in favour of the next source.
// - Roundcube's userlogins.log: the same webmail successes, but with the
//   real browser-side client IP Roundcube itself received over HTTP.
//
// Unlike the failure line, Dovecot emits this unconditionally -- it is not
// gated by auth_verbose (that setting only controls the auth worker's
// failure-reason detail). Confirmed live: dovecotlog already carries these
// lines with auth_verbose=no. No Dovecot config change was needed for this.
function mail_auth_successes(int $limit = 150): array {
    $events = [];

    $ok  = null;
    $out = qa_sudo_read(SUDO . ' /usr/local/sbin/qa-audit-log.sh mail-auth-success', 'audit:mail-auth', $ok, [0, 1]);
    $year = (int) date('Y');
    foreach (explode("\n", $out) as $line) {
        if ($line === '') continue;
        // Greedy ".*rip=" (locks onto the LAST rip= on the line), same
        // hardening as mail_auth_failures() -- see that function's comment
        // for why a non-greedy scan is unsafe here.
        if (!preg_match('/^(\w{3} +\d{1,2} \d{2}:\d{2}:\d{2}) (imap|pop3)-login: Info: Login: user=<([^>]*)>.*rip=([0-9a-fA-F:.]+)/',
                         $line, $m)) continue;
        if ($m[4] === '127.0.0.1' || $m[4] === '::1') continue; // see comment above: Roundcube's own log has the real IP
        if ($m[3] === '' || !valid_user($m[3])) continue; // a success line always has a real username; reject anything malformed
        // Dovecot's log carries no year -- same yearless-timestamp fallback
        // as mail_auth_failures().
        $dt = DateTime::createFromFormat('M j H:i:s Y', $m[1] . ' ' . $year);
        if ($dt !== false && $dt->getTimestamp() > time()) {
            $dt = DateTime::createFromFormat('M j H:i:s Y', $m[1] . ' ' . ($year - 1));
        }
        if ($dt === false) continue;
        $events[] = ['ts' => $dt->getTimestamp(), 'user' => $m[3], 'ip' => $m[4],
                     'proto' => strtoupper($m[2]), 'source' => strtoupper($m[2])];
    }

    // Roundcube's own log is apache-owned (unlike every other source here),
    // so it is read directly -- no sudo helper needed for this one.
    if (ROUNDCUBE_LOG_DIR !== '') {
        $rc = @file_get_contents(ROUNDCUBE_LOG_DIR . '/userlogins.log');
        if ($rc !== false) {
            foreach (explode("\n", $rc) as $line) {
                if ($line === '') continue;
                // [31-May-2026 13:06:12 +0000]: <sess> Successful login for user@domain (ID: N) from 1.2.3.4 in session ...
                if (!preg_match('/^\[(\d{2}-\w{3}-\d{4} \d{2}:\d{2}:\d{2}) ([+-]\d{4})\]: <[^>]*> Successful login for (\S+) \(ID: \d+\) from (\S+)/',
                                 $line, $m)) continue;
                if (!valid_user($m[3]) || !filter_var($m[4], FILTER_VALIDATE_IP)) continue;
                $dt = DateTime::createFromFormat('d-M-Y H:i:s O', $m[1] . ' ' . $m[2]);
                if ($dt === false) continue;
                $events[] = ['ts' => $dt->getTimestamp(), 'user' => $m[3], 'ip' => $m[4],
                             'proto' => 'WEBMAIL', 'source' => 'WEBMAIL'];
            }
        }
    }

    usort($events, fn($a, $b) => $b['ts'] <=> $a['ts']);
    return array_slice($events, 0, $limit);
}

// ── Login-history store (app-owned SQLite, mirrors _ioc_db() in ioc.php) ──
//
// A new file, not more tables in iocs.db: this is a different domain with a
// different retention policy, and independent files mean the ingester's
// writes never contend with IOC-lookup writes. See plans/zany-napping-
// sunrise.md for why SQLite here rather than the postfix MariaDB (keeps the
// deliberately read-only qaudit_ro grant from ever needing a write widening).
function _signin_db(): PDO {
    static $db = null;
    if ($db !== null) return $db;

    try {
        $path = dirname(SETTINGS_FILE) . '/logins.db';
        $db = new PDO('sqlite:' . $path, null, null, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        ]);
        $db->exec('PRAGMA busy_timeout = 5000');
        $db->exec('CREATE TABLE IF NOT EXISTS signin_events (
            id       INTEGER PRIMARY KEY AUTOINCREMENT,
            ts       INTEGER NOT NULL,
            user     TEXT NOT NULL,
            ip       TEXT NOT NULL,
            proto    TEXT NOT NULL,
            status   TEXT NOT NULL,
            cc       TEXT NOT NULL DEFAULT \'\',
            asn      INTEGER,
            lat      REAL,
            lon      REAL,
            score    INTEGER,
            tier     TEXT,
            reasons  TEXT NOT NULL DEFAULT \'\',
            notified INTEGER NOT NULL DEFAULT 0,
            UNIQUE(user, ip, ts, proto, status)
        )');
        $db->exec('CREATE INDEX IF NOT EXISTS idx_signin_user_ts ON signin_events(user, ts)');
        $db->exec('CREATE TABLE IF NOT EXISTS signin_places (
            user       TEXT NOT NULL,
            kind       TEXT NOT NULL,
            value      TEXT NOT NULL,
            first_seen INTEGER NOT NULL,
            last_seen  INTEGER NOT NULL,
            hits       INTEGER NOT NULL DEFAULT 1,
            PRIMARY KEY(user, kind, value)
        )');
        @chmod($path, 0640);
    } catch (Throwable $e) {
        throw new Exception('signin database initialization failed: ' . $e->getMessage());
    }

    return $db;
}

// The /24 (IPv4) or /48 (IPv6) network prefix a "familiar network" signal is
// keyed on -- narrower than ASN (a large residential ISP's whole ASN is too
// broad to mean "the same connection"), wider than the exact IP (a dynamic
// home IP legitimately changes address within the same network often).
function signin_net_prefix(string $ip): string {
    if (strpos($ip, ':') !== false) {
        $bin = @inet_pton($ip);
        if ($bin === false || strlen($bin) !== 16) return '';
        return inet_ntop(substr($bin, 0, 6) . str_repeat("\0", 10)) . '/48';
    }
    $parts = explode('.', $ip);
    if (count($parts) !== 4) return '';
    return $parts[0] . '.' . $parts[1] . '.' . $parts[2] . '.0/24';
}

// Record that $user was seen at $cc/$asn/$net/$proto -- the "usual" profile
// signin_risk_score() (Phase 3) reads back. Only called for SUCCESSFUL
// logins: a failed attempt from a new place must never make that place look
// familiar, or the very signal meant to catch a credential-stuffing attempt
// from a new network would erase itself on the first try.
function signin_record_place(PDO $db, string $user, string $kind, string $value, int $ts): void {
    if ($value === '') return;
    $stmt = $db->prepare(
        'INSERT INTO signin_places (user, kind, value, first_seen, last_seen, hits)
         VALUES (:user, :kind, :value, :ts, :ts, 1)
         ON CONFLICT(user, kind, value) DO UPDATE SET
            last_seen = :ts,
            hits = hits + 1'
    );
    $stmt->execute([':user' => $user, ':kind' => $kind, ':value' => $value, ':ts' => $ts]);
}

// Ingests recent success+failure events into logins.db: enrich (once per
// distinct IP -- qa_ip_geo()/qa_ip_asn()/qa_ip_country() all cache per
// process already) then INSERT OR IGNORE, so a re-run over the same ~8-day
// window is naturally idempotent via the UNIQUE key -- no offset/cursor
// file, matching this codebase's existing log-ingestion convention.
// Scoring is NOT done here (Phase 3) -- score/tier/reasons stay NULL.
// Returns ['inserted' => int, 'seen' => int] for the caller to report.
function signin_ingest(int $limit = 500, bool $dry = false): array {
    $db = _signin_db();
    $ins = $dry ? null : $db->prepare(
        'INSERT OR IGNORE INTO signin_events (ts, user, ip, proto, status, cc, asn, lat, lon, score, tier, reasons)
         VALUES (:ts, :user, :ip, :proto, :status, :cc, :asn, :lat, :lon, :score, :tier, :reasons)'
    );
    // Existence check BEFORE any enrichment/scoring, not just for dry-run:
    // on a normal 5-minute run, ~495 of the ~500 fetched rows are already
    // ingested (the source functions return the same recent window every
    // time -- see mail_auth_successes()'s own comment), so checking first
    // skips the geo shell-outs and the several scoring queries entirely
    // for anything not actually new, rather than doing that work and then
    // discarding it via INSERT OR IGNORE.
    $chk = $db->prepare(
        'SELECT 1 FROM signin_events WHERE user=:user AND ip=:ip AND ts=:ts AND proto=:proto AND status=:status'
    );

    $seen = 0; $inserted = 0; $samples = [];
    // Failures processed FIRST and fully inserted before any success is
    // scored: signin_risk_score()'s "recent failures from a new place"
    // signal reads already-stored fail rows, and would silently miss any
    // failure that arrived in this SAME 5-minute batch otherwise. Within
    // each batch, oldest-first (both source functions return newest-first)
    // so that if two new successes land for the same user in one run, the
    // later one's profile correctly sees the earlier one as prior history
    // -- not the other way around.
    $batches = [
        ['rows' => array_reverse(mail_auth_failures($limit)),  'status' => 'fail'],
        ['rows' => array_reverse(mail_auth_successes($limit)), 'status' => 'success'],
    ];
    foreach ($batches as $batch) {
        foreach ($batch['rows'] as $r) {
            $seen++;
            $proto = $r['proto'] ?? $r['source'];

            $chk->execute([':user' => $r['user'], ':ip' => $r['ip'], ':ts' => $r['ts'],
                            ':proto' => $proto, ':status' => $batch['status']]);
            if ($chk->fetch()) continue; // already ingested, nothing to do

            $geo = qa_ip_geo($r['ip']);
            $asn = qa_ip_asn($r['ip']);
            $score = null; $tier = null; $reasonsJson = null;

            if ($batch['status'] === 'success') {
                // Scored against the profile as it stood BEFORE this event
                // (signin_user_profile()'s own contract) -- must happen
                // before signin_record_place() below updates it, dry-run
                // or not, so a --dry-run preview shows the same score a
                // real run would have stored.
                $profile = signin_user_profile($db, $r['user'], $r['ts'], $r['ip'], $geo['cc']);
                $scored = signin_risk_score(
                    ['ts' => $r['ts'], 'ip' => $r['ip'], 'cc' => $geo['cc'], 'asn' => $asn,
                     'lat' => $geo['lat'], 'lon' => $geo['lon'], 'proto' => $proto],
                    $profile
                );
                $score = $scored['score']; $tier = $scored['tier'];
                $reasonsJson = json_encode($scored['reasons']);
            }

            if (!$dry) {
                $ins->execute([
                    ':ts' => $r['ts'], ':user' => $r['user'], ':ip' => $r['ip'],
                    ':proto' => $proto, ':status' => $batch['status'],
                    ':cc' => $geo['cc'], ':asn' => $asn, ':lat' => $geo['lat'], ':lon' => $geo['lon'],
                    ':score' => $score, ':tier' => $tier, ':reasons' => $reasonsJson,
                ]);
                if ($ins->rowCount() === 0) continue; // lost a race with another run -- not actually new
            }

            $inserted++;
            if (count($samples) < 10) {
                $tag = $tier !== null ? " [$tier $score%]" : '';
                $samples[] = date('Y-m-d H:i:s', $r['ts']) . " {$r['user']} {$r['ip']} $proto {$batch['status']}$tag";
            }
            if ($batch['status'] === 'success') {
                if (!$dry) {
                    $net = signin_net_prefix($r['ip']);
                    signin_record_place($db, $r['user'], 'cc',    $geo['cc'], $r['ts']);
                    if ($asn !== null) signin_record_place($db, $r['user'], 'asn', (string) $asn, $r['ts']);
                    if ($net !== '')   signin_record_place($db, $r['user'], 'net', $net, $r['ts']);
                    signin_record_place($db, $r['user'], 'proto', $proto, $r['ts']);
                }

                // 'learning' is deliberately excluded here (both from the
                // audit trail and from notification below): a brand-new
                // profile's very first login always scores high on raw
                // signal weight alone (nothing is familiar yet), and that
                // is not a real anomaly -- flagging it as one would be
                // noisy exactly when it is least informative.
                if ($tier === 'high') {
                    if (!$dry) audit_log('signin-high-risk', $r['user'], $r['ip'], (string) $score);

                    // signin_maybe_notify() handles the dry-run/real split
                    // for the SEND itself (and its own audit_log call);
                    // only the notified=1 flag on this row is specific to
                    // signin_ingest()'s own bookkeeping, so it stays here.
                    $didNotify = signin_maybe_notify($db, $r['user'], $r['ip'], $geo['cc'], $asn,
                                                      $score, $r['ts'], $proto, $dry);
                    if ($didNotify && !$dry) {
                        $db->prepare('UPDATE signin_events SET notified = 1 WHERE id = :id')
                           ->execute([':id' => $db->lastInsertId()]);
                    }
                }
            }
        }
    }

    return ['inserted' => $inserted, 'seen' => $seen, 'samples' => $samples];
}

// Inline prune, same "no separate cron" spirit as qa-ioc-expire.php's own
// relationship to iocs.db. Called at the end of every ingester run.
function signin_prune(int $eventsDays = 180, int $placesDays = 365): array {
    $db = _signin_db();
    $now = time();
    $de = $db->prepare('DELETE FROM signin_events WHERE ts < :cutoff');
    $de->execute([':cutoff' => $now - $eventsDays * 86400]);
    $dp = $db->prepare('DELETE FROM signin_places WHERE last_seen < :cutoff');
    $dp->execute([':cutoff' => $now - $placesDays * 86400]);
    return ['events_deleted' => $de->rowCount(), 'places_deleted' => $dp->rowCount()];
}

// Successful sign-ins for display, read from the DB the ingester populates
// -- NOT a live log parse. Same return shape as mail_auth_successes() (ts/
// user/ip/proto/source) so the Audit view's rendering is unchanged; only
// the source moved. This is the Phase-2-onward path: the ingester's own
// cron run (every 5 minutes) is what keeps this current, not the page
// load itself -- eliminates the ~500ms/page cost the raw log parse had
// (measured live during Phase 1: 25,000+ matching lines/8 days).
function signin_events_success(int $limit = 500, bool $anomaliesOnly = false): array {
    try {
        $db = _signin_db();
    } catch (Throwable $e) {
        return [];
    }
    $sql = 'SELECT ts, user, ip, proto, score, tier, reasons FROM signin_events WHERE status = \'success\'';
    if ($anomaliesOnly) $sql .= ' AND tier IN (\'medium\', \'high\')';
    $sql .= ' ORDER BY ts DESC LIMIT :limit';
    $stmt = $db->prepare($sql);
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();
    $rows = [];
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) {
        $reasons = json_decode((string) $r['reasons'], true);
        $rows[] = ['ts' => (int) $r['ts'], 'user' => $r['user'], 'ip' => $r['ip'],
                   'proto' => $r['proto'], 'source' => $r['proto'],
                   'score' => $r['score'] !== null ? (int) $r['score'] : null,
                   'tier' => $r['tier'], 'reasons' => is_array($reasons) ? $reasons : []];
    }
    return $rows;
}

// Count of tier='high'/'medium' success events in the last $hours -- the
// dashboard card's own query, kept here next to the table it reads rather
// than duplicated in views/dashboard.php.
// 'detail' is a short, newest-first list (capped, not exhaustive) of who
// actually triggered the count -- for a hover tooltip on the dashboard
// card. A bare "3 high-risk" tells an admin nothing actionable; naming the
// users is what turns the summary into something worth clicking through
// from, matching how the traffic chart's own per-bar tooltip already
// carries detail beyond what the bar's height alone shows.
function signin_anomaly_counts(int $hours = 24, int $detailLimit = 5): array {
    try {
        $db = _signin_db();
    } catch (Throwable $e) {
        return ['high' => 0, 'medium' => 0, 'detail' => []];
    }
    $stmt = $db->prepare('SELECT user, ip, cc, tier FROM signin_events
                           WHERE status = \'success\' AND tier IN (\'high\', \'medium\')
                             AND ts >= :cutoff ORDER BY ts DESC');
    $stmt->execute([':cutoff' => time() - $hours * 3600]);
    $out = ['high' => 0, 'medium' => 0, 'detail' => []];
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) {
        $out[$r['tier']]++;
        if (count($out['detail']) < $detailLimit) {
            $out['detail'][] = ['user' => $r['user'], 'ip' => $r['ip'], 'cc' => $r['cc'], 'tier' => $r['tier']];
        }
    }
    return $out;
}

// ── Risk scoring ────────────────────────────────────────────────────────

// Great-circle distance in km -- impossible-travel needs real distance, not
// just "country changed" (see qa_ip_geo()'s own comment for why: this
// deployment's users sit in a region where two countries can be under an
// hour apart by road).
function signin_haversine_km(float $lat1, float $lon1, float $lat2, float $lon2): float {
    $r = 6371.0;
    $dLat = deg2rad($lat2 - $lat1);
    $dLon = deg2rad($lon2 - $lon1);
    $a = sin($dLat / 2) ** 2 + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLon / 2) ** 2;
    return $r * 2 * atan2(sqrt($a), sqrt(1 - $a));
}

// Gathers everything signin_risk_score() needs about $user as it stood
// STRICTLY BEFORE $beforeTs (the event being scored) -- scored against
// signin_places as it existed before this login, not after, or every login
// would trivially look "familiar" against a profile it just wrote itself.
// This is why signin_ingest() must call this (and score) BEFORE it calls
// signin_record_place() for the same event.
function signin_user_profile(PDO $db, string $user, int $beforeTs, string $ip, string $cc): array {
    $places = ['cc' => [], 'asn' => [], 'net' => [], 'proto' => []];
    $stmt = $db->prepare('SELECT kind, value, first_seen, last_seen, hits FROM signin_places WHERE user = :user');
    $stmt->execute([':user' => $user]);
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) {
        $places[$r['kind']][$r['value']] = ['first_seen' => (int) $r['first_seen'], 'hits' => (int) $r['hits']];
    }
    $earliest = null;
    foreach ($places as $vals) foreach ($vals as $v) {
        if ($earliest === null || $v['first_seen'] < $earliest) $earliest = $v['first_seen'];
    }

    $cnt = $db->prepare('SELECT COUNT(*) FROM signin_events WHERE user = :user AND status = \'success\' AND ts < :ts');
    $cnt->execute([':user' => $user, ':ts' => $beforeTs]);
    $priorSuccesses = (int) $cnt->fetchColumn();

    $prev = $db->prepare('SELECT ts, lat, lon FROM signin_events
                           WHERE user = :user AND status = \'success\' AND ts < :ts
                             AND lat IS NOT NULL AND lon IS NOT NULL
                           ORDER BY ts DESC LIMIT 1');
    $prev->execute([':user' => $user, ':ts' => $beforeTs]);
    $lastLogin = $prev->fetch(PDO::FETCH_ASSOC) ?: null;

    // "New to the user" for the failure signal below: this specific IP or
    // country never having appeared as a SUCCESS is what makes a burst of
    // failures from it worth flagging -- failures from an already-familiar
    // place are far more likely a stale saved password than an attack.
    $rf = $db->prepare('SELECT COUNT(*) FROM signin_events
                         WHERE user = :user AND status = \'fail\' AND ts BETWEEN :from AND :to
                           AND (ip = :ip OR (cc != \'\' AND cc = :cc))');
    $rf->execute([':user' => $user, ':from' => $beforeTs - 86400, ':to' => $beforeTs, ':ip' => $ip, ':cc' => $cc]);
    $recentFailures = (int) $rf->fetchColumn();

    return ['places' => $places, 'earliest_first_seen' => $earliest,
            'prior_successes' => $priorSuccesses, 'last_login' => $lastLogin,
            'recent_failures' => $recentFailures];
}

// Human-readable labels for the reason codes signin_risk_score() emits --
// used by the Audit UI (Phase 4) to render the stored JSON without
// duplicating this list there.
const SIGNIN_REASON_LABELS = [
    'impossible_travel'    => 'Lehetetlen utazási sebesség az előző bejelentkezéshez képest',
    'new_country'          => 'Új ország ennél a felhasználónál',
    'recent_failures'      => 'Több sikertelen kísérlet ugyaninnen, új helyről',
    'known_country_new_asn'=> 'Ismert ország, de új hálózat (szolgáltató)',
    'known_asn_new_net'    => 'Ismert hálózat, de új IP-tartomány',
    'new_protocol'         => 'Első bejelentkezés ezzel a protokollal',
    'familiar_net'         => 'Jól ismert IP-tartomány',
    'familiar_asn'         => 'Ismert hálózat (szolgáltató)',
    'familiar_country'     => 'Ismert ország',
    'mature_profile'       => 'Régóta megfigyelt fiók',
];

// Weighted risk score for ONE successful login event, mirroring
// ioc_lookup_confidence()'s shape (src/ioc_lookup.php): weighted positive
// (risk) / negative (familiarity) sums, pct = 100*positive/(positive+
// negative), 3 tiers, and the explanation built INSIDE the function so
// score and reasons can never drift apart between the ingester (which
// stores both) and any future view that might otherwise try to recompute
// them differently -- the exact bug class that precedent exists to avoid.
//
// A "learning" tier overrides high/medium/low for a user with too little
// history to trust a verdict from yet (score is still computed and stored,
// alerts are just suppressed for it -- see qa-signin-monitor.php).
function signin_risk_score(array $event, array $profile): array {
    $places = $profile['places'];
    $cc = $event['cc']; $asn = $event['asn']; $net = signin_net_prefix($event['ip']); $proto = $event['proto'];

    $newCountry = $cc === '' ? true : !isset($places['cc'][$cc]);
    $familiarCountry = !$newCountry;
    $newAsn = $asn !== null && !isset($places['asn'][(string) $asn]);
    $familiarAsn = $asn !== null && isset($places['asn'][(string) $asn]);
    $newNet = $net !== '' && !isset($places['net'][$net]);
    $familiarNet3 = $net !== '' && isset($places['net'][$net]) && $places['net'][$net]['hits'] >= 3;
    $newProto = !isset($places['proto'][$proto]);
    $matureProfile = $profile['prior_successes'] >= 20;

    $impossibleTravel = false;
    if ($profile['last_login'] !== null && $event['lat'] !== null && $event['lon'] !== null) {
        $prev = $profile['last_login'];
        $hours = max(0.01, ($event['ts'] - (int) $prev['ts']) / 3600);
        $km = signin_haversine_km((float) $prev['lat'], (float) $prev['lon'], (float) $event['lat'], (float) $event['lon']);
        if ($km >= 500 && ($km / $hours) > 900) $impossibleTravel = true;
    }

    // "New to the user": consistent with signin_user_profile()'s own
    // reasoning -- a burst of failures from an already-familiar country
    // is not the signal this is meant to catch.
    $recentFailuresNewPlace = $profile['recent_failures'] >= 3 && $newCountry;

    $signals = []; // code => weight (positive risk, negative familiarity)
    if ($impossibleTravel)                 $signals['impossible_travel']     = 40;
    if ($newCountry)                       $signals['new_country']          = 25;
    if ($recentFailuresNewPlace)           $signals['recent_failures']      = 20;
    if (!$newCountry && $newAsn)           $signals['known_country_new_asn']= 15;
    if (!$newAsn && $newNet)               $signals['known_asn_new_net']    = 8;
    if ($newProto)                         $signals['new_protocol']         = 5;
    if ($familiarNet3)                     $signals['familiar_net']         = -30;
    if ($familiarAsn)                      $signals['familiar_asn']         = -20;
    if ($familiarCountry)                  $signals['familiar_country']     = -10;
    if ($matureProfile)                    $signals['mature_profile']       = -10;

    $positive = array_sum(array_filter($signals, fn($w) => $w > 0));
    $negative = -array_sum(array_filter($signals, fn($w) => $w < 0));
    $total = $positive + $negative;
    $pct = $total > 0 ? (int) round(100 * $positive / $total) : 0;
    $tier = $pct >= 70 ? 'high' : ($pct >= 40 ? 'medium' : 'low');

    // Cold start: too little history to trust a verdict from yet. Computed
    // against the EVENT's own timestamp, not wall-clock now, so a batch
    // ingest of older log lines scores consistently regardless of when the
    // cron actually runs.
    $historyDays = $profile['earliest_first_seen'] !== null
        ? ($event['ts'] - $profile['earliest_first_seen']) / 86400 : 0;
    if ($profile['prior_successes'] < 10 || $historyDays < 14) $tier = 'learning';

    $reasons = [];
    foreach ($signals as $code => $weight) {
        $reasons[] = ['code' => $code, 'weight' => $weight, 'label' => SIGNIN_REASON_LABELS[$code] ?? $code];
    }

    return ['score' => $pct, 'tier' => $tier, 'reasons' => $reasons];
}

// ── Notification ────────────────────────────────────────────────────────
//
// Master switch: same flag-file shape as password_expiry_enabled_file()
// (src/rbac.php) -- read directly by BOTH the web app (admin toggle) and
// this standalone cron script's own process, with no DB dependency, so a
// broken DB connection can never accidentally leave notifications either
// stuck on or silently unavailable to disable. Defaults OFF: unproven
// thresholds against live traffic is a real false-positive risk, same
// reasoning password-expiry was shipped and then paused for.
function signin_notify_enabled_file(): string {
    return dirname(SETTINGS_FILE) . '/signin_notify_enabled';
}

function signin_notify_enabled(): bool {
    $f = signin_notify_enabled_file();
    if (!is_file($f)) return false;
    return trim((string) @file_get_contents($f)) === '1';
}

function signin_notify_enabled_set(bool $on): array {
    $ok = qa_atomic_write(signin_notify_enabled_file(), $on ? '1' : '0');
    return [$ok, $ok ? '' : t('Nem sikerült írni: ') . signin_notify_enabled_file()];
}

// Decides whether a just-inserted high-tier row should trigger a "new
// sign-in" email, and sends it if so. Called only for tier==='high'
// (never 'learning' -- see signin_ingest()'s own comment on why) from
// signin_ingest() right after the row is committed. Returns true if an
// email was sent (or would have been, in dry-run) so the caller can mark
// the row notified=1.
function signin_maybe_notify(PDO $db, string $user, string $ip, string $cc, ?int $asn,
                              int $score, int $ts, string $proto, bool $dry): bool {
    if (!signin_notify_enabled()) return false;

    // Hard cap: 3/user/day, checked against already-notified rows directly
    // -- no separate counter to drift from the data it counts.
    $capDay = $db->prepare("SELECT COUNT(*) FROM signin_events
                             WHERE user = :user AND notified = 1 AND ts >= :cutoff");
    $capDay->execute([':user' => $user, ':cutoff' => $ts - 86400]);
    if ((int) $capDay->fetchColumn() >= 3) return false;

    // At most once per (user, country+ASN) per 7 days: the dominant case
    // (a genuinely new place) is already covered for free by signin_places
    // -- once recorded, that place stops being "new" and the score itself
    // drops below the high threshold on the next login from there. This
    // backstop only matters for a burst of high-tier logins from the SAME
    // new place within one week before signin_places would otherwise settle
    // it (e.g. several signals other than place-familiarity keep firing).
    // SQLite's IS is NULL-safe equality (unlike =), so this correctly
    // matches both a real ASN and the "no ASN data" NULL case with one
    // bound parameter either way.
    $capPlace = $db->prepare("SELECT COUNT(*) FROM signin_events
                               WHERE user = :user AND notified = 1 AND cc = :cc
                                 AND asn IS :asn AND ts >= :cutoff");
    $capPlace->execute([':user' => $user, ':cc' => $cc, ':asn' => $asn,
                         ':cutoff' => $ts - 7 * 86400]);
    if ((int) $capPlace->fetchColumn() > 0) return false;

    // A log-derived username is never trusted straight into a mail header --
    // re-validate both its shape AND that it is a real, active mailbox via
    // the app's own least-privilege DB read (audit_db(), already granted
    // SELECT on mailbox.username -- qa-password-expiry-notify.php already
    // relies on the same grant for the same reason).
    if (!valid_user($user)) return false;
    $adb = audit_db();
    if (!$adb) return false;
    $chk = $adb->prepare('SELECT 1 FROM mailbox WHERE username = :u AND active = 1');
    $chk->execute([':u' => $user]);
    if (!$chk->fetch()) return false;

    $countryName = $cc;
    if ($cc !== '' && class_exists('Locale')) {
        $n = (string) Locale::getDisplayRegion('-' . $cc, qa_lang());
        if ($n !== '' && $n !== $cc) $countryName = $n;
    }
    $org = $asn !== null ? qa_ip_asn_org($ip) : '';
    $network = $asn !== null ? ("AS$asn" . ($org !== '' ? " ($org)" : '')) : t('ismeretlen hálózat');

    // Language follows the console's own system-wide setting (qa_lang(),
    // read from a file -- not a per-request cookie/session), same as every
    // other string in this app: Hungarian is the source, t() translates
    // out when the configured language is something else. This runs from
    // cron with no HTTP request at all, so a per-VISITOR language (like
    // Roundcube's own $config['language']) was never an option here --
    // this is the operator's ONE console-wide setting, correctly readable
    // from this context precisely because it is not request-scoped.
    $subject = t('Új bejelentkezés a postafiókjában');
    // Deliberately no link: this app has no portable "our own webmail URL"
    // constant (qa-password-expiry-notify.php's own notice has the same
    // gap, for the same reason -- see its header comment), and this
    // codebase's installer serves many different mail domains, so a
    // hardcoded URL here would be wrong on every deployment but this one.
    // A security notice training users to click a link in an email is also
    // the wrong habit to build regardless.
    $body = t('Üdvözöljük!') . "\n\n"
          . sprintf(t('Új bejelentkezést észleltünk a postafiókjában (%s):'), $user) . "\n\n"
          . '  ' . t('Időpont (UTC)') . ': ' . gmdate('Y-m-d H:i:s', $ts) . "\n"
          . '  ' . t('IP-cím') . ": $ip\n"
          . '  ' . t('Helyszín') . ": $countryName\n"
          . '  ' . t('Hálózat') . ": $network\n"
          . '  ' . t('Protokoll') . ": $proto\n\n"
          . t('Ha Ön jelentkezett be, nincs teendője.') . "\n"
          . t('Ha NEM Ön jelentkezett be, azonnal változtassa meg a postafiók jelszavát, és értesítse a rendszergazdát.') . "\n\n"
          . sprintf(t('Ez egy automatikus üzenet a következőtől: %s.'), POSTMASTER_FROM) . "\n";

    if ($dry) {
        fwrite(STDOUT, "[dry-run] would notify $user: sign-in from $ip ($countryName)\n");
        return true;
    }

    $h = popen(SENDMAIL . ' -i -f ' . escapeshellarg(POSTMASTER_FROM) . ' ' . escapeshellarg($user), 'w');
    if (!$h) return false;
    fwrite($h, 'From: ' . POSTMASTER_FROM . "\r\n");
    fwrite($h, "To: $user\r\n");
    fwrite($h, "Subject: $subject\r\n");
    fwrite($h, "Content-Type: text/plain; charset=utf-8\r\n\r\n");
    fwrite($h, $body);
    $ok = pclose($h) === 0;
    if ($ok) audit_log('signin-notify', $user, $cc, $ip);
    return $ok;
}
