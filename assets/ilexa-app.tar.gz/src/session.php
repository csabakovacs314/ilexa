<?php
// PHP session purely for the CSRF token (auth is Apache Basic-auth).
// Cookie params set locally (never globally): Secure, HttpOnly, SameSite=Lax.
session_set_cookie_params([
    'lifetime' => 0, 'path' => COOKIE_PATH, 'secure' => true,
    'httponly' => true, 'samesite' => 'Lax',
]);
session_name(SESSION_NAME);
session_start();
if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

function csrf_token(): string { return $_SESSION['csrf'] ?? ''; }
function csrf_field(): string {
    return '<input type="hidden" name="_csrf" value="' . htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') . '">';
}
function csrf_ok(): bool {
    return isset($_SESSION['csrf'], $_POST['_csrf']) && hash_equals($_SESSION['csrf'], (string) $_POST['_csrf']);
}
