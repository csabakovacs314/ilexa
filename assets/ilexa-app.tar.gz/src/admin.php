<?php
// Admin tab: settings, FTS index management, system info.

// ── Editable setting definitions ──────────────────────────────────────────────
function _admin_rules(): array {
    return [
        'per_page'          => ['label' => t('Oldalankénti elemek'),          'min' =>  5, 'max' =>   500, 'const' => 'QA_PER_PAGE'],
        'user_cache_ttl'    => ['label' => t('Felhasználólista cache (mp)'),   'min' => 30, 'max' =>  3600, 'const' => 'USER_CACHE_TTL'],
        'admin_session_gap' => ['label' => t('Admin munkamenet-szünet (mp)'),  'min' => 60, 'max' => 86400, 'const' => 'ADMIN_SESSION_GAP'],
    ];
}

// ── Load runtime overrides from settings.json ─────────────────────────────────
function admin_settings_load(): array {
    if (!is_file(SETTINGS_FILE)) return [];
    $raw = json_decode(file_get_contents(SETTINGS_FILE), true);
    return is_array($raw) ? array_intersect_key($raw, _admin_rules()) : [];
}

// ── Persist one override ──────────────────────────────────────────────────────
function admin_settings_save(string $key, int $val): array {
    $rules = _admin_rules();
    if (!isset($rules[$key])) return [false, t('Ismeretlen beállítás.')];
    $r = $rules[$key];
    if ($val < $r['min'] || $val > $r['max']) {
        return [false, sprintf(t('Az értéknek %d és %d között kell lennie.'), $r['min'], $r['max'])];
    }
    $cur         = admin_settings_load();
    $cur[$key]   = $val;
    $ok          = file_put_contents(SETTINGS_FILE, json_encode($cur, JSON_PRETTY_PRINT), LOCK_EX) !== false;
    return [$ok, $ok ? '' : t('Nem sikerült írni: ') . SETTINGS_FILE];
}

// ── Remove one override (restore config.php default) ─────────────────────────
function admin_settings_reset(string $key): void {
    if (!isset(_admin_rules()[$key])) return;
    $cur = admin_settings_load();
    unset($cur[$key]);
    if (empty($cur)) {
        @unlink(SETTINGS_FILE);
    } else {
        file_put_contents(SETTINGS_FILE, json_encode($cur, JSON_PRETTY_PRINT), LOCK_EX);
    }
}

// ── List FTS Xapian indexes (runs as root via sudo) ───────────────────────────
// Weekly FTS index compaction: read and flip the switch the cron job gates on.
//
// The job is scheduled unconditionally and self-gates on FTS_OPTIMIZE_ENABLED,
// so turning it off here leaves cron alone and turning it back on needs no
// reinstall -- the same pattern the feed sources use.
function admin_fts_optimize_status(): array {
    $ok  = false;
    $out = qa_sudo_read(SUDO . ' /usr/local/sbin/fts-manage.sh optimize-status', 'fts-optimize', $ok);
    if (!$ok) return ['available' => false];
    $d = json_decode(trim($out), true);
    if (!is_array($d)) return ['available' => false];
    $d['available'] = true;
    return $d;
}

function admin_fts_optimize_set(bool $on): array {
    $cmd = SUDO . ' /usr/local/sbin/fts-manage.sh optimize-set ' . ($on ? 'on' : 'off') . ' 2>&1';
    $out = trim((string)shell_exec($cmd));
    return [str_starts_with($out, 'OK'), $out];
}

// rspamd scanning modules: enumerate with their effective on/off state.
//
// "Effective" matters: rspamd loads a module unless something sets
// enabled = false, so an absent setting means ON. The helper asks
// `rspamadm configdump`, which reports the merged result of every config layer
// rather than what any single file says.
const RSPAMD_MODULES_CACHE = 'rspamd-modules';

function admin_rspamd_modules(): array {
    // Cached: the helper shells out to rspamadm, which parses the whole rspamd
    // configuration. That is ~1s even after being reduced to a single dump
    // (it was 17.9s when it ran one dump per module), and this panel is on a
    // page the operator opens repeatedly. Flushed by the toggle below, so a
    // change is visible immediately rather than up to a TTL later.
    $d = _status_cached(RSPAMD_MODULES_CACHE, 300, function () {
        $ok  = false;
        $out = qa_sudo_read(SUDO . ' /usr/local/sbin/qa-rspamd-modules.sh list', 'rspamd-modules', $ok);
        if (!$ok) return null;                    // failure is not cached
        $d = json_decode(trim($out), true);
        return is_array($d) ? $d : null;
    });
    return $d ?: [];
}

function _rspamd_modules_flush(): void {
    @unlink(dirname(SETTINGS_FILE) . '/' . RSPAMD_MODULES_CACHE . '.cache.json');
}

// [$ok, $message]. The helper configtests before reloading and reverts its own
// change if the result would not parse, so a bad toggle cannot leave rspamd
// unable to start.
function admin_rspamd_module_set(string $module, bool $on): array {
    $cmd = SUDO . ' /usr/local/sbin/qa-rspamd-modules.sh set '
         . escapeshellarg($module) . ' ' . ($on ? 'on' : 'off') . ' 2>&1';
    $out = trim((string)shell_exec($cmd));
    // The listing is now stale by definition, whether or not the change stuck.
    _rspamd_modules_flush();
    return [str_starts_with($out, 'OK'), $out];
}

// Hungarian spam-classifier module (experimental, Phase 1: language +
// naturalness detection only -- see the Rendszer panel's own explanation
// text for what HU_LANGUAGE/HU_NATURALNESS actually mean and why
// HU_SPAM/HU_PHISHING/HU_SCAM are still placeholders). Unlike the rspamd
// modules above, this is not an rspamd config key: the gateway flips a
// plain state file the Lua postfilter re-reads on every message, so the
// change is instant and needs no rspamd reload -- see qa-hu-classify.sh.
function admin_hu_classify_status(): array {
    $ok  = false;
    $out = qa_sudo_read(SUDO . ' /usr/local/sbin/qa-hu-classify.sh status', 'hu-classify', $ok);
    if (!$ok) return ['installed' => false];
    $d = json_decode(trim($out), true);
    return is_array($d) ? $d : ['installed' => false];
}

// Recipient for the fortnightly classifier review mail. Empty means the
// helper is falling back to the general alert address (or that neither is
// set, i.e. no report is sent at all) -- admin_hu_classify_status()'s
// report_email_source says which, so the UI can be honest about where the
// address came from instead of implying it was typed here.
// Latest per-host measurement, written by qa-hu-classify-report.py. Read
// directly rather than through a sudo helper: it is world-readable
// aggregate statistics with no message content in it, and the panel needs
// it on every page load.
//
// Returns [] when no measurement exists yet, which is the honest state on a
// host where the fortnightly job has not run -- the panel says so instead
// of showing numbers borrowed from somewhere else.
function admin_hu_classify_measurement(): array {
    $f = '/var/lib/ilexa/hu-classify-measurement.json';
    if (!is_readable($f)) return [];
    $d = json_decode((string)file_get_contents($f), true);
    return is_array($d) && !empty($d['signals']) ? $d : [];
}

// Turns one measured signal into the advice the panel shows.
//
// The thresholds are about DEPLOYABILITY, not about how clever the model
// is. AUC says how well a signal ranks spam above ham; it says nothing
// about what happens at this host's real spam rate, which is the thing that
// decides whether a weight would help or just mis-flag good mail. So the
// recommendation stays conservative and always names the reason.
function admin_hu_classify_advice(string $sig, array $m, float $base): array {
    $auc  = (float)($m['auc'] ?? 0.5);
    $dist = abs($auc - 0.5);
    $ham_leaning = ($m['direction'] ?? 'spam') === 'ham';

    // Checked FIRST, before any strength test: this is a principled rule,
    // not a measurement one. A language-identity signal is not evidence of
    // spam even when it correlates strongly -- "this message is Hungarian"
    // is a property of the sender, not of intent, and scoring it would
    // penalise an entire language. Ordering this after the strength checks
    // made a weak reading report "too weak to score", which is true but
    // says the wrong thing: it implies a strong reading would qualify.
    if ($sig === 'hu_language' || $sig === 'en_language') {
        return ['never', t('Nyelvfelismerés - önmagában sosem spam-bizonyíték, ne kapjon pontszámot. Későbbi, nyelvfüggő szabályok feltételeként hasznos.')];
    }
    if ($dist < 0.05) {
        return ['none', t('Nem hordoz információt - ne kapjon pontszámot.')];
    }
    if ($dist < 0.10) {
        return ['none', t('Túl gyenge ahhoz, hogy pontszámot érdemeljen.')];
    }
    if ($dist < 0.20) {
        return ['watch', $ham_leaning
            ? t('Mérhető, de gyenge. Ha egyszer pontszámot kap, annak negatívnak kell lennie (a jó levelekre jellemző).')
            : t('Mérhető, de gyenge. Még figyelni kell - egy gyenge jelzés pontozása több téves találatot hoz, mint amennyi spamet kiszűr.')];
    }
    return ['candidate', $ham_leaning
        ? t('Erős elkülönítés, de a jó levelek felé mutat - csak negatív pontszámként lenne értelme, óvatosan.')
        : t('Erős elkülönítés. Aktiválás előtt ellenőrizni kell, hány jó levelet jelölne meg tévesen a valós spam-aránynál.')];
}

// Current per-symbol weights. 0 = shadow mode.
function admin_hu_classify_weights(): array {
    $ok = false;
    $out = qa_sudo_read(SUDO . ' /usr/local/sbin/qa-hu-classify.sh weights', 'hu-classify-weights', $ok);
    if (!$ok) return [];
    $d = json_decode(trim($out), true);
    return is_array($d) ? $d : [];
}

function admin_hu_classify_weight_set(string $sym, string $val): array {
    $cmd = SUDO . ' /usr/local/sbin/qa-hu-classify.sh weight set '
         . escapeshellarg($sym) . ' ' . escapeshellarg($val) . ' 2>&1';
    $out = trim((string)shell_exec($cmd));
    return [str_starts_with($out, 'OK'), $out];
}

function admin_hu_classify_measure(): array {
    $out = trim((string)shell_exec(SUDO . ' /usr/local/sbin/qa-hu-classify.sh measure 2>&1'));
    return [str_starts_with($out, 'OK'), $out];
}

// Whether a signal has separated spam from ham well enough that offering an
// activation control is defensible at all. The console shows no such button
// below this bar -- an operator should not be one click from scoring a
// signal the measurement does not support.
//
// 0.20 either side of 0.50 (i.e. AUC >0.70 or <0.30) is the same bar the
// panel's own guidance names, so the button appearing and the advice text
// can never disagree.
function admin_hu_classify_activatable(string $sig, array $m): bool {
    return admin_hu_classify_block_reason($sig, $m) === '';
}

// Why activation is not permitted, or '' when it is. Returned as text rather
// than a bool so the control can be shown DISABLED with the precondition in
// its tooltip: a button that is simply absent teaches nobody what would make
// it appear.
function admin_hu_classify_block_reason(string $sig, array $m): string {
    if ($sig === 'hu_language' || $sig === 'en_language') {
        return t('A nyelvfelismerés elvi okból nem kaphat pontszámot - nem a mérésen múlik.');
    }
    $auc  = (float)($m['auc'] ?? 0.5);
    $dist = abs($auc - 0.5);
    if ($dist < 0.20) {
        return sprintf(t('Az elkülönítésnek 0,70 fölé vagy 0,30 alá kell kerülnie. Jelenleg %s.'),
                       qa_num($auc));
    }
    return '';
}

function admin_hu_classify_report_email(string $addr): array {
    $cmd = SUDO . ' /usr/local/sbin/qa-hu-classify.sh report-email '
         . ($addr === '' ? 'clear' : 'set ' . escapeshellarg($addr)) . ' 2>&1';
    $out = trim((string)shell_exec($cmd));
    return [str_starts_with($out, 'OK'), $out];
}

function admin_hu_classify_set(bool $on): array {
    $cmd = SUDO . ' /usr/local/sbin/qa-hu-classify.sh set ' . ($on ? 'on' : 'off') . ' 2>&1';
    $out = trim((string)shell_exec($cmd));
    return [str_starts_with($out, 'OK'), $out];
}

function admin_fts_list(): array {
    $cmd  = SUDO . ' /usr/local/sbin/fts-manage.sh list 2>/dev/null';
    $out  = shell_exec($cmd);
    $rows = [];
    if (!$out) return $rows;
    foreach (explode("\n", trim($out)) as $line) {
        if (!preg_match('/^(\d+)\s+(.+)$/', $line, $m)) continue;
        $idx_dir = trim($m[2]);
        $parts   = explode('/', $idx_dir);
        $pos     = array_search('xapian-indexes', $parts);
        if ($pos === false || $pos < 1) continue;
        $user = $parts[$pos - 1];
        if (strpos($user, '@') === false) continue;
        $rows[] = ['user' => $user, 'dir' => $idx_dir, 'size_mb' => (int)$m[1]];
    }
    return $rows;
}

// ── Delete a user's FTS index (runs as root via sudo) ────────────────────────
function admin_delete_fts(string $user): array {
    if (!preg_match('/^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$/', $user)) {
        return [false, t('Érvénytelen felhasználónév.')];
    }
    $cmd = SUDO . ' /usr/local/sbin/fts-manage.sh delete ' . escapeshellarg($user) . ' 2>&1';
    $out = shell_exec($cmd);
    $ok  = str_starts_with(trim($out ?? ''), 'OK');
    return [$ok, trim($out ?? 'Nincs kimenet.')];
}

// ── System information ────────────────────────────────────────────────────────
function admin_system_info(): array {
    $disk = [];
    $df   = shell_exec('df -B1 ' . escapeshellarg(MAIL_DIR) . ' 2>/dev/null | tail -1');
    if ($df && preg_match('/(\d+)\s+(\d+)\s+(\d+)\s+(\d+)%/', $df, $m)) {
        $disk = ['total' => (int)$m[1], 'used' => (int)$m[2], 'avail' => (int)$m[3], 'pct' => (int)$m[4]];
    }

    $mem = [];
    $mi  = @file_get_contents('/proc/meminfo');
    if ($mi) {
        preg_match('/MemTotal:\s+(\d+)/', $mi, $mt);
        preg_match('/MemAvailable:\s+(\d+)/', $mi, $ma);
        $tk  = (int)($mt[1] ?? 0);
        $ak  = (int)($ma[1] ?? 0);
        $uk  = $tk - $ak;
        $mem = [
            'total' => $tk * 1024,
            'used'  => $uk * 1024,
            'avail' => $ak * 1024,
            'pct'   => $tk > 0 ? (int)round($uk / $tk * 100) : 0,
        ];
    }

    $swap = [];
    if ($mi) {
        preg_match('/SwapTotal:\s+(\d+)/', $mi, $st);
        preg_match('/SwapFree:\s+(\d+)/', $mi, $sf);
        $stk = (int)($st[1] ?? 0);
        $sfk = (int)($sf[1] ?? 0);
        $suk = $stk - $sfk;
        // Omit entirely on a swapless host rather than showing an empty 0/0 bar.
        if ($stk > 0) {
            $swap = [
                'total' => $stk * 1024,
                'used'  => $suk * 1024,
                'avail' => $sfk * 1024,
                'pct'   => (int)round($suk / $stk * 100),
            ];
        }
    }

    $cpu = [];
    $la = @file_get_contents('/proc/loadavg');
    if ($la && preg_match('/^([\d.]+)\s+([\d.]+)\s+([\d.]+)/', $la, $lm)) {
        $cores = (int)trim((string)shell_exec('nproc 2>/dev/null'));
        if ($cores < 1) $cores = 1;
        $load1 = (float)$lm[1];
        $cpu = [
            'load1'  => $load1,
            'load5'  => (float)$lm[2],
            'load15' => (float)$lm[3],
            'cores'  => $cores,
            // Capped at 100 for the bar width; the raw load1 figure (which can
            // exceed 1x per core, i.e. >100%) is still shown in the text below it.
            'pct'    => (int)round(min(100, $load1 / $cores * 100)),
        ];
    }

    $cache_dir = dirname(SETTINGS_FILE);
    $ck        = (int)trim(shell_exec('du -sk ' . escapeshellarg($cache_dir) . ' 2>/dev/null | cut -f1') ?? '0');

    // Show the FQDN, not the kernel's short hostname.
    //
    // `gethostname()` and even `hostname -f` return the SHORT name on a host
    // whose name is not resolvable with a domain -- measured on the reference
    // host, both return "hawking" while the server is known to the world as
    // mail.linuxforum.hu. So neither is a usable source for an FQDN.
    //
    // Postfix's myhostname IS authoritative here: it is the name in the SMTP
    // banner and the one the TLS certificate must match, i.e. the identity this
    // machine presents externally. Read through the existing root helper (this
    // file never runs postconf directly), where it is registered as read-only.
    //
    // Falls back to gethostname() so a host without the helper, or without
    // postfix configured, still shows something rather than an empty card.
    $hostname = '';
    if (defined('SUDO')) {
        $hostname = trim(qa_sudo_read(
            SUDO . ' /usr/local/sbin/qa-postfix-config.sh get myhostname',
            'postfix myhostname'));
    }
    if ($hostname === '') {
        $hostname = (string) (gethostname() ?: '');
    }

    $uptime_seconds = 0;
    $ut = @file_get_contents('/proc/uptime');
    if ($ut && preg_match('/^([\d.]+)/', $ut, $um)) {
        $uptime_seconds = (int) (float) $um[1];
    }

    $os_pretty = '';
    $osr = @file_get_contents('/etc/os-release');
    if ($osr && preg_match('/^PRETTY_NAME="?([^"\n]+)"?/m', $osr, $om)) {
        $os_pretty = trim($om[1]);
    }

    // Postfix queue depths for the dashboard's system card. One sudo call to
    // the same helper the Admin queue page uses (postqueue -j as root; the
    // web user has no direct queue access -- see qa-postfix-queue.sh).
    // Empty on any failure, and the view omits the row rather than showing
    // zeros it did not measure.
    $queues = [];
    $qout = shell_exec(SUDO . ' /usr/local/sbin/qa-postfix-queue.sh list 2>/dev/null');
    if ($qout !== null && trim($qout) !== '') {
        $qd = json_decode(trim($qout), true);
        if (is_array($qd)) {
            $queues = ['active' => 0, 'deferred' => 0, 'hold' => 0, 'total' => count($qd)];
            foreach ($qd as $qe) {
                $qn = strtolower((string)($qe['queue_name'] ?? ''));
                if (isset($queues[$qn])) $queues[$qn]++;
            }
        }
    }

    return ['disk' => $disk, 'mem' => $mem, 'swap' => $swap, 'cpu' => $cpu, 'cache_kb' => $ck,
            'hostname' => $hostname, 'uptime_seconds' => $uptime_seconds, 'os_pretty' => $os_pretty,
            'queues' => $queues];
}

// ── Password-expiry recovery-email coverage (Phase 1 of the password-expiry
//    plan; see /root/.claude/plans/zany-napping-sunrise.md) ───────────────────
//
// Measurement only -- nothing here enforces anything. It exists so later
// phases know when recovery-email coverage is high enough to make enforcement
// (a future phase) survivable, and to make the current low coverage visible
// to whoever is deciding when to schedule that.
//
// THE EXEMPTION RULE, defined once, here: an account with no recovery email
// set (email_other empty) must NEVER be a candidate for a hard authentication
// lockout in any later phase -- there would be no way back in. Any future
// enforcement code must check the same condition this function reports on
// (email_other IS NULL OR email_other = '') rather than re-deriving it.
//
// Read-only, via qaudit_ro's own narrowly-scoped grant (SELECT on
// domain/username/active/email_other/password_expiry/modified only --
// explicitly NOT password; verified live 2026-08-23 that this connection
// cannot select that column). Reuses audit_db() from src/audit.php rather
// than opening a second connection to the same database.
//
// Uses mailbox's own real `domain` column, not a SUBSTRING_INDEX(username)
// derivation -- confirmed live 2026-08-23 that `GROUP BY domain` binds to
// the real column over a same-named SELECT-list alias, which broke this
// under qaudit_ro's column-scoped grant (the alias was never a granted
// column) and would have been a needless landmine as a plain query even
// with full privileges. The real column is simpler and avoids the ambiguity
// entirely.
function admin_pwexpiry_coverage(): ?array {
    $db = audit_db();
    if (!$db) return null;

    $rows = $db->query(
        "SELECT domain,
                COUNT(*) AS total,
                SUM(email_other IS NOT NULL AND email_other != '') AS with_recovery
         FROM mailbox WHERE active = 1
         GROUP BY domain ORDER BY total DESC"
    )->fetchAll(PDO::FETCH_ASSOC);

    $total = 0; $with_recovery = 0;
    foreach ($rows as $r) { $total += (int)$r['total']; $with_recovery += (int)$r['with_recovery']; }

    return ['domains' => $rows, 'total' => $total, 'with_recovery' => $with_recovery];
}

// ── Human-readable byte sizes ─────────────────────────────────────────────────
function admin_fmt_bytes(int $bytes, int $prec = 1): string {
    if ($bytes >= 1073741824) return number_format($bytes / 1073741824, $prec) . ' GB';
    if ($bytes >= 1048576)    return number_format($bytes / 1048576,    $prec) . ' MB';
    if ($bytes >= 1024)       return number_format($bytes / 1024,       $prec) . ' KB';
    return $bytes . ' B';
}

// Uptime as a Hungarian-source duration string ("37 nap 10 óra"), NOT the "ago"-suffixed
// relative-time strings rel_time() uses (src/helpers.php) -- this is a forward-framed
// duration ("has been running for"), not a backward-framed timestamp ("last happened").
function admin_fmt_uptime(int $seconds): string {
    if ($seconds <= 0) return '';
    $days  = intdiv($seconds, 86400);
    $hours = intdiv($seconds % 86400, 3600);
    if ($days > 0) return sprintf(t('%d nap %d óra'), $days, $hours);
    if ($hours > 0) return sprintf(t('%d óra'), $hours);
    $minutes = intdiv($seconds % 3600, 60);
    return sprintf(t('%d perc'), max(1, $minutes));
}

// ── User management ──────────────────────────────────────────────────────────

function admin_users_list(): array {
    $data  = rbac_all();
    $me    = qa_user();
    $users = [];
    foreach ($data as $uname => $udata) {
        $users[] = [
            'username' => $uname,
            'role'     => $udata['role']    ?? 'viewer',
            'domains'  => $udata['domains'] ?? [],
            'is_self'  => ($uname === $me),
        ];
    }
    usort($users, fn($a, $b) => strcmp($a['username'], $b['username']));
    return $users;
}

function _htpasswd_run(string $action, string $username, string $password = ''): array {
    $cmd  = SUDO . ' /usr/local/sbin/htpasswd-manage.sh ' . escapeshellarg($action) . ' ' . escapeshellarg($username);
    $desc = [['pipe', 'r'], ['pipe', 'w'], ['pipe', 'w']];
    $proc = proc_open($cmd, $desc, $pipes);
    if (!is_resource($proc)) return [false, 'proc_open sikertelen'];
    if ($password !== '') fwrite($pipes[0], $password);
    fclose($pipes[0]);
    $out = trim(stream_get_contents($pipes[1]));
    fclose($pipes[1]);
    fclose($pipes[2]);
    proc_close($proc);
    $ok = str_contains($out, 'OK');
    return [$ok, $out];
}

function admin_user_add(string $username, string $password, string $role, array $domains = []): array {
    $valid = ['admin', 'operator', 'viewer', 'domain_admin'];
    if (!preg_match('/^[a-zA-Z0-9._-]{2,32}$/', $username))
        return [false, t('Érvénytelen felhasználónév (2–32 karakter: betű, szám, . _ -).')];
    if (strlen($password) < 8)
        return [false, t('A jelszónak legalább 8 karakter hosszúnak kell lennie.')];
    if (!in_array($role, $valid))
        return [false, t('Érvénytelen szerepkör.')];
    if ($role === 'domain_admin' && empty($domains))
        return [false, t('Domain-admin szerepkörhöz legalább egy tartomány szükséges.')];

    [$ok, $out] = _htpasswd_run('add', $username, $password);
    if (!$ok) return [false, 'htpasswd: ' . $out];

    // Two stores must agree. If the role write fails after the credential was
    // created, roll the credential back rather than leaving a user who can log
    // in with an unintended role (no roles.json entry = 'viewer', or 'admin'
    // while roles.json does not exist at all).
    $saved = rbac_with_lock(function () use ($username, $role, $domains) {
        $data            = rbac_all();
        $data[$username] = ['role' => $role];
        if (!empty($domains)) $data[$username]['domains'] = array_values($domains);
        return rbac_save($data);
    });
    if (!$saved) {
        _htpasswd_run('delete', $username);
        return [false, t('A szerepkör mentése sikertelen - a felhasználó nem jött létre.')];
    }
    return [true, ''];
}

function admin_user_delete(string $username): array {
    if ($username === qa_user()) return [false, t('Nem törölheted a saját felhasználódat.')];
    [$ok, $out] = _htpasswd_run('delete', $username);
    if (!$ok) return [false, 'htpasswd: ' . $out];
    rbac_with_lock(function () use ($username) {
        $data = rbac_all();
        unset($data[$username]);
        return rbac_save($data);
    });
    return [true, ''];
}

function admin_user_set_role(string $username, string $role, array $domains = []): array {
    $valid = ['admin', 'operator', 'viewer', 'domain_admin'];
    if (!in_array($role, $valid)) return [false, t('Érvénytelen szerepkör.')];
    if ($role === 'domain_admin' && empty($domains))
        return [false, t('Domain-admin szerepkörhöz legalább egy tartomány szükséges.')];
    if ($username === qa_user() && $role !== 'admin')
        return [false, t('Nem változtathatod meg a saját admin szerepkörödet.')];

    return rbac_with_lock(function () use ($username, $role, $domains) {
        $data = rbac_all();
        if (!isset($data[$username])) return [false, t('Felhasználó nem található.')];
        $data[$username]['role'] = $role;
        if (!empty($domains)) $data[$username]['domains'] = array_values($domains);
        else unset($data[$username]['domains']);
        return rbac_save($data)
            ? [true, '']
            : [false, t('A szerepkör mentése sikertelen - a felhasználó nem jött létre.')];
    });
}

function admin_user_set_password(string $username, string $password): array {
    if (strlen($password) < 8) return [false, t('A jelszónak legalább 8 karakter hosszúnak kell lennie.')];
    [$ok, $out] = _htpasswd_run('update', $username, $password);
    return [$ok, $ok ? '' : 'htpasswd: ' . $out];
}

// ── Email breach status (reads XposedOrNot cache file written by cron) ───────
function admin_breach_status(): array {
    $f = dirname(SETTINGS_FILE) . '/breach-check.json';
    if (!is_file($f)) return [];
    $raw = @file_get_contents($f);
    if (!$raw) return [];
    $data = json_decode($raw, true);
    if (!is_array($data)) return [];

    // Flatten emails map → results array for the view
    $emails  = $data['emails'] ?? [];
    $results = [];
    foreach ($emails as $email => $r) {
        $row = array_merge(['email' => $email], $r);
        // breach_count may be stored separately when names aren't available yet
        if (!isset($row['breach_count'])) {
            $row['breach_count'] = count($row['breaches'] ?? []);
        }
        $results[] = $row;
    }
    $exposed = array_filter($results, fn($r) => !empty($r['exposed']));
    // Infostealer findings are a SEPARATE list, not a subset of the breached
    // one: "credentials may be in a live stealer log" and "this address was in
    // a 2016 dump" are different problems needing different responses, and a
    // mailbox can be in either, both, or neither.
    $stealer = array_filter($results, fn($r) => !empty($r['stealer']));
    usort($stealer, fn($a, $b) => strcmp((string)($b['stealer']['latest'] ?? ''),
                                         (string)($a['stealer']['latest'] ?? '')));
    // Per-provider coverage, so a provider that has silently stopped answering
    // is visible as a low number rather than looking like good news.
    $providers = [];
    foreach ((array)($data['providers'] ?? []) as $pName => $p) {
        if (!is_string($pName) || !is_array($p)) continue;
        if (preg_match('/^[a-z0-9][a-z0-9_-]{0,30}$/', $pName) !== 1) continue;
        $providers[$pName] = [
            'kind'        => (string)($p['kind'] ?? ''),
            'coverage'    => (int)($p['coverage'] ?? 0),
            'last_run'    => (string)($p['last_run'] ?? ''),
            'last_status' => (string)($p['last_status'] ?? ''),
            'errors'      => (int)($p['errors'] ?? 0),
        ];
    }
    return [
        'schema'        => (int)($data['schema'] ?? 1),
        'last_run'      => $data['last_run']      ?? '',
        'total_users'   => (int)($data['total_users']   ?? 0),
        'checked_count' => (int)($data['checked_count'] ?? 0),
        'exposed_count' => (int)($data['exposed_count'] ?? 0),
        'stealer_count' => (int)($data['stealer_count'] ?? count($stealer)),
        'providers'     => $providers,
        'results'       => $results,
        'exposed'       => array_values($exposed),
        'stealer'       => array_values($stealer),
    ];
}

// ── External-API request budgets ─────────────────────────────────────────────
// Reads the ledger qa-quota-lib.php writes. Deliberately a plain file read and
// not a sudo shell-out: the file holds counters and timestamps, no keys and no
// personal data, and the Rendszer card renders it on every load. Adding a
// privileged fork per page render to display a number would be the expensive
// way to be no safer.
//
// Returns null when nothing has been recorded yet (nothing has spent from this
// budget since install) or the file is unreadable -- the view distinguishes
// "no data" from "0 used", because they mean different things.
const QA_QUOTA_LEDGER_DIR = '/var/lib/ilexa/quota';

function admin_quota_status(string $provider): ?array {
    if (preg_match('/^[a-z0-9][a-z0-9_-]{0,30}$/', $provider) !== 1) return null;
    $f = QA_QUOTA_LEDGER_DIR . '/' . $provider . '.json';
    if (!is_file($f)) return null;
    $raw = @file_get_contents($f);
    if ($raw === false || trim($raw) === '') return null;
    $d = json_decode($raw, true);
    if (!is_array($d) || !isset($d['limit'])) return null;

    // The ledger stores request timestamps; recompute usage against each
    // window rather than trusting the counters frozen into it at write time,
    // which went stale the moment the last request aged out. One recomputation
    // here beats a cron job whose only purpose is refreshing a display.
    //
    // A provider has SEVERAL windows (XposedOrNot publishes 2/sec, 25/hour and
    // 100/day). The headline figures describe the longest -- the budget in the
    // everyday sense -- and 'windows' carries the rest, because the hourly one
    // is what actually paces the sweep and an operator asking "why has it only
    // done 12 today" needs to see it.
    $now  = time();
    $all  = [];
    foreach ((array)($d['hits'] ?? []) as $t) {
        if (is_int($t) && $t <= $now + 60) $all[] = $t;
    }
    sort($all);

    // Fall back to a single day window for a ledger written before windows
    // existed, so the card keeps rendering across the upgrade.
    $defs = [];
    foreach ((array)($d['windows'] ?? []) as $name => $w) {
        if (!is_array($w)) continue;
        $defs[(string)$name] = [(int)($w['window'] ?? 0), (int)($w['limit'] ?? 0)];
    }
    if (!$defs) $defs = ['day' => [(int)($d['window'] ?? 86400), (int)$d['limit']]];

    $windows = [];
    $long    = null;
    foreach ($defs as $name => [$secs, $limit]) {
        if ($secs <= 0) continue;
        $in = array_values(array_filter($all, fn(int $t): bool => $t >= $now - $secs));
        $windows[$name] = [
            'name' => $name, 'window' => $secs, 'limit' => $limit,
            'used' => count($in), 'remaining' => max(0, $limit - count($in)),
            'reset_at' => $in ? $in[0] + $secs : null,
        ];
        if ($long === null || $secs > $windows[$long]['window']) $long = $name;
    }
    if ($long === null) return null;

    // Which window is the BUDGET is named by the ledger, not inferred from
    // which is longest. Some providers have no budget at all -- LeakCheck
    // publishes only a rate (1/sec, no daily cap), and rendering that as
    // "Keret: 1/1" would invent a daily allowance that does not exist and
    // read as permanently exhausted. Null here means "no daily cap"; the view
    // says so in words.
    $budget = $d['budget'] ?? null;
    if ($budget !== null && !isset($windows[$budget])) $budget = null;

    $reserve = (int)($d['reserve'] ?? 0);
    $head    = $windows[$budget ?? $long];
    return [
        'provider'        => $provider,
        'used'            => $head['used'],
        'limit'           => $head['limit'],
        'remaining'       => $head['remaining'],
        'reserve'         => $reserve,
        'batch_remaining' => max(0, $head['remaining'] - $reserve),
        'window'          => $head['window'],
        'reset_at'        => $head['reset_at'],
        'budget'          => $budget,
        'windows'         => $windows,
        'last_request'    => $all ? $all[count($all) - 1] : null,
    ];
}

// Providers whose budget the Rendszer card shows. Keep in step with
// QA_QUOTA_DEFAULTS in install/qa-quota-lib.php -- a provider listed there and
// not here simply goes undisplayed, which is a missing panel rather than a
// wrong number, but there is no reason for the two to drift.
const QA_BUDGETED_LOOKUP_SERVICES = ['xposedornot', 'leakcheck', 'hudsonrock'];

// Display names for the providers the mailbox sweep uses, for the dashboard's
// source attribution. A third copy of the service label map would be exactly
// the drift tools/check-lookup-services.php exists to catch, so this one is a
// const the gate also verifies -- not another literal buried in a view.
//
// The URL is the provider's own site, shown as required attribution. LeakCheck
// permits commercial use of its public API ON CONDITION of a "Powered by
// LeakCheck" link, so that link is a LICENCE TERM: removing it puts the
// integration outside its terms, not merely un-credited.
// 'incident_url' is where a per-finding marker points. Only XposedOrNot has
// true per-incident pages (handled separately via url_name); for the others it
// is the closest REAL page -- LeakCheck's is their /breaches directory, which
// carries a search box for its 1,366 indexed sources. Verified before choosing:
// leakcheck.io has no /breach/<name> route, the directory is client-rendered,
// and ?q= is ignored -- so a fabricated deep link would land on an unfiltered
// page and read as broken. The tooltip carries the exact name to search for.
const QA_BREACH_PROVIDER_LABEL = [
    'xposedornot' => ['label' => 'XposedOrNot', 'url' => 'https://xposedornot.com/',
                      'incident_url' => '', 'attribution' => false],
    'leakcheck'   => ['label' => 'LeakCheck',   'url' => 'https://leakcheck.io/',
                      'incident_url' => 'https://leakcheck.io/breaches', 'attribution' => true],
    'hudsonrock'  => ['label' => 'Hudson Rock', 'url' => 'https://www.hudsonrock.com/',
                      'incident_url' => 'https://www.hudsonrock.com/free-tools', 'attribution' => false],
];

// ── rspamd controller password ───────────────────────────────────────────────
// Unlike the feed keys this file belongs to the web user already, so it needs no
// sudo helper. Live Bayes learning aborts without it, which is easy to hit after
// a rebuild: the learning badge says LIVE while every learn silently fails.
function admin_rspamc_pw_present(): bool {
    return is_readable(RSPAMC_PW_FILE) && trim((string)@file_get_contents(RSPAMC_PW_FILE)) !== '';
}

function admin_rspamc_pw_set(string $pw): array {
    $pw = trim($pw);
    if ($pw === '') {
        _rspamc_pw_flush();
        @unlink(RSPAMC_PW_FILE);
        return [true, ''];
    }
    // No trailing newline: rspamc sends the file's contents verbatim as the
    // password, and a stray \n makes every call fail authentication.
    _rspamc_pw_flush();
    $ok = @file_put_contents(RSPAMC_PW_FILE, $pw, LOCK_EX) !== false;
    if ($ok) { @chmod(RSPAMC_PW_FILE, 0600); }
    return [$ok, $ok ? '' : t('Nem sikerült írni: ') . RSPAMC_PW_FILE];
}

// Reachability probe ONLY -- this does NOT validate the password, despite
// what this comment used to claim ("prove the credential actually works").
// rspamd's stock worker-controller.inc sets secure_ip = 127.0.0.1 / ::1, so
// every request from this host is trusted whatever password is sent: `stat`
// returns full data with a wrong password, an empty one, or none at all
// (verified against the live controller, 2026-08-17). There is no way to
// validate the credential from localhost, so callers must not present a
// success here as "the password is correct" -- the UI badge deliberately
// says only that the controller responds.
//
// The password still matters: rspamd_learn() refuses to learn without a
// readable password file, so a missing one silently disables training. That
// guard is this app's, not rspamd's.
const RSPAMC_PW_CACHE = 'rspamc-pw-check';

// Cached, because this is the single most expensive thing on the Rendszer page.
//
// It answers "does the stored controller password work", which changes only
// when someone changes the password -- but it answers it by running
// `rspamc stat`, and stat makes rspamd gather full statistics including the
// redis-backed Bayes counts. Measured at 2133ms on the reference host, i.e.
// about 60% of the page's entire render time, paid on every single load.
//
// Only a SUCCESSFUL check is cached. A failure is left uncached so the next
// page load retries: caching "broken" would pin a transient rspamd restart on
// the screen for the whole TTL, which is the empty-vs-failure mistake this
// codebase has already been bitten by. admin_rspamc_pw_set() flushes it, so a
// corrected password shows immediately.
function admin_rspamc_pw_check(): array {
    $d = _status_cached(RSPAMC_PW_CACHE, 300, function () {
        $cmd = RSPAMC . ' -h ' . escapeshellarg(RSPAMD_CTRL)
             . (admin_rspamc_pw_present() ? ' -P ' . escapeshellarg((string)@file_get_contents(RSPAMC_PW_FILE)) : '')
             . ' stat 2>&1';
        $out = (string) shell_exec($cmd);
        $ok  = str_contains($out, 'Messages scanned');
        // null => not cached, retried next render.
        return $ok ? [$ok, trim(substr($out, 0, 120))] : null;
    });
    if (is_array($d) && $d) return [(bool)$d[0], (string)($d[1] ?? '')];

    // Uncached failure path: ask directly so the operator still sees why.
    $cmd = RSPAMC . ' -h ' . escapeshellarg(RSPAMD_CTRL)
         . (admin_rspamc_pw_present() ? ' -P ' . escapeshellarg((string)@file_get_contents(RSPAMC_PW_FILE)) : '')
         . ' stat 2>&1';
    $out = (string) shell_exec($cmd);
    return [str_contains($out, 'Messages scanned'), trim(substr($out, 0, 120))];
}

function _rspamc_pw_flush(): void {
    @unlink(dirname(SETTINGS_FILE) . '/' . RSPAMC_PW_CACHE . '.cache.json');
}

// ── Abusix Mail Intelligence: DNS datafeed key ──────────────────────────────
// Same shape as the Spamhaus DQS helpers above and for the same reason: a
// standing rspamd RBL config keyed by an account key, not a feed with a cron
// cadence and not an on-demand lookup. Presence of the key IS the enable flag.
//
// The status here is deliberately NOT just "is a key configured". A key that
// Abusix does not accept, or a resolver that cannot reach them, leaves every
// lookup returning nothing -- and the panel used to paint that state green,
// because the only thing it checked was whether the config file existed. So the
// helper runs a live probe and reports reachability, and the row reflects it.
//
// The probe costs a DNS round trip, so it is cached: 10 minutes on success,
// which is the same order as the other status readers on this page. Cache
// invalidation matters here -- admin_abusix_set_key() drops the cache file, or
// saving a good key would leave the dot red for the rest of the TTL.
//
// (An earlier version of this comment said Abusix additionally required this
// server's IP to be allowlisted in their portal. That was wrong -- see
// qa-abusix.sh's header for the test that disproved it.)
// These set-key helpers are invoked with 2>&1, so ANY stray line the script
// writes to stderr lands in front of its "OK" and a plain str_starts_with()
// then reports a save that fully succeeded as a failure. That is not
// hypothetical: a backtick left inside the slice heredoc executed as a command,
// printed "command not found", and turned every successful Abusix key save into
// a red banner. Judge the verdict by the LAST non-empty line, which is the one
// the script actually ends with.
function _helper_said_ok(string $out): bool {
    $lines = preg_split('/\R/', trim($out)) ?: [];
    for ($i = count($lines) - 1; $i >= 0; $i--) {
        $l = trim($lines[$i]);
        if ($l !== '') return str_starts_with($l, 'OK');
    }
    return false;
}

const ABUSIX_STATUS_CACHE = 'abusix-status';

function admin_abusix_status(): array {
    $d = _status_cached(ABUSIX_STATUS_CACHE, 600, function () {
        $ok  = false;
        $out = qa_sudo_read(SUDO . ' /usr/local/sbin/qa-abusix.sh status', 'abusix', $ok);
        if (!$ok) return null;                 // helper failed -> do not cache
        $d = json_decode(trim($out), true);
        return is_array($d) ? $d : null;
    });
    return $d ?: ['has_key' => false, 'reachable' => null, 'state' => 'unknown'];
}

function _abusix_status_flush(): void {
    @unlink(dirname(SETTINGS_FILE) . '/' . ABUSIX_STATUS_CACHE . '.cache.json');
}

function admin_abusix_set_key(string $key): array {
    $cmd = SUDO . ' /usr/local/sbin/qa-abusix.sh set-key 2>&1';
    $p = proc_open($cmd, [0 => ['pipe','r'], 1 => ['pipe','w'], 2 => ['pipe','w']], $pipes);
    if (!is_resource($p)) return [false, t('Nincs kimenet.')];
    fwrite($pipes[0], $key);          // stdin only - never an argument
    fclose($pipes[0]);
    $out = trim(stream_get_contents($pipes[1]));
    fclose($pipes[1]); fclose($pipes[2]); proc_close($p);
    // The key just changed, so any cached reachability is stale by definition.
    // Without this the admin saves a working key and the row stays red for the
    // rest of the TTL, which reads as "the key was rejected".
    _abusix_status_flush();
    return _helper_said_ok($out) ? [true, ''] : [false, $out ?: t('Nincs kimenet.')];
}

// [$ok, $detail]; $detail is the helper's raw ASCII diagnostic, shown appended
// to a translated banner the same way admin_spamhaus_test's is.
function admin_abusix_test(): array {
    $out = qa_sudo_read(SUDO . ' /usr/local/sbin/qa-abusix.sh test', 'abusix');
    $d   = $out ? json_decode(trim($out), true) : null;
    if (!is_array($d)) return [false, t('Nincs kimenet.')];
    return [!empty($d['ok']), (string)($d['detail'] ?? '')];
}

// ── Feed sources: enable/disable + API keys (root-owned helper) ──────────────
// The web user never sees a key. The helper reports only whether one exists and
// takes a new one on stdin, so keys stay out of argv, the process list and here.
function admin_feed_sources(): array {
    $out = shell_exec(SUDO . ' /usr/local/sbin/qa-feeds-config.sh list 2>/dev/null');
    if (!$out) return [];
    $d = json_decode(trim($out), true);
    return is_array($d) ? $d : [];
}

// Every feed the console may enable, disable, key or refresh. A feed missing
// from this list is rejected by all three actions below with "Ismeretlen
// feed" even when the view offers it and the helpers support it -- which is
// exactly what happened to yara_forge: it was registered in the admin panel,
// qa-feeds-config.sh and feeds-refresh.sh but not here, so it could neither
// be refreshed NOR switched on. It ships default-off, so that made it
// unreachable from the UI entirely. Adding a feed means touching all six
// places in THIS repo: this constant, views/admin_system.php (row + label),
// views/dashboard.php, install/feeds-status.sh, install/qa-feeds-config.sh
// and install/feeds-refresh.sh -- and two more in the installer, or the feed
// works only on hosts where someone placed it by hand: ilexa-installer's
// assets/feeds/ (vendor the updater), modules/72-feeds.sh (install it, enable
// it, give it a cron line) and templates/rspamd/multimap.conf.tmpl (the rule
// that makes rspamd actually READ the downloaded map -- without it the feed
// refreshes forever and scores nothing).
//
// blocklistde is the cautionary case, and it is gone from this list for a
// second reason worth remembering: it was registered in qa-feeds-config.sh and
// feeds-refresh.sh only, so it was invisible in the console, unvendored in the
// installer and never scheduled -- and once all of that was fixed it turned
// out rspamd already ships a stock bl.blocklist.de DNSBL, so the whole feed
// duplicated a check the host was already making. Confirm nothing upstream
// already covers a source before wiring it as a feed.
//
// "Duplicated" is very nearly but not exactly true, and the difference is
// measured rather than assumed: the DNSBL misses ~18% of the downloadable
// all.txt, and that 18% is bulk-enumerated CIDR blocks nobody should be
// scoring on. Full numbers and method in ilexa-installer's
// templates/rspamd/multimap.conf.tmpl -- keep the two notes in step.
const FEED_SOURCES = ['otx', 'otx_uri', 'urlhaus', 'c2', 'abuseipdb',
                      'spamhaus', 'firehol', 'et', 'dshield', 'geoblock', 'rspamd_rules',
                      'yara_forge'];

function admin_feed_toggle(string $src, bool $on): array {
    if (!in_array($src, FEED_SOURCES, true)) return [false, t('Ismeretlen forrás.')];
    $cmd = SUDO . ' /usr/local/sbin/qa-feeds-config.sh ' . ($on ? 'enable' : 'disable')
         . ' ' . escapeshellarg($src) . ' 2>&1';
    $out = trim((string) shell_exec($cmd));
    // Enabling a keyed source without a key is refused by the helper on purpose.
    return str_starts_with($out, 'OK') ? [true, ''] : [false, $out ?: t('Nincs kimenet.')];
}

function admin_feed_set_key(string $src, string $key): array {
    if (!in_array($src, FEED_SOURCES, true)) return [false, t('Ismeretlen forrás.')];
    $cmd = SUDO . ' /usr/local/sbin/qa-feeds-config.sh set-key ' . escapeshellarg($src) . ' 2>&1';
    $p = proc_open($cmd, [0 => ['pipe','r'], 1 => ['pipe','w'], 2 => ['pipe','w']], $pipes);
    if (!is_resource($p)) return [false, t('Nincs kimenet.')];
    fwrite($pipes[0], $key);          // stdin only - never an argument
    fclose($pipes[0]);
    $out = trim(stream_get_contents($pipes[1]));
    fclose($pipes[1]); fclose($pipes[2]); proc_close($p);
    // Clearing a key also disables the source; feeds-status is now stale either way.
    @unlink(dirname(SETTINGS_FILE) . '/feeds-status.cache.json');
    return str_starts_with($out, 'OK') ? [true, ''] : [false, $out ?: t('Nincs kimenet.')];
}

// ── IOC-lookup services: enable/disable + API keys (root-owned helper) ──────
// Separate from the feed sources above: these are on-demand lookups (VT/
// URLhaus from the IOC tab), not cron-refreshed feeds, so they get their own
// small config script instead of overloading qa-feeds-config.sh's cadence-
// shaped abstraction.
function admin_ioclookup_sources(): array {
    $out = shell_exec(SUDO . ' /usr/local/sbin/qa-ioclookup-config.sh list 2>/dev/null');
    if (!$out) return [];
    $d = json_decode(trim($out), true);
    return is_array($d) ? $d : [];
}

// yaraify was missing here even though qa-ioclookup-config.sh's own SOURCES
// array and the view's $_il_label both list it -- same defect class as
// FEED_SOURCES missing yara_forge (fixed 2026-08-16): the helper and the view
// agreed the source exists, but this gate rejected it with "Ismeretlen
// forrás." before either admin_ioclookup_toggle() or admin_ioclookup_set_key()
// ever reached the shell helper. set-key was harmless either way -- the
// helper itself refuses it with "yaraify uses the abuse.ch key, managed from
// the feed sources" -- but enable/disable had no such shell-side refusal, so
// this was the only thing stopping YARAify from being switched on or off.
// ── Postscreen DNSBL sites/weights (root-owned helper) ─────────────────────
// Standing config /etc/ilexa/postscreen_dnsbl.conf; every mutation re-renders
// postscreen_dnsbl_sites/_threshold via postconf and reloads postfix. The
// helper validates too -- these PHP-side checks exist to give the operator a
// translated message instead of a shell error, not as the security boundary.
function admin_psdnsbl_list(): ?array {
    $out = shell_exec(SUDO . ' /usr/local/sbin/qa-postscreen-dnsbl.sh list 2>/dev/null');
    if (!$out) return null;
    $d = json_decode(trim($out), true);
    return is_array($d) && isset($d['sites']) ? $d : null;
}

function admin_psdnsbl_valid_site(string $s): bool {
    return (bool)preg_match('/^[a-z0-9]([a-z0-9._-]{0,251}[a-z0-9])?$/', $s);
}

function admin_psdnsbl_cmd(string $verb, array $args): array {
    $cmd = SUDO . ' /usr/local/sbin/qa-postscreen-dnsbl.sh ' . escapeshellarg($verb);
    foreach ($args as $a) $cmd .= ' ' . escapeshellarg($a);
    $out = trim((string)shell_exec($cmd . ' 2>&1'));
    return [str_starts_with($out, 'OK'), $out ?: t('Nincs kimenet.')];
}

// rspamd neural network: status + the shadow/promote switch.
//
// The card exists because this module fails SILENTLY -- an untrained ANN and a
// healthy quiet one look identical, and the reference host sat untrained for
// two weeks. It deliberately shows every symbol PROFILE, not just a total:
// training vectors are keyed by a digest of the symbol list, so shipping a new
// rule orphans the old set and restarts the count, and an orphaned profile can
// read 568/1001 while the live one sits at 148.
function admin_neural_status(): ?array {
    // Cached like every other panel on this page: the helper is cheap now,
    // but a sudo round-trip per render still costs ~280ms for numbers that
    // creep a few times a day. Invalidated by the mode switch below so the
    // card never shows the weight setting it just replaced.
    $d = _status_cached('neural-status', 60, function () {
        $out = shell_exec(SUDO . ' /usr/local/sbin/qa-neural-config.sh status 2>/dev/null');
        if (!$out) return null;
        $j = json_decode(trim($out), true);
        return is_array($j) && isset($j['profiles']) ? $j : null;
    });
    return $d ?: null;
}

function admin_neural_cache_clear(): void {
    @unlink(dirname(SETTINGS_FILE) . '/neural-status.cache.json');
}

function admin_neural_set_mode(string $mode): array {
    if ($mode !== 'promote' && $mode !== 'shadow') return [false, t('Ismeretlen mód.')];
    $out = trim((string) shell_exec(SUDO . ' /usr/local/sbin/qa-neural-config.sh ' . escapeshellarg($mode) . ' 2>&1'));
    return [str_starts_with($out, 'OK'), $out ?: t('Nincs kimenet.')];
}

// Brand guard (HU_BRAND_DN_SPOOF): protected brands, their display-name
// variants and real domains, in /etc/rspamd/local.d/brand_definitions.json.
// Every mutation restarts rspamd (the Lua rule loads its data at start; a
// reload demonstrably does not re-run it). The helper validates too — these
// PHP checks exist for translated messages, not as the security boundary.
function admin_brandguard_list(): ?array {
    $out = shell_exec(SUDO . ' /usr/local/sbin/qa-brand-guard.sh list 2>/dev/null');
    if (!$out) return null;
    $d = json_decode(trim($out), true);
    return is_array($d) && isset($d['brands']) ? $d : null;
}

// Lure phrases (brand_lures.json): the second half of the same feature —
// a phrase only ever scores next to a brand hit, so it shares the card,
// the helper and the restart.
function admin_brandguard_lures(): ?array {
    $out = shell_exec(SUDO . ' /usr/local/sbin/qa-brand-guard.sh lures 2>/dev/null');
    if (!$out) return null;
    $d = json_decode(trim($out), true);
    return is_array($d) && isset($d['phrases']) && is_array($d['phrases']) ? $d : null;
}

function admin_brandguard_cmd(string $verb, array $args): array {
    $cmd = SUDO . ' /usr/local/sbin/qa-brand-guard.sh ' . escapeshellarg($verb);
    foreach ($args as $a) $cmd .= ' ' . escapeshellarg($a);
    $out = trim((string)shell_exec($cmd . ' 2>&1'));
    return [str_starts_with($out, 'OK'), $out ?: t('Nincs kimenet.')];
}

const IOCLOOKUP_SOURCES = ['virustotal', 'urlhaus', 'otx', 'hrbl', 'mailspike', 'urlvet', 'yaraify', 'threatfox', 'xposedornot', 'leakcheck', 'hudsonrock'];

// Built-in OR operator-defined custom: the closed-array check is exactly
// how yaraify once became un-toggleable, so customs are consulted live.
function admin_ioclookup_known(string $src): bool {
    return in_array($src, IOCLOOKUP_SOURCES, true)
        || array_key_exists($src, ioc_lookup_custom_services());
}

function admin_ioclookup_toggle(string $src, bool $on): array {
    if (!admin_ioclookup_known($src)) return [false, t('Ismeretlen forrás.')];
    $cmd = SUDO . ' /usr/local/sbin/qa-ioclookup-config.sh ' . ($on ? 'enable' : 'disable')
         . ' ' . escapeshellarg($src) . ' 2>&1';
    $out = trim((string) shell_exec($cmd));
    return str_starts_with($out, 'OK') ? [true, ''] : [false, $out ?: t('Nincs kimenet.')];
}

function admin_ioclookup_set_key(string $src, string $key): array {
    if (!in_array($src, IOCLOOKUP_SOURCES, true)) return [false, t('Ismeretlen forrás.')];
    $cmd = SUDO . ' /usr/local/sbin/qa-ioclookup-config.sh set-key ' . escapeshellarg($src) . ' 2>&1';
    $p = proc_open($cmd, [0 => ['pipe','r'], 1 => ['pipe','w'], 2 => ['pipe','w']], $pipes);
    if (!is_resource($p)) return [false, t('Nincs kimenet.')];
    fwrite($pipes[0], $key);          // stdin only - never an argument
    fclose($pipes[0]);
    $out = trim(stream_get_contents($pipes[1]));
    fclose($pipes[1]); fclose($pipes[2]); proc_close($p);
    return str_starts_with($out, 'OK') ? [true, ''] : [false, $out ?: t('Nincs kimenet.')];
}

// ── Spamhaus DQS: account key for RBL + ZRD lookups (own tiny helper) ────────
// Not a feed (no cron cadence) and not an IOC-lookup (no on-demand query) --
// it is a standing rspamd RBL config keyed by account key, so it gets its
// own script rather than overloading either existing abstraction. Presence
// of the key IS the enable flag; there is no separate toggle.
const SPAMHAUS_STATUS_CACHE = 'spamhaus-dqs-status';

// Same contract as admin_abusix_status(): the helper probes rather than just
// checking that a config file exists, so the console can distinguish a working
// source from a merely-configured one. Cached for the same reason and flushed
// on set-key for the same reason -- see that function for the full note.
function admin_spamhaus_status(): array {
    $d = _status_cached(SPAMHAUS_STATUS_CACHE, 600, function () {
        $ok  = false;
        $out = qa_sudo_read(SUDO . ' /usr/local/sbin/qa-spamhaus-dqs.sh status', 'spamhaus-dqs', $ok);
        if (!$ok) return null;                 // helper failed -> do not cache
        $d = json_decode(trim($out), true);
        return is_array($d) ? $d : null;
    });
    return $d ?: ['has_key' => false, 'reachable' => null, 'state' => 'unknown'];
}

function _spamhaus_status_flush(): void {
    @unlink(dirname(SETTINGS_FILE) . '/' . SPAMHAUS_STATUS_CACHE . '.cache.json');
}

function admin_spamhaus_set_key(string $key): array {
    $cmd = SUDO . ' /usr/local/sbin/qa-spamhaus-dqs.sh set-key 2>&1';
    $p = proc_open($cmd, [0 => ['pipe','r'], 1 => ['pipe','w'], 2 => ['pipe','w']], $pipes);
    if (!is_resource($p)) return [false, t('Nincs kimenet.')];
    fwrite($pipes[0], $key);          // stdin only - never an argument
    fclose($pipes[0]);
    $out = trim(stream_get_contents($pipes[1]));
    fclose($pipes[1]); fclose($pipes[2]); proc_close($p);
    // The key just changed, so any cached reachability is stale by definition.
    _spamhaus_status_flush();
    return _helper_said_ok($out) ? [true, ''] : [false, $out ?: t('Nincs kimenet.')];
}

// Live DNS probe against Spamhaus's own documented test IP -- confirms the
// key is actually accepted by Spamhaus, not just syntactically written to
// rbl.conf. [$ok, $detail]; $detail is the shell helper's raw (untranslated,
// ASCII-only) diagnostic text, shown appended to a translated banner string
// the same way other admin_* failures already do (e.g. admin_feed_set_key).
function admin_spamhaus_test(): array {
    $out = shell_exec(SUDO . ' /usr/local/sbin/qa-spamhaus-dqs.sh test 2>/dev/null');
    $d   = $out ? json_decode(trim($out), true) : null;
    if (!is_array($d)) return [false, t('Nincs kimenet.')];
    return [!empty($d['ok']), (string)($d['detail'] ?? '')];
}

// ── Community feed slots (5 fixed, admin-configurable IP feeds) ──────────────
const COMMUNITY_FEEDS_CONFIG_PATH = '/var/cache/quarantine-admin/community_feeds.json';
const COMMUNITY_FEEDS_STATUS_PATH = '/var/cache/quarantine-admin/community_feeds_status.json';
const COMMUNITY_FEED_FORMATS = ['plain', 'json', 'jsonl'];
// COMMUNITY_FEED_MAX is the cap on *live* feeds (count($feeds)) -- what the
// UI's "N / 25" indicator and the at-cap add-form gate enforce against.
// COMMUNITY_FEED_MAX_ID is a separate concept: the ceiling an id itself must
// stay under. next_id only ever increases and ids are never reused, so if
// this ceiling were the same as the live-feed cap, create()'s own
// admin_community_feed_valid_id($id) check below would start rejecting
// every id once next_id climbed past 25 -- reachable in well under a year
// of ordinary add/delete churn on a 25-cap install, not a multi-decade edge
// case, and it would brick creation entirely (an empty feed list "at cap").
// 9999 is comfortably larger than any realistic lifetime creation count for
// this app while staying a small, easy-to-eyeball fixed width for the
// digits-only validators on both sides (this one and the shell guard in
// install/qa-community-feed-refresh.sh, which must be kept in sync -- see
// its own comment for why the length check there matters as much as the
// numeric one).
const COMMUNITY_FEED_MAX     = 25;
const COMMUNITY_FEED_MAX_ID  = 9999;

// Mirrors _community_feed_valid_id() in the root-owned lib -- same
// \z-anchored regex, not $ (which PCRE also matches just before a single
// trailing "\n", letting "1\n" slip through; Task 1's review found and fixed
// that exact defect in the root lib, so this copy must use \z too). Both
// sides check independently and neither trusts the other: this one keeps bad
// input out of the sudo call, and the root one holds even if this layer is
// compromised. (The two cannot share code -- the root lib is mode 750,
// unreadable by apache.) Validates against the id ceiling, NOT the live-feed
// cap -- see the comment on COMMUNITY_FEED_MAX_ID above for why those are
// two different numbers now.
function admin_community_feed_valid_id(mixed $id): bool {
    if (is_int($id)) return $id >= 1 && $id <= COMMUNITY_FEED_MAX_ID;
    if (!is_string($id)) return false;
    if (preg_match('/^[1-9][0-9]*\z/', $id) !== 1) return false;
    return (int) $id <= COMMUNITY_FEED_MAX_ID;
}

// Single choke point for every privileged community-feed operation. $id is
// always an int that has already passed admin_community_feed_valid_id(), and
// $mode is from a fixed literal set -- no admin-supplied string is ever
// interpolated here.
function admin_community_feed_cmd(int $id, string $mode): array {
    if (!admin_community_feed_valid_id($id)) return [false, t('Érvénytelen azonosító.')];
    if (!in_array($mode, ['refresh', 'provision', 'teardown', 'flush'], true)) {
        return [false, t('Érvénytelen művelet.')];
    }
    $out = trim((string) shell_exec(
        SUDO . ' /usr/local/sbin/qa-community-feed-refresh.sh '
        . escapeshellarg((string) $id) . ' ' . escapeshellarg($mode) . ' 2>/dev/null'
    ));
    if ($out === 'OK') return [true, ''];
    if ($out === 'ALREADY_RUNNING') {
        // Success only for refresh: a stale refresh in flight means the
        // feed's ipset already exists and is merely being repopulated, so
        // there is nothing for the caller to write. For the three lifecycle
        // modes ALREADY_RUNNING means the requested provision/teardown/flush
        // did NOT happen -- treating it as success there would make the
        // caller write config for a feed whose firewall plumbing was never
        // touched. Not reachable today (the script's mode dispatch returns
        // before the lifecycle branch can emit this token), but guarding by
        // mode rather than by "unreachable today" keeps it correct if that
        // ever changes (e.g. once create()/save()/delete() are serialised
        // and a queued second request meets an in-progress first one).
        if ($mode === 'refresh') return [true, 'already_running'];
        return [false, t('A tűzfal-módosítás már folyamatban van, próbálja újra néhány másodperc múlva.')];
    }
    return [false, $out ?: t('Nincs kimenet.')];
}

// Serialises read-modify-write on community_feeds.json, matching the
// established rbac_with_lock()/list_with_lock() pattern elsewhere in this
// codebase (src/rbac.php, src/lists.php): LOCK_EX on the write alone does
// not help, because two concurrent requests can both read the same
// pre-write state and the later write silently overwrites the earlier one.
//
// create() holds this lock across the ENTIRE read-allocate-provision-write
// sequence, including the ~18s firewall-cmd --reload inside provision() --
// not just the final write. Releasing it before provision() and re-checking
// next_id at write time was considered (compare-on-write) and rejected: by
// the time a losing request discovers its id was taken, it has already run
// a real `firewall-cmd --new-ipset`/`--add-rich-rule` for that id, which
// then has to be torn down again before the request can even report
// failure -- more moving parts for the same outcome. Holding the lock the
// whole way through instead means a second concurrent create() simply waits
// (its own request blocks for however long the first one's reload takes),
// then reads the now-advanced next_id and provisions a genuinely different
// id. Slower under contention, but the two requests can no longer observe
// or write the same next_id, which is what actually stops the lost update.
// save() and delete() are wrapped too, for the same lost-update reason on
// their own read-modify-write of the same file (an admin editing feed A in
// one tab while deleting feed B in another must not have one write clobber
// the other's), even though only create()'s race was timing-confirmed.
function admin_community_feeds_with_lock(callable $fn) {
    $lock = fopen(COMMUNITY_FEEDS_CONFIG_PATH . '.lock', 'c');
    if ($lock === false) return $fn();          // degrade to unlocked rather than fail
    @chmod(COMMUNITY_FEEDS_CONFIG_PATH . '.lock', 0600);
    flock($lock, LOCK_EX);
    try { return $fn(); }
    finally { flock($lock, LOCK_UN); fclose($lock); }
}

// Merges config (apache-writable) and status (root-writable, written by
// qa-community-feed-loader.php) into one array per slot -- two separate
// files so a web-triggered save and a root-run status write can never
// race on the same file (see the design spec's Global Constraints).
// Returns ['next_id' => int, 'feeds' => [int id => cfg]].
// Migrates the legacy flat shape ({"community_1": {...}}) on first read and
// writes it back, so this happens exactly once. Migration is non-destructive:
// it renames keys only, and never touches a firewall object -- the five slots
// provisioned at the 2026-08-11 rollout stay provisioned whether or not they
// are configured.
function admin_community_feeds_load(): array {
    $raw = [];
    if (is_file(COMMUNITY_FEEDS_CONFIG_PATH)) {
        $d = json_decode((string) @file_get_contents(COMMUNITY_FEEDS_CONFIG_PATH), true);
        if (is_array($d)) $raw = $d;
    }
    $status = [];
    if (is_file(COMMUNITY_FEEDS_STATUS_PATH)) {
        $d = json_decode((string) @file_get_contents(COMMUNITY_FEEDS_STATUS_PATH), true);
        if (is_array($d)) $status = $d;
    }

    $migrated = false;
    if (!isset($raw['feeds'])) {
        $feeds = [];
        foreach ($raw as $key => $cfg) {
            if (!is_array($cfg)) continue;
            if (preg_match('/^community_([1-9][0-9]*)$/', (string) $key, $m) !== 1) continue;
            $candId = (string) (int) $m[1];
            // Range-check here too, not just on the later read path: a
            // hostile or stale out-of-range legacy key (e.g. community_99999)
            // must never inflate next_id past the id ceiling and lock out
            // create(). Deliberately checked against the id ceiling
            // (COMMUNITY_FEED_MAX_ID via admin_community_feed_valid_id()),
            // not the live-feed cap (COMMUNITY_FEED_MAX): migration is
            // reconstructing whatever legacy keys exist, however many there
            // are -- it is not the place that enforces "no more than N live
            // feeds" (that is create()'s job, against count($feeds), at
            // creation time). A real legacy key here is always id 1-5 from
            // the 2026-08-11 rollout, so this only ever matters for hostile
            // or corrupted input.
            if (!admin_community_feed_valid_id($candId)) continue;
            $feeds[$candId] = $cfg;
        }
        $maxId = 0;
        foreach (array_keys($feeds) as $k) $maxId = max($maxId, (int) $k);
        // The rollout provisioned ids 1-5, so never restart numbering below 6
        // even if the config listed fewer -- reusing a provisioned id would
        // silently adopt an existing ipset.
        $raw = ['next_id' => max(6, $maxId + 1), 'feeds' => $feeds];
        $migrated = true;
    }

    $out = ['next_id' => (int) ($raw['next_id'] ?? 6), 'feeds' => []];
    foreach (($raw['feeds'] ?? []) as $id => $cfg) {
        if (!admin_community_feed_valid_id((string) $id) || !is_array($cfg)) continue;
        $n  = (int) $id;
        $st = $status["community_$n"] ?? [];
        $out['feeds'][$n] = [
            'id'               => $n,
            'label'            => (string) ($cfg['label'] ?? ''),
            'url'              => (string) ($cfg['url'] ?? ''),
            'format'           => (string) ($cfg['format'] ?? 'plain'),
            'field_path'       => (string) ($cfg['field_path'] ?? ''),
            'enabled'          => !empty($cfg['enabled']),
            'last_refresh_at'  => isset($st['last_refresh_at']) ? (int) $st['last_refresh_at'] : null,
            'last_count'       => isset($st['last_count']) ? (int) $st['last_count'] : null,
            'last_ok'          => array_key_exists('last_ok', $st) ? (bool) $st['last_ok'] : null,
            'last_error'       => (string) ($st['last_error'] ?? ''),
        ];
    }
    ksort($out['feeds']);

    // Not silent: this project has twice been bitten by apache/root ownership
    // drift on /var/cache/quarantine-admin, and a failed migration write
    // would otherwise retry-and-fail on every single request with no trace.
    if ($migrated && !_admin_community_feeds_write($raw['next_id'], $raw['feeds'])) {
        error_log('admin_community_feeds_load: migration write to ' . COMMUNITY_FEEDS_CONFIG_PATH . ' failed');
    }
    return $out;
}

// Shared atomic writer -- tempfile then rename, matching the existing pattern,
// so a concurrent read never sees a half-written config.
function _admin_community_feeds_write(int $nextId, array $feeds): bool {
    $payload = ['next_id' => $nextId, 'feeds' => $feeds];
    $tmp = tempnam(dirname(COMMUNITY_FEEDS_CONFIG_PATH), '.community-cfg-');
    if ($tmp === false) return false;
    if (file_put_contents($tmp, json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)) === false) {
        @unlink($tmp);
        return false;
    }
    @chmod($tmp, 0644);
    return rename($tmp, COMMUNITY_FEEDS_CONFIG_PATH);
}

// Validates one feed's fields. Returns [normalisedCfg, errorString]; the
// error is non-empty only when the input is rejected.
function _admin_community_feed_validate(array $cfg): array {
    $label   = mb_substr(trim((string) ($cfg['label'] ?? '')), 0, 80);
    $url     = trim((string) ($cfg['url'] ?? ''));
    $format  = trim((string) ($cfg['format'] ?? 'plain'));
    $fpath   = trim((string) ($cfg['field_path'] ?? ''));
    $enabled = !empty($cfg['enabled']);

    if ($enabled && $url === '') return [[], t('Adjon meg egy URL-t.')];
    if ($enabled && !preg_match('#^https?://#i', $url)) return [[], t('Csak http(s) URL adható meg.')];
    if (!in_array($format, COMMUNITY_FEED_FORMATS, true)) return [[], t('Érvénytelen formátum.')];
    if ($enabled && $format !== 'plain' && $fpath === '') {
        return [[], t('JSON/JSONL formátumhoz mező-elérési út szükséges.')];
    }
    return [['label' => $label, 'url' => $url, 'format' => $format,
             'field_path' => $fpath, 'enabled' => $enabled], ''];
}

function admin_community_feeds_save(int $id, array $cfg): array {
    if (!admin_community_feed_valid_id($id)) return [false, t('Érvénytelen azonosító.')];
    [$norm, $err] = _admin_community_feed_validate($cfg);
    if ($err !== '') return [false, $err];

    return admin_community_feeds_with_lock(function () use ($id, $norm) {
        $cur = admin_community_feeds_load();
        if (!isset($cur['feeds'][$id])) return [false, t('Ismeretlen forrás.')];
        $wasEnabled = !empty($cur['feeds'][$id]['enabled']);

        $feeds = [];
        foreach ($cur['feeds'] as $n => $f) {
            $feeds[(string) $n] = ['label' => $f['label'], 'url' => $f['url'], 'format' => $f['format'],
                                   'field_path' => $f['field_path'], 'enabled' => $f['enabled']];
        }
        $feeds[(string) $id] = $norm;
        if (!_admin_community_feeds_write($cur['next_id'], $feeds)) {
            return [false, t('Nem sikerült írni a konfigurációt.')];
        }

        // Disabling must stop the blocking immediately -- this is the bug that
        // let 16102 IPs stay blocked after a slot was cleared. Plumbing is
        // kept so re-enabling needs no firewall object creation.
        if ($wasEnabled && !$norm['enabled']) {
            [$fOk, $fErr] = admin_community_feed_cmd($id, 'flush');
            if (!$fOk) return [false, t('Mentve, de a blokkolás leállítása sikertelen: ') . $fErr];
        }
        return [true, ''];
    });
}

function admin_community_feed_create(array $cfg): array {
    // The whole read-allocate-provision-write sequence runs under the lock
    // (see admin_community_feeds_with_lock()'s comment for why provision is
    // inside rather than released early): this is what stops two concurrent
    // create() calls from both reading the same next_id, both provisioning
    // community_<id>, and the second one silently overwriting the first
    // feed's config row with its own. Validation is pure and cheap enough
    // that holding it inside the lock too (rather than hoisting it out) just
    // preserves the original error-precedence order (cap check, then
    // validation, then id checks) with no measurable cost.
    return admin_community_feeds_with_lock(function () use ($cfg) {
        $cur = admin_community_feeds_load();
        if (count($cur['feeds']) >= COMMUNITY_FEED_MAX) {
            return [false, sprintf(t('Legfeljebb %d forrás vehető fel.'), COMMUNITY_FEED_MAX), 0];
        }
        [$norm, $err] = _admin_community_feed_validate($cfg);
        if ($err !== '') return [false, $err, 0];

        // This is now a distinct failure mode from the cap check above: the
        // live-feed count can be well under COMMUNITY_FEED_MAX while next_id
        // has still, in principle, climbed past COMMUNITY_FEED_MAX_ID after
        // enough lifetime creates. "At most N feeds" would be the wrong
        // message for that case -- there could be far fewer than N live --
        // so this uses the generic invalid-id message instead.
        $id = (int) $cur['next_id'];
        if (!admin_community_feed_valid_id($id)) {
            return [false, t('Érvénytelen azonosító.'), 0];
        }
        // Symmetry with save()/delete(): never provision or overwrite an id
        // that is already listed. Not reachable on any normal write path
        // (next_id only ever advances past every existing key, and the lock
        // now rules out two requests observing the same next_id), but
        // out-of-band config state (hand edit, restored backup) must not
        // silently re-provision a live feed.
        if (isset($cur['feeds'][$id])) {
            return [false, t('Az azonosító már foglalt.'), 0];
        }

        $feeds = [];
        foreach ($cur['feeds'] as $n => $f) {
            $feeds[(string) $n] = ['label' => $f['label'], 'url' => $f['url'], 'format' => $f['format'],
                                   'field_path' => $f['field_path'], 'enabled' => $f['enabled']];
        }
        $feeds[(string) $id] = $norm;

        // Provision BEFORE writing config: a provisioned-but-unlisted ipset is
        // inert (nothing writes to it), whereas a listed-but-unprovisioned feed
        // would load IPs into an ipset with no drop rule -- blocked in the UI's
        // telling, but silently not blocked in reality.
        [$pOk, $pErr] = admin_community_feed_cmd($id, 'provision');
        if (!$pOk) return [false, t('Nem sikerült létrehozni a tűzfal-objektumot: ') . $pErr, 0];

        if (!_admin_community_feeds_write($id + 1, $feeds)) {
            return [false, t('Nem sikerült írni a konfigurációt.'), 0];
        }
        return [true, '', $id];
    });
}

function admin_community_feed_delete(int $id): array {
    if (!admin_community_feed_valid_id($id)) return [false, t('Érvénytelen azonosító.')];

    return admin_community_feeds_with_lock(function () use ($id) {
        $cur = admin_community_feeds_load();
        if (!isset($cur['feeds'][$id])) return [false, t('Ismeretlen forrás.')];

        // Teardown first: if it fails, the feed stays listed and the admin can
        // retry, rather than the config forgetting an ipset that is still dropping.
        [$tOk, $tErr] = admin_community_feed_cmd($id, 'teardown');
        if (!$tOk) return [false, t('Nem sikerült eltávolítani a tűzfal-objektumot: ') . $tErr];

        $feeds = [];
        foreach ($cur['feeds'] as $n => $f) {
            if ($n === $id) continue;
            $feeds[(string) $n] = ['label' => $f['label'], 'url' => $f['url'], 'format' => $f['format'],
                                   'field_path' => $f['field_path'], 'enabled' => $f['enabled']];
        }
        // next_id is NOT decremented -- ids are never reused, so a slow
        // in-flight refresh of the deleted feed can never land in a new
        // feed's ipset.
        if (!_admin_community_feeds_write($cur['next_id'], $feeds)) {
            return [false, t('Nem sikerült írni a konfigurációt.')];
        }
        return [true, ''];
    });
}

function admin_community_feed_refresh(int $id): array {
    return admin_community_feed_cmd($id, 'refresh');
}

// ── Alert recipient (root-owned helper) ─────────────────────────────────────
// Notification address for cron-alert.sh, which wraps the liveness and feed
// jobs. Empty means notifications are OFF, which is the default: nothing is
// ever mailed until an admin enters an address here.
function admin_alerts_get_recipient(): string {
    return trim(qa_sudo_read(SUDO . ' /usr/local/sbin/qa-alerts-config.sh get', 'alerts'));
}

// Returns [ok, info]. The helper does the real validation -- it is the thing
// that hands the value to mail(1) -- but reject the obvious cases here too so
// the operator gets an immediate, translated message instead of a shell error.
function admin_alerts_set_recipient(string $addr): array {
    $addr = trim($addr);
    if ($addr === '') {
        $out = shell_exec(SUDO . ' /usr/local/sbin/qa-alerts-config.sh clear 2>&1');
        return [str_starts_with(trim((string)$out), 'OK'), 'off'];
    }
    if (!filter_var($addr, FILTER_VALIDATE_EMAIL)) {
        return [false, t('Ez nem érvényes e-mail cím.')];
    }
    $cmd = SUDO . ' /usr/local/sbin/qa-alerts-config.sh set 2>&1';
    $p = proc_open($cmd, [0 => ['pipe','r'], 1 => ['pipe','w'], 2 => ['pipe','w']], $pipes);
    if (!is_resource($p)) return [false, t('Nincs kimenet.')];
    fwrite($pipes[0], $addr);
    fclose($pipes[0]);
    $out = trim(stream_get_contents($pipes[1]));
    fclose($pipes[1]); fclose($pipes[2]); proc_close($p);
    if (!str_starts_with($out, 'OK')) return [false, $out ?: t('Nincs kimenet.')];
    return [true, 'set'];
}

// ── Geoblock country list (root-owned helper) ────────────────────────────────
function admin_geoblock_get_countries(): string {
    return trim(qa_sudo_read(SUDO . ' /usr/local/sbin/qa-geoblock-config.sh get', 'geoblock'));
}

function admin_geoblock_set_countries(string $codes): array {
    $codes = trim($codes);
    if ($codes === '') {
        return [false, t('Adjon meg legalább egy országkódot (vagy kapcsolja ki a forrást a fenti kapcsolóval).')];
    }
    $cmd = SUDO . ' /usr/local/sbin/qa-geoblock-config.sh set 2>&1';
    $p = proc_open($cmd, [0 => ['pipe','r'], 1 => ['pipe','w'], 2 => ['pipe','w']], $pipes);
    if (!is_resource($p)) return [false, t('Nincs kimenet.')];
    fwrite($pipes[0], $codes);
    fclose($pipes[0]);
    $out = trim(stream_get_contents($pipes[1]));
    fclose($pipes[1]); fclose($pipes[2]); proc_close($p);
    if (!str_starts_with($out, 'OK')) return [false, $out ?: t('Nincs kimenet.')];
    // Apply immediately, the same trigger the manual Refresh button uses -
    // and report what actually happened instead of assuming it started.
    [$rok, $rinfo] = admin_feeds_refresh('geoblock');
    if (!$rok) {
        // The form disables Save while the source is off, but a direct POST
        // can still hit this: not a failure, just nothing to refresh yet.
        if ($rinfo === 'ERR_DISABLED') return [true, 'disabled'];
        return [true, 'refresh_err:' . $rinfo];
    }
    return [true, $rinfo];   // '' on plain success, 'already_running' when one was already in flight
}

// ── SIEM export settings (root-owned helper) ──────────────────────────────────
// enabled/host/port/protocol, parsed from qa-siem-config.sh's KEY=VALUE-per-
// line output. Safe defaults if the script or its config file cannot be
// read at all, so a transient sudo/read failure degrades to "looks
// disabled" rather than throwing a notice through the whole page.
function admin_siem_get(): array {
    $out = qa_sudo_read(SUDO . ' /usr/local/sbin/qa-siem-config.sh get', 'siem');
    $cfg = ['enabled' => 'no', 'host' => '', 'port' => '514', 'protocol' => 'udp',
            'ca_cert_configured' => 'no', 'ca_cert_subject' => '', 'ca_cert_expiry' => ''];
    foreach (explode("\n", $out) as $line) {
        if (!preg_match('/^(enabled|host|port|protocol|ca_cert_configured|ca_cert_subject|ca_cert_expiry)=(.*)$/', $line, $m)) continue;
        $cfg[$m[1]] = $m[2];
    }
    return $cfg;
}

// Returns [ok, info]. The helper does the real validation (host shape, port
// range, protocol, and -- authoritatively, via openssl -- the pasted CA
// cert itself) -- it is the thing that renders the values straight into an
// rsyslog action()/global() string -- but reject the obvious cases here too
// so the operator gets an immediate, translated message instead of a shell
// error. $caAction is 'none' (most saves -- leave whatever CA cert is
// already installed untouched), 'set' (install $caPem as the new CA,
// replacing any existing one) or 'clear' (remove the installed CA,
// reverting TLS to anonymous peer auth).
function admin_siem_set(bool $enabled, string $host, string $port, string $protocol, string $caAction, string $caPem): array {
    $host = trim($host);
    if ($enabled && $host === '') {
        return [false, t('Adjon meg egy célkiszolgálót (host vagy IP-cím), vagy kapcsolja ki a küldést.')];
    }
    if (!ctype_digit($port) || (int)$port < 1 || (int)$port > 65535) {
        return [false, t('Érvénytelen port (1-65535).')];
    }
    if (!in_array($protocol, ['udp', 'tcp', 'tls'], true)) {
        return [false, t('Érvénytelen protokoll.')];
    }
    if ($caAction === 'set') {
        if (strlen($caPem) > 16384) {
            return [false, t('A beillesztett tanúsítvány túl hosszú (max 16 KB).')];
        }
        if (str_contains($caPem, 'PRIVATE KEY')) {
            return [false, t('Ez privát kulcsnak tűnik, nem tanúsítványnak - csak a nyilvános CA-tanúsítványt illessze be.')];
        }
        if (!str_contains($caPem, '-----BEGIN CERTIFICATE-----') || !str_contains($caPem, '-----END CERTIFICATE-----')) {
            return [false, t('A beillesztett szöveg nem érvényes PEM formátumú tanúsítvány (X.509).')];
        }
    }
    $stdin = "enabled=" . ($enabled ? 'yes' : 'no') . "\nhost=$host\nport=$port\nprotocol=$protocol\n";
    if ($caAction === 'set') {
        $stdin .= "SET\n" . base64_encode($caPem);
    } elseif ($caAction === 'clear') {
        $stdin .= "CLEAR\n";
    }
    $cmd = SUDO . ' /usr/local/sbin/qa-siem-config.sh set 2>&1';
    $p = proc_open($cmd, [0 => ['pipe','r'], 1 => ['pipe','w'], 2 => ['pipe','w']], $pipes);
    if (!is_resource($p)) return [false, t('Nincs kimenet.')];
    fwrite($pipes[0], $stdin);
    fclose($pipes[0]);
    $out = trim(stream_get_contents($pipes[1]));
    fclose($pipes[1]); fclose($pipes[2]); proc_close($p);
    if (!str_starts_with($out, 'OK')) return [false, $out ?: t('Nincs kimenet.')];
    return [true, $out];
}

// ── Blocked-mail counters (sudo helper; parses maillog) ──────────────────────
// Cached: the scan is ~0.5s over a 30 MB log, and the numbers only move as
// mail arrives.
function admin_blocked_stats(): array {
    return _status_cached('blocked-stats', 300, function () {
        $out = shell_exec(SUDO . ' /usr/local/sbin/qa-blocked-stats.sh 2>/dev/null');
        if (!$out) return null;
        $d = json_decode(trim($out), true);
        return is_array($d) ? $d : null;
    });
}

// ── ClamAV status (sudo helper: daemon, DB freshness, unofficial-sig sources) ─
function admin_clamav_status(): array {
    return _status_cached('clamav-status', 60, function () {
        $out = shell_exec(SUDO . ' /usr/local/sbin/clamav-status.sh 2>/dev/null');
        if (!$out) return null;
        $data = json_decode(trim($out), true);
        return is_array($data) ? $data : null;
    });
}

// The nine clamav-unofficial-sigs sources, plus the YARA switch.
const CLAMAV_SOURCES = ['sanesecurity', 'securiteinfo', 'interserver', 'linuxmalwaredetect',
                        'malwareexpert', 'malwarepatrol', 'urlhaus', 'ditekshen', 'twinclams'];

// Change one source's rating in user.conf, or flip YARA. ENABLE drops the
// user override so the source falls back to default_dbs_rating.
function admin_clamav_toggle(string $src, string $val): array {
    $val = strtoupper(trim($val));
    $allowed = $src === 'yara' ? ['ON', 'OFF'] : ['LOW', 'MEDIUM', 'HIGH', 'DISABLE', 'ENABLE'];
    if ($src !== 'yara' && !in_array($src, CLAMAV_SOURCES, true)) return [false, t('Ismeretlen forrás.')];
    if (!in_array($val, $allowed, true))                          return [false, t('Érvénytelen érték.')];
    // The views hide these controls where clamav-unofficial-sigs is absent, but
    // a stale open tab or a bookmarked POST still reaches here. Fail with the
    // same explanation the panel shows rather than the helper's shell-level
    // stderr. Missing key defaults to true for the same reason as in the views:
    // an older clamav-status.sh must not lock out a host that has the package.
    $st = admin_clamav_status();
    if (!($st['unofficial_installed'] ?? true)) {
        return [false, t('A kiegészítő aláírás-források és a YARA szabályok kezeléséhez a clamav-unofficial-sigs csomag szükséges, ami ezen a gépen nincs telepítve - így itt nincs mit beállítani.')];
    }
    $cmd = SUDO . ' /usr/local/sbin/clamav-sig-toggle.sh '
         . escapeshellarg($src) . ' ' . escapeshellarg($val) . ' 2>&1';
    $out = trim(shell_exec($cmd) ?? '');
    return $out === 'OK' ? [true, ''] : [false, $out ?: 'Nincs kimenet.'];
}

// Most recent incident year for one breach row (0 when unknown).
function breach_latest_year(array $r): int {
    $y = (int)($r['latest_breach'] ?? 0);
    foreach ($r['breaches'] ?? [] as $b) {
        if (is_array($b)) $y = max($y, (int)($b['year'] ?? 0));
    }
    return $y;
}

// XposedOrNot publishes a page per breach at /breach/<Name>, and the names IT
// gave us are exactly the ones it uses in those URLs.
//
// ONLY for names xposedornot itself reported. This used to link every breach
// there unconditionally, which was correct while it was the only provider and
// became a dead-link generator the moment a second one could contribute a
// name xposedornot has never heard of. $sources is the merged finding's
// source list; a finding it did not report gets no link rather than a broken
// one.
function breach_url(string $name, array $sources = ['xposedornot']): string {
    if (!in_array('xposedornot', $sources, true)) return '';
    return 'https://xposedornot.com/breach/' . rawurlencode($name);
}

// Breach entries newest first, each with a display label and a detail URL.
// Tolerates both the current dict format and the older flat-name list.
function breach_names(array $r): array {
    $rows = [];
    foreach ($r['breaches'] ?? [] as $b) {
        if (is_array($b)) {
            $n = trim((string)($b['name'] ?? ''));
            if ($n === '') continue;
            // 'sources' is written by the sweep's merge step. A schema-1 row
            // predates it and can only have come from xposedornot.
            $src = [];
            foreach ((array)($b['sources'] ?? ['xposedornot']) as $sName) {
                if (is_string($sName) && $sName !== '') $src[] = $sName;
            }
            if (!$src) $src = ['xposedornot'];
            // alias_names maps each provider's EXACT wording to the sources
            // that used it, for findings the sweep grouped as one service
            // ("CouponMom" + "CouponMom / ArmorGames"). Kept so the view can
            // show what each source actually said rather than asserting one
            // name for all of them.
            $alias = [];
            foreach ((array)($b['alias_names'] ?? []) as $aName => $aSrc) {
                if (!is_string($aName) || $aName === '' || !is_array($aSrc)) continue;
                $clean = [];
                foreach ($aSrc as $one) if (is_string($one) && $one !== '') $clean[] = $one;
                $alias[$aName] = $clean;
            }
            $rows[] = ['name' => $n, 'year' => (int)($b['year'] ?? 0),
                       'data' => trim((string)($b['data'] ?? '')),
                       'sources' => $src,
                       'alias_names' => $alias,
                       'url_name' => trim((string)($b['url_name'] ?? '')) ?: $n];
        } elseif (trim((string)$b) !== '') {
            $rows[] = ['name' => (string)$b, 'year' => 0, 'data' => '',
                       'sources' => ['xposedornot'], 'alias_names' => []];
        }
    }
    usort($rows, fn($a, $b) => $b['year'] <=> $a['year'] ?: strcmp($a['name'], $b['name']));
    foreach ($rows as &$x) {
        $x['label'] = $x['year'] ? $x['name'] . ' (' . $x['year'] . ')' : $x['name'];
        // url_name is XposedOrNot's OWN spelling, recorded by the sweep's merge
        // step. The displayed name may be another provider's longer variant,
        // and building the link from that produced a 404 on exactly the
        // corroborated findings ("000webhost.com" vs "000webhost").
        $x['url']   = breach_url($x['url_name'] ?? $x['name'], $x['sources']);
    }
    return $rows;
}

// Short-lived cache for the sudo status helpers. Both describe state that only
// changes on cron timescales, but they were re-run on every dashboard and admin
// render, which is most of those pages' ~1s load time.
function _status_cached(string $key, int $ttl, callable $fetch): array {
    $f = dirname(SETTINGS_FILE) . '/' . $key . '.cache.json';
    if (is_readable($f) && (time() - (int)@filemtime($f)) < $ttl) {
        $d = json_decode((string)@file_get_contents($f), true);
        if (is_array($d)) return $d;
    }
    $d = $fetch();
    // Cache on success -- including a legitimately-empty [] (previously never
    // cached, so the sudo helper re-ran every render for an empty status). A
    // fetch failure returns null and is NOT cached: retry next render rather
    // than masking a transient sudo outage as "empty" for the full TTL.
    if (is_array($d)) { @file_put_contents($f, json_encode($d), LOCK_EX); return $d; }
    return [];
}

// ── Feed status (reads mtimes + entry counts via sudo helper) ─────────────────
function admin_feeds_status(): array {
    return _status_cached('feeds-status', 60, function () {
        $out = shell_exec(SUDO . ' /usr/local/sbin/feeds-status.sh 2>/dev/null');
        if (!$out) return null;
        $data = json_decode(trim($out), true);
        return is_array($data) ? $data : null;
    });
}

// ── DB migration status (read-only; console never applies) ────────────────────
// Reuses this app's own existing connections rather than opening new ones:
// audit_db() (qaudit_ro, needs its new SELECT on schema_migrations -- see
// ilexa-installer/modules/55-ilexa.sh) for mysql, and the same sqlite
// handles _ioc_db()/_signin_db() already open for the console's own IOC and
// sign-in-history features for iocs/logins. migration_status() itself
// (src/migrate.php) is connection-agnostic by design for exactly this.
function admin_migration_status(): array {
    return _status_cached('migration-status', 60, function () {
        $conns = [];
        try { $conns['mysql'] = audit_db(); } catch (Throwable $e) { $conns['mysql'] = null; }
        try { $conns['iocs'] = _ioc_db(); } catch (Throwable $e) { $conns['iocs'] = null; }
        try { $conns['logins'] = _signin_db(); } catch (Throwable $e) { $conns['logins'] = null; }
        return migration_status($conns);
    });
}

// ── Update check-now (no sudo -- qa-update-check.sh needs no privilege at
// all, see its own header) ─────────────────────────────────────────────────
function admin_update_check_now(): array {
    $out = trim(shell_exec('/usr/local/sbin/qa-update-check.sh --now 2>/dev/null') ?? '');
    // Do NOT unlink the cache here. The script has just written it -- atomically,
    // with the freshly fetched and signature-verified result -- so deleting it
    // throws away the very answer the button was pressed to get, and
    // update_status() then reports "never checked". Pressing "check now" made
    // the tile go GREY instead of green: the exact opposite of its purpose.
    // On an ERR_* the script leaves the previous cache in place on purpose, and
    // qa-update-check.sh reconciles installed/update_available up front on every
    // run, so the retained cache is still correct about the installed version.
    return [$out === 'OK' || $out === 'OK_NOTMODIFIED', $out ?: 'Nincs kimenet.'];
}

// ── Trigger the update-apply background job via sudo helper. Version shape
// validated here as the first gate; qa-update-apply.sh independently
// revalidates it AND re-fetches/re-verifies the manifest before trusting it
// -- the PHP layer's opinion of what to install is a hint, never authority,
// per the same defense-in-depth convention as
// install/qa-community-feed-refresh.sh. ─────────────────────────────────────
function admin_update_apply(string $ver): array {
    if (!preg_match('/^\d{1,3}\.\d{1,3}\.\d{1,4}$/', $ver)) return [false, 'Érvénytelen verzió.'];
    $cmd = SUDO . ' /usr/local/sbin/qa-update-apply.sh ' . escapeshellarg($ver) . ' 2>/dev/null';
    $out = trim(shell_exec($cmd) ?? '');
    if ($out === 'ALREADY_RUNNING') return [true, 'already_running'];
    if ($out === 'OK')              return [true, ''];
    return [false, $out ?: 'Nincs kimenet.'];
}

// ── Trigger a background feed refresh via sudo helper ─────────────────────────
function admin_feeds_refresh(string $feed): array {
    if (!in_array($feed, FEED_SOURCES, true)) return [false, 'Ismeretlen feed.'];
    $cmd = SUDO . ' /usr/local/sbin/feeds-refresh.sh ' . escapeshellarg($feed) . ' 2>/dev/null';
    $out = trim(shell_exec($cmd) ?? '');
    @unlink(dirname(SETTINGS_FILE) . '/feeds-status.cache.json');   // show the new state at once
    if ($out === 'ALREADY_RUNNING') return [true, 'already_running'];
    if ($out === 'OK')              return [true, ''];
    return [false, $out ?: 'Nincs kimenet.'];
}

// ── POST dispatcher ───────────────────────────────────────────────────────────
function handle_admin_post(): void {
    if (!can('admin')) { header('Location: ?'); exit; }
    $action     = $_POST['admin_action'] ?? '';
    // Allowlisted: this value is echoed straight into a Location header below.
    $return_to  = qa_admin_tab($_POST['admin_return_to'] ?? null, 'admin=1');
    switch ($action) {

        case 'toggle_learning':
            if (is_file(LEARN_FLAG)) {
                @unlink(LEARN_FLAG);
                $msg = 'learning_off';
            } else {
                @touch(LEARN_FLAG);
                $msg = 'learning_on';
            }
            header('Location: ?' . $return_to . '&msg=' . $msg);
            exit;

        // Presence-means-OFF -- opposite polarity of LEARN_FLAG above on
        // purpose (see src/update.php's note); do not "fix" to match.
        case 'toggle_update_check':
            if (is_file(UPDATE_CHECK_OFF)) {
                @unlink(UPDATE_CHECK_OFF);
                $msg = 'update_check_on';
            } else {
                @touch(UPDATE_CHECK_OFF);
                $msg = 'update_check_off';
            }
            audit_log('update_check_toggle', $msg === 'update_check_on' ? 'on' : 'off', '', '');
            header('Location: ?' . $return_to . '&msg=' . $msg);
            exit;

        case 'update_check_now':
            [$ok, $info] = admin_update_check_now();
            audit_log('update_check_now', $ok ? 'ok' : 'err', '', '');
            header('Location: ?' . $return_to . '&msg=' . ($ok ? 'update_check_ok' : 'update_check_err') . '&err=' . urlencode($info));
            exit;

        // Applying is ALWAYS this one manual path, in every toggle state --
        // see db/migrations/README.md's sibling design note and
        // install/qa-update-apply.sh's own header for why.
        case 'update_apply':
            $ver = trim($_POST['update_target_version'] ?? '');
            if (!UPDATE_APPLY_ENABLED) {
                header('Location: ?' . $return_to . '&msg=update_apply_disabled');
                exit;
            }
            [$ok, $info] = admin_update_apply($ver);
            audit_log('update_apply', $ok ? 'started' : 'err', '', $ver);
            if (!$ok) {
                header('Location: ?' . $return_to . '&msg=update_apply_err&err=' . urlencode($info));
            } else {
                header('Location: ?' . $return_to . '&msg=' . ($info === 'already_running' ? 'update_apply_running' : 'update_apply_started'));
            }
            exit;

        case 'save_setting':
            $key = trim($_POST['setting_key'] ?? '');
            $val = (int)($_POST['setting_val'] ?? 0);
            [$ok, $err] = admin_settings_save($key, $val);
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'setting_saved' : 'setting_err');
            if ($err) $loc .= '&err=' . urlencode($err);
            header('Location: ' . $loc);
            exit;

        case 'reset_setting':
            $key = trim($_POST['setting_key'] ?? '');
            admin_settings_reset($key);
            header('Location: ?' . $return_to . '&msg=setting_reset');
            exit;

        case 'ioc_export_regen_token':
            [$newToken, $ok] = ioc_export_token_regenerate();
            if ($ok) {
                // Flashed once via session, never the query string -- a
                // query-string token would land in Apache's access log,
                // which this app's own admin_logins() already greps
                // (ACCESS_LOG_GLOB). views/ioc.php reads and immediately
                // unsets this so it can never render twice.
                $_SESSION['ioc_export_new_token'] = $newToken;
                audit_log('ioc-export-token-regen', '-', '', '');
                header('Location: ?' . $return_to . '&msg=ioc_export_token_regen');
            } else {
                header('Location: ?' . $return_to . '&msg=ioc_export_token_err');
            }
            exit;

        case 'ioc_export_allow_add':
            $ip = trim($_POST['ioc_export_ip'] ?? '');
            [$ok, $err] = ioc_export_allowlist_add($ip);
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'ioc_export_allow_added' : 'ioc_export_allow_err');
            if ($err) $loc .= '&err=' . urlencode($err);
            header('Location: ' . $loc);
            exit;

        case 'ioc_export_allow_remove':
            $ip = trim($_POST['ioc_export_ip'] ?? '');
            $ok = ioc_export_allowlist_remove($ip);
            header('Location: ?' . $return_to . '&msg=' . ($ok ? 'ioc_export_allow_removed' : 'ioc_export_allow_err'));
            exit;

        case 'rspamd_module_toggle':
            $mod = trim($_POST['rspamd_module'] ?? '');
            $on  = ($_POST['rspamd_on'] ?? '') === '1';
            [$ok, $out] = admin_rspamd_module_set($mod, $on);
            audit_log('rspamd_module_' . ($on ? 'on' : 'off'), $mod, '', $ok ? 'ok' : 'err');
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'rmod_ok' : 'rmod_err');
            if (!$ok) $loc .= '&err=' . urlencode($out);
            header('Location: ' . $loc . '#rspamdmods');
            exit;

        case 'hu_classify_weight':
            $sym = trim($_POST['hu_weight_sym'] ?? '');
            $val = trim($_POST['hu_weight_val'] ?? '0');
            [$ok, $out] = admin_hu_classify_weight_set($sym, $val);
            audit_log('hu_classify_weight', $sym, '', $ok ? $val : 'err');
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'hu_weight_saved' : 'hu_weight_err');
            if (!$ok) $loc .= '&err=' . urlencode($out);
            header('Location: ' . $loc . '#huclassify');
            exit;

        case 'hu_classify_measure':
            [$ok, $out] = admin_hu_classify_measure();
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'hu_measure_started' : 'hu_measure_err');
            if (!$ok) $loc .= '&err=' . urlencode($out);
            header('Location: ' . $loc . '#huclassify');
            exit;

        case 'hu_classify_report_email':
            $addr = trim($_POST['hu_report_email'] ?? '');
            [$ok, $out] = admin_hu_classify_report_email($addr);
            audit_log('hu_classify_report_email', $addr === '' ? '(cleared)' : $addr, '', $ok ? 'ok' : 'err');
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'hu_report_saved' : 'hu_report_err');
            if (!$ok) $loc .= '&err=' . urlencode($out);
            header('Location: ' . $loc . '#huclassify');
            exit;

        case 'hu_classify_toggle':
            $on = ($_POST['hu_classify_on'] ?? '') === '1';
            [$ok, $out] = admin_hu_classify_set($on);
            audit_log('hu_classify_' . ($on ? 'on' : 'off'), '', '', $ok ? 'ok' : 'err');
            $loc = '?' . $return_to . '&msg=' . ($ok ? ($on ? 'hu_classify_on' : 'hu_classify_off') : 'hu_classify_err');
            if (!$ok) $loc .= '&err=' . urlencode($out);
            header('Location: ' . $loc . '#huclassify');
            exit;

        case 'fts_optimize_toggle':
            $on = ($_POST['fts_optimize'] ?? '') === '1';
            [$ok, $out] = admin_fts_optimize_set($on);
            audit_log('fts_optimize_' . ($on ? 'on' : 'off'), '', '', $ok ? 'ok' : 'err');
            $loc = '?' . $return_to . '&msg=' . ($ok ? ($on ? 'fts_opt_on' : 'fts_opt_off') : 'fts_opt_err');
            if (!$ok) $loc .= '&err=' . urlencode($out);
            header('Location: ' . $loc);
            exit;

        case 'delete_fts':
            $user = trim($_POST['fts_user'] ?? '');
            [$ok, $out] = admin_delete_fts($user);
            audit_log('fts_index_delete', $user, '', $ok ? 'ok' : 'err');
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'fts_deleted' : 'fts_err');
            if (!$ok) $loc .= '&err=' . urlencode($out);
            header('Location: ' . $loc);
            exit;

        case 'user_add':
            $uname   = trim($_POST['ua_username'] ?? '');
            $pw      = $_POST['ua_password'] ?? '';
            $role    = trim($_POST['ua_role']     ?? '');
            $domains = array_values(array_filter(array_map('trim', explode(',', $_POST['ua_domains'] ?? ''))));
            [$ok, $err] = admin_user_add($uname, $pw, $role, $domains);
            audit_log('user_add', $uname, $role, $ok ? 'ok' : 'err');
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'user_added' : 'user_err');
            if ($err) $loc .= '&err=' . urlencode($err);
            header('Location: ' . $loc);
            exit;

        case 'user_delete':
            $uname = trim($_POST['ud_username'] ?? '');
            [$ok, $err] = admin_user_delete($uname);
            audit_log('user_delete', $uname, '', $ok ? 'ok' : 'err');
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'user_deleted' : 'user_err');
            if ($err) $loc .= '&err=' . urlencode($err);
            header('Location: ' . $loc);
            exit;

        case 'user_set_role':
            $uname   = trim($_POST['ur_username'] ?? '');
            $role    = trim($_POST['ur_role']     ?? '');
            $domains = array_values(array_filter(array_map('trim', explode(',', $_POST['ur_domains'] ?? ''))));
            [$ok, $err] = admin_user_set_role($uname, $role, $domains);
            audit_log('user_set_role', $uname, $role, $ok ? 'ok' : 'err');
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'role_saved' : 'user_err');
            if ($err) $loc .= '&err=' . urlencode($err);
            header('Location: ' . $loc);
            exit;

        case 'user_set_password':
            $uname = trim($_POST['up_username'] ?? '');
            $pw    = $_POST['up_password'] ?? '';
            [$ok, $err] = admin_user_set_password($uname, $pw);
            audit_log('user_set_password', $uname, '', $ok ? 'ok' : 'err');
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'pw_saved' : 'user_err');
            if ($err) $loc .= '&err=' . urlencode($err);
            header('Location: ' . $loc);
            exit;

        case 'feed_refresh':
            $feed = trim($_POST['feed_name'] ?? '');
            [$ok, $info] = admin_feeds_refresh($feed);
            audit_log('feed_refresh', $feed, '', $ok ? 'ok' : 'err');
            if (!$ok) {
                $loc = '?' . $return_to . '&msg=feed_err&err=' . urlencode($info);
            } else {
                $loc = '?' . $return_to . '&msg=' . ($info === 'already_running' ? 'feed_running' : 'feed_refresh_ok');
            }
            header('Location: ' . $loc);
            exit;

        case 'set_language':
            [$ok, $err] = qa_lang_set(trim($_POST['lang'] ?? ''));
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'lang_saved' : 'lang_err');
            if ($err) $loc .= '&err=' . urlencode($err);
            header('Location: ' . $loc);
            exit;

        case 'set_view_policy':
            $old = qa_view_policy();
            $new = trim($_POST['view_policy'] ?? '');
            [$ok, $err] = qa_view_policy_set($new);
            // The GDPR-relevant record: who changed who may read other people's
            // mail, from what to what, and when. Logged on failure too, so an
            // attempted change is not invisible.
            audit_log('view-policy', $ok ? $new : 'FAILED:' . preg_replace('/\s+/', ' ', $new), '', $old);
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'view_policy_saved' : 'view_policy_err');
            if ($err) $loc .= '&err=' . urlencode($err);
            header('Location: ' . $loc . '#adatvedelem');
            exit;

        case 'set_password_expiry_enabled':
            $old = qa_password_expiry_enabled() ? '1' : '0';
            $new = ($_POST['password_expiry_enabled'] ?? '') === '1';
            [$ok, $err] = qa_password_expiry_enabled_set($new);
            audit_log('password-expiry-toggle', $ok ? ($new ? '1' : '0') : 'FAILED', '', $old);
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'password_expiry_toggle_saved' : 'password_expiry_toggle_err');
            if ($err) $loc .= '&err=' . urlencode($err);
            header('Location: ' . $loc . '#jelszo-lejarat');
            exit;

        case 'set_signin_notify_enabled':
            $old = signin_notify_enabled() ? '1' : '0';
            $new = ($_POST['signin_notify_enabled'] ?? '') === '1';
            [$ok, $err] = signin_notify_enabled_set($new);
            audit_log('signin-notify-toggle', $ok ? ($new ? '1' : '0') : 'FAILED', '', $old);
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'signin_notify_saved' : 'signin_notify_err');
            if ($err) $loc .= '&err=' . urlencode($err);
            header('Location: ' . $loc . '#bejelentkezesi-anomalia');
            exit;

        case 'rspamc_pw':
            [$ok, $err] = admin_rspamc_pw_set((string)($_POST['rspamc_pw'] ?? ''));
            audit_log('rspamc-pw-set', '', '', $ok ? 'ok' : 'err');   // never log the value
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'rspamc_pw_saved' : 'rspamc_pw_err');
            if ($err) $loc .= '&err=' . urlencode($err);
            header('Location: ' . $loc . '#learning'); exit;

        case 'feed_toggle':
            $fsrc = trim($_POST['feed_src'] ?? '');
            $on   = ($_POST['feed_on'] ?? '') === '1';
            [$ok, $err] = admin_feed_toggle($fsrc, $on);
            audit_log('feed-' . ($on ? 'enable' : 'disable'), $fsrc, '', $ok ? 'ok' : 'err');
            @unlink(dirname(SETTINGS_FILE) . '/feeds-status.cache.json');
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'feed_saved' : 'feed_cfg_err');
            if ($err) $loc .= '&err=' . urlencode($err);
            header('Location: ' . $loc . '#feeds'); exit;

        case 'feed_key':
            $fsrc = trim($_POST['feed_src'] ?? '');
            [$ok, $err] = admin_feed_set_key($fsrc, (string)($_POST['feed_key'] ?? ''));
            audit_log('feed-setkey', $fsrc, '', $ok ? 'ok' : 'err');   // never log the key
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'feed_key_saved' : 'feed_cfg_err');
            if ($err) $loc .= '&err=' . urlencode($err);
            header('Location: ' . $loc . '#feeds'); exit;

        case 'psdnsbl_add':
        case 'psdnsbl_weight': {
            $site = strtolower(trim($_POST['psdnsbl_site'] ?? ''));
            $w    = trim($_POST['psdnsbl_weight'] ?? '');
            if (!admin_psdnsbl_valid_site($site) || !preg_match('/^-?[0-9]{1,2}$/', $w)) {
                header('Location: ?' . $return_to . '&msg=psdnsbl_err&err=' . urlencode(t('Érvénytelen zóna vagy súly.')) . '#psdnsbl'); exit;
            }
            $verb = $action === 'psdnsbl_add' ? 'add' : 'set-weight';
            [$ok, $err] = admin_psdnsbl_cmd($verb, [$site, $w]);
            audit_log('psdnsbl-' . $verb, $site, 'weight=' . $w, $ok ? 'ok' : 'err');
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'psdnsbl_saved' : 'psdnsbl_err');
            if (!$ok) $loc .= '&err=' . urlencode($err);
            header('Location: ' . $loc . '#psdnsbl'); exit;
        }

        case 'psdnsbl_remove': {
            $site = strtolower(trim($_POST['psdnsbl_site'] ?? ''));
            if (!admin_psdnsbl_valid_site($site)) {
                header('Location: ?' . $return_to . '&msg=psdnsbl_err&err=' . urlencode(t('Érvénytelen zóna.')) . '#psdnsbl'); exit;
            }
            [$ok, $err] = admin_psdnsbl_cmd('remove', [$site]);
            audit_log('psdnsbl-remove', $site, '', $ok ? 'ok' : 'err');
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'psdnsbl_saved' : 'psdnsbl_err');
            if (!$ok) $loc .= '&err=' . urlencode($err);
            header('Location: ' . $loc . '#psdnsbl'); exit;
        }

        case 'psdnsbl_threshold': {
            $t = trim($_POST['psdnsbl_threshold'] ?? '');
            if (!preg_match('/^[0-9]{1,2}$/', $t)) {
                header('Location: ?' . $return_to . '&msg=psdnsbl_err&err=' . urlencode(t('Érvénytelen küszöbérték.')) . '#psdnsbl'); exit;
            }
            [$ok, $err] = admin_psdnsbl_cmd('set-threshold', [$t]);
            audit_log('psdnsbl-threshold', $t, '', $ok ? 'ok' : 'err');
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'psdnsbl_saved' : 'psdnsbl_err');
            if (!$ok) $loc .= '&err=' . urlencode($err);
            header('Location: ' . $loc . '#psdnsbl'); exit;
        }

        case 'neural_mode': {
            $mode = ($_POST['neural_mode'] ?? '') === 'promote' ? 'promote' : 'shadow';
            [$ok, $err] = admin_neural_set_mode($mode);
            admin_neural_cache_clear();
            audit_log('neural-' . $mode, '', '', $ok ? 'ok' : 'err');
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'neural_saved' : 'neural_err');
            if (!$ok) $loc .= '&err=' . urlencode($err);
            header('Location: ' . $loc . '#neural'); exit;
        }

        case 'brand_toggle': {
            $on = ($_POST['brand_on'] ?? '') === '1';
            [$ok, $err] = admin_brandguard_cmd('set-enabled', [$on ? 'yes' : 'no']);
            audit_log('brand-' . ($on ? 'enable' : 'disable'), '', '', $ok ? 'ok' : 'err');
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'brand_saved' : 'brand_err');
            if (!$ok) $loc .= '&err=' . urlencode($err);
            header('Location: ' . $loc . '#brandguard'); exit;
        }

        case 'brand_add': {
            $bid   = strtolower(trim($_POST['brand_id'] ?? ''));
            $bname = trim($_POST['brand_name'] ?? '');
            if (!preg_match('/^[a-z0-9][a-z0-9_-]{0,31}$/', $bid) || $bname === '' || mb_strlen($bname) > 64) {
                header('Location: ?' . $return_to . '&msg=brand_err&err=' . urlencode(t('Érvénytelen azonosító vagy márkanév.')) . '#brandguard'); exit;
            }
            [$ok, $err] = admin_brandguard_cmd('add-brand', [$bid, $bname]);
            audit_log('brand-add', $bid, $bname, $ok ? 'ok' : 'err');
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'brand_saved' : 'brand_err');
            if (!$ok) $loc .= '&err=' . urlencode($err);
            header('Location: ' . $loc . '#brandguard'); exit;
        }

        case 'brand_remove': {
            $bid = strtolower(trim($_POST['brand_id'] ?? ''));
            if (!preg_match('/^[a-z0-9][a-z0-9_-]{0,31}$/', $bid)) {
                header('Location: ?' . $return_to . '&msg=brand_err&err=' . urlencode(t('Érvénytelen azonosító.')) . '#brandguard'); exit;
            }
            [$ok, $err] = admin_brandguard_cmd('remove-brand', [$bid]);
            audit_log('brand-remove', $bid, '', $ok ? 'ok' : 'err');
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'brand_saved' : 'brand_err');
            if (!$ok) $loc .= '&err=' . urlencode($err);
            header('Location: ' . $loc . '#brandguard'); exit;
        }

        case 'brand_lure_toggle': {
            $on = ($_POST['brand_on'] ?? '') === '1';
            [$ok, $err] = admin_brandguard_cmd('lure-set-enabled', [$on ? 'yes' : 'no']);
            audit_log('brand-lure-' . ($on ? 'enable' : 'disable'), '', '', $ok ? 'ok' : 'err');
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'brand_saved' : 'brand_err');
            if (!$ok) $loc .= '&err=' . urlencode($err);
            header('Location: ' . $loc . '#brandguard'); exit;
        }

        case 'brand_lure_add':
        case 'brand_lure_remove': {
            $lang   = strtolower(trim($_POST['brand_lang'] ?? ''));
            // Collapse whitespace exactly as the helper does, so the string the
            // operator sees removed is the string that was stored.
            $phrase = trim(preg_replace('/\s+/u', ' ', (string)($_POST['brand_value'] ?? '')));
            $len    = function_exists('mb_strlen') ? mb_strlen($phrase) : strlen($phrase);
            if (!preg_match('/^[a-z]{2,8}$/', $lang) || $len < 8 || $len > 64) {
                header('Location: ?' . $return_to . '&msg=brand_err&err=' . urlencode(
                    t('Érvénytelen nyelvkód vagy fordulat (8–64 karakter).')) . '#brandguard'); exit;
            }
            $verb = $action === 'brand_lure_add' ? 'lure-add' : 'lure-remove';
            [$ok, $err] = admin_brandguard_cmd($verb, [$lang, $phrase]);
            audit_log('brand-' . $verb, $lang, $phrase, $ok ? 'ok' : 'err');
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'brand_saved' : 'brand_err');
            if (!$ok) $loc .= '&err=' . urlencode($err);
            header('Location: ' . $loc . '#brandguard'); exit;
        }

        case 'brand_variant_add':
        case 'brand_variant_remove':
        case 'brand_domain_add':
        case 'brand_domain_remove': {
            $bid = strtolower(trim($_POST['brand_id'] ?? ''));
            $val = strtolower(trim($_POST['brand_value'] ?? ''));
            $isVariant = str_contains($action, 'variant');
            $validVal  = $isVariant
                ? (bool)preg_match('/^=?[a-z0-9][a-z0-9 ]{2,46}$/', $val)
                : (bool)preg_match('/^[a-z0-9]([a-z0-9._-]{0,251}[a-z0-9])?$/', $val) && str_contains($val, '.');
            if (!preg_match('/^[a-z0-9][a-z0-9_-]{0,31}$/', $bid) || !$validVal) {
                header('Location: ?' . $return_to . '&msg=brand_err&err=' . urlencode($isVariant
                    ? t('Érvénytelen névváltozat (kisbetű/szám/szóköz, 3–47 karakter, opcionális "=" előtag).')
                    : t('Érvénytelen domain.')) . '#brandguard'); exit;
            }
            $verb = str_replace(['brand_', '_'], ['', '-'], $action);   // pl. variant-add
            $verb = preg_replace('/^(variant|domain)-(add|remove)$/', '$2-$1', $verb);
            [$ok, $err] = admin_brandguard_cmd($verb, [$bid, $val]);
            audit_log('brand-' . $verb, $bid, $val, $ok ? 'ok' : 'err');
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'brand_saved' : 'brand_err');
            if (!$ok) $loc .= '&err=' . urlencode($err);
            header('Location: ' . $loc . '#brandguard'); exit;
        }

        case 'ioclookup_addcustom': {
            $cn = strtolower(trim($_POST['cl_name'] ?? ''));
            $cz = strtolower(trim($_POST['cl_zone'] ?? ''));
            $ct = array_values(array_intersect((array)($_POST['cl_types'] ?? []), ['ip', 'domain']));
            $cw = trim($_POST['cl_weight'] ?? '10');
            if (!preg_match('/^[a-z0-9][a-z0-9_-]{1,30}$/', $cn) || !preg_match('/^[a-z0-9]([a-z0-9._-]{0,251}[a-z0-9])?$/', $cz)
                || !$ct || !preg_match('/^[0-9]{1,2}$/', $cw)) {
                header('Location: ?' . $return_to . '&msg=ioclookup_err&err=' . urlencode(t('Érvénytelen név, zóna, típus vagy súly.')) . '#ioclookup'); exit;
            }
            $cmd = SUDO . ' /usr/local/sbin/qa-ioclookup-config.sh add-custom '
                 . escapeshellarg($cn) . ' ' . escapeshellarg($cz) . ' ' . escapeshellarg(implode(',', $ct)) . ' ' . escapeshellarg($cw) . ' 2>&1';
            $out = trim((string)shell_exec($cmd));
            $ok = str_starts_with($out, 'OK');
            audit_log('ioclookup-addcustom', $cn, $cz, $ok ? 'ok' : 'err');
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'ioclookup_saved' : 'ioclookup_err');
            if (!$ok) $loc .= '&err=' . urlencode($out ?: t('Nincs kimenet.'));
            header('Location: ' . $loc . '#ioclookup'); exit;
        }

        case 'ioclookup_removecustom': {
            $cn = strtolower(trim($_POST['cl_name'] ?? ''));
            if (!preg_match('/^[a-z0-9][a-z0-9_-]{1,30}$/', $cn)) {
                header('Location: ?' . $return_to . '&msg=ioclookup_err&err=' . urlencode(t('Érvénytelen név.')) . '#ioclookup'); exit;
            }
            $out = trim((string)shell_exec(SUDO . ' /usr/local/sbin/qa-ioclookup-config.sh remove-custom ' . escapeshellarg($cn) . ' 2>&1'));
            $ok = str_starts_with($out, 'OK');
            audit_log('ioclookup-removecustom', $cn, '', $ok ? 'ok' : 'err');
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'ioclookup_saved' : 'ioclookup_err');
            if (!$ok) $loc .= '&err=' . urlencode($out ?: t('Nincs kimenet.'));
            header('Location: ' . $loc . '#ioclookup'); exit;
        }

        case 'ioclookup_toggle':
            $lsrc = trim($_POST['ioclookup_src'] ?? '');
            $on   = ($_POST['ioclookup_on'] ?? '') === '1';
            [$ok, $err] = admin_ioclookup_toggle($lsrc, $on);
            audit_log('ioclookup-' . ($on ? 'enable' : 'disable'), $lsrc, '', $ok ? 'ok' : 'err');
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'ioclookup_saved' : 'ioclookup_err');
            if ($err) $loc .= '&err=' . urlencode($err);
            header('Location: ' . $loc . '#ioclookup'); exit;

        case 'ioclookup_key':
            $lsrc = trim($_POST['ioclookup_src'] ?? '');
            [$ok, $err] = admin_ioclookup_set_key($lsrc, (string)($_POST['ioclookup_key'] ?? ''));
            audit_log('ioclookup-setkey', $lsrc, '', $ok ? 'ok' : 'err');   // never log the key
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'ioclookup_key_saved' : 'ioclookup_err');
            if ($err) $loc .= '&err=' . urlencode($err);
            header('Location: ' . $loc . '#ioclookup'); exit;

        case 'spamhaus_key':
            [$ok, $err] = admin_spamhaus_set_key((string)($_POST['spamhaus_key'] ?? ''));
            audit_log('spamhaus-dqs-setkey', '', '', $ok ? 'ok' : 'err');   // never log the key
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'spamhaus_key_saved' : 'spamhaus_err');
            if ($err) $loc .= '&err=' . urlencode($err);
            header('Location: ' . $loc . '#feeds'); exit;

        case 'spamhaus_test':
            [$ok, $detail] = admin_spamhaus_test();
            audit_log('spamhaus-dqs-test', '', '', $ok ? 'ok' : 'err');
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'spamhaus_test_ok' : 'spamhaus_test_err');
            if ($detail !== '') $loc .= '&err=' . urlencode($detail);
            header('Location: ' . $loc . '#feeds'); exit;

        case 'abusix_key':
            [$ok, $err] = admin_abusix_set_key((string)($_POST['abusix_key'] ?? ''));
            audit_log('abusix_key', $ok ? 'set' : 'failed');
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'abusix_key_saved' : 'abusix_err')
                 . ($ok ? '' : '&err=' . urlencode($err));
            break;

        case 'abusix_test':
            [$ok, $detail] = admin_abusix_test();
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'abusix_test_ok' : 'abusix_test_err')
                 . '&err=' . urlencode($detail);
            break;

        case 'community_feed_create':
            [$cfOk, $cfErr, $cfNewId] = admin_community_feed_create([
                'label'      => $_POST['cf_label']      ?? '',
                'url'        => $_POST['cf_url']        ?? '',
                'format'     => $_POST['cf_format']     ?? 'plain',
                'field_path' => $_POST['cf_field_path'] ?? '',
                'enabled'    => !empty($_POST['cf_enabled']),
            ]);
            audit_log('community-feed-create', (string) $cfNewId, '', $cfOk ? 'ok' : 'err');
            $cfLoc = '?' . $return_to . '&msg=' . ($cfOk ? 'community_feed_saved' : 'community_feed_err');
            if (!$cfOk) $cfLoc .= '&err=' . urlencode($cfErr);
            header('Location: ' . $cfLoc . '#community-feeds');
            exit;

        case 'community_feed_delete':
            $cfSlot = (int) ($_POST['cf_slot'] ?? 0);
            if (!admin_community_feed_valid_id($cfSlot)) {
                header('Location: ?' . $return_to . '&msg=community_feed_err&err=' . urlencode(t('Érvénytelen azonosító.')) . '#community-feeds');
                exit;
            }
            [$cfOk, $cfErr] = admin_community_feed_delete($cfSlot);
            // The GDPR-adjacent record: who deleted which feed id, and when.
            // Deliberately id-only -- the label is admin free text and would
            // need preg_replace('/\s+/', ' ', $val) sanitisation before it
            // could safely reach this tab-delimited log; the entry count is
            // not passed in here either. Leaving both out is the safer
            // default, not an oversight.
            audit_log('community-feed-delete', (string) $cfSlot, '', $cfOk ? 'ok' : 'err');
            $cfLoc = '?' . $return_to . '&msg=' . ($cfOk ? 'community_feed_deleted' : 'community_feed_err');
            if (!$cfOk) $cfLoc .= '&err=' . urlencode($cfErr);
            header('Location: ' . $cfLoc . '#community-feeds');
            exit;

        case 'community_feed_save':
            $cfSlot = (int) ($_POST['cf_slot'] ?? 0);
            $cfCfg = [
                'label' => $_POST['cf_label'] ?? '', 'url' => $_POST['cf_url'] ?? '',
                'format' => $_POST['cf_format'] ?? 'plain', 'field_path' => $_POST['cf_field_path'] ?? '',
                'enabled' => ($_POST['cf_enabled'] ?? '') === '1',
            ];
            [$cfOk, $cfErr] = admin_community_feeds_save($cfSlot, $cfCfg);
            audit_log('community-feed-save', (string) $cfSlot, '', $cfOk ? 'ok' : 'err');
            $cfLoc = '?' . $return_to . '&msg=' . ($cfOk ? 'community_feed_saved' : 'community_feed_err');
            if ($cfErr) $cfLoc .= '&err=' . urlencode($cfErr);
            header('Location: ' . $cfLoc . '#community-feeds'); exit;

        case 'community_feed_refresh':
            $cfSlot = (int) ($_POST['cf_slot'] ?? 0);
            [$cfOk, $cfInfo] = admin_community_feed_refresh($cfSlot);
            audit_log('community-feed-refresh', (string) $cfSlot, '', $cfOk ? 'ok' : 'err');
            if (!$cfOk) {
                $cfLoc = '?' . $return_to . '&msg=community_feed_err&err=' . urlencode($cfInfo);
            } else {
                $cfLoc = '?' . $return_to . '&msg=' . ($cfInfo === 'already_running' ? 'community_feed_running' : 'community_feed_refresh_ok');
            }
            header('Location: ' . $cfLoc . '#community-feeds'); exit;

        case 'set_alert_recipient':
            // Admin-only by construction: handle_admin_post() returns above
            // unless can('admin'). Submitting an empty field is the documented
            // way to turn notifications back off.
            $addr = trim((string)($_POST['alert_recipient'] ?? ''));
            [$ok, $info] = admin_alerts_set_recipient($addr);
            // The address is operator-entered free text; collapse whitespace
            // before it reaches the TSV audit log.
            audit_log('alert-recipient', 'alerts',
                      $addr === '' ? '(off)' : preg_replace('/\s+/', ' ', $addr),
                      $ok ? 'ok' : 'err');
            if (!$ok) {
                $loc = '?' . $return_to . '&msg=alerts_err&err=' . urlencode($info);
            } else {
                $loc = '?' . $return_to . '&msg=' . ($info === 'off' ? 'alerts_off' : 'alerts_set');
            }
            header('Location: ' . $loc); exit;

        case 'set_siem_export':
            // Admin-only by construction: handle_admin_post() returns above
            // unless can('admin'). This is security-relevant configuration
            // (where copies of Fail2Ban/Apache/ilexa audit events leave the
            // box, and whether they leave at all), so both the on/off flip
            // and the target itself are worth their own audit-log record.
            $seEnabled  = isset($_POST['siem_enabled']);
            $seHost     = trim((string)($_POST['siem_host'] ?? ''));
            $sePort     = trim((string)($_POST['siem_port'] ?? '514'));
            $seProtocol = trim((string)($_POST['siem_protocol'] ?? 'udp'));
            $seCaPem    = trim((string)($_POST['siem_ca_cert_pem'] ?? ''));
            if (isset($_POST['siem_ca_remove'])) {
                $seCaAction = 'clear';
            } elseif ($seCaPem !== '') {
                $seCaAction = 'set';
            } else {
                $seCaAction = 'none';
            }
            [$ok, $info] = admin_siem_set($seEnabled, $seHost, $sePort, $seProtocol, $seCaAction, $seCaPem);
            audit_log('siem-export', ($seEnabled ? 'on' : 'off'),
                      ($seHost === '' ? '(none)' : "$seHost:$sePort/$seProtocol")
                      . ($seCaAction !== 'none' ? " ca=$seCaAction" : ''), $ok ? 'ok' : 'err');
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'siem_saved' : 'siem_err');
            if (!$ok) $loc .= '&err=' . urlencode($info);
            header('Location: ' . $loc . '#siem-export'); exit;

        case 'geoblock_set_countries':
            $countries = trim((string)($_POST['geoblock_countries'] ?? ''));
            [$ok, $info] = admin_geoblock_set_countries($countries);
            // Collapse interior whitespace before it hits the TSV audit log - the
            // submitted string is otherwise unvalidated free text.
            audit_log('geoblock-countries', 'geoblock', preg_replace('/\s+/', ' ', $countries), $ok ? 'ok' : 'err');
            if (!$ok) {
                $loc = '?' . $return_to . '&msg=geoblock_err&err=' . urlencode($info);
            } elseif ($info === 'already_running') {
                $loc = '?' . $return_to . '&msg=geoblock_running';
            } elseif ($info === 'disabled') {
                $loc = '?' . $return_to . '&msg=geoblock_off';
            } elseif (str_starts_with($info, 'refresh_err:')) {
                $loc = '?' . $return_to . '&msg=geoblock_ref_err&err=' . urlencode(substr($info, strlen('refresh_err:')));
            } else {
                $loc = '?' . $return_to . '&msg=geoblock_saved';
            }
            header('Location: ' . $loc . '#feeds'); exit;

        case 'clamav_toggle':
            $src = trim($_POST['cv_source'] ?? '');
            $val = trim($_POST['cv_value']  ?? '');
            [$ok, $err] = admin_clamav_toggle($src, $val);
            audit_log('clamav_sig', $src, strtoupper($val), $ok ? 'ok' : 'err');
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'clamav_saved' : 'clamav_err');
            if ($err) $loc .= '&err=' . urlencode($err);
            header('Location: ' . $loc . '#clamav');
            exit;

        case 'postfix_save_setting':
            $key = trim($_POST['pf_key'] ?? '');
            $val = trim($_POST['pf_val'] ?? '');
            [$ok, $err] = postfix_setting_save($key, $val);
            audit_log('postfix-setting', $key, preg_replace('/\s+/', ' ', $val), $ok ? 'ok' : 'err');
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'postfix_setting_saved' : 'postfix_setting_err');
            if ($err) $loc .= '&err=' . urlencode($err);
            header('Location: ' . $loc . '#postfix-network'); exit;

        case 'postfix_save_restriction':
            $dir    = trim($_POST['pf_dir'] ?? '');
            $tokens = array_values(array_filter(array_map('trim', explode("\n", $_POST['pf_tokens'] ?? ''))));
            [$ok, $err] = postfix_restriction_save($dir, $tokens);
            audit_log('postfix-restriction', $dir, implode(',', $tokens), $ok ? 'ok' : 'err');
            $loc = '?' . $return_to . '&msg=' . ($ok ? 'postfix_restriction_saved' : 'postfix_restriction_err');
            if ($err) $loc .= '&err=' . urlencode($err);
            header('Location: ' . $loc . '#postfix-restrictions'); exit;

    }
}
