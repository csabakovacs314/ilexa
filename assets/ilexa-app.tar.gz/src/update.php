<?php
// Update check/apply status for the console. update_status() is a PURE
// READER of the cache file qa-update-check.sh writes -- it never fetches,
// unlike _status_cached()'s lazy-refresh-on-expiry shape (src/admin.php).
// That's deliberate: a network call with a 20s timeout has no business on a
// dashboard render's critical path, and "automated updates" is a promise
// about a CRON schedule, not about what happens when someone loads a page.
// A missing or stale (>48h) cache file renders as unknown, never as a
// trigger to go fetch one.

const UPDATE_STATUS_CACHE = '/var/cache/quarantine-admin/update-status.cache.json';
const UPDATE_RUN_CACHE    = '/var/cache/quarantine-admin/update-run.json';
const UPDATE_STALE_SECONDS = 48 * 3600;

// Dashboard/About tile data. Never throws, never blocks.
function update_status(): array {
    // UPDATE_CHECK_OFF (bootstrap.php, from $cfg['update_check_off_flag']):
    // presence means checking is OFF -- the OPPOSITE polarity of LEARN_FLAG
    // (presence=ON). Deliberate: update-checking must default ON so an
    // existing host is protected without any installer action, whereas
    // LEARN_FLAG's feature must be deliberately opted into. See the toggle
    // handler in admin.php for the same note at the point someone is most
    // likely to assume they match.
    $checkOff = is_file(UPDATE_CHECK_OFF);

    if (!is_readable(UPDATE_STATUS_CACHE)) {
        return ['known' => false, 'check_disabled' => $checkOff, 'reason' => 'never_checked'];
    }
    $age = time() - (int)@filemtime(UPDATE_STATUS_CACHE);
    $d = json_decode((string)@file_get_contents(UPDATE_STATUS_CACHE), true);
    if (!is_array($d) || empty($d['ok'])) {
        return ['known' => false, 'check_disabled' => $checkOff, 'reason' => 'last_check_failed'];
    }
    if ($age > UPDATE_STALE_SECONDS) {
        return ['known' => false, 'check_disabled' => $checkOff, 'reason' => 'stale', 'age_seconds' => $age] + $d;
    }
    $d['known'] = true;
    $d['check_disabled'] = $checkOff;
    $d['age_seconds'] = $age;
    return $d;
}

// A run currently in progress or the most recent completed one, for the
// dashboard's "Frissítés folyamatban: <phase>" line. Never throws.
function update_run_state(): ?array {
    if (!is_readable(UPDATE_RUN_CACHE)) return null;
    $d = json_decode((string)@file_get_contents(UPDATE_RUN_CACHE), true);
    return is_array($d) ? $d : null;
}

// One-time latch: the apply script writes audit_written:false on every
// terminal state; the first render that observes a terminal state with the
// latch still false appends the terminal audit_log() row and flips it. Kept
// here (apache-owned AUDIT_LOG) rather than in the root-run apply script, so
// the process that owns the audit log format is the only one appending to
// it -- see audit.php's own header for why that file is treated as
// authoritative.
function update_reconcile_audit(): void {
    $run = update_run_state();
    if (!$run) return;
    if (!empty($run['audit_written'])) return;
    if (!in_array($run['state'] ?? '', ['ok', 'failed', 'rolled_back', 'needs_attention'], true)) return;

    // 'failed' and 'rolled_back' are deliberately distinct in the audit log:
    // 'failed' means the run aborted BEFORE go_live and production was never
    // touched, 'rolled_back' means it went live and was reverted. Collapsing
    // the two (the earlier bug) recorded rollbacks that never happened.
    $outcome = [
        'ok'          => 'ok',
        'failed'      => 'failed_no_change',
        'rolled_back' => 'rolled_back',
    ][$run['state']] ?? 'FAILED';
    audit_log('update_apply', $outcome, (string)($run['from'] ?? ''), (string)($run['to'] ?? ''));

    $run['audit_written'] = true;
    @file_put_contents(UPDATE_RUN_CACHE, json_encode($run, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), LOCK_EX);
}
