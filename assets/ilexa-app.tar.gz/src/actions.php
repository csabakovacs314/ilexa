<?php
// Return whether the mailbox operation actually succeeded, so a bulk run can
// report real counts instead of assuming every item worked.
function do_release(string $user, string $folder, string $uid): bool {
    audit_log('release', $user, $folder, $uid);
    rspamd_learn('ham', $user, $folder, $uid);
    return qa_da_ok(['move-inbox', $user, $folder, $uid]);
}

function do_delete(string $user, string $folder, string $uid): bool {
    audit_log('delete', $user, $folder, $uid);
    rspamd_learn('spam', $user, $folder, $uid);
    return qa_da_ok(['expunge', $user, $folder, $uid]);
}

// Lazy-loaded rspamd module list for the Rendszer panel.
//
// The panel is collapsed by default, so loading its data during the page render
// meant paying ~870ms for a table most page loads never display. This endpoint
// is fetched when the section is first expanded instead.
function handle_rspamd_modules(): void {
    header('Content-Type: application/json; charset=utf-8');
    if (!can('admin')) {
        http_response_code(403);
        echo json_encode(['error' => t('Nincs jogosultság ehhez a művelethez.')]); exit;
    }
    echo json_encode(['modules' => admin_rspamd_modules()]);
    exit;
}

function handle_view(): void {
    header('Content-Type: application/json; charset=utf-8');

    // Endpoint-level authorization: hiding the UI control is not a control.
    if (!can('view')) {
        http_response_code(403);
        echo json_encode(['error' => t('Nincs jogosultság ehhez a művelethez.')]); exit;
    }

    $uid = $_GET['uid'] ?? '';
    $isArchive = ($_GET['archive'] ?? '') === '1';

    // Site-wide content-viewing policy (GDPR). A ceiling on top of can():
    // it can only remove access, never grant it. Checked before either branch
    // so no future branch can slip past it.
    if (!qa_view_allowed($isArchive)) {
        http_response_code(403);
        echo json_encode(['error' => t('A levéltartalom megtekintése jelenleg le van tiltva (adatvédelmi beállítás).')]); exit;
    }

    if ($isArchive) {
        if (!can('archive')) {
            http_response_code(403);
            echo json_encode(['error' => t('Nincs jogosultság ehhez a művelethez.')]); exit;
        }
        $user = ARCHIVE_USER; $folder = ARCHIVE_MAILBOX;
        if (!valid_uid($uid)) {
            echo json_encode(['error' => t('Érvénytelen paraméterek')]); exit;
        }
    } else {
        $user   = $_GET['user']   ?? '';
        if ($user !== '' && !qa_domain_allowed($user)) {
            http_response_code(403);
            echo json_encode(['error' => t('Nincs jogosultság ehhez a művelethez.')]); exit;
        }
        $folder = $_GET['folder'] ?? '';
        if (!valid_user($user) || !valid_folder($folder) || !valid_uid($uid)) {
            echo json_encode(['error' => t('Érvénytelen paraméterek')]);
            exit;
        }
    }

    $cmd = SUDO . ' ' . QA_DOVEADM . ' fetch-text ' . escapeshellarg($user)
         . ' ' . escapeshellarg($folder) . ' ' . escapeshellarg($uid)
         . ' 2>/dev/null | ' . PYTHON3 . ' ' . escapeshellarg(PARSE_EMAIL_PY);

    $json = shell_exec($cmd);

    if (!$json || ($data = json_decode($json, true)) === null) {
        echo json_encode(['error' => t('Nem sikerült betölteni a levelet')]);
        exit;
    }

    echo $json;
    exit;
}

function handle_post(): void {
    $action = $_POST['action'] ?? '';

    // IOC-tab actions self-gate on can('admin') inside handle_ioc_action();
    // delegated here rather than duplicating that permission logic.
    if (in_array($action, ['ioc_add', 'ioc_expire', 'ioc_extract', 'ioc_confirm', 'ioc_lookup', 'ioc_promote', 'ioc_unpromote', 'ioc_bulk_import'], true)) {
        handle_ioc_action($action);
        return; // unreachable -- handle_ioc_action() always exits
    }

    // Campaign-tab actions self-gate on can('admin') inside handle_campaign_action();
    // delegated here rather than duplicating that permission logic.
    if (in_array($action, ['campaign_dismiss', 'campaign_add_ioc'], true)) {
        handle_campaign_action($action);
        return; // unreachable -- handle_campaign_action() always exits
    }

    // Quarantine-row reputation lookup self-gates on can('lists') inside
    // handle_quar_lookup_action() (same permission list_lookup uses) and
    // returns JSON on failure -- deliberately NOT added to the action_ops/
    // list_lookup guard below, whose header('Location: ?') on failure is
    // AJAX-hostile (trips the client's r.json(), which then re-submits).
    if ($action === 'quar_lookup') {
        handle_quar_lookup_action();
        return; // unreachable -- handle_quar_lookup_action() always exits
    }

    // Archívum-row automatic IOC check self-gates on can('admin') +
    // qa_view_allowed(true) inside handle_arc_lookup_action() and returns
    // JSON on failure -- same AJAX-hostile-Location() reasoning as
    // quar_lookup above, so it is excluded from the action_ops guard below
    // for the same reason.
    if ($action === 'arc_ioc_check') {
        handle_arc_lookup_action();
        return; // unreachable -- handle_arc_lookup_action() always exits
    }
    if ($action === 'arc_ioc_add') {
        handle_arc_lookup_add_action();
        return; // unreachable -- handle_arc_lookup_add_action() always exits
    }

    // ── Permission guards ─────────────────────────────────────────────────────
    $action_ops = ['release', 'delete', 'bulk', 'quick_block', 'quick_white', 'arc_ham', 'arc_spam', 'arc_resend'];
    if (in_array($action, $action_ops, true) && !can('action')) {
        header('Location: ?'); exit;
    }
    // The archive learn/resend actions operate on the single global archive
    // mailbox (every domain's mail), so they require archive access too --
    // not just 'action'. Without this a domain_admin (who keeps 'action' but
    // loses 'archive') could arc_resend any archived message to an arbitrary
    // recipient, or arc_spam/arc_ham archived content they can no longer read.
    if (in_array($action, ['arc_ham', 'arc_spam', 'arc_resend'], true) && !can('archive')) {
        header('Location: ?'); exit;
    }
    // Resending pipes the full original message to an arbitrary recipient, so it
    // sits at the archive tier of the content-viewing policy: if you may not read
    // it, you may not remail it. arc_ham/arc_spam are NOT gated -- they only feed
    // Bayes and display nothing.
    if ($action === 'arc_resend' && !qa_view_allowed(true)) {
        // AJAX-only client (arcResend() in views/layout_foot.php) requires a JSON
        // body; a 302 to an HTML page trips its content-type check and surfaces as
        // "network error - check whether the mail was sent", which is both wrong and
        // dangerous advice for a resend. Keep the redirect for a non-AJAX POST, which
        // is what makes the view_policy_denied notice reachable at all.
        if (($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'XMLHttpRequest') {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode([
                'ok' => false, 'outcome' => null,
                'message' => t('A művelet le van tiltva az adatvédelmi beállítás miatt.'),
                'learned_as' => null, 'learned_at' => null,
            ]);
            exit;
        }
        header('Location: ?arc=1&msg=view_policy_denied'); exit;
    }
    if (in_array($action, ['list_add', 'list_remove', 'list_lookup'], true) && !can('lists')) {
        header('Location: ?'); exit;
    }

    if ($action === 'list_lookup') {
        handle_list_lookup_action();
        return; // unreachable -- handle_list_lookup_action() always exits
    }

    // ── Block-/white-list actions ──
    if (in_array($action, ['list_add', 'list_remove'], true)) {
        $which = (($_POST['which'] ?? '') === 'white') ? 'white' : 'block';
        $admin = $_SERVER['REMOTE_USER'] ?? '-';
        $back  = '?' . ($which === 'white' ? 'white' : 'block') . '=1';
        if ($action === 'list_add') {
            $type = (string) ($_POST['b_type'] ?? '');
            $pat  = (string) ($_POST['b_pattern'] ?? '');
            $err  = list_add($which, $type, $pat, $admin);
            if ($err === '') audit_log($which . '-add', strtolower(trim($pat)), $type, '');
            header('Location: ' . $back . ($err === '' ? '&ok=1' : '&err=' . urlencode($err)));
        } else {
            $key = (string) ($_POST['b_key'] ?? '');
            if ($key !== '' && list_remove($which, $key)) audit_log($which . '-remove', $key, '', '');
            header('Location: ' . $back);
        }
        exit;
    }

    // ── Quick block/whitelist a sender from a message row or viewer ──
    if (in_array($action, ['quick_block', 'quick_white'], true)) {
        $which = $action === 'quick_white' ? 'white' : 'block';
        $admin = $_SERVER['REMOTE_USER'] ?? '-';
        $raw   = (string) ($_POST['sender'] ?? '');
        $email = '';
        if (filter_var($raw, FILTER_VALIDATE_EMAIL)) {
            $email = strtolower($raw);
        } elseif (preg_match('/[\w.+\-]+@[\w.\-]+\.[A-Za-z]{2,}/', $raw, $m)) {
            $email = strtolower($m[0]);
        }
        $err = '';
        if ($email !== '') {
            $err = list_add($which, 'address', $email, $admin);
            if ($err === '') audit_log($which . '-add', $email, 'address', '');
        }
        $listed = ($email !== '' && $err === '') ? $which : '';
        $qerr   = ($email !== '' && $err !== '') ? $err : '';
        if (($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'XMLHttpRequest') {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode([
                'ok' => $listed !== '',
                'listed' => $listed !== '' ? $listed : null,
                'message' => $qerr !== '' ? $qerr : ($listed === 'white'
                    ? t('A feladó felkerült a fehérlistára.')
                    : ($listed === 'block' ? t('A feladó felkerült a blokklistára.') : null)),
            ]);
            exit;
        }
        if (($_POST['back'] ?? '') === 'arc') {
            header('Location: ?' . http_build_query(array_filter([
                'arc' => '1', 'listed' => $listed, 'qerr' => $qerr,
                'adomain' => $_POST['af_domain'] ?? '', 'afrom' => $_POST['af_from'] ?? '',
                'ato' => $_POST['af_to'] ?? '', 'asubject' => $_POST['af_subject'] ?? '',
                'astatus' => $_POST['af_status'] ?? '', 'asince' => $_POST['af_since'] ?? '',
                'abefore' => $_POST['af_before'] ?? '', 'page' => $_POST['af_page'] ?? '1',
            ])));
        } else {
            header('Location: ?' . http_build_query(array_filter([
                'quar' => '1', 'search' => '1', 'listed' => $listed, 'qerr' => $qerr,
                'domain' => $_POST['f_domain'] ?? '', 'user' => $_POST['f_user'] ?? '',
                'folder' => $_POST['f_folder'] ?? '', 'since' => $_POST['f_since'] ?? '',
                'before' => $_POST['f_before'] ?? '', 'from' => $_POST['f_from'] ?? '',
                'subject' => $_POST['f_subject'] ?? '',
            ])));
        }
        exit;
    }

    // ── Archive actions: learn spam/ham, or re-send ──
    if (in_array($action, ['arc_spam', 'arc_ham', 'arc_resend'], true)) {
        $uid = $_POST['msg_uid'] ?? '';
        $msg = '';
        $isAjax = ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'XMLHttpRequest';
        $ajaxPayload = ['ok' => false, 'outcome' => null, 'message' => t('Érvénytelen levél.'), 'learned_as' => null, 'learned_at' => null];
        if (valid_uid($uid)) {
            if ($action === 'arc_spam') {
                $outcome = rspamd_learn('spam', ARCHIVE_USER, ARCHIVE_MAILBOX, $uid);
                $learned = null;
                $was_spam = archive_original_is_spam($uid);
                if ($outcome === 'learned') { archive_mark_learned($uid, 'spam'); $learned = ['as' => 'spam', 'at' => time()]; }
                $msg = 'arc_learn_spam_' . $outcome;
                audit_log('arc-spam', ARCHIVE_USER, ARCHIVE_MAILBOX, $uid);
                $ajaxPayload = [
                    'ok' => $outcome !== 'failed', 'outcome' => $outcome, 'message' => arc_learn_message('spam', $outcome),
                    'learned_as' => $learned['as'] ?? null, 'learned_at' => $learned['at'] ?? null, 'was_spam' => $was_spam,
                ];
            } elseif ($action === 'arc_ham') {
                $outcome = rspamd_learn('ham', ARCHIVE_USER, ARCHIVE_MAILBOX, $uid);
                $learned = null;
                $was_spam = archive_original_is_spam($uid);
                if ($outcome === 'learned') { archive_mark_learned($uid, 'ham'); $learned = ['as' => 'ham', 'at' => time()]; }
                $msg = 'arc_learn_ham_' . $outcome;
                audit_log('arc-ham', ARCHIVE_USER, ARCHIVE_MAILBOX, $uid);
                $ajaxPayload = [
                    'ok' => $outcome !== 'failed', 'outcome' => $outcome, 'message' => arc_learn_message('ham', $outcome),
                    'learned_as' => $learned['as'] ?? null, 'learned_at' => $learned['at'] ?? null, 'was_spam' => $was_spam,
                ];
            } else {
                $sent = archive_resend($uid, trim((string)($_POST['recipient'] ?? '')));
                $ajaxPayload = ['ok' => $sent, 'message' => $sent ? t('Levél újraküldve.') : t('Az újraküldés nem sikerült.')];
            }
        }
        if ($isAjax) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode($ajaxPayload);
            exit;
        }
        header('Location: ?' . http_build_query(array_filter([
            'arc' => '1',
            'msg'      => $msg,
            'adomain'  => $_POST['af_domain']  ?? '',
            'afrom'    => $_POST['af_from']    ?? '', 'ato'     => $_POST['af_to']     ?? '',
            'asubject' => $_POST['af_subject'] ?? '', 'astatus' => $_POST['af_status'] ?? '',
            'asince'   => $_POST['af_since']   ?? '', 'abefore' => $_POST['af_before'] ?? '',
            'page'     => $_POST['af_page']    ?? '1',
        ])));
        exit;
    }

    if (in_array($action, ['release', 'delete'], true)) {
        $user   = $_POST['msg_user']   ?? '';
        $folder = $_POST['msg_folder'] ?? '';
        $uid    = $_POST['msg_uid']    ?? '';
        if (valid_user($user) && valid_folder($folder) && valid_uid($uid)
            && qa_domain_allowed($user)) {
            $ok = $action === 'release' ? do_release($user, $folder, $uid)
                                        : do_delete($user, $folder, $uid);
            $_GET['op']   = $action;
            $_GET['done'] = $ok ? '1' : '0';
            $_GET['fail'] = $ok ? '0' : '1';
        }
    }

    if ($action === 'bulk') {
        $bulk   = $_POST['bulk_action'] ?? '';
        $items  = $_POST['items'] ?? [];
        $n_ok = 0; $n_fail = 0;
        if (in_array($bulk, ['release', 'delete'], true) && is_array($items)) {
            foreach ($items as $item) {
                $parts = explode('|', $item);
                if (count($parts) === 3) {
                    [$u, $f, $uid] = $parts;
                    if (valid_user($u) && valid_folder($f) && valid_uid($uid)
                        && qa_domain_allowed($u)) {
                        $r = $bulk === 'release' ? do_release($u, $f, $uid)
                                                 : do_delete($u, $f, $uid);
                        $r ? $n_ok++ : $n_fail++;
                    } else {
                        $n_fail++;   // rejected by validation or domain scope
                    }
                }
            }
            $_GET['op']   = $bulk;
            $_GET['done']  = (string) $n_ok;
            $_GET['fail']  = (string) $n_fail;
        }
    }

    // PRG: redirect back preserving GET filters
    $qs = http_build_query(array_filter([
        'domain'  => $_POST['f_domain']  ?? '',
        'user'    => $_POST['f_user']    ?? '',
        'folder'  => $_POST['f_folder']  ?? '',
        'since'   => $_POST['f_since']   ?? '',
        'before'  => $_POST['f_before']  ?? '',
        'from'    => $_POST['f_from']    ?? '',
        'subject' => $_POST['f_subject'] ?? '',
        'search'  => '1',
        'quar'    => '1',
        // Outcome of the operation just performed, so the page can say what
        // actually happened rather than silently re-rendering the list.
        'op'      => $_GET['op']   ?? '',
        'done'    => $_GET['done'] ?? '',
        'fail'    => $_GET['fail'] ?? '',
    ], fn($v) => $v !== '' && $v !== null));
    header('Location: ?' . $qs);
    exit;
}

// CSV export (read-only). UTF-8 BOM so Excel shows Hungarian.
function handle_export(): void {
    $type  = $_GET['export'] ?? '';
    // Direct endpoint: enforce the same permission the UI button implies.
    $need  = in_array($type, ['audit', 'ioc_hashes', 'user_logins',
                               'admin_logins', 'admin_login_failures', 'mail_auth_failures'], true)
           ? 'admin' : 'archive';
    if (!can($need)) { http_response_code(403); exit("403 Forbidden\n"); }
    // The archive CSV emits sender/recipient/subject for up to 10,000 messages --
    // a larger disclosure than opening one message, so it needs the top policy
    // tier. audit (admin-action records), ioc_hashes (SHA256 values) and the
    // four Bejelentkezések lists (usernames/IPs/timestamps, no message
    // metadata) are deliberately NOT gated here.
    if ($type === 'archive' && !qa_view_allowed(true)) {
        http_response_code(403); exit("403 Forbidden\n");
    }
    $today = date('Y-m-d');
    $emit  = function (string $name, array $head, array $rows) {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $name . '"');
        $out = fopen('php://output', 'w');
        fwrite($out, "\xEF\xBB\xBF");   // UTF-8 BOM
        fputcsv($out, $head);
        foreach ($rows as $row) fputcsv($out, $row);
        fclose($out);
        exit;
    };

    if ($type === 'archive') {
        [$rows] = archive_search(parse_af(), 1, 10000);
        $emit('archivum_' . $today . '.csv',
            // Country/IP sit between subject and score, matching the on-screen
            // column order. Exported as the raw code plus the IP it came from,
            // not the flag glyph: a CSV lands in a spreadsheet, where "DE" is
            // filterable and an emoji is not.
            [t('Idő'), t('Feladó'), t('Címzett'), t('Tárgy'), t('Ország'), 'IP', 'Pont', t('Állapot')],
            array_map(fn($r) => [
                date('Y-m-d H:i', (int)$r['ts']), $r['from_addr'], $r['to_addr'], $r['subject'],
                $r['sender_cc'] ?? '', $r['sender_ip'] ?? '',
                $r['rspamd_score'] === null ? '' : round((float)$r['rspamd_score'], 2),
                $r['is_spam'] ? 'spam' : 'ham',
            ], $rows));
    }
    if ($type === 'audit') {
        [$rows] = audit_ops_all();
        $emit('audit_' . $today . '.csv',
            [t('Idő'), t('Művelet'), t('Felhasználó'), 'Mappa', 'UID', 'Admin', 'IP'],
            array_map(fn($r) => [
                date('Y-m-d H:i:s', (int)$r['ts']), $r['action'], $r['user'],
                $r['folder'], $r['uid'], $r['admin'], $r['ip'],
            ], $rows));
    }
    if ($type === 'ioc_hashes') {
        $emit('ioc_hashes_' . $today . '.csv', ['sha256'],
            array_map(fn($h) => [$h], ioc_export_hashes_csv()));
    }
    if ($type === 'user_logins') {
        $rows = [];
        $db = audit_db();
        if ($db) {
            try {
                $rows = $db->query(
                    'SELECT username, last_login FROM last_login ORDER BY last_login DESC'
                )->fetchAll(PDO::FETCH_ASSOC);
            } catch (Throwable $e) { /* emit whatever we have -- empty is a valid CSV */ }
        }
        $emit('utolso_belepesek_' . $today . '.csv',
            [t('Felhasználó'), t('Utolsó bejelentkezés')],
            array_map(fn($r) => [$r['username'], date('Y-m-d H:i:s', (int)$r['last_login'])], $rows));
    }
    // Same "raw code, not the flag glyph" reasoning as the archive export
    // above: a spreadsheet filters on "IE", not an <img>. 2000 caps the same
    // way archive's 10,000 does -- generous, not literally unbounded.
    if ($type === 'admin_logins') {
        $rows = admin_logins(2000);
        $emit('admin_belepesek_' . $today . '.csv',
            [t('Belépés'), 'Admin', t('Forrás IP'), t('Ország'), t('Kérések')],
            array_map(fn($s) => [
                date('Y-m-d H:i:s', $s['start']), $s['user'], $s['ip'], qa_ip_country($s['ip']), $s['hits'],
            ], $rows));
    }
    if ($type === 'admin_login_failures') {
        $rows = admin_login_failures(2000);
        $emit('admin_sikertelen_' . $today . '.csv',
            [t('Időpont'), t('Megadott felhasználó'), t('Forrás IP'), t('Ország'), t('Ok')],
            array_map(fn($f) => [
                date('Y-m-d H:i:s', $f['ts']), $f['user'], $f['ip'], qa_ip_country($f['ip']), $f['reason'],
            ], $rows));
    }
    if ($type === 'mail_auth_failures') {
        $rows = mail_auth_failures(2000);
        $emit('mail_sikertelen_' . $today . '.csv',
            [t('Időpont'), t('Felhasználó'), t('Forrás IP'), t('Ország'), t('Forrás')],
            array_map(fn($f) => [
                date('Y-m-d H:i:s', $f['ts']), $f['user'], $f['ip'], qa_ip_country($f['ip']), $f['source'],
            ], $rows));
    }
    header('Location: ?');
    exit;
}
