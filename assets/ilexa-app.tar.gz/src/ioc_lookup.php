<?php
// On-demand reputation lookups for IOC-store entries (VirusTotal, URLhaus, ThreatFox, etc.)
// Informational only: a verdict is displayed, never written back into
// iocs.confidence/tags. Every external call goes through the root-owned
// install/qa-ioc-lookup.sh via sudo -- this module never talks to VT/
// URLhaus directly, and never sees either service's API key.
//
// Which services support which IOC type is fixed (VT: ip/domain/url/hash;
// URLhaus: domain/url/hash) -- what IS admin-configurable is whether each
// service is used at all, via qa-ioclookup-config.sh (Admin tab). A
// disabled service is filtered out of ioc_lookup_services_for()'s results,
// so its button/badge simply doesn't appear on the IOC page.

const IOC_LOOKUP_TTL = 86400; // 24h

// Aggregate confidence from the cached per-service verdicts, weighted by
// source reliability. Pure computation over ioc_lookup_cached()'s existing
// data -- no new fetch, no new schema, no new persistence. Returns null
// when no service has returned a real verdict yet (malicious/suspicious/
// clean); 'unknown' and absent services never contribute either way.
const IOC_CONFIDENCE_WEIGHTS = [
    'virustotal' => 40,
    'mailspike'  => 40,
    'urlhaus'    => 30,
    'otx'        => 20,
    'hrbl'       => 10,
    // Named YARA rule matches on a known sample are strong, specific evidence
    // -- weighted with urlhaus rather than virustotal because, like urlhaus,
    // it reports "this exact artefact is known bad" rather than aggregating
    // many engines' opinions.
    'yaraify'    => 30,
    // Same reasoning as urlhaus/yaraify: a ThreatFox hit is a specific,
    // attributed indicator (malware family + submitter confidence), not an
    // aggregated multi-engine score, so it gets the same tier rather than
    // OTX's lower weight. qa-ioc-lookup.sh already downgrades a low-confidence
    // hit (<50) to 'suspicious', which this weighting table halves anyway.
    'threatfox'  => 30,
];

// Verdict -> SVG symbol id. Single source of truth: views/ioc.php,
// views/lists.php and views/quarantine.php read this directly, and
// views/layout_foot.php emits it to JS via json_encode so the client map is
// generated from this one rather than retyped. Before consolidation the same
// four pairs were written out nine times (three PHP arrays, three JS objects,
// three hardcoded legends), and the two render paths for a single row -- the
// server one on page load, the AJAX one after a check -- read different
// copies. Anything not in this map falls back to 'icon-info'.
//
// The three legend loops (views/ioc.php, views/lists.php, views/quarantine.php)
// iterate this map but look up their labels in a separate, locally-defined
// $*_legend_labels array in each of those three views -- adding a verdict
// here does NOT add its label. Add it in all three views too, or the legend
// entry renders unlabeled (the label lookup falls back to the raw key).
const QA_VERDICT_ICON = [
    'malicious'  => 'icon-x',
    'suspicious' => 'icon-warning',
    'clean'      => 'icon-check',
    'unknown'    => 'icon-info',
];

function ioc_lookup_confidence(array $cached): ?array {
    $positive = 0.0;
    $negative = 0.0;
    foreach ($cached as $service => $lk) {
        $weight = IOC_CONFIDENCE_WEIGHTS[$service] ?? 0;
        if ($weight === 0) continue;
        switch ($lk['verdict']) {
            case 'malicious':  $positive += $weight;      break;
            case 'suspicious': $positive += $weight / 2;  break;
            case 'clean':      $negative += $weight;      break;
            // 'unknown': contributes nothing
        }
    }
    $total = $positive + $negative;
    if ($total <= 0) return null;

    $pct = (int)round(100 * $positive / $total);
    $tier = $pct >= 80 ? 'high' : ($pct >= 50 ? 'medium' : 'low');
    return ['pct' => $pct, 'tier' => $tier];
}

const IOC_LOOKUP_SERVICE_TYPES = [
    'virustotal' => ['ip', 'domain', 'url', 'hash'],
    'urlhaus'    => ['domain', 'url', 'hash'],
    'otx'        => ['ip', 'domain', 'url', 'hash'],
    'hrbl'       => ['ip', 'domain'],
    'mailspike'  => ['ip'],
    'urlvet'     => ['url', 'domain'],
    'yaraify'    => ['hash'],
    'threatfox'  => ['ip', 'domain', 'url', 'hash'],
];

// Which surfaces a service participates in. A service ABSENT from this map
// runs on EVERY surface -- that is the default, and it is why the five
// reputation services are not listed here. Only add a service to RESTRICT
// it.
//
// url.vet is restricted because it is a structural scorer with a ~31s worst
// case on non-resolving domains (which it does not cache), and the list
// pages render many rows of entries an operator has already decided about.
// See docs/superpowers/specs/2026-08-15-urlvet-surface-scoping-design.md.
const IOC_LOOKUP_SERVICE_SURFACES = [
    'urlvet' => ['ioc', 'quarantine'],
];

// Per-surface timeout override in seconds, passed to qa-ioc-lookup.sh as its
// 4th argument. Absent => the script's own default for that service.
//
// A service listed here for a surface is ALSO best-effort on that surface:
// lookup_run_value() drops its errors instead of surfacing them, because we
// deliberately gave it a budget it will often miss and a predictable error
// on every row would just train operators to ignore the error channel.
const IOC_LOOKUP_SERVICE_TIMEOUTS = [
    'urlvet' => ['quarantine' => 6],
];

// null => no override; the shell script uses its own per-service default.
function ioc_lookup_timeout_for(string $service, string $surface): ?int {
    return IOC_LOOKUP_SERVICE_TIMEOUTS[$service][$surface] ?? null;
}

// Memoized per service for the lifetime of the request: views/ioc.php calls
// this once per IOC row, so without memoization a 25-row page would shell
// out to sudo up to 50 times. Each service is looked up at most once per
// request; a toggle via the Admin tab takes effect on the next request
// (POST+redirect starts a fresh PHP process with an empty $memo).
function ioc_lookup_service_enabled(string $service): bool {
    static $memo = [];
    if (isset($memo[$service])) return $memo[$service];
    $cmd = SUDO . ' /usr/local/sbin/qa-ioclookup-config.sh is-enabled '
         . escapeshellarg($service) . ' >/dev/null 2>&1';
    exec($cmd, $out, $rc);
    return $memo[$service] = ($rc === 0);
}

function ioc_lookup_services_for(string $type, string $surface = 'ioc'): array {
    $out = [];
    foreach (IOC_LOOKUP_SERVICE_TYPES as $service => $types) {
        if (!in_array($type, $types, true)) continue;
        // Absent from the surfaces map => runs everywhere.
        $surfaces = IOC_LOOKUP_SERVICE_SURFACES[$service] ?? null;
        if ($surfaces !== null && !in_array($surface, $surfaces, true)) continue;
        if (!ioc_lookup_service_enabled($service)) continue;
        $out[] = $service;
    }
    return $out;
}

// Existing cached rows for one IOC, keyed by service name.
function ioc_lookup_cached(int $iocId): array {
    try {
        $stmt = _ioc_db()->prepare(
            'SELECT service, verdict, detail, checked_at FROM ioc_lookups WHERE ioc_id = :id');
        $stmt->execute([':id' => $iocId]);
        $out = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $out[$row['service']] = $row;
        }
        return $out;
    } catch (Throwable $e) {
        return [];
    }
}

// Shells out to the root-owned lookup helper via sudo. Returns
// [bool $ok, string $err, ?array $data]; $data on success is
// ['verdict' => ..., 'detail' => ..., 'raw' => ...] (raw may be any JSON
// value the service returned, opaque to this function).
function _ioc_lookup_call(string $service, string $type, string $value, ?int $timeout = null): array {
    $cmd = SUDO . ' ' . QA_IOC_LOOKUP . ' ' . escapeshellarg($service) . ' '
         . escapeshellarg($type) . ' ' . escapeshellarg($value);
    // Optional per-surface budget. escapeshellarg on an int is belt-and-braces:
    // the value comes from IOC_LOOKUP_SERVICE_TIMEOUTS, never from a request.
    if ($timeout !== null) $cmd .= ' ' . escapeshellarg((string)$timeout);
    // urlvet needs up to URLVET_TIMEOUT=35s for a non-resolving domain (the
    // API does not cache incomplete analyses, so a shorter budget fails
    // permanently rather than costing a retry). set_time_limit() RESTARTS
    // PHP's counter, so calling it per service gives each one its own
    // allowance instead of making the whole sequential loop share one.
    //
    // NOTE on the ceiling this guards against: /etc/php.ini declares
    // max_execution_time TWICE (30 in the main block, 300 further down) and
    // last-wins, so the effective FPM value here is 300 -- not the 30 an
    // earlier version of this comment claimed. This call is therefore
    // defensive rather than strictly required today: it makes the per-lookup
    // budget explicit and survives someone later "fixing" that duplicate
    // down to 30. The real ceiling on a whole request is the web server's
    // proxy timeout (Apache's default 60s), which set_time_limit cannot
    // raise -- so keep the per-call value at or below it.
    // Suppressed because it is a no-op (and warns) where PHP runs with a
    // hard limit it may not raise.
    @set_time_limit(60);
    $json = shell_exec($cmd);
    $data = $json !== null ? json_decode($json, true) : null;

    if (!is_array($data)) {
        return [false, t('Nem sikerült elérni a szolgáltatást.'), null];
    }
    if (isset($data['error'])) {
        return [false, (string)$data['error'], null];
    }
    if (!isset($data['verdict'])) {
        return [false, t('Érvénytelen válasz a szolgáltatástól.'), null];
    }
    return [true, '', $data];
}

// Orchestrates a lookup across every service applicable to this IOC's type:
// serves a cached row if it's within IOC_LOOKUP_TTL, otherwise calls
// $caller (defaults to _ioc_lookup_call, overridable for offline testing)
// and upserts the result. On a per-service failure, falls back to that
// service's last-good cached row (if any) rather than clearing it -- a
// failed re-check degrades to "last known good", it never blanks a badge
// that previously had a result. Failures are never persisted to
// ioc_lookups; only successful lookups are written.
function ioc_lookup_run(int $iocId, ?callable $caller = null): array {
    $caller = $caller ?? '_ioc_lookup_call';
    $ioc = ioc_get($iocId);
    if ($ioc === null) {
        return ['results' => [], 'errors' => ['_' => t('Ismeretlen indikátor.')]];
    }

    $cached  = ioc_lookup_cached($iocId);
    $results = [];
    $errors  = [];
    $now     = time();

    foreach (ioc_lookup_services_for($ioc['type'], 'ioc') as $service) {
        $have = $cached[$service] ?? null;
        if ($have !== null && ($now - (int)$have['checked_at']) < IOC_LOOKUP_TTL) {
            $results[$service] = $have;
            continue;
        }

        // Same best-effort rule lookup_run_value() applies: a per-surface
        // timeout override means we knowingly gave this service a budget it
        // will often miss, so its failure is an expected outcome and not
        // something to report. No 'ioc' override exists today, so this is
        // currently a no-op -- it is here because the rule is stated as
        // universal on IOC_LOOKUP_SERVICE_TIMEOUTS above, and an invariant
        // honoured by only one of its two implementations is a trap for
        // whoever adds the first one.
        $timeout    = ioc_lookup_timeout_for($service, 'ioc');
        $bestEffort = $timeout !== null;

        [$ok, $err, $data] = $caller($service, $ioc['type'], $ioc['value'], $timeout);
        if (!$ok) {
            if (!$bestEffort) $errors[$service] = $err;
            if ($have !== null) $results[$service] = $have;
            continue;
        }

        $verdict = in_array($data['verdict'], ['malicious', 'suspicious', 'clean', 'unknown'], true)
                 ? $data['verdict'] : 'unknown';
        $detail = mb_substr((string)($data['detail'] ?? ''), 0, 200);

        try {
            $stmt = _ioc_db()->prepare(
                'INSERT INTO ioc_lookups (ioc_id, service, verdict, detail, raw_json, checked_at)
                 VALUES (:ioc_id, :service, :verdict, :detail, :raw_json, :checked_at)
                 ON CONFLICT(ioc_id, service) DO UPDATE SET
                    verdict = :verdict, detail = :detail, raw_json = :raw_json, checked_at = :checked_at'
            );
            $stmt->execute([
                ':ioc_id' => $iocId, ':service' => $service, ':verdict' => $verdict,
                ':detail' => $detail, ':raw_json' => json_encode($data['raw'] ?? null),
                ':checked_at' => $now,
            ]);
        } catch (Throwable $e) {
            $errors[$service] = t('Adatbázis hiba.');
            if ($have !== null) $results[$service] = $have;
            continue;
        }

        $results[$service] = ['service' => $service, 'verdict' => $verdict,
                               'detail' => $detail, 'checked_at' => $now];
    }

    return ['results' => $results, 'errors' => $errors];
}
