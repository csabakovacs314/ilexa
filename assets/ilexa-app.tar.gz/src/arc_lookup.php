<?php
// Immediate, automatic reputation check for one archived message
// ("IOC ellenőrzés" button, Archívum tab). Reuses ioc_extract_candidates()
// (src/ioc.php) for the same sender-IP/from-domain/URL/attachment-hash
// extraction the manual curation flow already does, but instead of staging
// candidates for an admin to review and add to the permanent IOC store, it
// runs each one straight through the shared list_lookups reputation cache
// (src/list_lookup.php) and returns a verdict for an immediate popup.
// Nothing here writes to iocs.db -- only the existing 24h reputation cache
// the IOC/Lists/Quarantine pages already share.

// A message's candidate count is unbounded (URLs, attachments), unlike
// src/quar_lookup.php's fixed two indicators (domain + IP). That function's
// own comment documents an accepted cold-worst-case of ~5 services x 15s
// PER indicator (views/layout_foot.php's quar-lookup-btn handler) as
// tolerable for two indicators; left uncapped here, a link-heavy newsletter
// could turn that into many minutes behind a single click. Capping the
// url/hash candidates (ip/domain are always at most one each) keeps the
// worst case in the same ballpark already accepted for that button.
const ARC_LOOKUP_MAX_EXTRA = 3;

// Candidate list for the automatic check: ioc_extract_candidates()'s full
// set, minus a From-domain that is one of this server's own hosted domains
// (mirrors quar_row_indicators()'s 'local' skip in src/quar_lookup.php --
// spam routinely forges From: to a locally hosted domain, and checking our
// own domain's reputation is never useful), capped per ARC_LOOKUP_MAX_EXTRA
// above.
function arc_lookup_candidates(array $parsed): array {
    $all    = ioc_extract_candidates($parsed);
    $ipDom  = array_values(array_filter($all, fn($c) => in_array($c['type'], ['ip', 'domain'], true)));
    $extra  = array_values(array_filter($all, fn($c) => in_array($c['type'], ['url', 'hash'], true)));

    $localDomains = array_map('strtolower', get_domains());
    $ipDom = array_values(array_filter($ipDom, function ($c) use ($localDomains) {
        return $c['type'] !== 'domain' || !in_array(strtolower($c['value']), $localDomains, true);
    }));

    return array_merge($ipDom, array_slice($extra, 0, ARC_LOOKUP_MAX_EXTRA));
}

// Mirrors handle_quar_lookup_action()'s AJAX/JSON contract (src/quar_lookup.php)
// applied to an archived message's full candidate set instead of two fixed
// indicators.
//
// $caller is a test-only seam, never populated from request input -- see
// handle_quar_lookup_action()'s identical comment for why.
function handle_arc_lookup_action(?callable $caller = null): void {
    $isAjax = ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'XMLHttpRequest';

    $deny = function (string $msg, ?int $status = null) use ($isAjax): void {
        if ($isAjax) {
            header('Content-Type: application/json; charset=utf-8');
            if ($status !== null) http_response_code($status);
            echo json_encode(['ok' => false, 'candidates' => [], 'confidence' => null, 'errors' => ['_' => $msg]]);
            exit;
        }
        header('Location: ?arc=1'); exit;
    };

    // Same authorization level as the button this replaces (the archive
    // row's "IOC" extract-to-review button, formerly gated on can('admin')
    // alone in views/archive.php) -- every role with can('admin') also
    // carries 'archive' (src/rbac.php ROLE_PERMS), so this stays consistent
    // with that precedent rather than introducing a new permission tier.
    if (!can('admin')) { $deny(t('Nincs jogosultság ehhez a művelethez.'), 403); return; }

    // Reading message content is gated the same way viewing/resending it
    // already is (GDPR content-view policy) -- extracting indicators from a
    // body/attachment IS reading the content.
    if (!qa_view_allowed(true)) { $deny(t('A művelet le van tiltva az adatvédelmi beállítás miatt.'), 403); return; }

    $uid = (string) ($_POST['msg_uid'] ?? '');
    if (!valid_uid($uid)) { $deny(t('Érvénytelen paraméterek')); return; }

    $cmd = SUDO . ' ' . QA_DOVEADM . ' fetch-text ' . escapeshellarg(ARCHIVE_USER)
         . ' ' . escapeshellarg(ARCHIVE_MAILBOX) . ' ' . escapeshellarg($uid)
         . ' 2>/dev/null | ' . PYTHON3 . ' ' . escapeshellarg(PARSE_EMAIL_PY);
    $json   = shell_exec($cmd);
    $parsed = $json ? json_decode($json, true) : null;
    if (!is_array($parsed) || isset($parsed['error'])) {
        $deny(t('Nem sikerült feldolgozni az üzenetet indikátor-kinyeréshez.')); return;
    }

    $candidates = arc_lookup_candidates($parsed);
    if (!$candidates) {
        $deny(t('Ehhez a levélhez nincs ellenőrizhető adat.')); return;
    }

    $out  = [];
    $best = null;
    foreach ($candidates as $cand) {
        $r    = lookup_run_value($cand['type'], $cand['value'], $caller, 'archive');
        $conf = ioc_lookup_confidence($r['results']);
        $out[] = [
            'type' => $cand['type'], 'value' => $cand['value'],
            'results' => $r['results'], 'errors' => $r['errors'], 'confidence' => $conf,
        ];
        if ($conf !== null && ($best === null || $conf['pct'] > $best['pct'])) {
            $best = $conf;
        }
    }

    audit_log('arc-ioc-check', ARCHIVE_USER, ARCHIVE_MAILBOX, $uid);

    // Held for handle_arc_lookup_add_action() below: the popup's "Add &
    // activate" button picks candidates by index, mirroring ioc_confirm's
    // session-held-candidates pattern (src/ioc.php) rather than trusting a
    // type/value pair the client sends back directly -- keeps this action's
    // trust surface identical to the existing extract-to-review flow it
    // replaces, even though can('admin') already has unrestricted ioc_add
    // via the IOC tab's own manual-add form.
    $_SESSION['arc_ioc_check'] = ['uid' => $uid, 'candidates' => $out];

    $result = ['ok' => true, 'candidates' => $out, 'confidence' => $best, 'errors' => []];
    if ($isAjax) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($result);
        exit;
    }
    header('Location: ?arc=1'); exit;
}

// The popup's "Hozzáadás és élesítés" (Add & activate) button: adds the
// admin's checked candidates from the just-run check (held in
// $_SESSION['arc_ioc_check']) to the permanent IOC store, then immediately
// promotes each one added -- ip goes on the live admin block list, domain/
// url goes into the compiled block-hosts map (ioc_promote(), src/ioc.php).
// This is the one part of the popup that reaches beyond the read-only
// reputation cache: it creates real, immediately-enforced mail rejection,
// so it stays behind an explicit admin click on explicitly checked rows --
// never auto-fired by the check itself.
function handle_arc_lookup_add_action(): void {
    $isAjax = ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'XMLHttpRequest';

    $deny = function (string $msg, ?int $status = null) use ($isAjax): void {
        if ($isAjax) {
            header('Content-Type: application/json; charset=utf-8');
            if ($status !== null) http_response_code($status);
            echo json_encode(['ok' => false, 'added' => 0, 'promoted' => 0, 'errors' => ['_' => $msg]]);
            exit;
        }
        header('Location: ?arc=1'); exit;
    };

    if (!can('admin')) { $deny(t('Nincs jogosultság ehhez a művelethez.'), 403); return; }

    $uid    = (string) ($_POST['msg_uid'] ?? '');
    $picked = $_POST['ioc_pick'] ?? [];
    $review = $_SESSION['arc_ioc_check'] ?? null;

    // The stored review must belong to THIS message: a stale or
    // cross-message session (e.g. the admin ran a check on a different row
    // in another tab after opening this popup) must never let a pick index
    // resolve against the wrong message's candidates.
    if (!is_array($review) || (string) ($review['uid'] ?? '') !== $uid) {
        $deny(t('A jelölés lejárt, indítsd újra az ellenőrzést.')); return;
    }
    if (!is_array($picked) || !$picked) {
        $deny(t('Nincs kijelölt indikátor.')); return;
    }

    $added = 0; $promoted = 0; $errors = [];
    foreach ($picked as $idxRaw) {
        $idx = (int) $idxRaw;
        if (!isset($review['candidates'][$idx])) continue;
        $cand = $review['candidates'][$idx];

        // Derive the stored confidence level from this candidate's OWN
        // computed reputation tier (high/medium/low -- the exact same
        // vocabulary IOC_CONFIDENCE_LEVELS uses) when the check produced
        // one, falling back to 'medium' the same way ioc_confirm() does
        // when no admin-chosen level exists.
        $level = $cand['confidence']['tier'] ?? 'medium';

        [$ok, $err, $id] = ioc_add([
            'type' => $cand['type'], 'value' => $cand['value'],
            'source' => 'archive-ioc-check', 'confidence' => $level,
            'added_by' => qa_user(), 'source_ref' => $uid,
        ]);
        if (!$ok) { $errors[] = $cand['value'] . ': ' . $err; continue; }
        $added++;

        [$pok, $perr] = ioc_promote((int) $id);
        if ($pok) { $promoted++; } else { $errors[] = $cand['value'] . ': ' . $perr; }
    }

    if ($added > 0)    audit_log('arc-ioc-add',     ARCHIVE_USER, ARCHIVE_MAILBOX, $uid . ':' . $added);
    if ($promoted > 0) audit_log('arc-ioc-promote',  ARCHIVE_USER, ARCHIVE_MAILBOX, $uid . ':' . $promoted);

    $result = ['ok' => $added > 0, 'added' => $added, 'promoted' => $promoted, 'errors' => $errors];
    if ($isAjax) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($result);
        exit;
    }
    header('Location: ?arc=1'); exit;
}
