<?php
/**
 * Translation.
 *
 * Hungarian is the source language: the key IS the Hungarian string, so an
 * untranslated string renders as Hungarian rather than as a bare key slug,
 * and there is no separate hu.php to keep in sync.
 *
 *   t('Felhasználó')                        → 'User' when the language is en
 *   sprintf(t('%s levél'), $n)              → interpolation stays outside the key
 *   h(t('Törlés'))                          → t() returns raw text; h() escapes it
 *
 * HTML entities (&mdash;, &#10003;) belong in the template, never inside a
 * translation value.
 *
 * The language is site-wide, stored in its own file because the settings
 * store (admin_settings_save) is integer-only by contract.
 */

// The language the literals in this codebase are WRITTEN in. t() short-circuits
// when the active language equals it, so this is a statement of fact about the
// source, not a preference -- changing it to 'en' would make every page render
// the untranslated Hungarian source strings.
const LANG_DEFAULT = 'hu';

// What a console with no language file on disk shows. Distinct from
// LANG_DEFAULT on purpose: a fresh or upgraded host that has never had a
// language chosen came up Hungarian, which is wrong for everyone who is not
// this project's original operator. The installer seeds the file from the
// wizard (whose own default is already 'en'), so this only governs hosts where
// that file is missing -- upgrades from before it existed, and any install
// where seeding did not happen.
const LANG_FALLBACK = 'en';

// Every lang/<code>.php returns ['_name' => 'Display Name', ...]. A file
// without a usable _name is silently skipped, not a fatal error -- matches
// t()'s own missing-key fallback philosophy elsewhere in this file. Also
// protected against parse errors: PHP 7+ promotes a syntax error in an
// included file to a catchable ParseError (extends Throwable), so a
// malformed language file is caught and skipped, not a fatal. Falls back to
// a hardcoded Hungarian entry if the scan finds nothing at all for
// LANG_DEFAULT, so the selector is never empty even if lang/hu.php is
// somehow missing or broken.
function available_languages(): array {
    static $langs = null;
    if ($langs !== null) return $langs;
    $langs = [];
    foreach (glob(dirname(__DIR__) . '/lang/*.php') as $f) {
        $code = basename($f, '.php');
        try {
            $data = @include $f;
            if (is_array($data) && isset($data['_name']) && $data['_name'] !== '') {
                $langs[$code] = (string) $data['_name'];
            }
        } catch (\Throwable $e) {
            // Silently skip malformed language files (including parse errors)
            // so a broken lang/*.php doesn't crash every admin page.
        }
    }
    if (!isset($langs[LANG_DEFAULT])) $langs[LANG_DEFAULT] = 'Magyar';
    ksort($langs);
    return $langs;
}

function lang_file(): string {
    return dirname(SETTINGS_FILE) . '/language';
}

// Active language: whatever is on disk, falling back to Hungarian.
function qa_lang(): string {
    static $lang = null;
    if ($lang !== null) return $lang;
    $lang = LANG_FALLBACK;
    $f = lang_file();
    if (is_file($f)) {
        $v = strtolower(trim((string)@file_get_contents($f)));
        if (isset(available_languages()[$v])) $lang = $v;
    }
    return $lang;
}

function qa_lang_set(string $lang): array {
    if (!isset(available_languages()[$lang])) return [false, t('Ismeretlen nyelv.')];
    $ok = qa_atomic_write(lang_file(), $lang);
    return [$ok, $ok ? '' : t('Nem sikerült írni: ') . lang_file()];
}

// Translate. Hungarian is the source, so it is returned untouched.
function t(string $s): string {
    static $map = null;
    if (qa_lang() === LANG_DEFAULT) return $s;
    if ($map === null) {
        $f   = dirname(__DIR__) . '/lang/' . qa_lang() . '.php';
        $map = is_file($f) ? (require $f) : [];
        if (!is_array($map)) $map = [];
    }
    return $map[$s] ?? $s;
}

// Locale-aware integer formatting: Hungarian groups with a space and uses a
// comma for decimals; English groups with a comma.
function n_fmt(int|float $n): string {
    return qa_lang() === 'hu'
        ? number_format((float)$n, 0, ',', ' ')
        : number_format((float)$n, 0, '.', ',');
}
