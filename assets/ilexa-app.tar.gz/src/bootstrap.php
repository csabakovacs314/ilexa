<?php
// Load site config and define global constants, then pull in all modules.
$cfg = require dirname(__DIR__) . '/config.php';

// Merge runtime overrides from the admin UI (settings.json).
// Whitelist-only: only known numeric settings can override config.php values,
// preventing untrusted keys from reaching shell-interpolated constants.
$_sf = $cfg['settings_file'] ?? '/var/cache/quarantine-admin/settings.json';
if (is_file($_sf) && is_readable($_sf)) {
    $_ov = json_decode(file_get_contents($_sf), true);
    if (is_array($_ov)) {
        foreach (['per_page', 'user_cache_ttl', 'admin_session_gap'] as $_k) {
            if (isset($_ov[$_k]) && is_int($_ov[$_k])) $cfg[$_k] = $_ov[$_k];
        }
    }
}
unset($_sf, $_ov, $_k);

date_default_timezone_set($cfg['timezone']);

define('DOVEADM',           $cfg['doveadm']);
define('QA_DOVEADM',        $cfg['qa_doveadm'] ?? '/usr/local/sbin/qa-doveadm.sh');
define('QA_IOC_LOOKUP',     $cfg['qa_ioc_lookup'] ?? '/usr/local/sbin/qa-ioc-lookup.sh');
// Sidebar link to PostfixAdmin (mailbox/domain management). Set to '' to hide
// the menu entry entirely -- PostfixAdmin is a separate application and is not
// present on every deployment, so a hardcoded link would be a dead end there.
define('POSTFIXADMIN_URL',  $cfg['postfixadmin_url'] ?? '/postfixadmin/');
// Roundcube's own userlogins.log carries the real browser-side client IP for
// a failed webmail login -- Dovecot only ever sees Roundcube's own loopback
// connection for the same event (see mail_auth_failures(), src/audit.php).
// Set to '' to skip this source entirely on a deployment without Roundcube.
define('ROUNDCUBE_LOG_DIR', $cfg['roundcube_log_dir'] ?? '/var/www/html/roundcube/logs');
define('SUDO',              $cfg['sudo']);
define('RSPAMC',            $cfg['rspamc']);
define('SENDMAIL',          $cfg['sendmail']);
define('PYTHON3',           $cfg['python3']);
define('RSPAMD_CTRL',       $cfg['rspamd_ctrl']);
define('FOLDERS',           array_merge($cfg['quarantine_folders'], ['all', 'both']));
define('ARCHIVE_USER',      $cfg['archive_user']);
define('ARCHIVE_MAILBOX',   $cfg['archive_mailbox']);
define('ARCHIVE_DA_OPTS',   $cfg['archive_da_opts']);
define('POSTMASTER_FROM',   $cfg['postmaster_from']);
define('LEARN_LOG',         $cfg['learn_log']);
define('AUDIT_LOG',         $cfg['audit_log']);
define('LEARN_FLAG',        $cfg['learn_flag']);
// Defaulted, like UPDATE_APPLY_ENABLED below and UNLIKE the older keys above:
// a one-click update replaces the app tree but NEVER config.php (excluded from
// every bundle -- it holds the real DB password), so a host updated from a
// release that predates this key keeps its old config.php and would hit an
// undefined-key warning here, leaving the constant null. Every NEW config key
// must carry its own default for exactly this reason; the keys above predate
// the self-update path and are present in every config.php that has ever
// existed, which is the only reason they can get away with a bare read.
define('UPDATE_CHECK_OFF',  $cfg['update_check_off_flag'] ?? '/var/cache/quarantine-admin/update_check.disabled');
// Root-editable kill switch, config.php only -- not exposed in the UI. No
// RBAC tier exists above 'admin' for something as consequential as applying
// a self-update, so this is the cheap extra safety net: a host can disable
// one-click apply entirely without touching sudoers. Defaults true (most
// configs will not set this key at all) so absence never silently disables
// the feature.
define('UPDATE_APPLY_ENABLED', ($cfg['update_apply_enabled'] ?? true) !== false);
define('RSPAMC_PW_FILE',    $cfg['rspamc_pw_file']);
define('DB_CRED',           $cfg['db_cred']);
define('USER_CACHE',        $cfg['user_cache']);
define('USER_CACHE_TTL',    $cfg['user_cache_ttl']);
define('LIST_DIR',          $cfg['list_dir']);
define('ACCESS_LOG_GLOB',   $cfg['access_log_glob']);
define('ADMIN_SESSION_GAP', $cfg['admin_session_gap']);
define('COOKIE_PATH',       $cfg['cookie_path']);
define('SESSION_NAME',      $cfg['session_name']);
define('QA_PER_PAGE_FTS',    (int)($cfg['per_page_fts']    ?? 10));
define('QA_PER_PAGE_BREACH', (int)($cfg['per_page_breach'] ?? 5));
define('QA_PER_PAGE_LISTS',  (int)($cfg['per_page_lists']  ?? 25));
define('QA_PER_PAGE_IOC',    (int)($cfg['per_page_ioc']    ?? 25));
define('QA_PER_PAGE_LOGINS', (int)($cfg['per_page_logins'] ?? 10));
define('QA_PER_PAGE',       $cfg['per_page']);
define('PARSE_EMAIL_PY',    $cfg['parse_email_py']);
define('SITE_TITLE',        $cfg['site_title']);
define('SITE_SUBTITLE',     $cfg['site_subtitle']);
define('CREDIT_IDEA',       $cfg['credit_idea'] ?? '');
define('CREDIT_CODE',       $cfg['credit_code'] ?? '');
define('SETTINGS_FILE',     $cfg['settings_file'] ?? '/var/cache/quarantine-admin/settings.json');
define('MAIL_DIR',          $cfg['mail_dir']       ?? '/data/mail');
define('ROLES_FILE',        dirname(SETTINGS_FILE) . '/roles.json');

$d = __DIR__;
require $d . '/i18n.php';
require $d . '/session.php';
require $d . '/validators.php';
require $d . '/helpers.php';
require $d . '/doveadm.php';
require $d . '/rspamd.php';
require $d . '/audit.php';
require $d . '/signin.php';
require $d . '/lists.php';
require $d . '/archive.php';
require $d . '/actions.php';
require $d . '/ioc.php';
require $d . '/ioc_enforce.php';
require $d . '/ioc_export.php';
require $d . '/campaigns.php';
require $d . '/ioc_lookup.php';
require $d . '/list_lookup.php';
require $d . '/feed_health.php';
require $d . '/quar_lookup.php';
require $d . '/arc_lookup.php';
require $d . '/migrate.php';
require $d . '/update.php';
require $d . '/admin.php';
require $d . '/postfix.php';
require $d . '/rbac.php';
unset($d, $cfg);
