<?php
// Campaign detection: clusters recent spam-flagged archive_index rows by
// (from-domain, normalized-subject) and stores qualifying clusters in
// iocs.db's campaigns table (docs/superpowers/specs/2026-08-11-campaign-
// detection-design.md). Detection itself runs from cron
// (qa-campaign-detect.php, Task 2); this file is the shared logic both
// the cron script and the admin-tab dispatcher (Task 3) call into.

// Raw candidate rows from archive_index -- no grouping, no filtering
// beyond is_spam/recency. Returns [] if the postfix DB is unreachable
// (audit_db() returns null on connection failure) or the query fails --
// both are non-fatal for a scheduled job: the next run's window will
// still catch an ongoing campaign.
function campaign_fetch_candidates(int $lookbackHours = 48): array {
    $db = audit_db();
    if (!$db) return [];
    try {
        $cutoff = time() - $lookbackHours * 3600;
        $stmt = $db->prepare('SELECT from_addr, subject, ts FROM archive_index WHERE is_spam = 1 AND ts >= :cutoff');
        $stmt->execute([':cutoff' => $cutoff]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        return [];
    }
}

// Pure function: no DB access, no globals (decode_subject() below is
// itself pure -- string-only, no side effects -- so calling it here
// doesn't violate that). Groups rows by (from-domain, normalized-
// subject) and returns only groups meeting $minCount. Domain extraction
// reuses the exact pattern ioc_extract_candidates() already uses in
// src/ioc.php -- from_addr is not guaranteed to be a bare address
// ("Display Name <user@example.com>" would break a naive
// substring-after-@ split). Subject normalization first runs
// decode_subject() (existing, src/helpers.php) -- confirmed against live
// archive_index data that a real minority of rows still store the raw
// RFC 2047 encoded-word form (e.g. "=?utf-8?B?...?="), never decoded by
// whatever indexer wrote them; without this, those rows' "signature"
// would be the base64 blob itself, which never collides with anything
// (different messages base64-encode to different-looking blobs even when
// their decoded text is identical), silently under-detecting exactly the
// non-ASCII-subject campaigns most relevant to a Hungarian-language
// deployment. decode_subject() is a safe no-op on already-decoded text
// (checks for the '=?' marker before attempting anything). After
// decoding, strips digits (so "Invoice #4521" and "Invoice #7823"
// collide into one signature) and collapses whitespace; rows whose
// subject normalizes to an empty string are skipped, so an empty-subject
// flood doesn't group into one giant bucket.
//
// Case-folding uses mb_strtolower(..., 'UTF-8'), NOT strtolower(). This
// was a real Critical-class bug caught by the final whole-branch review
// (before any live cron run ever wrote to the campaigns table -- so no
// data migration was needed to fix it): strtolower() is byte-wise/ASCII-
// only, so on Hungarian text it silently leaves accented characters
// untouched while still mangling the surrounding bytes it can't
// interpret correctly. Five real messages with subjects "ÁRAJÁNLAT 12",
// "árajánlat 34", "Árajánlat 56", "ÁRAJÁNLAT 78", "árajánlat 90" (a
// genuine 5-message campaign, all differing only in case) produced THREE
// different signatures under strtolower() -- "ÁrajÁnlat", "árajánlat",
// "Árajánlat" -- so campaign_group_candidates($rows, 5) returned zero
// groups instead of one. This is the same failure class as the
// decode_subject() fix above (non-ASCII text on a Hungarian-language
// deployment), reintroduced one function call later. The whitespace
// collapse also gets a /u (Unicode) modifier so multi-byte whitespace
// characters collapse correctly too.
function campaign_group_candidates(array $rows, int $minCount = 5): array {
    $groups = [];
    foreach ($rows as $row) {
        $from = (string) ($row['from_addr'] ?? '');
        if (!preg_match('/@([a-z0-9.-]+\.[a-z]{2,})/i', $from, $m)) continue;
        $domain = strtolower($m[1]);

        $subject = decode_subject((string) ($row['subject'] ?? ''));
        $sig = mb_strtolower(trim(preg_replace('/\s+/u', ' ', preg_replace('/[0-9]+/', '', $subject))), 'UTF-8');
        if ($sig === '') continue;

        $ts = (int) ($row['ts'] ?? 0);
        $key = $domain . '|' . $sig;
        if (!isset($groups[$key])) {
            $groups[$key] = [
                'domain' => $domain,
                'subject_signature' => $sig,
                'subject_sample' => $subject,
                'count' => 0,
                'first_seen' => $ts,
                'last_seen' => $ts,
            ];
        }
        $groups[$key]['count']++;
        if ($ts < $groups[$key]['first_seen']) $groups[$key]['first_seen'] = $ts;
        if ($ts > $groups[$key]['last_seen'])  $groups[$key]['last_seen']  = $ts;
    }
    return array_values(array_filter($groups, fn($g) => $g['count'] >= $minCount));
}

// Insert-or-update by (from_domain, subject_signature). Never resurrects
// a dismissed campaign -- checked before every write, not just at
// creation, since a still-active dismissed pattern would otherwise flip
// back to 'new' the moment its count changes on a later run.
//
// Returns bool: true on a real write OR an intentional dismissed-skip
// (both are "handled correctly"), false only on an actual failure. The
// final whole-branch review flagged the original void-returning version
// as an Important production-readiness gap: qa-campaign-detect.php
// (Task 2) printed "upserted: " . count($groups) regardless of whether
// any write actually succeeded, since count($groups) is the number of
// groups ATTEMPTED, not written -- a fresh rollout with an unwritable
// iocs.db (the single most likely first-rollout failure mode, since this
// is the first cron script since qa-ioc-expire.php to write iocs.db as
// apache) would log a clean-looking "upserted: 7" while silently writing
// nothing, with no way for an operator to tell from the log alone.
function campaign_upsert(array $group): bool {
    try {
        $db = _ioc_db();
        $stmt = $db->prepare('SELECT id, status FROM campaigns WHERE from_domain = :d AND subject_signature = :s');
        $stmt->execute([':d' => $group['domain'], ':s' => $group['subject_signature']]);
        $existing = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($existing && $existing['status'] === 'dismissed') {
            return true;
        }

        if ($existing) {
            $upd = $db->prepare('UPDATE campaigns SET message_count = :c, last_seen_at = :last, subject_sample = :sample WHERE id = :id');
            $upd->execute([
                ':c' => $group['count'], ':last' => $group['last_seen'],
                ':sample' => $group['subject_sample'], ':id' => $existing['id'],
            ]);
        } else {
            $ins = $db->prepare('INSERT INTO campaigns
                (from_domain, subject_signature, subject_sample, message_count, first_seen_at, last_seen_at, status, created_at)
                VALUES (:d, :s, :sample, :c, :first, :last, \'new\', :created)');
            $ins->execute([
                ':d' => $group['domain'], ':s' => $group['subject_signature'], ':sample' => $group['subject_sample'],
                ':c' => $group['count'], ':first' => $group['first_seen'], ':last' => $group['last_seen'],
                ':created' => time(),
            ]);
        }
        return true;
    } catch (Throwable $e) {
        return false;
    }
}

function campaign_list(): array {
    try {
        $stmt = _ioc_db()->query("SELECT * FROM campaigns WHERE status != 'dismissed' ORDER BY last_seen_at DESC");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        return [];
    }
}

// Domains already present as an active IOC -- used by the view to show a
// "already added" badge instead of the add button. Derived, not stored: no
// campaigns-table column to keep in sync, and it naturally reverts if the
// IOC is later deactivated via the IOC tab.
function campaign_existing_ioc_domains(): array {
    try {
        $stmt = _ioc_db()->query("SELECT value FROM iocs WHERE type = 'domain' AND active = 1");
        return $stmt->fetchAll(PDO::FETCH_COLUMN, 0);
    } catch (Throwable $e) {
        return [];
    }
}

function campaign_dismiss(int $id): bool {
    try {
        $stmt = _ioc_db()->prepare("UPDATE campaigns SET status = 'dismissed' WHERE id = :id");
        $stmt->execute([':id' => $id]);
        return $stmt->rowCount() > 0;
    } catch (Throwable $e) {
        return false;
    }
}

// Self-gated dispatcher for the campaigns tab's one POST action, mirroring
// handle_ioc_action()'s self-gating style (checks its own permission
// rather than relying on the caller).
function handle_campaign_action(string $action): void {
    if (!can('admin')) { header('Location: ?'); exit; }

    switch ($action) {
        case 'campaign_dismiss':
            $id = (int) ($_POST['campaign_id'] ?? 0);
            $ok = $id > 0 && campaign_dismiss($id);
            if ($ok) audit_log('campaign-dismiss', (string) $id, '', '');
            header('Location: ?campaigns=1&msg=' . ($ok ? 'campaign_dismissed' : 'campaign_err'));
            exit;

        case 'campaign_add_ioc':
            $id = (int) ($_POST['campaign_id'] ?? 0);
            $domain = '';
            if ($id > 0) {
                try {
                    $stmt = _ioc_db()->prepare('SELECT from_domain FROM campaigns WHERE id = :id');
                    $stmt->execute([':id' => $id]);
                    $domain = (string) ($stmt->fetchColumn() ?: '');
                } catch (Throwable $e) {
                    $domain = '';
                }
            }
            $ok = false;
            if ($domain !== '') {
                [$ok] = ioc_add([
                    'type' => 'domain', 'value' => $domain, 'source' => 'campaign',
                    'confidence' => 'medium', 'source_ref' => 'campaign:' . $id,
                ]);
            }
            if ($ok) audit_log('campaign-add-ioc', $domain, '', (string) $id);
            header('Location: ?campaigns=1&msg=' . ($ok ? 'campaign_ioc_added' : 'campaign_ioc_err'));
            exit;

        default:
            header('Location: ?campaigns=1'); exit;
    }
}
