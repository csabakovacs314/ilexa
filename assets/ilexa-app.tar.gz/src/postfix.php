<?php
// Postfix main.cf settings and restriction chains.
// Every function here shells out to the qa-postfix-config.sh root helper --
// this file never touches postconf/postfix directly.

// ── Curated main.cf settings ──────────────────────────────────────────────────
function _postfix_rules(): array {
    $tls_protocol_presets = ['!SSLv2,!SSLv3,!TLSv1,!TLSv1.1', '!SSLv2,!SSLv3,!TLSv1,!TLSv1.1,!TLSv1.2'];
    return [
        'mynetworks' => [
            'label'    => t('Megbízható hálózatok (mynetworks)'),
            'type'     => 'text',
            'help'     => t('Szóközzel elválasztott CIDR-lista, pl. 127.0.0.0/8 10.0.0.0/8.'),
            'options'  => null,
            'validate' => function (string $v): bool {
                $v = trim($v);
                if ($v === '') return false;
                foreach (preg_split('/\s+/', $v) as $tok) {
                    if ($tok === '') continue;
                    if (!preg_match('/^(\d{1,3}\.){3}\d{1,3}(\/\d{1,2})?$/', $tok)
                        && !preg_match('/^[0-9a-fA-F:]+(\/\d{1,3})?$/', $tok)) return false;
                }
                return true;
            },
        ],
        'relay_domains' => [
            'label'    => t('Relézett tartományok (relay_domains)'),
            'type'     => 'text',
            'help'     => t('Alapesetben $mydestination - csak akkor módosítsa, ha a saját tartományokon kívül is releznie kell.'),
            'options'  => null,
            'validate' => fn(string $v): bool => trim($v) !== '',
        ],
        'relayhost' => [
            'label'    => t('Kimenő relay (relayhost)'),
            'type'     => 'text',
            'help'     => t('Üresen hagyva közvetlen kézbesítés. Formátum: host vagy [host]:port.'),
            'options'  => null,
            'validate' => fn(string $v): bool => $v === '' ||
                (bool) preg_match('/^(\[[a-zA-Z0-9.\-]+\]|[a-zA-Z0-9.\-]+)?(:[0-9]{1,5})?$/', $v),
        ],
        'message_size_limit' => [
            'label'    => t('Max. üzenetméret (bájt)'),
            'type'     => 'number',
            'help'     => t('1 048 576 – 524 288 000 bájt (1–500 MB) között.'),
            'options'  => null,
            'validate' => fn(string $v): bool => ctype_digit($v) && (int)$v >= 1048576 && (int)$v <= 524288000,
        ],
        'smtpd_tls_security_level' => [
            'label'    => t('Bejövő TLS-szint (smtpd_tls_security_level)'),
            'type'     => 'enum',
            'help'     => '',
            'options'  => ['none', 'may', 'encrypt'],
            'validate' => fn(string $v): bool => in_array($v, ['none', 'may', 'encrypt'], true),
        ],
        'smtp_tls_security_level' => [
            'label'    => t('Kimenő TLS-szint (smtp_tls_security_level)'),
            'type'     => 'enum',
            'help'     => '',
            'options'  => ['none', 'may', 'encrypt', 'dane', 'dane-only'],
            'validate' => fn(string $v): bool => in_array($v, ['none', 'may', 'encrypt', 'dane', 'dane-only'], true),
        ],
        'smtpd_tls_mandatory_protocols' => [
            'label'    => t('Bejövő kötelező protokollok'),
            'type'     => 'enum',
            'help'     => '',
            'options'  => $tls_protocol_presets,
            'validate' => fn(string $v): bool => in_array($v, $tls_protocol_presets, true),
        ],
        'smtp_tls_mandatory_protocols' => [
            'label'    => t('Kimenő kötelező protokollok'),
            'type'     => 'enum',
            'help'     => '',
            'options'  => $tls_protocol_presets,
            'validate' => fn(string $v): bool => in_array($v, $tls_protocol_presets, true),
        ],
    ];
}

function postfix_settings_load(): array {
    $out = [];
    foreach (array_keys(_postfix_rules()) as $key) {
        $out[$key] = trim(qa_sudo_read(
            SUDO . ' /usr/local/sbin/qa-postfix-config.sh get ' . escapeshellarg($key),
            'postfix:' . $key));
    }
    return $out;
}

function postfix_setting_save(string $key, string $val): array {
    $rules = _postfix_rules();
    if (!isset($rules[$key])) return [false, t('Ismeretlen beállítás.')];
    if (!($rules[$key]['validate'])($val)) return [false, t('Érvénytelen érték.')];
    $cmd = SUDO . ' /usr/local/sbin/qa-postfix-config.sh set '
         . escapeshellarg($key) . ' ' . escapeshellarg($val) . ' 2>&1';
    $out = trim((string) shell_exec($cmd));
    return str_starts_with($out, 'OK') ? [true, ''] : [false, $out ?: t('Nincs kimenet.')];
}

// Read-only display only (certbot manages these files) -- not part of
// _postfix_rules() because they're never settable through this UI.
function postfix_tls_cert_info(): array {
    $out = [];
    foreach (['smtpd_tls_cert_file', 'smtpd_tls_key_file'] as $key) {
        $out[$key] = trim(qa_sudo_read(
            SUDO . ' /usr/local/sbin/qa-postfix-config.sh get ' . escapeshellarg($key),
            'postfix:' . $key));
    }
    return $out;
}

// Read-only display only (edited directly on the server, not through this
// UI -- see /root/hrbl-dnsbl-integration-design.md for how/why). Parses
// "host1*weight1 host2*weight2 ..." into pairs.
function postfix_dnsbl_sites(): array {
    $raw = trim(qa_sudo_read(
        SUDO . ' /usr/local/sbin/qa-postfix-config.sh get postscreen_dnsbl_sites',
        'postfix:postscreen_dnsbl_sites'));
    if ($raw === '') return [];
    $out = [];
    foreach (preg_split('/\s+/', $raw) as $tok) {
        if ($tok === '') continue;
        $parts = explode('*', $tok, 2);
        $out[] = ['host' => $parts[0], 'weight' => $parts[1] ?? '1'];
    }
    return $out;
}

// ── Restriction chains ────────────────────────────────────────────────────────
const POSTFIX_SAFE_TOKENS = ['permit_mynetworks', 'permit_sasl_authenticated',
    'reject_unauth_destination', 'reject_invalid_hostname', 'reject_unknown_hostname',
    'reject_unauth_pipelining', 'reject_non_fqdn_recipient', 'reject_non_fqdn_sender',
    'permit', 'warn_if_reject'];

function postfix_restriction_directives(): array {
    return ['smtpd_client_restrictions', 'smtpd_helo_restrictions',
            'smtpd_recipient_restrictions', 'smtpd_relay_restrictions'];
}

function postfix_restriction_get(string $dir): array {
    if (!in_array($dir, postfix_restriction_directives(), true)) return [];
    $out = qa_sudo_read(SUDO . ' /usr/local/sbin/qa-postfix-config.sh get-restriction '
                     . escapeshellarg($dir), 'postfix:restriction:' . $dir);
    $d = json_decode(trim((string) $out), true);
    return is_array($d) ? $d : [];
}

function postfix_restriction_save(string $dir, array $tokens): array {
    if (!in_array($dir, postfix_restriction_directives(), true))
        return [false, t('Ismeretlen korlátozási lánc.')];
    $tokens = array_values(array_filter(array_map('trim', $tokens), fn($t) => $t !== ''));
    if (empty($tokens)) return [false, t('A lista nem lehet üres.')];

    $current = postfix_restriction_get($dir);
    foreach ($tokens as $t) {
        if (!in_array($t, POSTFIX_SAFE_TOKENS, true) && !in_array($t, $current, true)) {
            return [false, t('Nem engedélyezett elem: ') . $t];
        }
    }

    $cmd = SUDO . ' /usr/local/sbin/qa-postfix-config.sh set-restriction ' . escapeshellarg($dir) . ' 2>&1';
    $p = proc_open($cmd, [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes);
    if (!is_resource($p)) return [false, t('Nincs kimenet.')];
    fwrite($pipes[0], implode("\n", $tokens));
    fclose($pipes[0]);
    $out = trim(stream_get_contents($pipes[1]));
    fclose($pipes[1]); fclose($pipes[2]); proc_close($p);
    return str_starts_with($out, 'OK') ? [true, ''] : [false, $out ?: t('Nincs kimenet.')];
}
