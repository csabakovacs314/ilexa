<?php
// Postfix main.cf settings and restriction chains.
// Every function here shells out to the qa-postfix-config.sh root helper --
// this file never touches postconf/postfix directly.

// ── Curated main.cf settings ──────────────────────────────────────────────────
function _postfix_rules(): array {
    $tls_protocol_presets = ['!SSLv2,!SSLv3,!TLSv1,!TLSv1.1', '!SSLv2,!SSLv3,!TLSv1,!TLSv1.1,!TLSv1.2'];
    return [
        'mynetworks' => [
            'label'    => t('Megbízható hálózatok (mynetworks)'),
            'type'     => 'text',
            'help'     => t('Szóközzel elválasztott CIDR-lista, pl. 127.0.0.0/8 10.0.0.0/8.'),
            'options'  => null,
            'validate' => function (string $v): bool {
                $v = trim($v);
                if ($v === '') return false;
                foreach (preg_split('/\s+/', $v) as $tok) {
                    if ($tok === '') continue;
                    if (!preg_match('/^(\d{1,3}\.){3}\d{1,3}(\/\d{1,2})?$/', $tok)
                        && !preg_match('/^[0-9a-fA-F:]+(\/\d{1,3})?$/', $tok)) return false;
                }
                return true;
            },
        ],
        'relay_domains' => [
            'label'    => t('Relézett tartományok (relay_domains)'),
            'type'     => 'text',
            'help'     => t('Alapesetben $mydestination - csak akkor módosítsa, ha a saját tartományokon kívül is releznie kell.'),
            'options'  => null,
            'validate' => fn(string $v): bool => trim($v) !== '',
        ],
        'relayhost' => [
            'label'    => t('Kimenő relay (relayhost)'),
            'type'     => 'text',
            'help'     => t('Üresen hagyva közvetlen kézbesítés. Formátum: host vagy [host]:port.'),
            'options'  => null,
            'validate' => fn(string $v): bool => $v === '' ||
                (bool) preg_match('/^(\[[a-zA-Z0-9.\-]+\]|[a-zA-Z0-9.\-]+)?(:[0-9]{1,5})?$/', $v),
        ],
        'message_size_limit' => [
            'label'    => t('Max. üzenetméret (bájt)'),
            'type'     => 'number',
            'help'     => t('1 048 576 – 524 288 000 bájt (1–500 MB) között.'),
            'options'  => null,
            'validate' => fn(string $v): bool => ctype_digit($v) && (int)$v >= 1048576 && (int)$v <= 524288000,
        ],
        'smtpd_tls_security_level' => [
            'label'    => t('Bejövő TLS-szint (smtpd_tls_security_level)'),
            'type'     => 'enum',
            'help'     => '',
            'options'  => ['none', 'may', 'encrypt'],
            'validate' => fn(string $v): bool => in_array($v, ['none', 'may', 'encrypt'], true),
        ],
        'smtp_tls_security_level' => [
            'label'    => t('Kimenő TLS-szint (smtp_tls_security_level)'),
            'type'     => 'enum',
            'help'     => '',
            'options'  => ['none', 'may', 'encrypt', 'dane', 'dane-only'],
            'validate' => fn(string $v): bool => in_array($v, ['none', 'may', 'encrypt', 'dane', 'dane-only'], true),
        ],
        'smtpd_tls_mandatory_protocols' => [
            'label'    => t('Bejövő kötelező protokollok'),
            'type'     => 'enum',
            'help'     => '',
            'options'  => $tls_protocol_presets,
            'validate' => fn(string $v): bool => in_array($v, $tls_protocol_presets, true),
        ],
        'smtp_tls_mandatory_protocols' => [
            'label'    => t('Kimenő kötelező protokollok'),
            'type'     => 'enum',
            'help'     => '',
            'options'  => $tls_protocol_presets,
            'validate' => fn(string $v): bool => in_array($v, $tls_protocol_presets, true),
        ],
    ];
}

// ONE helper invocation for every key, not one per key.
//
// This used to loop `qa-postfix-config.sh get <key>` over ~13 keys, and the
// TLS card added two more, so rendering the Rendszer page spawned this helper
// 15 times -- each through its own sh + sudo. strace put it at ~900ms of the
// page's ~1.4s render. The helper's get-many verb applies the same per-key
// allowlist, so this is purely fewer round trips.
//
// Falls back to the per-key path if get-many is unavailable (an older helper
// still on disk after a partial upgrade), so the page degrades in speed
// rather than going blank.
function postfix_settings_load(): array {
    $keys = array_keys(_postfix_rules());
    if (!$keys) return [];
    $cmd = SUDO . ' /usr/local/sbin/qa-postfix-config.sh get-many';
    foreach ($keys as $k) $cmd .= ' ' . escapeshellarg($k);
    $raw = qa_sudo_read($cmd, 'postfix:get-many');

    $out = [];
    foreach (explode("\n", (string)$raw) as $line) {
        if ($line === '' || !str_contains($line, '=')) continue;
        [$k, $v] = explode('=', $line, 2);
        if (in_array($k, $keys, true)) $out[$k] = trim($v);
    }
    if (count($out) === count($keys)) return $out;

    foreach ($keys as $key) {
        if (isset($out[$key])) continue;
        $out[$key] = trim(qa_sudo_read(
            SUDO . ' /usr/local/sbin/qa-postfix-config.sh get ' . escapeshellarg($key),
            'postfix:' . $key));
    }
    return $out;
}

function postfix_setting_save(string $key, string $val): array {
    $rules = _postfix_rules();
    if (!isset($rules[$key])) return [false, t('Ismeretlen beállítás.')];
    if (!($rules[$key]['validate'])($val)) return [false, t('Érvénytelen érték.')];
    $cmd = SUDO . ' /usr/local/sbin/qa-postfix-config.sh set '
         . escapeshellarg($key) . ' ' . escapeshellarg($val) . ' 2>&1';
    $out = trim((string) shell_exec($cmd));
    return str_starts_with($out, 'OK') ? [true, ''] : [false, $out ?: t('Nincs kimenet.')];
}

// Read-only display only (certbot manages these files) -- not part of
// _postfix_rules() because they're never settable through this UI.
function postfix_tls_cert_info(): array {
    $out = [];
    $raw = qa_sudo_read(SUDO . ' /usr/local/sbin/qa-postfix-config.sh get-many '
        . 'smtpd_tls_cert_file smtpd_tls_key_file', 'postfix:tls-files');
    foreach (explode("\n", (string)$raw) as $line) {
        if ($line === '' || !str_contains($line, '=')) continue;
        [$k, $v] = explode('=', $line, 2);
        if ($k === 'smtpd_tls_cert_file' || $k === 'smtpd_tls_key_file') $out[$k] = trim($v);
    }
    foreach (['smtpd_tls_cert_file', 'smtpd_tls_key_file'] as $key) {
        if (isset($out[$key])) continue;
        $out[$key] = trim(qa_sudo_read(
            SUDO . ' /usr/local/sbin/qa-postfix-config.sh get ' . escapeshellarg($key),
            'postfix:' . $key));
    }
    return $out;
}

// Read-only display only (edited directly on the server, not through this
// UI -- see /root/hrbl-dnsbl-integration-design.md for how/why). Parses
// "host1*weight1 host2*weight2 ..." into pairs.
function postfix_dnsbl_sites(): array {
    $raw = trim(qa_sudo_read(
        SUDO . ' /usr/local/sbin/qa-postfix-config.sh get postscreen_dnsbl_sites',
        'postfix:postscreen_dnsbl_sites'));
    if ($raw === '') return [];
    $out = [];
    foreach (preg_split('/\s+/', $raw) as $tok) {
        if ($tok === '') continue;
        $parts = explode('*', $tok, 2);
        $out[] = ['host' => $parts[0], 'weight' => $parts[1] ?? '1'];
    }
    return $out;
}

// ── Restriction chains ────────────────────────────────────────────────────────
const POSTFIX_SAFE_TOKENS = ['permit_mynetworks', 'permit_sasl_authenticated',
    'reject_unauth_destination', 'reject_invalid_hostname', 'reject_unknown_hostname',
    'reject_unauth_pipelining', 'reject_non_fqdn_recipient', 'reject_non_fqdn_sender',
    'permit', 'warn_if_reject'];

function postfix_restriction_directives(): array {
    return ['smtpd_client_restrictions', 'smtpd_helo_restrictions',
            'smtpd_recipient_restrictions', 'smtpd_relay_restrictions'];
}

function postfix_restriction_get(string $dir): array {
    if (!in_array($dir, postfix_restriction_directives(), true)) return [];
    $out = qa_sudo_read(SUDO . ' /usr/local/sbin/qa-postfix-config.sh get-restriction '
                     . escapeshellarg($dir), 'postfix:restriction:' . $dir);
    $d = json_decode(trim((string) $out), true);
    return is_array($d) ? $d : [];
}

// ── Relay-control guard ───────────────────────────────────────────────────────
// Postfix 2.10+ accepts a recipient only if it passes BOTH
// smtpd_relay_restrictions and smtpd_recipient_restrictions, and smtpd will not
// start unless one of them holds a working reject_unauth_destination (or
// equivalent). Without this guard the chain editor could save relay=`permit`
// next to a recipient chain lacking reject_unauth_destination: an open relay,
// or a mail outage at the next smtpd start.
//
// install/qa-postfix-config.sh enforces the SAME rule and is the authoritative
// copy (it is the privilege boundary); this one only exists so the operator
// gets a translated message. tools/check-postfix-relay-guard.php runs one case
// table against both, so they cannot drift apart silently.
const POSTFIX_RELAY_CONTROLS = ['reject_unauth_destination', 'defer_unauth_destination', 'reject', 'defer'];

function _postfix_relay_partner(string $dir): ?string {
    return ['smtpd_relay_restrictions'     => 'smtpd_recipient_restrictions',
            'smtpd_recipient_restrictions' => 'smtpd_relay_restrictions'][$dir] ?? null;
}

// A chain as Postfix itself reads it: entries split on commas AND whitespace
// ("warn_if_reject reject_unknown_hostname" is two words), and every word of a
// "{ ... }" group (check_policy_service { inet:..., default_action=DUNNO })
// replaced by an opaque '{}', so nothing inside a group can pass for a control.
function _postfix_chain_words(array $entries): array {
    $words = [];
    $depth = 0;
    foreach ($entries as $e) {
        foreach (preg_split('/[\s,]+/', (string) $e, -1, PREG_SPLIT_NO_EMPTY) as $w) {
            $o = substr_count($w, '{');
            if ($depth > 0 || $o > 0) {
                $depth = max(0, $depth + $o - substr_count($w, '}'));
                $words[] = '{}';
                continue;
            }
            $words[] = $w;
        }
    }
    return $words;
}

// True if a relay control is reached before any bare `permit`. A control right
// after warn_if_reject only logs, so it does not count (Postfix's own startup
// check skips it the same way); a `permit` always ends the chain.
function _postfix_chain_relay_safe(array $words): bool {
    $skip = false;
    foreach ($words as $w) {
        if ($w === 'permit') return false;
        // warn_if_reject is checked BEFORE the skip is consumed: Postfix keeps
        // the warn flag set across consecutive warn_if_reject entries, so
        // "warn_if_reject, warn_if_reject, reject_unauth_destination" still
        // only logs. Consuming the second one as "the skipped word" counted
        // that control as working -- an open-relay bypass (2026-10-14 review).
        if ($w === 'warn_if_reject') { $skip = true; continue; }
        if ($skip) { $skip = false; continue; }
        if (in_array($w, POSTFIX_RELAY_CONTROLS, true)) return true;
    }
    return false;
}

// Pure -- no shell-out. Returns null if $proposed may be saved as $dir, else
// the operator-facing reason. $otherChain is the CURRENT value of the partner
// directive (relay <-> recipient); it is ignored for client/helo.
function postfix_relay_guard(string $dir, array $proposed, array $otherChain): ?string {
    $words = _postfix_chain_words($proposed);
    $p = array_search('permit', $words, true);
    if ($p !== false && $p !== count($words) - 1)
        return t('A „permit” csak a lánc utolsó eleme lehet - ami utána áll, azt a Postfix figyelmen kívül hagyja.');
    if (_postfix_relay_partner($dir) === null) return null;
    if (_postfix_chain_relay_safe($words)) return null;
    if (_postfix_chain_relay_safe(_postfix_chain_words($otherChain))) return null;
    return t('Elutasítva: a smtpd_relay_restrictions és a smtpd_recipient_restrictions közül legalább az egyikben maradnia kell egy reject_unauth_destination (vagy defer_unauth_destination, reject, defer) elemnek, amelyet nem előz meg „permit”, és nem közvetlenül warn_if_reject után áll. Enélkül a szerver nyílt relé lenne, vagy a Postfix nem indulna el.');
}

function postfix_restriction_save(string $dir, array $tokens): array {
    if (!in_array($dir, postfix_restriction_directives(), true))
        return [false, t('Ismeretlen korlátozási lánc.')];
    $tokens = array_values(array_filter(array_map('trim', $tokens), fn($t) => $t !== ''));
    if (empty($tokens)) return [false, t('A lista nem lehet üres.')];

    $current = postfix_restriction_get($dir);
    foreach ($tokens as $t) {
        if (!in_array($t, POSTFIX_SAFE_TOKENS, true) && !in_array($t, $current, true)) {
            return [false, t('Nem engedélyezett elem: ') . $t];
        }
    }
    // A failed read of the partner returns [] -- fail closed: the proposed
    // chain must then be relay-safe on its own.
    $partner = _postfix_relay_partner($dir);
    $guard   = postfix_relay_guard($dir, $tokens, $partner !== null ? postfix_restriction_get($partner) : []);
    if ($guard !== null) return [false, $guard];

    $cmd =SUDO . ' /usr/local/sbin/qa-postfix-config.sh set-restriction ' . escapeshellarg($dir) . ' 2>&1';
    $p = proc_open($cmd, [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes);
    if (!is_resource($p)) return [false, t('Nincs kimenet.')];
    fwrite($pipes[0], implode("\n", $tokens));
    fclose($pipes[0]);
    $out = trim(stream_get_contents($pipes[1]));
    fclose($pipes[1]); fclose($pipes[2]); proc_close($p);
    return str_starts_with($out, 'OK') ? [true, ''] : [false, $out ?: t('Nincs kimenet.')];
}
