<?php
// Pull a bare, lowercased address out of a From-style string. Stored
// from_addr values (and anything typed by an admin) are commonly "Display
// Name <addr@domain>", not a bare address -- and the list matcher's compiled
// regexes are anchored ('.../i' ending in $), so matching the raw string
// against them silently never matches (the string ends in '>', not the
// domain). Returns '' if no address-shaped substring is found.
function qa_extract_email(string $raw): string {
    if (filter_var($raw, FILTER_VALIDATE_EMAIL)) return strtolower($raw);
    if (preg_match('/[\w.+\-]+@[\w.\-]+\.[A-Za-z]{2,}/', $raw, $m)) return strtolower($m[0]);
    return '';
}

// Build a filter-preserving URL for a given results page.
function page_url(int $p, array $f): string {
    return '?' . http_build_query(array_filter([
        'domain'  => $f['domain'],  'user'    => $f['user'],    'folder' => $f['folder'],
        'since'   => $f['since'],   'before'  => $f['before'],
        'from'    => $f['from']    ?? '', 'subject' => $f['subject'] ?? '',
        'qsort'   => $_GET['qsort'] ?? '', 'qdir' => $_GET['qdir'] ?? '',
        'page'    => $p, 'search'  => '1', 'quar' => '1',
    ]));
}

// Filter-preserving URL for an audit tab + page. Audit is a section of the
// Rendszer page, not a page of its own, so these must carry sysconfig=1 and
// anchor back to the section -- otherwise paging or switching tab would jump
// to the top of Rendszer with the section collapsed again.
function audit_url(string $tab, int $p): string {
    return '?' . http_build_query(['sysconfig' => 1, 'audit' => $tab, 'page' => $p]) . '#audit';
}

// Short relative time in Hungarian (for the login snapshot).
function rel_time(int $ts): string {
    $d = time() - $ts;
    if ($d < 0)      return '';
    if ($d < 60)     return 'most';
    if ($d < 3600)   return sprintf(t('%d perce'), floor($d / 60));
    if ($d < 86400)  return sprintf(t('%d órája'), floor($d / 3600));
    return sprintf(t('%d napja'), floor($d / 86400));
}

// HTML-escape, then wrap case-insensitive matches of $needle in <mark>.
function hl(string $text, string $needle): string {
    $safe = h($text);
    if ($needle === '') return $safe;
    $out = preg_replace('/(' . preg_quote(h($needle), '/') . ')/iu', '<mark>$1</mark>', $safe);
    return $out ?? $safe;
}

// Convert ISO date → IMAP date format (e.g. 2026-08-01 → 1-Aug-2026)
function imap_date(string $iso): string {
    return date('j-M-Y', (int)strtotime($iso));
}

// Build the "mailbox X [SINCE ..] [BEFORE ..] ALL" search argument tail.
function search_args(string $folder, string $since, string $before): string {
    $extra = 'mailbox ' . escapeshellarg($folder);
    if ($since)  { $extra .= ' SINCE '  . escapeshellarg(imap_date($since));  }
    if ($before) { $extra .= ' BEFORE ' . escapeshellarg(imap_date($before)); }
    return $extra . ' ALL';
}

function decode_subject(string $s): string {
    // Only MIME-decode when an encoded-word is actually present. iconv_mime_decode
    // DROPS raw 8-bit/UTF-8 bytes in an un-encoded header (e.g. "AJÁNLAT" → "AJNLAT"),
    // which would both mangle display and break the subject filter.
    if (strpos($s, '=?') === false) {
        return $s;
    }
    $decoded = iconv_mime_decode($s, ICONV_MIME_DECODE_CONTINUE_ON_ERROR, 'UTF-8');
    return $decoded !== false ? $decoded : $s;
}

// Returns just the .pager block; the caller supplies the .results-footer row,
// because some pages put other controls (e.g. "new search") alongside it.
// One pager for every list. Four near-identical copies had drifted apart in
// markup and label wording; page sizes now come from config rather than being
// hardcoded per view.
function render_pager(int $page, int $pages, callable $url, string $summary = ''): string {
    if ($pages <= 1) return '';
    $chevron_prev = '<svg class="icon icon-rot-180"><use href="#icon-chevron"></use></svg>';
    $chevron_next = '<svg class="icon"><use href="#icon-chevron"></use></svg>';
    $prev = $page > 1
        ? '<a class="btn btn-sm btn-primary" href="' . h($url($page - 1)) . '">' . $chevron_prev . ' ' . h(t('Előző')) . '</a>'
        : '<span class="btn btn-sm pager-disabled">' . $chevron_prev . ' ' . h(t('Előző')) . '</span>';
    $next = $page < $pages
        ? '<a class="btn btn-sm btn-primary" href="' . h($url($page + 1)) . '">' . h(t('Következő')) . ' ' . $chevron_next . '</a>'
        : '<span class="btn btn-sm pager-disabled">' . h(t('Következő')) . ' ' . $chevron_next . '</span>';
    return '<div class="pager">' . $prev
         . '<span class="pager-info">' . h(sprintf(t('%1$d. / %2$d oldal'), $page, $pages))
         . ($summary !== '' ? ' &middot; ' . $summary : '') . '</span>'
         . $next . '</div>';
}

// ── sudo helper reads that can tell failure from "nothing configured" ────────
// Every read-only `qa-*-config.sh get|list|status` call used to be
// trim(shell_exec('... 2>/dev/null')), which collapses two different states
// into one empty string: the setting genuinely is not set, and the helper
// crashed / sudo was denied / the script is missing. The admin pages then
// rendered a failure as "nincs beállítva" -- the same class of silent-empty
// failure as the 2026-08-13 /dev/null incident, where every 2>/dev/null
// shell-out for apache broke and the UI just showed nothing.
//
// qa_sudo_read() keeps stderr suppressed (helper stderr can carry paths and
// is not for a web user) but keeps the EXIT STATUS, sets $ok, records the
// failure for a page-level banner, and error_log()s it.
//
// proc_open, not exec(): exec() trims trailing whitespace from each output
// line, which silently corrupts any value whose formatting matters. See
// qa_da() in src/doveadm.php, where that behaviour ate doveadm's form-feed
// record separator.
function qa_sudo_failures(array $add = []): array {
    static $all = [];
    foreach ($add as $f) $all[(string)$f] = true;
    return array_keys($all);
}

// $ok_codes: exit statuses that are NOT failures. Defaults to [0]. grep needs
// [0, 1] -- it exits 1 for "no matches", which is an ordinary empty result,
// and only 2+ means a real error (unreadable file, bad pattern). Treating
// grep's 1 as a failure would fire the banner on every quiet log.
function qa_sudo_read(string $cmd, string $label, ?bool &$ok = null, array $ok_codes = [0]): string {
    $rc   = 1;
    $body = '';
    $proc = @proc_open($cmd . ' 2>/dev/null',
        [1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes);
    if (is_resource($proc)) {
        $body = (string) stream_get_contents($pipes[1]);
        fclose($pipes[1]);
        if (isset($pipes[2])) fclose($pipes[2]);
        $rc = proc_close($proc);
    }
    $ok = in_array($rc, $ok_codes, true);
    if (!$ok) {
        qa_sudo_failures([$label]);
        error_log('qa_sudo_read(): "' . $label . '" helper exited ' . $rc
            . ' -- returning empty; do not read this as "not configured"');
    }
    return $body;
}

// Atomically replace a small single-value settings file (language selection,
// GDPR view policy). tempfile + chmod + rename, so a reader never observes a
// half-written value and the mode is set before the file is reachable under its
// real name.
//
// These two settings were the only writers in the codebase still doing a plain
// file_put_contents(..., LOCK_EX): LOCK_EX serialises writers but does nothing
// for a reader, which can still read a partially-written file. Both fail closed
// on garbage (unknown language -> default, unknown policy -> 'none' = deny), so
// the impact was small, but every other settings writer here (rbac_save,
// list_save, _ioc_export_write, _ioc_block_hosts_compile) already used the
// atomic pattern and these two were the outliers.
//
// Defined in helpers.php, which bootstrap.php loads AFTER i18n.php -- fine,
// because the only callers are runtime POST handlers, long after every require
// has completed. Do not call this from a file's top-level load path.
function qa_atomic_write(string $path, string $data, int $mode = 0644): bool {
    $dir = dirname($path);
    $tmp = tempnam($dir, '.qa-');
    if ($tmp === false) return false;
    if (file_put_contents($tmp, $data) === false) { @unlink($tmp); return false; }
    @chmod($tmp, $mode);
    if (!rename($tmp, $path)) { @unlink($tmp); return false; }
    return true;
}

// Renders an ISO-3166 alpha-2 country code as a flag image for a table cell.
//
// An <img>, NOT a Unicode regional-indicator pair. This first shipped as
// emoji (HU -> U+1F1ED U+1F1FA), which needs no assets at all -- but Windows
// ships no flag-emoji font, so every flag rendered there as the bare letters
// "HU", which is exactly what the operator saw. Image flags render
// identically on every platform. See assets/flags/README.md for why those
// are 40x30 PNG8 rather than the upstream SVGs.
//
// A code with no matching file degrades to the two-letter code through the
// alt text rather than a broken image, so a country GeoLite2 starts
// returning before this asset set knows about it still reads correctly.
//
// The country NAME in the tooltip comes from intl (already relied on
// elsewhere), so it follows the console's active language -- "Germany" in
// English, "Nemetorszag" in Hungarian -- instead of a hand-maintained
// 250-entry table that would drift.
//
// Returns '' for an empty/invalid code. That is the normal case for a good
// share of rows, not an error: the sender IP is only taken when the topmost
// Received: header matches the exact shape our own MTA writes (see
// topmost_received_ip() in archive-indexer.php), and locally-submitted or
// unusually-routed mail legitimately has no public client IP at all.
//
// $ip, when given, joins the SAME title rather than a wrapping element:
// nesting a title inside a title makes the inner one win on hover, so the
// caller would silently lose whichever it thought it was adding.
// Live IP -> ISO country code lookup, for a source that (unlike the archive
// index) has no pre-computed sender_cc column to read -- audit.php's failed-
// login sources are transient log lines, not DB rows. Deliberately the same
// mmdblookup invocation archive-indexer.php's geoip_cc() already uses (same
// DB path, same regex), so a given IP never resolves to two different
// answers depending on which code path asked. Not merged into one shared
// function across the two files: archive-indexer.php runs as a standalone
// cron script with no bootstrap.php dependency, and duplicating six lines is
// cheaper than giving it one.
function qa_ip_country(string $ip): string {
    static $cache = [];
    if (isset($cache[$ip])) return $cache[$ip];
    $db = '/usr/share/GeoIP/GeoLite2-Country.mmdb';
    if (!is_readable($db) || !filter_var($ip, FILTER_VALIDATE_IP)) return $cache[$ip] = '';
    $out = @shell_exec('mmdblookup --file ' . escapeshellarg($db)
                     . ' --ip ' . escapeshellarg($ip) . ' country iso_code 2>/dev/null');
    return $cache[$ip] = ($out !== null && preg_match('/"([A-Z]{2})"/', $out, $m)) ? $m[1] : '';
}

// City-tier lookup (lat/lon + country) -- login-anomaly scoring's
// impossible-travel signal needs real distance, not just a country change
// (this deployment's user base sits in a region where two countries can be
// less than an hour apart by road). Same cache-per-request, fail-empty-not-
// fatal shape as qa_ip_country(): a missing/stale city DB (qa-geoipdb-
// refresh.sh's own tier, independently fail-closed) degrades this signal to
// unavailable rather than breaking anything that calls it.
function qa_ip_geo(string $ip): array {
    static $cache = [];
    if (isset($cache[$ip])) return $cache[$ip];
    $empty = ['lat' => null, 'lon' => null, 'cc' => ''];
    $db = '/usr/share/GeoIP/GeoLite2-City.mmdb';
    if (!is_readable($db) || !filter_var($ip, FILTER_VALIDATE_IP)) return $cache[$ip] = $empty;
    $ipArg = escapeshellarg($ip);
    $lat = @shell_exec('mmdblookup --file ' . escapeshellarg($db) . ' --ip ' . $ipArg . ' location latitude 2>/dev/null');
    $lon = @shell_exec('mmdblookup --file ' . escapeshellarg($db) . ' --ip ' . $ipArg . ' location longitude 2>/dev/null');
    $cc  = @shell_exec('mmdblookup --file ' . escapeshellarg($db) . ' --ip ' . $ipArg . ' country iso_code 2>/dev/null');
    $result = $empty;
    if ($lat !== null && preg_match('/(-?\d+\.\d+)/', $lat, $m)) $result['lat'] = (float) $m[1];
    if ($lon !== null && preg_match('/(-?\d+\.\d+)/', $lon, $m)) $result['lon'] = (float) $m[1];
    if ($cc !== null && preg_match('/"([A-Z]{2})"/', $cc, $m)) $result['cc'] = $m[1];
    return $cache[$ip] = $result;
}

// ASN lookup -- the "usual network" / "new device" proxy signal for
// login-anomaly scoring (IMAP/POP3 auth carries no browser user-agent, so
// there is no real device fingerprint available; ASN+/24 is the closest
// achievable substitute). Same shape as qa_ip_country() again.
function qa_ip_asn(string $ip): ?int {
    static $cache = [];
    if (array_key_exists($ip, $cache)) return $cache[$ip];
    $db = '/usr/share/GeoIP/GeoLite2-ASN.mmdb';
    if (!is_readable($db) || !filter_var($ip, FILTER_VALIDATE_IP)) return $cache[$ip] = null;
    $out = @shell_exec('mmdblookup --file ' . escapeshellarg($db)
                     . ' --ip ' . escapeshellarg($ip) . ' autonomous_system_number 2>/dev/null');
    return $cache[$ip] = ($out !== null && preg_match('/(\d+)/', $out, $m)) ? (int) $m[1] : null;
}

// The org NAME (e.g. "Google LLC"), not just the AS number -- for the
// login-anomaly notification email, a bare "AS15169" means nothing to a
// mailbox owner while "Google LLC" is at least recognizable. Separate call
// (not folded into qa_ip_asn()) since most callers only need the number.
function qa_ip_asn_org(string $ip): string {
    static $cache = [];
    if (isset($cache[$ip])) return $cache[$ip];
    $db = '/usr/share/GeoIP/GeoLite2-ASN.mmdb';
    if (!is_readable($db) || !filter_var($ip, FILTER_VALIDATE_IP)) return $cache[$ip] = '';
    $out = @shell_exec('mmdblookup --file ' . escapeshellarg($db)
                     . ' --ip ' . escapeshellarg($ip) . ' autonomous_system_organization 2>/dev/null');
    return $cache[$ip] = ($out !== null && preg_match('/"([^"]*)"/', $out, $m)) ? $m[1] : '';
}

function qa_country_flag(?string $cc, ?string $ip = null): string {
    $cc = strtoupper(trim((string) $cc));
    if (!preg_match('/^[A-Z]{2}$/', $cc)) return '';
    $name = '';
    if (class_exists('Locale')) {
        $name = (string) Locale::getDisplayRegion('-' . $cc, qa_lang());
    }
    if ($name === '' || $name === $cc) $name = $cc;
    $title = $name;
    if ($ip !== null && $ip !== '') $title .= ' — ' . $ip;
    // COOKIE_PATH-prefixed, matching every other asset reference in the app
    // (favicon, logo). A bare relative "assets/..." resolves against the
    // CURRENT URL, so it breaks the moment the console is opened without a
    // trailing slash -- the flags would 404 on /ilexa but work on /ilexa/.
    return '<img class="cc-flag" src="' . h(COOKIE_PATH) . 'assets/flags/' . strtolower($cc) . '.png"'
         . ' width="20" height="15" loading="lazy" alt="' . h($cc) . '"'
         . ' title="' . h($title) . '">';
}

// Format a number with the decimal separator the active language actually
// uses. Hungarian writes 0,683 and English 0.683; mixing them inside one
// sentence ("0,70 fölé ... Jelenleg 0.326") reads like a typo, which is
// exactly what the classifier panel did before this existed.
function qa_num(float $v, int $dec = 3): string {
    return qa_lang() === 'hu'
        ? number_format($v, $dec, ',', ' ')
        : number_format($v, $dec, '.', ',');
}

