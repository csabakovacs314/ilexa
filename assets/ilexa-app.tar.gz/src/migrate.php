<?php
// Migration framework core: file parsing, ledger read/pending computation,
// checksum-drift detection, and (given a DDL-capable PDO) application.
//
// Deliberately connection-agnostic -- every function takes a PDO as a
// parameter rather than opening its own, because the same logic serves two
// very different privilege contexts: the console's read-only status display
// (qaudit_ro via DB_CRED, SELECT-only on schema_migrations) and the root-run
// apply path (ilexa_mig via /etc/ilexa/secrets/db-migrate.php, DDL-capable
// on the allowlisted tables only -- see install/qa-db-migrate.php). Baking a
// connection in here would make it impossible to keep those two privilege
// levels apart, which is the entire point of having two credentials.
//
// See db/migrations/README.md for the file format, the atomicity rules
// (MySQL DDL is NOT transactional -- every statement must be individually
// idempotent), and why baselining works the way it does.

define('MIGRATIONS_DIR', __DIR__ . '/../db/migrations');
define('MIGRATION_STORES', ['mysql', 'iocs', 'logins']);

// mysql migrations may only touch these tables -- enforced here AND by
// tools/check-migrations.php. NOT postfix.last_login: that table belongs to
// Dovecot's last-login dict plugin (ilexa-installer/modules/25-dovecot.sh),
// not this app. A schema change there is out of scope by definition. This
// allowlist is also what makes the apply path's pre-migration mysqldump a
// SUFFICIENT rollback substrate -- widen it only with that in mind.
define('MIGRATION_MYSQL_TABLE_ALLOWLIST', ['archive_index', 'schema_migrations']);

// Parse every db/migrations/NNNN_*.sql file into [id => [...]]. Never throws
// on a malformed file -- returns it with a non-empty 'error' so the caller
// (lint, or the status page) can report it rather than crash the whole read.
function migration_files(string $dir = MIGRATIONS_DIR): array {
    $out = [];
    foreach (glob($dir . '/[0-9][0-9][0-9][0-9]_*.sql') ?: [] as $path) {
        $base = basename($path);
        if (!preg_match('/^(\d{4})_/', $base, $m)) continue;
        $id  = (int)$m[1];
        $raw = @file_get_contents($path);
        if ($raw === false) {
            $out[$id] = ['id' => $id, 'path' => $path, 'error' => 'unreadable'];
            continue;
        }
        $parsed = _migration_parse($raw);
        $parsed['id']       = $id;
        $parsed['path']     = $path;
        $parsed['checksum'] = hash('sha256', $raw);
        if ($parsed['id'] !== ($parsed['header']['ilexa-migration'] ?? null)) {
            $parsed['error'] = sprintf(
                'filename id %04d does not match header ilexa-migration: %s',
                $id, $parsed['header']['ilexa-migration'] ?? '(missing)'
            );
        }
        $out[$id] = $parsed;
    }
    ksort($out);
    return $out;
}

// Header + @UP/@DOWN split. Header lines are "-- key: value" before @UP;
// unrecognised keys are kept as-is (forward-compatible) rather than dropped.
function _migration_parse(string $raw): array {
    $upPos = stripos($raw, '-- @UP');
    if ($upPos === false) {
        return ['header' => [], 'up' => '', 'down' => '', 'error' => 'no -- @UP section'];
    }
    $headerText = substr($raw, 0, $upPos);
    $header = [];
    foreach (explode("\n", $headerText) as $line) {
        if (preg_match('/^--\s*([a-z-]+)\s*:\s*(.*)$/i', trim($line), $m)) {
            $key = strtolower($m[1]);
            $val = trim($m[2]);
            $header[$key] = ($key === 'ilexa-migration') ? (int)$val : $val;
        }
    }
    $downPos = stripos($raw, '-- @DOWN');
    if ($downPos !== false && $downPos > $upPos) {
        $up   = substr($raw, $upPos + 6, $downPos - $upPos - 6);
        $down = substr($raw, $downPos + 8);
    } else {
        $up   = substr($raw, $upPos + 6);
        $down = '';
    }
    return ['header' => $header, 'up' => trim($up), 'down' => trim($down), 'error' => ''];
}

// Split a section into [ ['guard' => ?string, 'sql' => string], ... ],
// one entry per terminated statement. Quote-aware only enough to not split
// inside a single-quoted SQL string literal (our migrations are plain DDL;
// this is not a general SQL parser and isn't trying to be one).
function migration_statements(string $section): array {
    $stmts = [];
    $buf = ''; $inStr = false; $pendingGuard = null;
    $lines = explode("\n", $section);
    foreach ($lines as $line) {
        $trimmed = trim($line);
        if ($trimmed === '') continue;
        if (preg_match('/^--\s*@GUARD:\s*(.+)$/i', $trimmed, $m)) {
            $pendingGuard = trim($m[1]);
            continue;
        }
        if (preg_match('/^--/', $trimmed) && !$inStr) continue; // plain comment line
        for ($i = 0, $n = strlen($line); $i < $n; $i++) {
            $ch = $line[$i];
            $buf .= $ch;
            if ($ch === "'" && ($i === 0 || $line[$i - 1] !== '\\')) $inStr = !$inStr;
            if ($ch === ';' && !$inStr) {
                $stmts[] = ['guard' => $pendingGuard, 'sql' => trim($buf)];
                $buf = ''; $pendingGuard = null;
            }
        }
        $buf .= "\n";
    }
    if (trim($buf) !== '') $stmts[] = ['guard' => $pendingGuard, 'sql' => trim($buf)];
    return $stmts;
}

// Guard vocabulary: table_exists(t) | column_exists(t,c) | index_exists(i),
// each optionally NOT-prefixed. Deliberately three predicates and no more --
// see db/migrations/README.md. $store is 'iocs'|'logins' (guards are a
// SQLite-only feature; mysql DDL uses IF NOT EXISTS instead and never needs
// a guard).
function migration_guard_eval(PDO $db, string $guard): bool {
    $negate = false;
    if (preg_match('/^NOT\s+(.+)$/i', $guard, $m)) { $negate = true; $guard = $m[1]; }
    $result = false;
    if (preg_match('/^table_exists\(\s*([A-Za-z0-9_]+)\s*\)$/i', $guard, $m)) {
        $st = $db->prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?");
        $st->execute([$m[1]]);
        $result = (bool)$st->fetchColumn();
    } elseif (preg_match('/^column_exists\(\s*([A-Za-z0-9_]+)\s*,\s*([A-Za-z0-9_]+)\s*\)$/i', $guard, $m)) {
        $cols = $db->query('PRAGMA table_info(' . $m[1] . ')')->fetchAll(PDO::FETCH_COLUMN, 1);
        $result = in_array($m[2], $cols, true);
    } elseif (preg_match('/^index_exists\(\s*([A-Za-z0-9_]+)\s*\)$/i', $guard, $m)) {
        $st = $db->prepare("SELECT 1 FROM sqlite_master WHERE type='index' AND name=?");
        $st->execute([$m[1]]);
        $result = (bool)$st->fetchColumn();
    } else {
        throw new RuntimeException("unrecognised guard predicate: $guard");
    }
    return $negate ? !$result : $result;
}

function migration_ensure_ledger_table(PDO $db, string $engine): void {
    if ($engine === 'mysql') {
        $db->exec("CREATE TABLE IF NOT EXISTS schema_migrations (
            id INT UNSIGNED NOT NULL PRIMARY KEY,
            applied_at BIGINT UNSIGNED NOT NULL,
            checksum CHAR(64) NOT NULL,
            duration_ms INT UNSIGNED,
            applied_by VARCHAR(64) NOT NULL DEFAULT ''
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
    } else {
        $db->exec("CREATE TABLE IF NOT EXISTS schema_migrations (
            id INTEGER NOT NULL PRIMARY KEY,
            applied_at INTEGER NOT NULL,
            checksum TEXT NOT NULL,
            duration_ms INTEGER,
            applied_by TEXT NOT NULL DEFAULT ''
        );");
    }
}

// [id => row] for one store. Assumes migration_ensure_ledger_table() already ran.
function migration_ledger(PDO $db): array {
    $out = [];
    foreach ($db->query('SELECT id, applied_at, checksum, duration_ms, applied_by FROM schema_migrations') as $row) {
        $out[(int)$row['id']] = $row;
    }
    return $out;
}

// Migrations for one store, in id order, not yet in that store's ledger.
function migration_pending(string $store, array $files, array $ledger): array {
    $out = [];
    foreach ($files as $id => $mig) {
        if (($mig['header']['store'] ?? '') !== $store) continue;
        if (isset($ledger[$id])) continue;
        $out[$id] = $mig;
    }
    ksort($out);
    return $out;
}

// A released (ledgered) migration whose on-disk checksum no longer matches
// what was recorded when it was applied -- i.e. it was edited after
// shipping. Hard-error condition, never silently ignored; see README.md.
function migration_checksum_drift(array $files, array $ledger): array {
    $drift = [];
    foreach ($ledger as $id => $row) {
        if (!isset($files[$id])) continue; // applied but file since removed -- also worth flagging, see caller
        if (($files[$id]['checksum'] ?? null) !== $row['checksum']) {
            $drift[$id] = ['expected' => $row['checksum'], 'actual' => $files[$id]['checksum']];
        }
    }
    return $drift;
}

// Apply one migration's @UP to $db. Never throws -- returns
// [ok, error, elapsed_ms] so a batch runner can decide whether to continue
// (mysql -- every statement idempotent, so continuing is safe) or stop
// (sqlite -- transactional, a failure has already rolled back).
function migration_apply_one(PDO $db, string $store, array $mig, bool $dryRun = false): array {
    $t0 = microtime(true);
    $stmts = migration_statements($mig['up']);
    try {
        $useTxn = ($store !== 'mysql'); // MySQL DDL implicit-commits; see README.md
        if ($useTxn) $db->beginTransaction();
        foreach ($stmts as $s) {
            if ($s['guard'] !== null && !migration_guard_eval($db, $s['guard'])) continue;
            if ($s['sql'] === '' || $s['sql'] === ';') continue;
            $db->exec(rtrim($s['sql'], "; \t\n"));
        }
        if ($dryRun) {
            if ($useTxn) $db->rollBack();
        } elseif ($useTxn) {
            $db->commit();
        }
        if (!$dryRun) {
            $ins = $db->prepare('INSERT INTO schema_migrations (id, applied_at, checksum, duration_ms, applied_by) VALUES (?,?,?,?,?)');
            $ins->execute([$mig['id'], time(), $mig['checksum'], (int)round((microtime(true) - $t0) * 1000), $mig['applied_by'] ?? 'update-apply']);
        }
        return [true, '', (int)round((microtime(true) - $t0) * 1000)];
    } catch (Throwable $e) {
        if (($useTxn ?? false) && $db->inTransaction()) { try { $db->rollBack(); } catch (Throwable $ig) {} }
        return [false, $e->getMessage(), (int)round((microtime(true) - $t0) * 1000)];
    }
}

// Apply every pending migration for one store, in order. Stops at the first
// failure -- see README.md: mysql statements are individually idempotent so
// a partial mysql failure is safely re-runnable later, but this function
// does not itself retry or skip ahead, that decision belongs to the caller.
function migration_apply_pending(PDO $db, string $store, array $pending, bool $dryRun = false): array {
    $results = [];
    foreach ($pending as $id => $mig) {
        [$ok, $err, $ms] = migration_apply_one($db, $store, $mig, $dryRun);
        $results[$id] = ['ok' => $ok, 'error' => $err, 'ms' => $ms];
        if (!$ok) break;
    }
    return $results;
}

// Read-only summary for the console's Rendszer page. $conns is
// ['mysql'=>?PDO, 'iocs'=>?PDO, 'logins'=>?PDO] -- a missing/null connection
// for a store renders that store as 'unknown', never as an error, since
// qaudit_ro genuinely cannot always reach every store (e.g. sqlite files not
// yet created on a very fresh install).
function migration_status(array $conns, string $dir = MIGRATIONS_DIR): array {
    $files = migration_files($dir);
    $out = [];
    foreach (MIGRATION_STORES as $store) {
        $db = $conns[$store] ?? null;
        if (!$db instanceof PDO) {
            $out[$store] = ['ok' => false, 'reason' => 'no_connection'];
            continue;
        }
        try {
            $ledger  = migration_ledger($db);
            $pending = migration_pending($store, $files, $ledger);
            $drift   = migration_checksum_drift(
                array_filter($files, fn($f) => ($f['header']['store'] ?? '') === $store),
                $ledger
            );
            $out[$store] = [
                'ok' => true,
                'applied_count' => count($ledger),
                'latest_applied' => $ledger ? max(array_keys($ledger)) : 0,
                'pending' => array_keys($pending),
                'drift' => $drift,
            ];
        } catch (Throwable $e) {
            $out[$store] = ['ok' => false, 'reason' => $e->getMessage()];
        }
    }
    return $out;
}
