<?php
// Role-based access control.
//
// roles.json doesn't exist  →  everyone is 'admin' (backward compat, no RBAC yet).
// roles.json exists         →  user must be listed; unknown users fall back to 'viewer'.
//
// Roles and their permitted actions:
//   admin        - everything, including the Admin tab and user management
//   operator     - take actions (release/delete/train/block/whitelist), view archive; NO admin tab
//   viewer       - read-only: see spam queue and archive, no buttons
//   domain_admin - operator-level but restricted to their assigned domain(s)

// i18n-deferred-start -- translated at render, views/layout_header.php:7
const ROLE_LABELS = [
    'admin'        => 'Admin',
    'operator'     => 'Operátor',
    'viewer'       => 'Megfigyelő',
    'domain_admin' => 'Domain-admin',
];
// i18n-deferred-end

const ROLE_PERMS = [
    'admin'        => ['view', 'action', 'train', 'lists', 'archive', 'admin'],
    'operator'     => ['view', 'action', 'train', 'lists', 'archive'],
    'viewer'       => ['view'],
    'domain_admin' => ['view', 'action', 'train', 'lists'],
];

// ── roles.json helpers ────────────────────────────────────────────────────────

function rbac_all(): array {
    if (!is_file(ROLES_FILE)) return [];
    $raw = json_decode(file_get_contents(ROLES_FILE), true);
    return is_array($raw) ? $raw : [];
}

function rbac_save(array $data): bool {
    $tmp = tempnam(dirname(ROLES_FILE), '.roles-');
    if ($tmp === false) return false;
    if (file_put_contents($tmp, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) === false) {
        @unlink($tmp); return false;
    }
    @chmod($tmp, 0600);
    return rename($tmp, ROLES_FILE);
}

// Serialises read-modify-write on roles.json. LOCK_EX on the write alone lets
// two concurrent role edits each read the old file and the later write win,
// discarding the other change.
function rbac_with_lock(callable $fn) {
    $lock = fopen(ROLES_FILE . '.lock', 'c');
    if ($lock === false) return $fn();
    @chmod(ROLES_FILE . '.lock', 0600);
    flock($lock, LOCK_EX);
    try { return $fn(); }
    finally { flock($lock, LOCK_UN); fclose($lock); }
}

// ── Current request identity ──────────────────────────────────────────────────

function qa_user(): string {
    return $_SERVER['REMOTE_USER'] ?? '';
}

function qa_role(): string {
    $all = rbac_all();
    if (empty($all)) return 'admin';   // no RBAC configured yet
    return $all[qa_user()]['role'] ?? 'viewer';
}

function qa_domains(): array {
    $all = rbac_all();
    return $all[qa_user()]['domains'] ?? [];
}

// ── Fail closed ───────────────────────────────────────────────────────────────
// The app takes its identity from Apache. If Apache auth is ever off or
// misconfigured, REMOTE_USER is empty -- and because an absent roles.json means
// "everyone is admin" (see above), an anonymous request would otherwise arrive
// with full admin rights. Refuse to run at all without an authenticated identity.
function qa_require_auth(): void {
    if (qa_user() !== '') return;
    http_response_code(401);
    header('WWW-Authenticate: Basic realm="Quarantine Admin"');
    header('Content-Type: text/plain; charset=utf-8');
    exit("401 Unauthorized - authentication required.\n");
}

// Domain-admins may only touch mailboxes in their assigned domains. This is the
// server-side counterpart to the UI's domain filter; the UI filter alone is not
// an authorization control.
function qa_domain_allowed(string $mailbox): bool {
    if (qa_role() !== 'domain_admin') return true;
    $at = strrpos($mailbox, '@');
    if ($at === false) return false;
    return in_array(strtolower(substr($mailbox, $at + 1)), array_map('strtolower', qa_domains()), true);
}

// ── Permission check ──────────────────────────────────────────────────────────

function can(string $perm): bool {
    $role  = qa_role();
    $perms = ROLE_PERMS[$role] ?? ['view'];
    return in_array($perm, $perms, true);
}

// ── Message-content viewing policy (GDPR) ────────────────────────────────────
// Site-wide, admin-settable: may content be opened/resent/bulk-exported at all?
// Stored in its own file next to the language setting, deliberately mirroring
// qa_lang()/qa_lang_set() -- settings.json is int-only by signature
// (admin_settings_save(string, int)) and its bootstrap whitelist is
// security-relevant, so an enum string does not belong there.
//
// FAIL CLOSED: absent, unreadable, empty, or invalid all resolve to 'none'.
// That is the security property -- the feature must not be defeatable by
// deleting or corrupting a file.
const VIEW_POLICIES = ['none', 'spam', 'all'];

function view_policy_file(): string {
    return dirname(SETTINGS_FILE) . '/view_policy';
}

function qa_view_policy(): string {
    static $p = null;
    if ($p !== null) return $p;
    $p = 'none';
    $f = view_policy_file();
    if (is_file($f)) {
        $v = strtolower(trim((string) @file_get_contents($f)));
        if (in_array($v, VIEW_POLICIES, true)) $p = $v;
    }
    return $p;
}

function qa_view_policy_set(string $p): array {
    if (!in_array($p, VIEW_POLICIES, true)) return [false, t('Ismeretlen beállítás.')];
    $ok = qa_atomic_write(view_policy_file(), $p);
    return [$ok, $ok ? '' : t('Nem sikerült írni: ') . view_policy_file()];
}

// The policy is a CEILING, never a grant: callers keep their own can() check
// and add this one. qa_view_allowed() can only ever remove access.
function qa_view_allowed(bool $isArchive): bool {
    $p = qa_view_policy();
    if ($p === 'all')  return true;
    if ($p === 'spam') return !$isArchive;
    return false;
}

// ── Password-expiry enforcement master switch ────────────────────────────────
// Paused as a project (2026-08-23) but deliberately not ripped out: the
// backfilled password_expiry data (see zany-napping-sunrise.md, Phase 0),
// the Roundcube password_expiry plugin, and the qa-password-expiry-notify.php
// cron job all stay in place -- this is the single switch that makes every
// one of them a no-op instead. Re-enabling later is flipping one file back
// to '1', not re-implementing anything.
//
// Same file-based pattern as qa_view_policy() above, for the same reason
// (an enum/bool doesn't belong in settings.json's int-only slots) --
// FAIL CLOSED to disabled: absent, unreadable, or anything other than
// exactly '1' all resolve to off. A feature whose failure mode is locking
// someone out must default to inert when misconfigured, not active.
//
// Read directly (file, not this function) by two OTHER things that must
// make the same decision without a PHP/DB dependency: the Roundcube plugin
// (assets/roundcube-password-expiry/password_expiry.php) and the notifier
// cron script (install/qa-password-expiry-notify.php) both check this exact
// path themselves. If the path here ever changes, update those two too.
function password_expiry_enabled_file(): string {
    return dirname(SETTINGS_FILE) . '/password_expiry_enabled';
}

function qa_password_expiry_enabled(): bool {
    $f = password_expiry_enabled_file();
    if (!is_file($f)) return false;
    return trim((string) @file_get_contents($f)) === '1';
}

function qa_password_expiry_enabled_set(bool $on): array {
    $ok = qa_atomic_write(password_expiry_enabled_file(), $on ? '1' : '0');
    return [$ok, $ok ? '' : t('Nem sikerült írni: ') . password_expiry_enabled_file()];
}
