<?php
// SHA256 hash export + bulk import for the IOC store (docs/superpowers/
// specs/2026-08-11-ioc-hash-export-import-design.md). Token/IP-allowlist
// config for the unauthenticated pull endpoint (export-hashes.php) lives in
// a small JSON file next to settings.json -- read/write helpers here,
// HTTP-facing code lives in export-hashes.php and the
// handle_export()/handle_admin_post() dispatchers.

function _ioc_export_config_path(): string {
    return dirname(SETTINGS_FILE) . '/ioc_export.json';
}

// Fails closed: an absent/unreadable/malformed config means the pull
// endpoint accepts nothing, never "accepts everything". @-suppressed:
// file_get_contents() on an unreadable-but-present file emits an
// unsuppressed E_WARNING otherwise -- on export-hashes.php, an
// unauthenticated public endpoint, that warning (if display_errors is on)
// would print before the 403 headers are sent, degrading the denial to a
// 200 that discloses the config file's path. @chmod() below already
// follows this same suppression convention.
function _ioc_export_config(): array {
    $path = _ioc_export_config_path();
    if (!is_file($path)) return ['token' => '', 'allowed_ips' => []];
    $raw = json_decode((string) @file_get_contents($path), true);
    if (!is_array($raw)) return ['token' => '', 'allowed_ips' => []];
    return [
        'token' => is_string($raw['token'] ?? null) ? $raw['token'] : '',
        'allowed_ips' => is_array($raw['allowed_ips'] ?? null)
            ? array_values(array_filter($raw['allowed_ips'], 'is_string'))
            : [],
    ];
}

// Atomic tempfile-then-rename, same pattern rbac_save() already uses in
// src/rbac.php for roles.json -- a bare file_put_contents() with LOCK_EX
// on the write alone still lets a concurrent reader observe a truncated
// file mid-write (LOCK_EX blocks other WRITERS, not readers who never
// request a lock), which for THIS file specifically is worse than usual:
// a reader that sees a truncated file gets token="" back from
// _ioc_export_config(), and if that reader is itself a subsequent
// allowlist add/remove, it will write that empty token back out,
// silently destroying the credential while every caller still reports
// success.
function _ioc_export_write(array $cfg): bool {
    $path = _ioc_export_config_path();
    $tmp = tempnam(dirname($path), '.ioc-export-');
    if ($tmp === false) return false;
    if (file_put_contents($tmp, json_encode($cfg, JSON_PRETTY_PRINT)) === false) {
        @unlink($tmp); return false;
    }
    @chmod($tmp, 0600);
    return rename($tmp, $path);
}

// Serialises read-modify-write on ioc_export.json -- same rationale as
// rbac_with_lock() in src/rbac.php, which this is a direct copy of:
// atomic rename alone still lets two concurrent admin actions (e.g. two
// browser tabs) each read the old file and the later write win,
// discarding the other change. The lock file lives next to the config
// file it protects, mirroring ROLES_FILE . '.lock' in src/rbac.php.
function _ioc_export_with_lock(callable $fn) {
    $lockPath = _ioc_export_config_path() . '.lock';
    $lock = fopen($lockPath, 'c');
    if ($lock === false) return $fn();
    @chmod($lockPath, 0600);
    flock($lock, LOCK_EX);
    try { return $fn(); }
    finally { flock($lock, LOCK_UN); fclose($lock); }
}

// Returns [string $token, bool $ok]. $ok reflects whether the new token
// was actually persisted to disk -- a caller that discards this cannot
// tell a successful rotation from a failed write that silently leaves
// the OLD token live while the admin believes they just rotated it (a
// credential-rotation control where belief and reality can diverge is
// worse than one that just fails loudly).
function ioc_export_token_regenerate(): array {
    return _ioc_export_with_lock(function () {
        $token = bin2hex(random_bytes(32));
        $cfg = _ioc_export_config();
        $cfg['token'] = $token;
        $ok = _ioc_export_write($cfg);
        return [$token, $ok];
    });
}

function ioc_export_allowlist_add(string $ip): array {
    $ip = trim($ip);
    if (filter_var($ip, FILTER_VALIDATE_IP) === false) {
        return [false, t('Érvénytelen IP-cím.')];
    }
    return _ioc_export_with_lock(function () use ($ip) {
        $cfg = _ioc_export_config();
        if (in_array($ip, $cfg['allowed_ips'], true)) return [true, ''];
        $cfg['allowed_ips'][] = $ip;
        $ok = _ioc_export_write($cfg);
        return [$ok, $ok ? '' : t('Nem sikerült írni a konfigurációt.')];
    });
}

function ioc_export_allowlist_remove(string $ip): bool {
    return _ioc_export_with_lock(function () use ($ip) {
        $cfg = _ioc_export_config();
        $cfg['allowed_ips'] = array_values(array_filter(
            $cfg['allowed_ips'], fn($x) => $x !== $ip));
        return _ioc_export_write($cfg);
    });
}

// Whether $remoteAddr may fetch the automated pull endpoint with $token.
// Both the token and the IP must match -- the caller must treat a false
// return identically regardless of which check failed (no "wrong IP" vs
// "wrong token" distinction in the HTTP response, so probing can't narrow
// down which half is right).
function ioc_export_pull_allowed(string $token, string $remoteAddr): bool {
    $cfg = _ioc_export_config();
    if ($cfg['token'] === '' || $token === '') return false;
    if (!hash_equals($cfg['token'], $token)) return false;
    return in_array($remoteAddr, $cfg['allowed_ips'], true);
}

// Active, 64-hex-char (SHA256-shape) hash-type IOC values. Filtered in PHP,
// not SQL -- SQLite has no built-in regex operator, and _ioc_valid_value()
// already validates hash shape in PHP, so this matches that convention
// rather than adding a SQLite extension dependency for one query.
function ioc_export_hashes_csv(): array {
    $stmt = _ioc_db()->query("SELECT value FROM iocs WHERE type = 'hash' AND active = 1");
    $out = [];
    foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $v) {
        if (strlen($v) === 64 && ctype_xdigit($v)) $out[] = $v;
    }
    return $out;
}

// Splits pasted text on newlines/commas/whitespace, validates each token
// via the same _ioc_valid_value('hash', ...) the single-add form already
// uses (accepting MD5/SHA1/SHA256, not just SHA256 -- that restriction is
// export-only), adds each via ioc_add(). One bad line never rejects the
// whole paste -- it's tallied as invalid and skipped. A value already
// active is tallied as duplicate; a value that's new or was previously
// expired (inactive) is tallied as added, since ioc_add()'s upsert
// reactivates it -- that's a real state change, not a no-op.
//
// Deliberately does NOT lowercase the token before comparing/storing.
// ioc_add()'s dedup relies on iocs' UNIQUE(type, value) constraint, which
// is case-sensitive by default in SQLite -- and the pre-existing manual
// single-add path (views/ioc.php's add-indicator form -> handle_ioc_action()
// case 'ioc_add') stores whatever case the admin typed, unnormalized. An
// earlier draft of this function lowercased here, which meant a hash
// pasted in different case than an already-stored manual entry silently
// inserted a SECOND active row for the same real-world hash (ioc_add()'s
// ON CONFLICT never fired, since the differently-cased value didn't match
// the unique index) -- both the SELECT-before-insert duplicate check above
// and the final tally would then also disagree with what actually landed
// in the table. Passing the token through unchanged makes this function's
// dedup behavior identical to the manual path's: exact-string match, no
// surprise normalization invented for one entry point but not the other.
function ioc_bulk_import_hashes(string $raw, string $confidence, string $addedBy): array {
    $tokens = preg_split('/[\s,]+/', trim($raw), -1, PREG_SPLIT_NO_EMPTY);
    $seen = [];
    $added = 0; $duplicate = 0; $invalid = 0;
    foreach ($tokens as $tok) {
        $v = trim($tok);
        if ($v === '' || isset($seen[$v])) continue;
        $seen[$v] = true;
        if (!_ioc_valid_value('hash', $v)) { $invalid++; continue; }

        $existingStmt = _ioc_db()->prepare('SELECT active FROM iocs WHERE type = :t AND value = :v');
        $existingStmt->execute([':t' => 'hash', ':v' => $v]);
        $wasActive = $existingStmt->fetchColumn();

        [$ok] = ioc_add([
            'type' => 'hash', 'value' => $v, 'source' => 'bulk-import',
            'confidence' => $confidence, 'added_by' => $addedBy,
        ]);
        if (!$ok) { $invalid++; continue; }

        if ($wasActive !== false && (int) $wasActive === 1) $duplicate++;
        else $added++;
    }
    return ['added' => $added, 'duplicate' => $duplicate, 'invalid' => $invalid];
}
