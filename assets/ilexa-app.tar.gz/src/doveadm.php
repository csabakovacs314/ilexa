<?php
// All doveadm access goes through the root-owned gateway, which decides the
// command shape itself. Nothing here can add options or reach another folder.
// Same gateway call, but reports whether it exited 0 -- used where the caller
// must know if the mailbox actually changed (release/delete).
function qa_da_ok(array $args): bool {
    $cmd = SUDO . ' ' . QA_DOVEADM;
    foreach ($args as $a) $cmd .= ' ' . escapeshellarg((string)$a);
    $rc = 1;
    @exec($cmd . ' 2>/dev/null', $out, $rc);
    return $rc === 0;
}

// Records that a gateway call FAILED (non-zero exit), so the request can tell
// the operator instead of rendering a failure as "no mail found". Same
// accumulate-then-report shape as qa_fetch_dropped_uids() below: static, so it
// collects across every qa_da() call in this request and starts empty on the
// next one. Call with no argument to read.
//
// Why this exists: qa_da() returns '' both when a search legitimately matched
// nothing and when the doveadm gateway blew up, and every caller treated the
// two identically. The 2026-08-13 /dev/null incident is the worst version of
// this -- a chmod on /dev/null broke every `2>/dev/null` shell-out for apache
// and the console answered HTTP 200 with an empty result set, giving the
// operator no signal at all that nothing was actually being searched.
function qa_da_failures(array $add = []): array {
    static $all = [];
    foreach ($add as $f) $all[(string)$f] = true;
    return array_keys($all);
}

// $ok is set to false when the gateway exits non-zero. Existing callers that
// omit it behave exactly as before -- '' on failure -- but the failure is now
// recorded for the banner and error_log()'d either way.
function qa_da(array $args, ?bool &$ok = null): string {
    $cmd = SUDO . ' ' . QA_DOVEADM;
    foreach ($args as $a) $cmd .= ' ' . escapeshellarg((string)$a);
    // proc_open, NOT exec(): shell_exec() discards the exit status (the whole
    // reason a failure was indistinguishable from an empty result), but exec()
    // cannot be used either -- it splits output into lines and trims trailing
    // whitespace from each, and doveadm's record separator is a line
    // containing ONLY a form feed, which is whitespace. exec() silently turns
    // that into an empty line, parse_fetch() skips empty lines, and every
    // message in a fetch batch then merges into a single record (write-once
    // fields mean only the first uid/From/Subject survives) -- i.e. a
    // multi-message folder would render as one message. Verified by diffing
    // exec() against shell_exec() on a fixture containing a \f separator
    // before this shipped.
    //
    // stderr still goes to /dev/null -- it can carry mailbox paths and is not
    // something to surface to a web user -- but the status is kept.
    $rc   = 1;
    $body = '';
    $proc = @proc_open($cmd . ' 2>/dev/null',
        [1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes);
    if (is_resource($proc)) {
        $body = (string) stream_get_contents($pipes[1]);
        fclose($pipes[1]);
        if (isset($pipes[2])) fclose($pipes[2]);
        $rc = proc_close($proc);
    }
    $ok = ($rc === 0);
    if (!$ok) {
        $what = (string)($args[0] ?? '?');
        qa_da_failures([$what]);
        error_log('qa_da(): doveadm gateway exited ' . $rc . ' for "' . $what
            . '" -- returning empty; callers must not read this as "no mail found"');
    }
    return $body;
}

// Cached list of all mail users. `doveadm user '*'` is cheap (~0.2s) but called
// several times per request; cache to a file (short TTL) plus a per-request memo.
function all_users(): array {
    static $memo = null;
    if ($memo !== null) return $memo;

    if (is_readable(USER_CACHE) && (time() - (int)@filemtime(USER_CACHE)) < USER_CACHE_TTL) {
        $data = json_decode((string)@file_get_contents(USER_CACHE), true);
        if (is_array($data)) return $memo = $data;
    }

    $ok    = null;
    $out   = qa_da(['users'], $ok);
    $users = array_values(array_filter(
        array_map('trim', explode("\n", trim((string)$out))),
        fn($u) => $u !== '' && strpos($u, '@') !== false && $u !== 'postfix'
    ));
    sort($users);
    // Never cache a failed or empty lookup. This was the amplifier: one
    // transient gateway failure wrote an EMPTY user list to USER_CACHE, and
    // every request for the next USER_CACHE_TTL (300s) then read that empty
    // list from cache -- so the console kept showing no users, no domains and
    // no mail for five minutes after the gateway had already recovered, with
    // nothing anywhere saying why. A stale-but-real cache is strictly better
    // than a poisoned one, so on failure fall back to whatever is on disk
    // regardless of age.
    if (!$ok || !$users) {
        $stale = json_decode((string)@file_get_contents(USER_CACHE), true);
        if (is_array($stale) && $stale) {
            error_log('all_users(): gateway returned no usable list — serving the last known cache ('
                . count($stale) . ' users) rather than caching an empty one');
            return $memo = $stale;
        }
        return $memo = $users;   // nothing better to offer; do NOT write it
    }
    @file_put_contents(USER_CACHE, json_encode($users), LOCK_EX);
    @chmod(USER_CACHE, 0600);
    return $memo = $users;
}

function get_domains(): array {
    $domains = [];
    foreach (all_users() as $u) {
        if (($at = strpos($u, '@')) !== false) {
            $domains[substr($u, $at + 1)] = true;
        }
    }
    ksort($domains);
    return array_keys($domains);
}

function get_users(string $domain = ''): array {
    $users = all_users();
    if ($domain) {
        $users = array_filter($users, fn($u) => str_ends_with($u, '@' . $domain));
    }
    return array_values($users);
}

// Search ALL users at once (doveadm search -A) for one folder.
// Returns [ user => [uid, uid, ...] ]. One process instead of one-per-user.
function search_all(string $folder, string $since, string $before): array {
    $raw = qa_da(['search-all', $folder, $since ? imap_date($since) : '', $before ? imap_date($before) : '']);
    $map = [];
    foreach (explode("\n", trim($raw)) as $line) {
        // -A output format: "<user> <guid> <uid>"
        $parts = preg_split('/\s+/', trim($line));
        if (count($parts) >= 2 && strpos($parts[0], '@') !== false && ctype_digit(end($parts))) {
            $map[$parts[0]][] = end($parts);
        }
    }
    return $map;
}

// Records drops made by qa_fetch_sane_records() (duplicate uid within one
// doveadm fetch batch -- see that function's header comment for why they're
// dropped) so the request can show the operator a warning instead of only
// error_log()'ing invisibly. Call with no argument to read the accumulated
// list; call with a batch to add to it. Static, so it accumulates across
// every fetch_uids() call made during this request (index.php's
// per-folder/per-user search loop calls it many times) and starts empty
// again on the next request -- the same per-request-only assumption
// $orderWarned in parse_fetch() already relies on.
//
// Entries are "user|folder|uid", NOT a bare uid: uids are only unique
// *within one mailbox*. Two unrelated drops in two different users'
// mailboxes that happen to share a uid number are an ordinary coincidence,
// not an attack precondition, and keying on the bare uid would silently
// collapse them into one entry -- undercounting real drops and making the
// report unusable (an admin can't act on "UID 911" alone across 20+
// mailboxes). qa_fetch_dropped_display() renders these back out.
function qa_fetch_dropped_uids(array $add = []): array {
    static $all = [];
    foreach ($add as $tag) {
        $all[(string)$tag] = true;
    }
    return array_keys($all);
}

// Turns qa_fetch_dropped_uids()'s "user|folder|uid" tags into a short,
// admin-actionable string for the notice banner (index.php).
function qa_fetch_dropped_display(array $tags): string {
    return implode(', ', array_map(function (string $tag): string {
        [$user, $folder, $uid] = array_pad(explode('|', $tag, 3), 3, '?');
        return "$user/$folder: $uid";
    }, $tags));
}

// Filters a parse_fetch() result down to records that can be trusted to
// correspond 1:1 with the uids actually requested.
//
// Defence in depth against a residual edge of the parse_fetch() hardening:
// a raw \f byte inside a forged Received header (fully sender-controlled
// text) would still read as doveadm's own record separator, ending a record
// early and letting the rest of the attacker's text be key-parsed into a
// fresh, spurious record with an attacker-chosen uid. parse_fetch() alone
// cannot tell that text apart from real doveadm output once a separator has
// been seen.
//
// A membership filter alone is NOT enough: a phantom can forge a uid that
// IS in the batch, producing two records for the same uid -- one genuine,
// one fully attacker-controlled (From/Subject/Date). Because release/delete
// act on a row's real uid, not its displayed text, an admin fooled by a
// plausible-looking duplicate could act on the wrong message.
//
// Keeping only the "first" occurrence of a duplicated uid is NOT safe
// either: doveadm streams records in the order uids were requested, and a
// phantom is emitted wherever its host message's own record falls in that
// order -- which can be BEFORE the real record for the uid it forges (e.g.
// a low-uid attacker message forging a higher uid still in the same
// batch). Keep-first would then keep the forgery and silently discard the
// genuine row -- worse than doing nothing.
//
// So: any uid that appears more than once in the batch is untrustworthy in
// its entirety -- every record sharing that uid is dropped (fail closed;
// the admin sees nothing for that message rather than an ambiguous or
// wrong one). This precondition (a literal form-feed surviving intact
// inside a header field, through Postfix -> Dovecot -> doveadm) has not
// been reproduced against a real mailbox as of this writing.
function qa_fetch_sane_records(array $records, array $uids): array {
    $records = array_values(array_filter(
        $records,
        fn($m) => in_array($m['uid'] ?? null, $uids, true)
    ));

    $counts = [];
    foreach ($records as $m) {
        $counts[$m['uid']] = ($counts[$m['uid']] ?? 0) + 1;
    }
    // array_keys() on a numeric-string-keyed array returns ints (PHP casts
    // '11' => 11 as an array key), so cast back to string -- otherwise the
    // strict in_array() below never matches and every duplicate silently
    // survives the "fail closed" filter it's supposed to enforce.
    $dupes = array_map('strval', array_keys(array_filter($counts, fn($c) => $c > 1)));
    if ($dupes) {
        error_log('qa_fetch_sane_records: duplicate uid(s) in doveadm fetch output ('
            . implode(',', $dupes) . ') -- dropping all matching records (possible forged header)');
        // Tag every dropped record with its own user/folder (set on each
        // record by parse_fetch(), never attacker-controlled) -- not just
        // the bare uid -- so qa_fetch_dropped_uids() can't conflate two
        // unrelated drops in different mailboxes that happen to share a
        // uid number.
        $tags = [];
        foreach ($records as $m) {
            if (in_array($m['uid'], $dupes, true)) {
                $tags[] = ($m['user'] ?? '?') . '|' . ($m['folder'] ?? '?') . '|' . $m['uid'];
            }
        }
        qa_fetch_dropped_uids($tags);
        return array_values(array_filter($records, fn($m) => !in_array($m['uid'], $dupes, true)));
    }
    return $records;
}

// Fetch + parse a known set of uids for one user/folder.
function fetch_uids(string $user, string $folder, array $uids): array {
    if (!$uids) return [];
    // Neither caller of fetch_uids() (fetch_folder()'s search-user parse,
    // or search_all()'s per-user uid list) dedupes its uid list before
    // building it. Without this, a duplicate in the REQUEST would also be a
    // duplicate uid in the doveadm response for a completely benign reason,
    // and qa_fetch_sane_records()'s fail-closed duplicate handling would
    // then drop a genuine message from view while logging a misleading
    // "possible forged header" alarm. Deduping the request first makes any
    // duplicate uid seen in the *response* unconditionally anomalous.
    $uids = array_values(array_unique($uids));
    $raw  = qa_da(['fetch-headers', $user, $folder, implode(',', $uids)]);
    return qa_fetch_sane_records(parse_fetch($raw, $user, $folder), $uids);
}

// Fetch messages for one specific user/folder (per-user search path).
function fetch_folder(string $user, string $folder, string $since, string $before): array {
    $raw_uids = qa_da(['search-user', $user, $folder, $since ? imap_date($since) : '', $before ? imap_date($before) : '']);
    if (!trim($raw_uids)) return [];

    $uids = [];
    foreach (explode("\n", trim($raw_uids)) as $line) {
        $parts = preg_split('/\s+/', trim($line));
        if (count($parts) >= 2 && ctype_digit(end($parts))) {
            $uids[] = end($parts);
        }
    }
    return fetch_uids($user, $folder, $uids);
}

// Parse multi-record doveadm fetch output.
//
// doveadm separates records with a form-feed-only line (\f\n), not a blank
// line -- verified by hexdump against real captured output. The separator is
// matched explicitly here so a whitespace-only header fold can never be
// mistaken for one (it used to work only because rtrim() happened to strip
// \x0C to '').
//
// When 'hdr.received' is requested it must be the LAST field in the fetch
// list. doveadm prefixes only the *first* Received: occurrence with
// 'hdr.received: '; every later occurrence in the same message is emitted as
// a bare, fully sender-controlled line at column 0, indistinguishable from a
// 'key: value' field line. Once that key is seen, every following line is
// consumed without key-parsing until the record separator -- this is what
// stops a forged header like "Received: uid: 999999" from clobbering $cur.
// Only the first occurrence's own line plus its TAB-indented continuation
// lines are kept; a bare column-0 line ends the appending (but the record
// stays out of key-parsing until the separator).
//
// A small key allowlist + write-once rule is kept as defence in depth, and
// it also stops the current parser's habit of manufacturing junk keys out of
// continuation lines that happen to contain "key: value"-shaped text (e.g. a
// timestamp fold like "13:25:19").
function parse_fetch(string $raw, string $user, string $folder): array {
    $messages = [];
    $cur      = ['user' => $user, 'folder' => $folder];
    $allowed  = ['uid' => true, 'hdr_from' => true, 'hdr_subject' => true,
                 'date_received' => true, 'hdr_received' => true];

    // True from the hdr.received line until the record separator: no line in
    // this window is ever key-parsed again.
    $inReceived = false;
    // True only while still within the first Received block's own lines
    // (its 'hdr.received:' line and TAB continuations); false once the first
    // bare column-0 line (the second occurrence, or an attacker's fake one)
    // is seen.
    $appending = false;
    // Set once hdr_received is seen for the current record, and never
    // cleared for that record -- tracked separately from
    // isset($cur['hdr_received']) so the field-order guard below keeps
    // working even if a later caller unset()s that key after extracting
    // something from it.
    $sawReceived = false;

    // Field-order guard: hdr.received must be requested LAST in the doveadm
    // wrapper's field list (install/qa-doveadm.sh, a different, root-owned
    // file outside this repo's normal review path). If it isn't, every
    // field after it is silently dropped for the rest of that record by the
    // state machine below -- with no error. error_log() once per request
    // (static, since this function runs once per user/folder and a local
    // flag would still emit one line per user on a real regression) so a
    // future edit to that wrapper's field order fails loudly instead of
    // silently blanking From/Subject/Date across the whole quarantine view.
    static $orderWarned = false;

    $finalize = function () use (&$messages, &$cur, &$sawReceived, &$orderWarned) {
        if (!isset($cur['uid'])) {
            return;
        }
        if ($sawReceived && !$orderWarned
            && (!isset($cur['hdr_from']) || !isset($cur['hdr_subject']) || !isset($cur['date_received']))) {
            $orderWarned = true;
            error_log('parse_fetch(): a record with hdr_received is missing hdr_from/hdr_subject/'
                . 'date_received -- hdr.received is likely no longer last in the doveadm fetch field '
                . 'list (install/qa-doveadm.sh); later fields are being silently dropped.');
        }
        // Derive the trustworthy sender IP from the topmost Received: block,
        // which is all $cur['hdr_received'] ever holds (the state machine
        // above stops appending at the first bare column-0 line, i.e. the
        // second Received: occurrence or an attacker's forged one).
        //
        // Pass it RAW -- do NOT unfold. An earlier version joined every
        // continuation line onto one line before scanning, reasoning that
        // hdr_received holds only the topmost, Postfix-written block. That
        // reasoning missed that Postfix's OWN cleanup process folds a
        // message's first DATA line onto this same header (as an ordinary
        // continuation line) whenever that line starts with a space or TAB
        // -- with no authentication and no exotic HELO/RCPT needed, just an
        // unlucky first body line. Unfolding placed that attacker-authored
        // line after Postfix's own client-IP group, and "last bracket on
        // the line" then returned it. qa_topmost_received_client_ip() scans
        // ONLY physical line 1, which is exactly the single record smtpd
        // itself writes ("from %s (%s [%s])") and never a fold target --
        // see that function's doc comment for the full account and the
        // corpus measurement backing "line 1 only" over "unfold and scan
        // everything". Never reintroduce an unfold here.
        //
        // Then discard the raw text: keeping it around would turn the ~3x
        // doveadm output growth from hdr.received into a ~3x growth of the
        // in-memory $results array index.php builds for every matching
        // message before paging.
        $cur['sender_ip'] = qa_topmost_received_client_ip((string)($cur['hdr_received'] ?? ''));
        unset($cur['hdr_received']);
        $messages[] = $cur;
    };

    foreach (explode("\n", $raw) as $line) {
        // Record separator: a line that is only a form feed (with an
        // optional trailing CR), checked before any trimming of the line
        // content so a whitespace-only fold can't be mistaken for it.
        if (rtrim($line, "\r") === "\f") {
            $finalize();
            $cur         = ['user' => $user, 'folder' => $folder];
            $inReceived  = false;
            $appending   = false;
            $sawReceived = false;
            continue;
        }

        $trimmed = rtrim($line, " \t\r\0\x0B\x0C");
        if ($trimmed === '') {
            continue;
        }

        if ($inReceived) {
            // RFC 5322 folding allows either SP or HTAB; the real fixture
            // happens to be all-TAB, but don't assume that holds generally.
            if ($appending && $line !== '' && ($line[0] === "\t" || $line[0] === ' ')) {
                $cur['hdr_received'] .= "\n" . $trimmed;
            } else {
                $appending = false;
            }
            continue;
        }

        if (preg_match('/^([^:]+):\s*(.*)$/', $trimmed, $m)) {
            $key = strtolower(str_replace(['.', 'hdr.'], ['_', ''], $m[1]));
            if (isset($allowed[$key]) && !isset($cur[$key])) {
                $cur[$key] = $m[2];
                if ($key === 'hdr_received') {
                    $inReceived  = true;
                    $appending   = true;
                    $sawReceived = true;
                }
            }
        }
    }
    $finalize();
    return $messages;
}
