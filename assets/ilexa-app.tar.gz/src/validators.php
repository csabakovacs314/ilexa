<?php
function valid_user(string $s): bool {
    return (bool) preg_match('/^[a-zA-Z0-9._%+\-@]+$/', $s) && strlen($s) <= 120;
}
function valid_domain(string $s): bool {
    return (bool) preg_match('/^[a-zA-Z0-9.\-]+$/', $s) && strlen($s) <= 80;
}
function valid_date(string $s): bool {
    return (bool) preg_match('/^\d{4}-\d{2}-\d{2}$/', $s) && strtotime($s) !== false;
}
function valid_uid(string $s): bool {
    return ctype_digit($s);
}
function valid_folder(string $s): bool {
    return in_array($s, FOLDERS, true);
}
function h(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

// Escape a string for embedding inside a SINGLE-QUOTED JavaScript literal.
//
// h() is not a substitute: it escapes for HTML, leaves the apostrophe in
// ENT_QUOTES form (&#039;) which a JS parser never decodes inside a script
// block, and does nothing about backslashes or newlines.
//
// This exists because of a real outage. views/layout_foot.php emitted
// translated strings raw into confirm('...') literals. In Hungarian that was
// safe by accident -- t() returns the KEY for the source language, and no
// Hungarian key contains an apostrophe. Switching the console to English
// substituted "the recipient's Inbox", whose apostrophe closed the literal
// early, and the resulting SyntaxError killed the ENTIRE inline script. Every
// function on the page went undefined, so message content could not be opened
// at all -- with nothing in the UI to indicate why, and the server side
// working perfectly. Reported 2026-08-18 as "after changing language i cant
// view the message's content".
//
// Escapes </ as well, so a translation containing "</script>" cannot end the
// script element early, and U+2028/2029 which are literal line terminators in
// JS string context.
function jsq(string $s): string {
    return strtr($s, [
        '\\'       => '\\\\',
        "'"        => "\\'",
        "\n"       => '\\n',
        "\r"       => '',
        '</'       => '<\\/',
        "\u{2028}" => '\\u2028',
        "\u{2029}" => '\\u2029',
    ]);
}
