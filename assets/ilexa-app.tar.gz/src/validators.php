<?php
function valid_user(string $s): bool {
    return (bool) preg_match('/^[a-zA-Z0-9._%+\-@]+$/', $s) && strlen($s) <= 120;
}
function valid_domain(string $s): bool {
    return (bool) preg_match('/^[a-zA-Z0-9.\-]+$/', $s) && strlen($s) <= 80;
}
function valid_date(string $s): bool {
    return (bool) preg_match('/^\d{4}-\d{2}-\d{2}$/', $s) && strtotime($s) !== false;
}
function valid_uid(string $s): bool {
    return ctype_digit($s);
}
function valid_folder(string $s): bool {
    return in_array($s, FOLDERS, true);
}
function h(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

// Escape a string for embedding inside a SINGLE-QUOTED JavaScript literal.
//
// h() is not a substitute: it escapes for HTML, leaves the apostrophe in
// ENT_QUOTES form (&#039;) which a JS parser never decodes inside a script
// block, and does nothing about backslashes or newlines.
//
// This exists because of a real outage. views/layout_foot.php emitted
// translated strings raw into confirm('...') literals. In Hungarian that was
// safe by accident -- t() returns the KEY for the source language, and no
// Hungarian key contains an apostrophe. Switching the console to English
// substituted "the recipient's Inbox", whose apostrophe closed the literal
// early, and the resulting SyntaxError killed the ENTIRE inline script. Every
// function on the page went undefined, so message content could not be opened
// at all -- with nothing in the UI to indicate why, and the server side
// working perfectly. Reported 2026-08-18 as "after changing language i cant
// view the message's content".
//
// Escapes </ as well, so a translation containing "</script>" cannot end the
// script element early, and U+2028/2029 which are literal line terminators in
// JS string context.
function jsq(string $s): string {
    return strtr($s, [
        '\\'       => '\\\\',
        "'"        => "\\'",
        "\n"       => '\\n',
        "\r"       => '',
        '</'       => '<\\/',
        "\u{2028}" => '\\u2028',
        "\u{2029}" => '\\u2029',
    ]);
}

// The admin "tab" a form should return to after a POST, and the tab a lazily
// loaded card fragment renders its forms for.
//
// It arrives from ?tab= (fragment fetch) and from a hidden admin_return_to
// field (POST), so it is attacker-supplied in both cases. It is not currently
// dangerous -- h() escapes it in markup, and PHP's header() refuses CRLF, so
// no header injection, and a "?..."-relative Location cannot leave the origin.
// But it is echoed into a redirect and into every form on the page, and the
// set of real tabs is tiny and fixed, so an allowlist costs nothing and
// removes the question entirely.
const QA_ADMIN_TABS = ['sysconfig=1', 'admin=1', 'audit=ops', 'audit=logins'];

function qa_admin_tab(?string $raw, string $default = 'sysconfig=1'): string {
    $v = trim((string) $raw);
    // 'dash' means the dashboard, which is the PARAMETER-LESS page -- returning
    // '' makes the caller's "?{$tab}&msg=..." resolve to "?&msg=...". Handled
    // ahead of the allowlist because the dashboard has no tab parameter to put
    // in QA_ADMIN_TABS, and NOT by allowing '' there: an absent/blank
    // admin_return_to must keep falling through to $default, which is what the
    // other ~59 forms in this app rely on.
    //
    // Still fully allowlisted in the sense that matters: the only strings this
    // function can ever return are these fixed literals or $default, so nothing
    // request-controlled reaches the Location header.
    if ($v === 'dash') return '';
    return in_array($v, QA_ADMIN_TABS, true) ? $v : $default;
}
