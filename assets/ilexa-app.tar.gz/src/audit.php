<?php
// Authoritative record of a destructive op (release/delete). TSV: epoch, ip, admin,
// action, user, folder, uid. All fields pre-validated so none contain tabs/newlines.
//
// Also mirrored to syslog (LOG_LOCAL4), additive to the file write above --
// nothing reads audit_log() from syslog today, this only makes the SAME
// events available to whatever is already tailing local1-4 in
// /etc/rsyslog.d/60-siem-forward.conf (SIEM export prep, 2026-08-21) without
// depending on that PHP process's own filesystem access to AUDIT_LOG. A
// syslog() failure (extension missing, syslogd down) must never block the
// file write, which the rest of this app treats as the source of truth.
//
// $folder/$uid default to '' because one call site (admin.php's abusix_key
// case) passes only two arguments; with required parameters that was an
// ArgumentCountError AFTER the key had already been saved -- a 500 instead of
// the redirect, and no audit row. Existing four-argument callers are unaffected.
function audit_log(string $action, string $user = '', string $folder = '', string $uid = ''): void {
    $ip    = $_SERVER['REMOTE_ADDR'] ?? '-';
    $admin = $_SERVER['REMOTE_USER'] ?? '-';
    $line  = implode("\t", [time(), $ip, $admin, $action, $user, $folder, $uid]);
    @file_put_contents(AUDIT_LOG, $line . "\n", FILE_APPEND | LOCK_EX);

    if (function_exists('syslog')) {
        @openlog('ilexa-audit', LOG_ODELAY | LOG_PID, LOG_LOCAL4);
        @syslog(LOG_INFO, "action=$action admin=$admin ip=$ip user=$user folder=$folder uid=$uid");
    }
}

// PDO to the postfix DB via least-privilege creds: SELECT on last_login and
// archive_index, plus a narrow column-scoped UPDATE on archive_index
// (learned_as/learned_at only - see actions.php's arc_spam/arc_ham handling).
// Everything else stays read-only to this connection.
function audit_db(): ?PDO {
    if (!is_readable(DB_CRED)) return null;
    $c = @include DB_CRED;
    if (!is_array($c)) return null;
    try {
        $dsn = 'mysql:unix_socket=' . $c['socket'] . ';dbname=' . $c['db'] . ';charset=utf8mb4';
        return new PDO($dsn, $c['user'], $c['pass'],
                       [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_TIMEOUT => 3]);
    } catch (Throwable $e) {
        return null;
    }
}

// Parse the operation audit log → [rows(newest-first), total].
function audit_ops_all(): array {
    if (!is_readable(AUDIT_LOG)) return [[], 0];
    $lines = array_filter(explode("\n", (string) @file_get_contents(AUDIT_LOG)),
                          fn($l) => trim($l) !== '');
    $rows = [];
    foreach (array_reverse($lines) as $l) {
        $p = explode("\t", $l);
        if (count($p) < 7) continue;
        $rows[] = ['ts' => (int)$p[0], 'ip' => $p[1], 'admin' => $p[2],
                   'action' => $p[3], 'user' => $p[4], 'folder' => $p[5], 'uid' => $p[6]];
    }
    return [$rows, count($rows)];
}

// ── Audit page: action catalogue, normalised rows, paging ───────────────────
//
// audit_ops_all() above stays as it is: the ?export=audit CSV (and whatever
// SIEM/consumer parses it) is built from its raw rows and must not change.
// Everything below exists only for rendering the Audit page.
//
// CATEGORY RULE -- which Audit tab a code belongs on:
//   'ops'    ("Spam műveletek") -- an action on a specific message, mailbox
//            or sender: quarantine release/delete/lookup; archive teach/resend;
//            IOC capture FROM an archived message (its row references
//            user/folder/UID, so it reads naturally in that table); block-/
//            allowlist entries and their reputation lookups; the sign-in
//            monitor's per-mailbox alerts (written by cron, admin '-').
//   'config' ("Konfiguráció") -- anything that changes how the system behaves
//            or administers it: settings, feeds, DNSBLs, rspamd modules, brand
//            guard, ClamAV, Postfix, FTS, SIEM, alerts, console users/roles,
//            updates, the data-protection policy, the IOC store itself
//            (add/expire/activate/lookup/import/export) and campaigns.
//   Unknown codes (a call site added without updating this table, or a
//   historic code) fall back to 'config' and to the raw code as the label.
//   tools/check-audit-labels.php fails when an audit_log('<code>' literal in
//   src/ has no entry here, so the fallback is only ever for history.
//
// Codes are compared lower-cased: the filter value travels as ?action_f=,
// which index.php restricts to [a-z0-9_-], and archive.php writes
// 'arc-resend-FAIL'. A historic "code:extra" form (an early arc-resend wrote
// 'arc-resend:<recipient>') resolves to its known head.
//
// The labels are t() literals written out here, not a constant table looked
// up through t($var): tools/check-i18n.php only sees literal t('...') calls,
// so this keeps every label inside the translation-coverage gate.
function audit_action_catalog(): array {
    static $cat = null;
    if ($cat !== null) return $cat;
    $o = 'ops';
    $c = 'config';
    return $cat = [
        // Quarantine
        'release'                  => [$o, t('Felszabadítás')],
        'delete'                   => [$o, t('Törlés')],
        'quar-lookup'              => [$o, t('Hírnév-ellenőrzés (karantén)')],
        // Archive (message-bound)
        'arc-spam'                 => [$o, t('Spam-tanítás (archívum)')],
        'arc-ham'                  => [$o, t('Ham-tanítás (archívum)')],
        'arc-resend'               => [$o, t('Újraküldés (archívum)')],
        'arc-resend-fail'          => [$o, t('Sikertelen újraküldés (archívum)')],
        'arc-ioc-check'            => [$o, t('IOC ellenőrzés (archívum)')],
        'arc-ioc-add'              => [$o, t('IOC-felvétel (archívum)')],
        'arc-ioc-promote'          => [$o, t('IOC-élesítés (archívum)')],
        'ioc-extract'              => [$o, t('IOC-kinyerés (archívum)')],
        'ioc-confirm'              => [$o, t('Kinyert indikátorok jóváhagyása')],
        // Sender block-/allowlists
        'block-add'                => [$o, t('Blokklistára vétel')],
        'block-remove'             => [$o, t('Törlés a blokklistáról')],
        'white-add'                => [$o, t('Fehérlistára vétel')],
        'white-remove'             => [$o, t('Törlés a fehérlistáról')],
        'list-lookup'              => [$o, t('Hírnév-ellenőrzés (blokk-/fehérlista)')],
        // Sign-in monitor (cron)
        'signin-high-risk'         => [$o, t('Kockázatos bejelentkezés észlelve')],
        'signin-notify'            => [$o, t('Bejelentkezési értesítés elküldve')],

        // IOC store and campaigns
        'ioc-add'                  => [$c, t('Indikátor hozzáadása')],
        'ioc-expire'               => [$c, t('Indikátor lejáratása')],
        'ioc-promote'              => [$c, t('Indikátor élesítése')],
        'ioc-unpromote'            => [$c, t('Indikátor élesítésének visszavonása')],
        'ioc-lookup'               => [$c, t('IOC ellenőrzés')],
        'ioc-bulk-import'          => [$c, t('Hash-lista importálása')],
        'ioc-export-pull'          => [$c, t('IOC hash-lista letöltése (külső tűzfal)')],
        'ioc-export-denied'        => [$c, t('IOC hash-lista letöltése elutasítva')],
        'ioc-export-token-regen'   => [$c, t('IOC-export token újragenerálása')],
        'campaign-dismiss'         => [$c, t('Kampány elvetése')],
        'campaign-add-ioc'         => [$c, t('Kampány domainjének felvétele IOC-ként')],
        // Updates
        'update_check_toggle'      => [$c, t('Automatikus frissítés-ellenőrzés átkapcsolása')],
        'update_check_now'         => [$c, t('Frissítés-ellenőrzés indítása')],
        'update_apply'             => [$c, t('Frissítés telepítése')],
        // Console users, policy, notifications
        'user_add'                 => [$c, t('Konzolfelhasználó létrehozása')],
        'user_delete'              => [$c, t('Konzolfelhasználó törlése')],
        'user_set_role'            => [$c, t('Szerepkör módosítása')],
        'user_set_password'        => [$c, t('Konzolfelhasználó jelszavának módosítása')],
        'view-policy'              => [$c, t('Levéltartalom-megtekintési szabály módosítása')],
        'password-expiry-toggle'   => [$c, t('Jelszó-lejárati kényszerítés átkapcsolása')],
        'signin-notify-toggle'     => [$c, t('Bejelentkezési anomália-értesítés átkapcsolása')],
        'alert-recipient'          => [$c, t('Hibaértesítési cím módosítása')],
        'siem-export'              => [$c, t('SIEM-exportálás beállítása')],
        // rspamd
        'rspamd_module_on'         => [$c, t('rspamd modul bekapcsolása')],
        'rspamd_module_off'        => [$c, t('rspamd modul kikapcsolása')],
        'rspamc-pw-set'            => [$c, t('rspamd vezérlő-jelszó módosítása')],
        'hu_classify_on'           => [$c, t('Nyelvi spam-jelzők bekapcsolása')],
        'hu_classify_off'          => [$c, t('Nyelvi spam-jelzők kikapcsolása')],
        'hu_classify_weight'       => [$c, t('Nyelvi spam-jelző súlyának módosítása')],
        'hu_classify_report_email' => [$c, t('Nyelvi spam-jelzők jelentési címének módosítása')],
        'neural-promote'           => [$c, t('Neurális háló élesítése')],
        'neural-shadow'            => [$c, t('Neurális háló árnyék módba állítása')],
        // Brand guard
        'brand-enable'             => [$c, t('Márkavédelem bekapcsolása')],
        'brand-disable'            => [$c, t('Márkavédelem kikapcsolása')],
        'brand-add'                => [$c, t('Védett márka felvétele')],
        'brand-remove'             => [$c, t('Védett márka eltávolítása')],
        'brand-add-variant'        => [$c, t('Márka-névváltozat felvétele')],
        'brand-remove-variant'     => [$c, t('Márka-névváltozat eltávolítása')],
        'brand-add-domain'         => [$c, t('Márka valódi domainjének felvétele')],
        'brand-remove-domain'      => [$c, t('Márka valódi domainjének eltávolítása')],
        'brand-lure-enable'        => [$c, t('Adathalász fordulatok figyelésének bekapcsolása')],
        'brand-lure-disable'       => [$c, t('Adathalász fordulatok figyelésének kikapcsolása')],
        'brand-lure-add'           => [$c, t('Adathalász fordulat felvétele')],
        'brand-lure-remove'        => [$c, t('Adathalász fordulat eltávolítása')],
        // Feeds, DNSBLs, reputation services
        'feed_refresh'             => [$c, t('Blokklista-forrás azonnali frissítése')],
        'feed-enable'              => [$c, t('Blokklista-forrás bekapcsolása')],
        'feed-disable'             => [$c, t('Blokklista-forrás kikapcsolása')],
        'feed-setkey'              => [$c, t('Blokklista-forrás kulcsának módosítása')],
        'community-feed-create'    => [$c, t('Közösségi IP-forrás létrehozása')],
        'community-feed-delete'    => [$c, t('Közösségi IP-forrás törlése')],
        'community-feed-save'      => [$c, t('Közösségi IP-forrás mentése')],
        'community-feed-refresh'   => [$c, t('Közösségi IP-forrás frissítése')],
        'psdnsbl-add'              => [$c, t('Postscreen DNSBL lista felvétele')],
        'psdnsbl-set-weight'       => [$c, t('Postscreen DNSBL súlyának módosítása')],
        'psdnsbl-remove'           => [$c, t('Postscreen DNSBL lista eltávolítása')],
        'psdnsbl-threshold'        => [$c, t('Postscreen DNSBL elutasítási küszöbének módosítása')],
        'spamhaus-dqs-setkey'      => [$c, t('Spamhaus DQS fiókkulcs módosítása')],
        'spamhaus-dqs-test'        => [$c, t('Spamhaus DQS fiókkulcs tesztelése')],
        'abusix_key'               => [$c, t('Abusix datafeed kulcs módosítása')],
        'ioclookup-enable'         => [$c, t('IOC-keresési szolgáltatás bekapcsolása')],
        'ioclookup-disable'        => [$c, t('IOC-keresési szolgáltatás kikapcsolása')],
        'ioclookup-setkey'         => [$c, t('IOC-keresési szolgáltatás kulcsának módosítása')],
        'ioclookup-addcustom'      => [$c, t('Egyéni DNSBL szolgáltatás felvétele')],
        'ioclookup-removecustom'   => [$c, t('Egyéni DNSBL szolgáltatás eltávolítása')],
        'geoblock-countries'       => [$c, t('Geoblokk országlista módosítása')],
        'clamav_sig'               => [$c, t('ClamAV aláírás-forrás módosítása')],
        // Postfix, FTS
        'postfix-setting'          => [$c, t('Postfix-beállítás módosítása')],
        'postfix-restriction'      => [$c, t('Postfix korlátozási lánc módosítása')],
        'fts_optimize_on'          => [$c, t('Heti FTS-indextömörítés bekapcsolása')],
        'fts_optimize_off'         => [$c, t('Heti FTS-indextömörítés kikapcsolása')],
        'fts_index_delete'         => [$c, t('FTS-index törlése')],
    ];
}

// Canonical (catalogue) form of a raw or user-supplied code. Unknown codes are
// returned lower-cased and clipped, never otherwise interpreted.
function audit_action_code(string $raw): string {
    $code = strtolower(trim($raw));
    if ($code === '') return '';
    $cat = audit_action_catalog();
    if (isset($cat[$code])) return $code;
    $head = strstr($code, ':', true);
    if ($head !== false && isset($cat[$head])) return $head;
    return mb_substr(audit_scrub($code), 0, 64);
}

function audit_action_label(string $code): string {
    $c = audit_action_code($code);
    return audit_action_catalog()[$c][1] ?? audit_clip($code, 64);
}

function audit_action_category(string $code): string {
    return audit_action_catalog()[audit_action_code($code)][0] ?? 'config';
}

// Invalid UTF-8 (a raw 8-bit value that reached a field) would make h()'s
// htmlspecialchars() return '' and silently blank the cell.
function audit_scrub(string $s): string {
    return function_exists('mb_scrub') ? mb_scrub($s, 'UTF-8') : $s;
}

// Every rendered field goes through this: bounded to $max characters.
function audit_clip(string $s, int $max = 200): string {
    $s = audit_scrub($s);
    return mb_strlen($s) > $max ? mb_substr($s, 0, $max - 1) . '…' : $s;
}

// on/off/1/0 as words; anything else unchanged.
function audit_onoff(string $v): string {
    if ($v === 'on'  || $v === '1') return t('Bekapcsolva');
    if ($v === 'off' || $v === '0') return t('Kikapcsolva');
    return $v;
}

// Raw result field -> [display text, state]; state is 'ok', 'err' or ''.
function audit_result(string $raw): array {
    switch ($raw) {
        case 'ok':
        case 'set':
        case 'success':          return [t('Sikeres'), 'ok'];   // update-apply writes 'success'
        case 'err':
        case 'failed':
        case 'FAILED':           return [t('Hiba'), 'err'];
        case 'started':          return [t('Elindítva'), ''];
        case 'failed_no_change': return [t('Sikertelen, nem módosult'), 'err'];
        case 'rolled_back':      return [t('Visszaállítva'), 'err'];
        default:                 return [audit_clip($raw), ''];
    }
}

// Block-/allowlist entry type, worded as on the Lists page.
function audit_list_type(string $type): string {
    return ['domain' => 'Domain', 'address' => t('Cím'), 'wildcard' => t('Minta'), 'ip' => 'IP'][$type] ?? $type;
}

// One parsed TSV line [ts, ip, admin, action, user, folder, uid] -> the row
// shape views/audit.php renders. Config-type codes write key/value/result into
// the user/folder/uid columns; this is the one place that knows, per code,
// which is which. Every row carries every key, so the view never has to ask.
function audit_normalise_row(array $p): array {
    [$ts, $ip, $admin, $raw, $u, $f, $id] = array_map('strval', array_slice(array_pad($p, 7, ''), 0, 7));
    $code = audit_action_code($raw);
    $cat  = audit_action_category($code);

    $user = $u; $folder = $f; $uid = $id; $note = '';
    $target = $u; $detail = $f; $result = $id;

    if ($cat === 'ops') {
        switch ($code) {
            case 'arc-ioc-add':
            case 'arc-ioc-promote':       // uid is "<uid>:<count>"
                if (preg_match('/^(\d+):(\d+)$/', $id, $m)) {
                    $uid  = $m[1];
                    $note = sprintf(t('%d indikátor'), (int) $m[2]);
                }
                break;
            case 'ioc-confirm':           // (<archive uid>, '', <count>)
                $user = ''; $folder = ''; $uid = $u;
                $note = ctype_digit($id) ? sprintf(t('%d indikátor'), (int) $id) : $id;
                break;
            case 'block-add':
            case 'white-add':             // (<pattern>, <type>, '')
                $folder = ''; $note = audit_list_type($f);
                break;
            case 'block-remove':
            case 'white-remove':          // (<key>, '', '')
                $folder = '';
                break;
            case 'list-lookup':           // (<pattern>, <list type>, <result count>)
                $folder = ''; $uid = '';
                $note = audit_list_type($f) . (ctype_digit($id) ? ' · ' . sprintf(t('%d találat'), (int) $id) : '');
                break;
            case 'signin-high-risk':      // (<user>, <ip>, <score>)
                $folder = ''; $uid = '';
                $note = $f . ($id !== '' ? ' · ' . t('Kockázat') . ': ' . $id . '%' : '');
                break;
            case 'signin-notify':         // (<user>, <country>, <ip>)
                $folder = ''; $uid = '';
                $note = trim($f . ' ' . $id);
                break;
        }
        $target = $detail = $result = '';
    } else {
        switch ($code) {
            case 'update_check_toggle':   // (on|off, '', '')
                $target = ''; $detail = audit_onoff($u); $result = '';
                break;
            case 'update_check_now':      // (ok|err, '', '')
            case 'abusix_key':            // (set|failed)
                $target = ''; $detail = ''; $result = $u;
                break;
            case 'update_apply':          // (started|err, '', <ver>) or (<outcome>, <from>, <to>)
                $target = $id; $detail = $f !== '' ? $f . ' → ' . $id : ''; $result = $u;
                break;
            case 'view-policy':           // (<new>|FAILED:<new>, '', <old>)
            case 'password-expiry-toggle':
            case 'signin-notify-toggle':  // (1|0|FAILED, '', <old>)
                $failed = strncmp($u, 'FAILED', 6) === 0;
                $new    = $failed ? (string) substr($u, 7) : $u;
                $target = '';
                $detail = $new !== '' ? audit_onoff($id) . ' → ' . audit_onoff($new) : audit_onoff($id);
                $result = $failed ? 'err' : 'ok';
                break;
            case 'hu_classify_weight':    // (<symbol>, '', <value>|err)
                $detail = $id === 'err' ? '' : $id; $result = $id === 'err' ? 'err' : 'ok';
                break;
            case 'psdnsbl-add':
            case 'psdnsbl-set-weight':    // (<zone>, weight=<n>, ok|err)
                $detail = preg_replace('/^weight=/', t('Súly') . ': ', $f);
                break;
            case 'psdnsbl-threshold':     // (<n>, '', ok|err)
                $target = ''; $detail = $u;
                break;
            case 'siem-export':           // (on|off, <host:port/proto [ca=..]>, ok|err)
                $target = $f; $detail = audit_onoff($u);
                break;
            case 'alert-recipient':       // ('alerts', <address>|(off), ok|err)
                $target = $f; $detail = '';
                break;
            case 'geoblock-countries':    // ('geoblock', <countries>, ok|err)
                $target = ''; $detail = $f;
                break;
            case 'ioc-add':               // (<value>, <type>, <id>)
                $detail = $f . ($id !== '' ? ' · #' . $id : ''); $result = '';
                break;
            case 'ioc-expire':
            case 'ioc-promote':
            case 'ioc-unpromote':
            case 'campaign-dismiss':      // (<id>, '', '')
                $target = $u !== '' ? '#' . $u : ''; $detail = ''; $result = '';
                break;
            case 'ioc-lookup':            // (<id>, '', <result count>)
                $target = $u !== '' ? '#' . $u : '';
                $detail = ctype_digit($id) ? sprintf(t('%d találat'), (int) $id) : $id;
                $result = '';
                break;
            case 'ioc-bulk-import':       // ('', 'hash', <added>)
                $target = $f;
                $detail = ctype_digit($id) ? sprintf(t('%d indikátor'), (int) $id) : $id;
                $result = '';
                break;
            case 'ioc-export-pull':
            case 'ioc-export-denied':
            case 'ioc-export-token-regen':  // ('-', '', '')
                $target = $detail = $result = '';
                break;
            case 'campaign-add-ioc':      // (<domain>, '', <campaign id>)
                $detail = $id !== '' ? '#' . $id : ''; $result = '';
                break;
            case 'community-feed-create':
            case 'community-feed-delete':
            case 'community-feed-save':
            case 'community-feed-refresh': // (<slot>, '', ok|err)
                $target = $u !== '' ? '#' . $u : '';
                break;
        }
        $user = $folder = $uid = '';
    }

    [$resText, $resState] = audit_result($result);
    return [
        'time'         => (int) $ts,
        'ip'           => audit_clip($ip, 64),
        'admin'        => audit_clip($admin, 64),
        'code'         => $code,
        'label'        => audit_action_label($code),
        'category'     => $cat,
        'user'         => audit_clip($user),
        'folder'       => audit_clip($folder, 64),
        'uid'          => audit_clip($uid, 64),
        'note'         => audit_clip($note),
        'target'       => audit_clip($target),
        'detail'       => audit_clip($detail),
        'result'       => $resText,
        'result_state' => $resState,
    ];
}

// Read AUDIT_LOG into parsed 7-field lines (oldest first).
// $state: 'ok', 'missing' (no file yet -- an empty log, not an error) or
// 'unreadable' (the file is there but this process cannot read it, or its
// directory cannot be searched, which hides even its existence).
function audit_log_lines(?string &$state = null): array {
    $state = 'ok';
    if (!file_exists(AUDIT_LOG)) {
        $dir   = dirname(AUDIT_LOG);
        $state = (is_dir($dir) && !is_executable($dir)) ? 'unreadable' : 'missing';
        return [];
    }
    $fh = is_file(AUDIT_LOG) ? @fopen(AUDIT_LOG, 'rb') : false;
    if ($fh === false) { $state = 'unreadable'; return []; }

    $out = [];
    while (($line = fgets($fh)) !== false) {
        $line = rtrim($line, "\r\n");
        if (trim($line) === '') continue;
        $p = explode("\t", $line);
        if (count($p) < 7) continue;
        // A value that once carried a tab split into extra columns; keep it
        // visible in the last field rather than dropping it.
        if (count($p) > 7) $p = array_merge(array_slice($p, 0, 6), [implode(' ', array_slice($p, 6))]);
        $out[] = $p;
    }
    fclose($fh);
    return $out;
}

// One page of one Audit tab.
//   $category  'ops' | 'config' (anything else is treated as 'ops')
//   $action    action-type filter, '' = all. A code belonging to the other
//              tab, or unknown to this tab's log, is ignored (= all).
//   $page      1-based; clamped to the available range here.
//   $per_page  clamped to 1..500.
// Returns ['rows' => normalised rows newest-first, 'total' => matching count,
//          'actions' => [code => label] present in this category (plus the
//          active filter), sorted by label,
//          'action' => the effective filter, 'page', 'pages', 'per_page',
//          'category', 'unreadable' => bool].
function audit_ops_page(string $category, string $action, int $page, int $per_page): array {
    $category = $category === 'config' ? 'config' : 'ops';
    $per_page = max(1, min(500, $per_page));
    $action   = audit_action_code($action);
    if ($action !== '' && audit_action_category($action) !== $category) $action = '';

    $state = 'ok';
    $lines = audit_log_lines($state);

    $present = [];
    $match   = [];
    foreach ($lines as $p) {
        $code = audit_action_code($p[3]);
        if (audit_action_category($code) !== $category) continue;
        $present[$code] = true;
        if ($action === '' || $code === $action) $match[] = $p;
    }
    if ($action !== '' && !isset($present[$action]) && !isset(audit_action_catalog()[$action])) {
        // Not a catalogued code and not in the log: nothing to filter on.
        $action = '';
        $match  = [];
        foreach ($lines as $p) {
            if (audit_action_category(audit_action_code($p[3])) === $category) $match[] = $p;
        }
    }
    if ($action !== '') $present[$action] = true;   // keep the select showing the active filter

    $actions = [];
    foreach (array_keys($present) as $code) $actions[$code] = audit_action_label($code);
    uasort($actions, fn($a, $b) => strnatcasecmp($a, $b));

    $total = count($match);
    $pages = max(1, (int) ceil($total / $per_page));
    $page  = max(1, min($page, $pages));
    $slice = array_slice(array_reverse($match), ($page - 1) * $per_page, $per_page);

    return [
        'rows'       => array_map('audit_normalise_row', $slice),
        'total'      => $total,
        'actions'    => $actions,
        'action'     => $action,
        'page'       => $page,
        'pages'      => $pages,
        'per_page'   => $per_page,
        'category'   => $category,
        'unreadable' => $state === 'unreadable',
    ];
}

// Admin logins to this tool, derived from Apache's access log.
// grep-first shrinks MB of shared SSL log to the few app lines, then we keep only
// authenticated hits and collapse bursts into login sessions (newest-first, capped).
//
// Reads via the root-owned qa-audit-log.sh (sudo), not a direct grep of
// ACCESS_LOG_GLOB: the containing log directory is 0700 root on a stock
// install, readable by apache only through a directory ACL the installer
// sets (modules/55-ilexa.sh) -- and that ACL's mask can get silently reset
// by anything that later chmods the directory (confirmed live on hawking
// 2026-08-21: the named ACL entry was still present but its effective
// permission had been zeroed out by exactly this). A root-run reader has no
// such failure mode.
function admin_logins(int $limit = 100): array {
    // grep exits 1 on "no matches" (an ordinary quiet log) and 2+ on a real
    // error -- e.g. the access log unreadable by the web user, which is exactly
    // how this view silently showed "no login history" instead of saying it
    // could not read anything.
    $ok  = null;
    $out = qa_sudo_read(
        SUDO . ' /usr/local/sbin/qa-audit-log.sh admin-logins ' . escapeshellarg(COOKIE_PATH),
        'audit:access-log', $ok, [0, 1]);
    if ($out === '') return [];

    $events = [];
    foreach (explode("\n", $out) as $line) {
        // IP - USER [dd/Mon/yyyy:HH:MM:SS +ZZZZ] "req" ...
        if (!preg_match('#^(\S+) \S+ (\S+) \[([^\]]+)\]#', $line, $m)) continue;
        if ($m[2] === '-') continue;   // pre-auth challenge
        $dt = DateTime::createFromFormat('d/M/Y:H:i:s O', $m[3]);
        if ($dt === false) continue;
        $events[] = ['ts' => $dt->getTimestamp(), 'user' => $m[2], 'ip' => $m[1]];
    }
    if (!$events) return [];
    usort($events, fn($a, $b) => $a['ts'] <=> $b['ts']);

    $sessions = [];
    $open     = [];   // "user|ip" => session index
    foreach ($events as $e) {
        $key = $e['user'] . '|' . $e['ip'];
        if (!isset($open[$key]) || $e['ts'] - $sessions[$open[$key]]['last'] > ADMIN_SESSION_GAP) {
            $sessions[]  = ['start' => $e['ts'], 'last' => $e['ts'],
                            'user'  => $e['user'], 'ip' => $e['ip'], 'hits' => 1];
            $open[$key]  = count($sessions) - 1;
        } else {
            $sessions[$open[$key]]['last'] = $e['ts'];
            $sessions[$open[$key]]['hits']++;
        }
    }
    usort($sessions, fn($a, $b) => $b['start'] <=> $a['start']);
    return array_slice($sessions, 0, $limit);
}

// Failed logins to this tool, derived from Apache's error log. The access
// log's %u is always "-" on a failed Basic Auth attempt, so admin_logins()
// alone can never answer "who tried and failed" -- only mod_auth_basic's
// error-log entries carry the attempted username.
function admin_login_failures(int $limit = 100): array {
    $ok  = null;
    $out = qa_sudo_read(
        SUDO . ' /usr/local/sbin/qa-audit-log.sh admin-login-failures ' . escapeshellarg(COOKIE_PATH),
        'audit:error-log', $ok, [0, 1]);
    if ($out === '') return [];

    $events = [];
    foreach (explode("\n", $out) as $line) {
        if (!preg_match('/^\[([^\]]+)\] \[auth_basic:error\] \[pid [^\]]+\] \[remote ([^:\]]+):\d+\] (AH0161[78]): (.*)$/',
                         $line, $m)) continue;
        $dt = DateTime::createFromFormat('D M j H:i:s.u Y', $m[1]);
        if ($dt === false) continue;
        $rest = $m[4];
        if ($m[3] === 'AH01617'
            && preg_match('/^user (\S.*?): authentication failure for "[^"]*": (.+)$/', $rest, $rm)) {
            $user = $rm[1]; $reason = $rm[2];
        } elseif ($m[3] === 'AH01618' && preg_match('/^user (\S*) not found:/', $rest, $rm)) {
            $user   = $rm[1] !== '' ? $rm[1] : t('(nincs megadva)');
            $reason = t('ismeretlen felhasználó');
        } else {
            continue; // a future AH0161x shape neither branch recognizes -- skip, don't guess
        }
        $events[] = ['ts' => $dt->getTimestamp(), 'user' => $user, 'ip' => $m[2], 'reason' => $reason];
    }
    usort($events, fn($a, $b) => $b['ts'] <=> $a['ts']);
    return array_slice($events, 0, $limit);
}

// Failed POP3/IMAP/webmail authentication, merged from two sources:
//
// - Dovecot's own log: every direct IMAP/POP3 client failure, real source
//   IP. Roundcube's failed attempts ALSO land here (Roundcube authenticates
//   as an IMAP client), but with rip=127.0.0.1 -- Dovecot only ever sees
//   Roundcube's own server-side connection, never the browser's real IP --
//   so those rows are dropped in favour of the next source.
// - Roundcube's userlogins.log: the same webmail failures, but with the
//   real browser-side client IP Roundcube itself received over HTTP.
//
// Merging without the drop above would double-count every webmail failure
// once with a useless IP and once with a useful one.
function mail_auth_failures(int $limit = 150): array {
    $events = [];

    $ok  = null;
    $out = qa_sudo_read(SUDO . ' /usr/local/sbin/qa-audit-log.sh mail-auth-failures', 'audit:mail-auth', $ok, [0, 1]);
    $year = (int) date('Y');
    foreach (explode("\n", $out) as $line) {
        if ($line === '') continue;
        // Greedy ".*rip=" (NOT the old non-greedy ".*?rip="), so this locks
        // onto the LAST "rip=" on the line, not the first. Dovecot's %u
        // substitution does not escape '>' in the username, and this
        // username comes straight from the attacker's own SASL AUTH command
        // (no real account needed to produce a failure line) -- a crafted
        // username containing its own "..., rip=<fake>" text can close the
        // user=<...> tag early and inject a fake rip= that a non-greedy scan
        // would grab first. Dovecot always appends its OWN real
        // "..., method=%m, rip=%r, ..." fields after the substituted
        // username, so the real rip= is structurally guaranteed to be the
        // last one on the line -- greedy matching finds that one instead.
        // Confirmed against both a crafted-injection line and a real one.
        // valid_user() below is a second, independent gate: even a line
        // that still somehow parses oddly is dropped if the captured
        // "username" isn't shaped like a real one.
        if (!preg_match('/^(\w{3} +\d{1,2} \d{2}:\d{2}:\d{2}) (imap|pop3)-login:.*auth failed.*user=<([^>]*)>.*rip=([0-9a-fA-F:.]+)/',
                         $line, $m)) continue;
        if ($m[4] === '127.0.0.1' || $m[4] === '::1') continue; // see comment above: Roundcube's own log has the real IP
        if ($m[3] !== '' && !valid_user($m[3])) continue;
        // Dovecot's log carries no year. A line from December, read in
        // January, would otherwise parse as a bogus future date -- fall back
        // a year whenever that happens rather than showing it wrong.
        $dt = DateTime::createFromFormat('M j H:i:s Y', $m[1] . ' ' . $year);
        if ($dt !== false && $dt->getTimestamp() > time()) {
            $dt = DateTime::createFromFormat('M j H:i:s Y', $m[1] . ' ' . ($year - 1));
        }
        if ($dt === false) continue;
        $events[] = ['ts' => $dt->getTimestamp(), 'user' => $m[3] !== '' ? $m[3] : t('(nincs megadva)'),
                     'ip' => $m[4], 'source' => strtoupper($m[2])];
    }

    // Roundcube's own log is apache-owned (unlike every other source here),
    // so it is read directly -- no sudo helper needed for this one.
    if (ROUNDCUBE_LOG_DIR !== '') {
        $rc = @file_get_contents(ROUNDCUBE_LOG_DIR . '/userlogins.log');
        if ($rc !== false) {
            foreach (explode("\n", $rc) as $line) {
                if ($line === '') continue;
                // [21-Aug-2026 08:43:09 +0000]: <sess> Failed login for user@domain from 1.2.3.4 in session ...
                if (!preg_match('/^\[(\d{2}-\w{3}-\d{4} \d{2}:\d{2}:\d{2}) ([+-]\d{4})\]: <[^>]*> Failed login for (\S+) from (\S+)/',
                                 $line, $m)) continue;
                $dt = DateTime::createFromFormat('d-M-Y H:i:s O', $m[1] . ' ' . $m[2]);
                if ($dt === false) continue;
                $events[] = ['ts' => $dt->getTimestamp(), 'user' => $m[3], 'ip' => $m[4], 'source' => 'WEBMAIL'];
            }
        }
    }

    usort($events, fn($a, $b) => $b['ts'] <=> $a['ts']);
    return array_slice($events, 0, $limit);
}
