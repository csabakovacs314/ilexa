<?php
// Authoritative record of a destructive op (release/delete). TSV: epoch, ip, admin,
// action, user, folder, uid. All fields pre-validated so none contain tabs/newlines.
//
// Also mirrored to syslog (LOG_LOCAL4), additive to the file write above --
// nothing reads audit_log() from syslog today, this only makes the SAME
// events available to whatever is already tailing local1-4 in
// /etc/rsyslog.d/60-siem-forward.conf (SIEM export prep, 2026-08-21) without
// depending on that PHP process's own filesystem access to AUDIT_LOG. A
// syslog() failure (extension missing, syslogd down) must never block the
// file write, which the rest of this app treats as the source of truth.
function audit_log(string $action, string $user, string $folder, string $uid): void {
    $ip    = $_SERVER['REMOTE_ADDR'] ?? '-';
    $admin = $_SERVER['REMOTE_USER'] ?? '-';
    $line  = implode("\t", [time(), $ip, $admin, $action, $user, $folder, $uid]);
    @file_put_contents(AUDIT_LOG, $line . "\n", FILE_APPEND | LOCK_EX);

    if (function_exists('syslog')) {
        @openlog('ilexa-audit', LOG_ODELAY | LOG_PID, LOG_LOCAL4);
        @syslog(LOG_INFO, "action=$action admin=$admin ip=$ip user=$user folder=$folder uid=$uid");
    }
}

// PDO to the postfix DB via least-privilege creds: SELECT on last_login and
// archive_index, plus a narrow column-scoped UPDATE on archive_index
// (learned_as/learned_at only - see actions.php's arc_spam/arc_ham handling).
// Everything else stays read-only to this connection.
function audit_db(): ?PDO {
    if (!is_readable(DB_CRED)) return null;
    $c = @include DB_CRED;
    if (!is_array($c)) return null;
    try {
        $dsn = 'mysql:unix_socket=' . $c['socket'] . ';dbname=' . $c['db'] . ';charset=utf8mb4';
        return new PDO($dsn, $c['user'], $c['pass'],
                       [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_TIMEOUT => 3]);
    } catch (Throwable $e) {
        return null;
    }
}

// Parse the operation audit log → [rows(newest-first), total].
function audit_ops_all(): array {
    if (!is_readable(AUDIT_LOG)) return [[], 0];
    $lines = array_filter(explode("\n", (string) @file_get_contents(AUDIT_LOG)),
                          fn($l) => trim($l) !== '');
    $rows = [];
    foreach (array_reverse($lines) as $l) {
        $p = explode("\t", $l);
        if (count($p) < 7) continue;
        $rows[] = ['ts' => (int)$p[0], 'ip' => $p[1], 'admin' => $p[2],
                   'action' => $p[3], 'user' => $p[4], 'folder' => $p[5], 'uid' => $p[6]];
    }
    return [$rows, count($rows)];
}

// Admin logins to this tool, derived from Apache's access log.
// grep-first shrinks MB of shared SSL log to the few app lines, then we keep only
// authenticated hits and collapse bursts into login sessions (newest-first, capped).
//
// Reads via the root-owned qa-audit-log.sh (sudo), not a direct grep of
// ACCESS_LOG_GLOB: the containing log directory is 0700 root on a stock
// install, readable by apache only through a directory ACL the installer
// sets (modules/55-ilexa.sh) -- and that ACL's mask can get silently reset
// by anything that later chmods the directory (confirmed live on hawking
// 2026-08-21: the named ACL entry was still present but its effective
// permission had been zeroed out by exactly this). A root-run reader has no
// such failure mode.
function admin_logins(int $limit = 100): array {
    // grep exits 1 on "no matches" (an ordinary quiet log) and 2+ on a real
    // error -- e.g. the access log unreadable by the web user, which is exactly
    // how this view silently showed "no login history" instead of saying it
    // could not read anything.
    $ok  = null;
    $out = qa_sudo_read(
        SUDO . ' /usr/local/sbin/qa-audit-log.sh admin-logins ' . escapeshellarg(COOKIE_PATH),
        'audit:access-log', $ok, [0, 1]);
    if ($out === '') return [];

    $events = [];
    foreach (explode("\n", $out) as $line) {
        // IP - USER [dd/Mon/yyyy:HH:MM:SS +ZZZZ] "req" ...
        if (!preg_match('#^(\S+) \S+ (\S+) \[([^\]]+)\]#', $line, $m)) continue;
        if ($m[2] === '-') continue;   // pre-auth challenge
        $dt = DateTime::createFromFormat('d/M/Y:H:i:s O', $m[3]);
        if ($dt === false) continue;
        $events[] = ['ts' => $dt->getTimestamp(), 'user' => $m[2], 'ip' => $m[1]];
    }
    if (!$events) return [];
    usort($events, fn($a, $b) => $a['ts'] <=> $b['ts']);

    $sessions = [];
    $open     = [];   // "user|ip" => session index
    foreach ($events as $e) {
        $key = $e['user'] . '|' . $e['ip'];
        if (!isset($open[$key]) || $e['ts'] - $sessions[$open[$key]]['last'] > ADMIN_SESSION_GAP) {
            $sessions[]  = ['start' => $e['ts'], 'last' => $e['ts'],
                            'user'  => $e['user'], 'ip' => $e['ip'], 'hits' => 1];
            $open[$key]  = count($sessions) - 1;
        } else {
            $sessions[$open[$key]]['last'] = $e['ts'];
            $sessions[$open[$key]]['hits']++;
        }
    }
    usort($sessions, fn($a, $b) => $b['start'] <=> $a['start']);
    return array_slice($sessions, 0, $limit);
}

// Failed logins to this tool, derived from Apache's error log. The access
// log's %u is always "-" on a failed Basic Auth attempt, so admin_logins()
// alone can never answer "who tried and failed" -- only mod_auth_basic's
// error-log entries carry the attempted username.
function admin_login_failures(int $limit = 100): array {
    $ok  = null;
    $out = qa_sudo_read(
        SUDO . ' /usr/local/sbin/qa-audit-log.sh admin-login-failures ' . escapeshellarg(COOKIE_PATH),
        'audit:error-log', $ok, [0, 1]);
    if ($out === '') return [];

    $events = [];
    foreach (explode("\n", $out) as $line) {
        if (!preg_match('/^\[([^\]]+)\] \[auth_basic:error\] \[pid [^\]]+\] \[remote ([^:\]]+):\d+\] (AH0161[78]): (.*)$/',
                         $line, $m)) continue;
        $dt = DateTime::createFromFormat('D M j H:i:s.u Y', $m[1]);
        if ($dt === false) continue;
        $rest = $m[4];
        if ($m[3] === 'AH01617'
            && preg_match('/^user (\S.*?): authentication failure for "[^"]*": (.+)$/', $rest, $rm)) {
            $user = $rm[1]; $reason = $rm[2];
        } elseif ($m[3] === 'AH01618' && preg_match('/^user (\S*) not found:/', $rest, $rm)) {
            $user   = $rm[1] !== '' ? $rm[1] : t('(nincs megadva)');
            $reason = t('ismeretlen felhasználó');
        } else {
            continue; // a future AH0161x shape neither branch recognizes -- skip, don't guess
        }
        $events[] = ['ts' => $dt->getTimestamp(), 'user' => $user, 'ip' => $m[2], 'reason' => $reason];
    }
    usort($events, fn($a, $b) => $b['ts'] <=> $a['ts']);
    return array_slice($events, 0, $limit);
}

// Failed POP3/IMAP/webmail authentication, merged from two sources:
//
// - Dovecot's own log: every direct IMAP/POP3 client failure, real source
//   IP. Roundcube's failed attempts ALSO land here (Roundcube authenticates
//   as an IMAP client), but with rip=127.0.0.1 -- Dovecot only ever sees
//   Roundcube's own server-side connection, never the browser's real IP --
//   so those rows are dropped in favour of the next source.
// - Roundcube's userlogins.log: the same webmail failures, but with the
//   real browser-side client IP Roundcube itself received over HTTP.
//
// Merging without the drop above would double-count every webmail failure
// once with a useless IP and once with a useful one.
function mail_auth_failures(int $limit = 150): array {
    $events = [];

    $ok  = null;
    $out = qa_sudo_read(SUDO . ' /usr/local/sbin/qa-audit-log.sh mail-auth-failures', 'audit:mail-auth', $ok, [0, 1]);
    $year = (int) date('Y');
    foreach (explode("\n", $out) as $line) {
        if ($line === '') continue;
        if (!preg_match('/^(\w{3} +\d{1,2} \d{2}:\d{2}:\d{2}) (imap|pop3)-login:.*auth failed.*user=<([^>]*)>.*?rip=([0-9a-fA-F:.]+)/',
                         $line, $m)) continue;
        if ($m[4] === '127.0.0.1' || $m[4] === '::1') continue; // see comment above: Roundcube's own log has the real IP
        // Dovecot's log carries no year. A line from December, read in
        // January, would otherwise parse as a bogus future date -- fall back
        // a year whenever that happens rather than showing it wrong.
        $dt = DateTime::createFromFormat('M j H:i:s Y', $m[1] . ' ' . $year);
        if ($dt !== false && $dt->getTimestamp() > time()) {
            $dt = DateTime::createFromFormat('M j H:i:s Y', $m[1] . ' ' . ($year - 1));
        }
        if ($dt === false) continue;
        $events[] = ['ts' => $dt->getTimestamp(), 'user' => $m[3] !== '' ? $m[3] : t('(nincs megadva)'),
                     'ip' => $m[4], 'source' => strtoupper($m[2])];
    }

    // Roundcube's own log is apache-owned (unlike every other source here),
    // so it is read directly -- no sudo helper needed for this one.
    if (ROUNDCUBE_LOG_DIR !== '') {
        $rc = @file_get_contents(ROUNDCUBE_LOG_DIR . '/userlogins.log');
        if ($rc !== false) {
            foreach (explode("\n", $rc) as $line) {
                if ($line === '') continue;
                // [21-Aug-2026 08:43:09 +0000]: <sess> Failed login for user@domain from 1.2.3.4 in session ...
                if (!preg_match('/^\[(\d{2}-\w{3}-\d{4} \d{2}:\d{2}:\d{2}) ([+-]\d{4})\]: <[^>]*> Failed login for (\S+) from (\S+)/',
                                 $line, $m)) continue;
                $dt = DateTime::createFromFormat('d-M-Y H:i:s O', $m[1] . ' ' . $m[2]);
                if ($dt === false) continue;
                $events[] = ['ts' => $dt->getTimestamp(), 'user' => $m[3], 'ip' => $m[4], 'source' => 'WEBMAIL'];
            }
        }
    }

    usort($events, fn($a, $b) => $b['ts'] <=> $a['ts']);
    return array_slice($events, 0, $limit);
}
