<?php
// On-demand reputation lookups for Block/Whitelist entries. Mirrors
// src/ioc_lookup.php's cache/TTL/upsert structure exactly, but keyed on
// (type, value) instead of an IOC row id -- list entries aren't IOCs, and
// checking one never creates or touches an iocs row.

// Maps a list entry's (type, pattern) to the value actually worth
// checking. address/wildcard have no per-mailbox reputation service, so
// checking the domain part is the useful proxy; a CIDR ip entry has no
// single reputation, so it returns null (no check offered).
function list_lookup_effective_value(string $listType, string $pattern): ?array {
    $p = strtolower(trim($pattern));
    if ($p === '') return null;
    switch ($listType) {
        case 'domain':
            return ['domain', ltrim($p, '@')];
        case 'ip':
            if (strpos($p, '/') !== false) return null; // CIDR: no single-IP reputation
            return ['ip', $p];
        case 'address':
        case 'wildcard':
            $at = strrpos($p, '@');
            $domain = $at !== false ? substr($p, $at + 1) : '';
            return $domain !== '' ? ['domain', $domain] : null;
        default:
            return null;
    }
}

function list_lookup_cached(string $type, string $value): array {
    try {
        $stmt = _ioc_db()->prepare(
            'SELECT service, verdict, detail, checked_at FROM list_lookups WHERE type = :type AND value = :value');
        $stmt->execute([':type' => $type, ':value' => $value]);
        $out = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $out[$row['service']] = $row;
        }
        return $out;
    } catch (Throwable $e) {
        return [];
    }
}

// Runs the actual per-service reputation lookup for a plain (type, value)
// pair -- cache read, TTL check, external call, degrade-to-last-good on
// error, and DB upsert. No list-entry normalisation here: callers that have
// a block/whitelist *entry* (which needs stripping/CIDR-rejection/etc.) go
// through list_lookup_run() below; callers that already have a bare
// domain/IP (e.g. a message's sender domain or sending IP) call this
// directly so they don't inherit the list page's normalisation rules or
// mislabel their own audit trail.
function lookup_run_value(string $type, string $value, ?callable $caller = null,
                          string $surface = 'lists'): array {
    $caller = $caller ?? '_ioc_lookup_call';

    $cached  = list_lookup_cached($type, $value);
    $results = [];
    $errors  = [];
    $now     = time();

    foreach (ioc_lookup_services_for($type, $surface) as $service) {
        $have = $cached[$service] ?? null;
        if ($have !== null && ($now - (int)$have['checked_at']) < ioc_lookup_ttl_for($service)) {
            $results[$service] = $have;
            continue;
        }

        // A per-surface timeout override also marks the service BEST-EFFORT
        // here: we knowingly gave it a budget it will often miss, so a
        // failure is an expected outcome rather than something to report.
        // Surfacing it would put a url.vet error on most rows of reported
        // spam and train operators to ignore the error channel entirely.
        $timeout    = ioc_lookup_timeout_for($service, $surface);
        $bestEffort = $timeout !== null;

        [$ok, $err, $data] = $caller($service, $type, $value, $timeout);
        if (!$ok) {
            if (!$bestEffort) $errors[$service] = $err;
            if ($have !== null) $results[$service] = $have;
            continue;
        }

        $verdict = in_array($data['verdict'], ['malicious', 'suspicious', 'clean', 'unknown'], true)
                 ? $data['verdict'] : 'unknown';
        $detail = mb_substr((string)($data['detail'] ?? ''), 0, 200);

        try {
            $stmt = _ioc_db()->prepare(
                'INSERT INTO list_lookups (type, value, service, verdict, detail, raw_json, checked_at)
                 VALUES (:type, :value, :service, :verdict, :detail, :raw_json, :checked_at)
                 ON CONFLICT(type, value, service) DO UPDATE SET
                    verdict = :verdict, detail = :detail, raw_json = :raw_json, checked_at = :checked_at'
            );
            $stmt->execute([
                ':type' => $type, ':value' => $value, ':service' => $service, ':verdict' => $verdict,
                ':detail' => $detail, ':raw_json' => json_encode($data['raw'] ?? null),
                ':checked_at' => $now,
            ]);
        } catch (Throwable $e) {
            $errors[$service] = t('Adatbázis hiba.');
            if ($have !== null) $results[$service] = $have;
            continue;
        }

        $results[$service] = ['service' => $service, 'verdict' => $verdict,
                               'detail' => $detail, 'checked_at' => $now];
    }

    return ['results' => $results, 'errors' => $errors];
}

// Same cache/TTL/degrade-to-last-good semantics as ioc_lookup_run(), for a
// block/whitelist *entry* -- normalises via list_lookup_effective_value()
// first, then delegates the actual lookup to lookup_run_value().
function list_lookup_run(string $listType, string $pattern, ?callable $caller = null): array {
    $eff = list_lookup_effective_value($listType, $pattern);
    if ($eff === null) {
        return ['results' => [], 'errors' => ['_' => t('Erre a típusra nincs hírnév-ellenőrzés.')], 'checked_value' => null];
    }
    [$type, $value] = $eff;

    $out = lookup_run_value($type, $value, $caller, 'lists');
    $out['checked_value'] = $value;
    return $out;
}

// Mirrors handle_ioc_action('ioc_lookup')'s exact AJAX/JSON/toast contract.
function handle_list_lookup_action(): void {
    if (!can('lists')) { header('Location: ?'); exit; }

    $listType = (string) ($_POST['l_type'] ?? '');
    $pattern  = (string) ($_POST['l_pattern'] ?? '');
    $back     = ($_POST['which'] ?? '') === 'white' ? '?white=1' : '?block=1';
    $isAjax   = ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'XMLHttpRequest';

    // Reject anything that wouldn't resolve to a well-formed checkable
    // value before spending shared external-API quota on it --
    // l_type/l_pattern are untrusted POST input (the pre-submit button
    // sends an unsaved, never-validated pattern). Validating against
    // list_compile() directly was tried and reverted: it validates as if
    // the pattern were being freshly typed by an admin today, but real
    // stored entries include legacy formats (e.g. an "@"-prefixed domain
    // from the old mailscanner-import tool) that list_compile() rejects
    // outright even though list_lookup_effective_value() already
    // normalizes them correctly -- that broke the check button for
    // roughly a third of this environment's real block/whitelist rows.
    // Instead, validate the *effective* value (post-normalization) with
    // _ioc_valid_value(), the same domain/ip shape validator the IOC
    // store itself already trusts.
    $eff = list_lookup_effective_value($listType, $pattern);
    if ($eff === null) {
        $result = ['results' => [], 'errors' => ['_' => t('Erre a típusra nincs hírnév-ellenőrzés.')]];
    } elseif (!_ioc_valid_value($eff[0], $eff[1])) {
        $result = ['results' => [], 'errors' => ['_' => t('Érvénytelen érték ehhez a típushoz.')]];
    } else {
        $result = list_lookup_run($listType, $pattern);
    }
    $ok = count($result['results']) > 0 || count($result['errors']) === 0;
    audit_log('list-lookup', $pattern, $listType, (string) count($result['results']));

    if ($isAjax) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'ok' => $ok, 'results' => $result['results'], 'errors' => $result['errors'],
            // Same scoring the server-rendered page uses -- ioc_lookup_confidence()
            // consumes exactly the shape list_lookup_run() returns.
            'confidence' => ioc_lookup_confidence($result['results']),
        ]);
        exit;
    }
    header('Location: ' . $back); exit;
}
