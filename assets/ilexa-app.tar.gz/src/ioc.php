<?php
// IOC (indicator-of-compromise) store: a curated, admin-maintained set of
// IP/domain/URL/hash/email indicators with provenance and context. Separate
// from the existing bulk threat-intel feeds (OTX/URLhaus/Spamhaus DROP/
// ThreatFox+Feodo/AbuseIPDB/FireHOL/ET) -- this store is for indicators an
// admin has actually looked at, not high-volume automated lists. No
// enforcement wiring: adding an indicator here never creates a firewalld or
// rspamd rule.

const IOC_TYPES = ['ip', 'domain', 'url', 'hash', 'email'];
const IOC_CONFIDENCE_LEVELS = ['low', 'medium', 'high'];

// Megbízhatóság rendered as an icon rather than the raw word, so the column can
// be narrow (the header "Megbízhatóság" needs ~122px of TEXT, but the cell
// content no longer does) and so it reads the same in both shipped languages.
//
// One glyph, three colour steps: confidence is an INTENSITY scale, and a single
// shield at three strengths reads as a level, where three unrelated glyphs would
// have to be learned. Deliberately NOT the .verdict-clean/-suspicious/-malicious
// classes: those mean "this indicator is harmless / bad", and painting a
// low-CONFIDENCE indicator green would assert something about the indicator that
// nobody measured -- confidence here is what the person who added it typed, not
// a verdict. See the explanation paragraph at the top of views/ioc.php.
//
// CO-DEPENDENCY, same shape as QA_VERDICT_ICON: the legend at the bottom of
// views/ioc.php iterates this map but takes its LABELS from a local array there.
// Adding a level here without adding its label renders the level key raw.
// Típus rendered as an icon. IOC_TYPES is a CLOSED, insert-validated set, so
// every value that can reach the table has an entry here -- no fallback is
// reachable in practice, but views/ioc.php still renders the raw word if one
// ever is, rather than an empty cell.
const QA_IOC_TYPE_ICON = [
    'domain' => 'icon-globe',
    'url'    => 'icon-link',
    'hash'   => 'icon-hash',
    'ip'     => 'icon-server',
    'email'  => 'icon-mail',
];

// Forrás rendered as an icon -- but source is NOT a closed set: it is free text
// up to 40 chars (see ioc_add()), so an unmapped value is genuinely reachable
// and the view MUST fall back to showing the text. These four are every source
// the code itself produces (campaigns.php, quarantine-confirm, manual add,
// bulk hash import).
const QA_IOC_SOURCE_ICON = [
    'manual'             => 'icon-user',
    'bulk-import'        => 'icon-download',
    'quarantine-confirm' => 'icon-inbox',
    'campaign'           => 'icon-layers',
];

const QA_IOC_CONFIDENCE_ICON = [
    'high'   => ['icon' => 'icon-shield', 'class' => 'ioc-conf-high'],
    'medium' => ['icon' => 'icon-shield', 'class' => 'ioc-conf-medium'],
    'low'    => ['icon' => 'icon-shield', 'class' => 'ioc-conf-low'],
];

function _ioc_db(): PDO {
    static $db = null;
    if ($db !== null) return $db;

    try {
        $path = dirname(SETTINGS_FILE) . '/iocs.db';
        $db = new PDO('sqlite:' . $path, null, null, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        ]);
        $db->exec('PRAGMA busy_timeout = 5000');
        $db->exec('CREATE TABLE IF NOT EXISTS iocs (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            type          TEXT NOT NULL,
            value         TEXT NOT NULL,
            source        TEXT NOT NULL DEFAULT \'manual\',
            confidence    TEXT NOT NULL DEFAULT \'medium\',
            notes         TEXT NOT NULL DEFAULT \'\',
            tags          TEXT NOT NULL DEFAULT \'\',
            added_by      TEXT NOT NULL DEFAULT \'\',
            source_ref    TEXT NOT NULL DEFAULT \'\',
            created_at    INTEGER NOT NULL,
            last_seen_at  INTEGER NOT NULL,
            expires_at    INTEGER,
            active        INTEGER NOT NULL DEFAULT 1,
            UNIQUE(type, value)
        )');
        $db->exec('CREATE INDEX IF NOT EXISTS idx_iocs_type_active ON iocs(type, active)');
        $db->exec('CREATE TABLE IF NOT EXISTS ioc_lookups (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            ioc_id      INTEGER NOT NULL REFERENCES iocs(id),
            service     TEXT NOT NULL,
            verdict     TEXT NOT NULL,
            detail      TEXT NOT NULL DEFAULT \'\',
            raw_json    TEXT NOT NULL DEFAULT \'\',
            checked_at  INTEGER NOT NULL,
            UNIQUE(ioc_id, service)
        )');
        $db->exec('CREATE INDEX IF NOT EXISTS idx_ioc_lookups_ioc ON ioc_lookups(ioc_id)');
        $db->exec('CREATE TABLE IF NOT EXISTS list_lookups (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            type        TEXT NOT NULL,
            value       TEXT NOT NULL,
            service     TEXT NOT NULL,
            verdict     TEXT NOT NULL,
            detail      TEXT NOT NULL DEFAULT \'\',
            raw_json    TEXT NOT NULL DEFAULT \'\',
            checked_at  INTEGER NOT NULL,
            UNIQUE(type, value, service)
        )');
        $db->exec('CREATE INDEX IF NOT EXISTS idx_list_lookups_type_value ON list_lookups(type, value)');
        $db->exec('CREATE TABLE IF NOT EXISTS feed_samples (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            feed        TEXT NOT NULL,
            sampled_at  INTEGER NOT NULL,
            count       INTEGER NOT NULL,
            age         INTEGER NOT NULL
        )');
        $db->exec('CREATE INDEX IF NOT EXISTS idx_feed_samples ON feed_samples(feed, sampled_at)');
        $cols = $db->query('PRAGMA table_info(iocs)')->fetchAll(PDO::FETCH_COLUMN, 1);
        if (!in_array('promoted_at', $cols, true)) {
            $db->exec('ALTER TABLE iocs ADD COLUMN promoted_at INTEGER');
        }
        $db->exec('CREATE TABLE IF NOT EXISTS campaigns (
            id                 INTEGER PRIMARY KEY AUTOINCREMENT,
            from_domain        TEXT NOT NULL,
            subject_signature  TEXT NOT NULL,
            subject_sample     TEXT NOT NULL,
            message_count      INTEGER NOT NULL,
            first_seen_at      INTEGER NOT NULL,
            last_seen_at       INTEGER NOT NULL,
            status             TEXT NOT NULL DEFAULT \'new\',
            created_at         INTEGER NOT NULL,
            UNIQUE(from_domain, subject_signature)
        )');
        @chmod($path, 0640);
    } catch (Throwable $e) {
        throw new Exception('IOC database initialization failed: ' . $e->getMessage());
    }

    return $db;
}

function _ioc_valid_value(string $type, string $value): bool {
    switch ($type) {
        case 'ip':
            return filter_var($value, FILTER_VALIDATE_IP) !== false;
        case 'domain':
            return (bool) preg_match(
                '/^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)+$/i',
                $value);
        case 'url':
            return (bool) preg_match('#^https?://#i', $value)
                && filter_var($value, FILTER_VALIDATE_URL) !== false;
        case 'hash':
            return (bool) preg_match('/^[a-fA-F0-9]{32}$|^[a-fA-F0-9]{40}$|^[a-fA-F0-9]{64}$/', $value);
        case 'email':
            return filter_var($value, FILTER_VALIDATE_EMAIL) !== false;
        default:
            return false;
    }
}

// Insert a new indicator, or upsert (bump last_seen_at/confidence/source,
// reactivate) if (type, value) already exists. notes/tags/added_by/
// source_ref are left unchanged on an upsert -- the original curator's
// annotation is not silently overwritten by a later re-confirmation.
function ioc_add(array $data): array {
    $type  = trim((string)($data['type']  ?? ''));
    $value = trim((string)($data['value'] ?? ''));
    if (!in_array($type, IOC_TYPES, true)) {
        return [false, t('Ismeretlen indikátor-típus.'), null];
    }
    if ($value === '' || !_ioc_valid_value($type, $value)) {
        return [false, t('Érvénytelen érték ehhez a típushoz.'), null];
    }

    $source     = mb_substr(trim((string)($data['source'] ?? 'manual')), 0, 40);
    if ($source === '') $source = 'manual';
    $confidence = in_array($data['confidence'] ?? '', IOC_CONFIDENCE_LEVELS, true)
                ? $data['confidence'] : 'medium';
    $notes      = mb_substr(trim((string)($data['notes'] ?? '')), 0, 500);
    $tags       = mb_substr(trim((string)($data['tags'] ?? '')), 0, 200);
    $added_by   = mb_substr(trim((string)($data['added_by'] ?? '')), 0, 60);
    $source_ref = mb_substr(trim((string)($data['source_ref'] ?? '')), 0, 60);
    $expires_at = (isset($data['expires_at']) && (int)$data['expires_at'] > 0)
                ? (int)$data['expires_at'] : null;
    $now = time();

    try {
        $db   = _ioc_db();
        $stmt = $db->prepare(
            'INSERT INTO iocs (type, value, source, confidence, notes, tags, added_by,
                                source_ref, created_at, last_seen_at, expires_at, active)
             VALUES (:type, :value, :source, :confidence, :notes, :tags, :added_by,
                     :source_ref, :created_at, :last_seen_at, :expires_at, 1)
             ON CONFLICT(type, value) DO UPDATE SET
                last_seen_at = :last_seen_at,
                confidence   = :confidence,
                source       = :source,
                active       = 1,
                expires_at   = :expires_at'
        );
        $stmt->execute([
            ':type' => $type, ':value' => $value, ':source' => $source,
            ':confidence' => $confidence, ':notes' => $notes, ':tags' => $tags,
            ':added_by' => $added_by, ':source_ref' => $source_ref,
            ':created_at' => $now, ':last_seen_at' => $now, ':expires_at' => $expires_at,
        ]);

        $idStmt = $db->prepare('SELECT id FROM iocs WHERE type = :type AND value = :value');
        $idStmt->execute([':type' => $type, ':value' => $value]);
        $id = $idStmt->fetchColumn();

        // Seed the per-IOC lookup cache from any fresh VALUE-keyed results
        // (list_lookups): the Archívum IOC popup, the quarantine rows and
        // the list pages all persist their reputation checks there, keyed
        // by (type, value) -- so an indicator checked in the popup and then
        // added here would otherwise land on the IOC page with empty
        // badges, asking the operator to re-run lookups that finished
        // seconds ago (reported live). Same-source data, same TTL window,
        // zero repeated API calls; INSERT OR IGNORE so an existing per-IOC
        // row (re-adds) is never overwritten by an older value-keyed one.
        if ($id !== false) {
            try {
                $seed = $db->prepare(
                    'INSERT OR IGNORE INTO ioc_lookups (ioc_id, service, verdict, detail, raw_json, checked_at)
                     SELECT :id, service, verdict, detail, raw_json, checked_at
                       FROM list_lookups
                      WHERE type = :type AND value = :value AND checked_at >= :fresh');
                $seed->execute([':id' => (int)$id, ':type' => $type, ':value' => $value,
                                ':fresh' => $now - IOC_LOOKUP_TTL]);
            } catch (Throwable $e) {
                // Seeding is a convenience; the add itself must never fail on it.
            }
        }

        return [true, '', $id !== false ? (int)$id : null];
    } catch (Throwable $e) {
        return [false, t('Adatbázis hiba.'), null];
    }
}

// Existing confirmed IOC row matching this exact (type, value), or null.
// Case-insensitive on value: ioc_add() trims but never lowercases on
// insert, so a manually-added or extracted IOC can carry mixed case --
// COLLATE NOCASE matches regardless, rather than silently missing real
// matches because of stored-value casing.
function ioc_find_by_value(string $type, string $value): ?array {
    try {
        $stmt = _ioc_db()->prepare(
            'SELECT id, type, value, confidence FROM iocs
             WHERE type = :type AND value = :value COLLATE NOCASE AND active = 1 LIMIT 1');
        $stmt->execute([':type' => $type, ':value' => trim($value)]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    } catch (Throwable $e) {
        return null;
    }
}

function ioc_get(int $id): ?array {
    try {
        $stmt = _ioc_db()->prepare('SELECT * FROM iocs WHERE id = :id');
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row !== false ? $row : null;
    } catch (Throwable $e) {
        return null;
    }
}

// $filters keys (all optional): type, source, tag (substring), q (substring
// match against value/notes), active (bool, default true-only).
function ioc_list(array $filters = [], int $page = 1, int $per_page = 25): array {
    try {
        $where  = [];
        $params = [];

        $active = array_key_exists('active', $filters) ? (bool)$filters['active'] : true;
        $where[] = 'active = :active';
        $params[':active'] = $active ? 1 : 0;

        if (!empty($filters['type']) && in_array($filters['type'], IOC_TYPES, true)) {
            $where[] = 'type = :type';
            $params[':type'] = $filters['type'];
        }
        if (!empty($filters['source'])) {
            $where[] = 'source = :source';
            $params[':source'] = mb_substr((string)$filters['source'], 0, 40);
        }
        if (!empty($filters['tag'])) {
            $where[] = 'tags LIKE :tag ESCAPE \'\\\'';
            $params[':tag'] = '%' . str_replace(['%', '_'], ['\%', '\_'], (string)$filters['tag']) . '%';
        }
        if (!empty($filters['q'])) {
            $where[] = '(value LIKE :q ESCAPE \'\\\' OR notes LIKE :q ESCAPE \'\\\')';
            $params[':q'] = '%' . str_replace(['%', '_'], ['\%', '\_'], (string)$filters['q']) . '%';
        }

        $whereSql = 'WHERE ' . implode(' AND ', $where);
        $db = _ioc_db();

        $countStmt = $db->prepare("SELECT COUNT(*) FROM iocs $whereSql");
        $countStmt->execute($params);
        $total = (int) $countStmt->fetchColumn();

        $page     = max(1, $page);
        $per_page = max(1, $per_page);
        $offset   = ($page - 1) * $per_page;

        $stmt = $db->prepare(
            "SELECT * FROM iocs $whereSql ORDER BY last_seen_at DESC LIMIT :limit OFFSET :offset"
        );
        foreach ($params as $k => $v) $stmt->bindValue($k, $v);
        $stmt->bindValue(':limit', $per_page, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();

        return [$stmt->fetchAll(PDO::FETCH_ASSOC), $total];
    } catch (Throwable $e) {
        return [[], 0];
    }
}

function ioc_expire(int $id): bool {
    [$unpromoted] = ioc_unpromote($id);
    if (!$unpromoted) return false;
    try {
        $stmt = _ioc_db()->prepare('UPDATE iocs SET active = 0 WHERE id = :id');
        $stmt->execute([':id' => $id]);
        return $stmt->rowCount() > 0;
    } catch (Throwable $e) {
        return false;
    }
}

// Turns a confirmed ip/domain/url IOC into a live block. ip reuses the
// existing admin IP blocklist (src/lists.php) directly -- that's a
// separate JSON store, not derived from iocs.db, so there's no ordering
// concern there. domain/url is the opposite: _ioc_block_hosts_compile()
// reads its rows FROM iocs.db's promoted_at column, so promoted_at must be
// set BEFORE compiling (not after) and rolled back if the compile fails --
// a failed compile always means nothing changed on disk, since the atomic
// tempfile-then-rename write in _ioc_block_hosts_compile() never partially
// applies.
//
// ip ALSO stamps promoted_at, but purely as a provenance flag, not as
// enforcement state: enforcement truth for ip stays entirely in
// blocklist.json (compile()/the UI badge never read promoted_at for ip).
// promoted_at here only answers "did THIS feature add this block", so
// ioc_unpromote() can tell an IOC row it promoted apart from an unrelated
// row that merely shares a value with something an admin hand-blocklisted
// via the Blokkolás tab. Without this, expiring the latter would delete
// the former's block too -- see ioc_unpromote()'s comment below.
function ioc_promote(int $id): array {
    $row = ioc_get($id);
    if ($row === null) return [false, t('Ismeretlen indikátor.')];

    switch ($row['type']) {
        case 'ip':
            $err = list_add('block', 'ip', strtolower($row['value']), qa_user());
            if ($err !== '' && $err !== t('Ez a minta már szerepel a listán.')) {
                return [false, $err];
            }
            try {
                $stmt = _ioc_db()->prepare('UPDATE iocs SET promoted_at = :t WHERE id = :id');
                $stmt->execute([':t' => time(), ':id' => $id]);
            } catch (Throwable $e) { /* best-effort: enforcement already succeeded */ }
            return [true, ''];

        case 'domain':
        case 'url':
            $prev = $row['promoted_at'];
            try {
                $stmt = _ioc_db()->prepare('UPDATE iocs SET promoted_at = :t WHERE id = :id');
                $stmt->execute([':t' => time(), ':id' => $id]);
            } catch (Throwable $e) {
                return [false, t('Adatbázis hiba.')];
            }
            if (_ioc_block_hosts_compile()) return [true, ''];
            try {
                $stmt = _ioc_db()->prepare('UPDATE iocs SET promoted_at = :t WHERE id = :id');
                $stmt->execute([':t' => $prev, ':id' => $id]);
            } catch (Throwable $e) { /* best-effort rollback */ }
            return [false, t('Nem sikerült írni a blokklistát.')];

        default:
            return [false, t('Ez a típus nem élesíthető.')];
    }
}

// The single shared teardown path -- ioc_unpromote() itself, ioc_expire(),
// and ioc_expire_sweep() (Task 3) all call this rather than reimplementing
// the ip/domain/url branching. No-ops (returns success) if the row is
// missing, so every caller can call it speculatively.
//
// Every branch gates on `$row['promoted_at'] === null` INSIDE the branch,
// never as a blanket guard before the switch. An earlier version of this
// function had a blanket pre-switch guard, which made the ip branch
// permanently unreachable back when ip promotion never set promoted_at at
// all. Now that ioc_promote() stamps promoted_at for ip too (as a
// provenance flag -- see its comment), the per-branch guard is what makes
// list_remove() safe to call: it only fires for a row THIS feature
// promoted, never for a row that merely shares a value with something an
// admin hand-blocklisted via the Blokkolás tab. Calling list_remove()
// unconditionally (the pre-fix version of this function) silently deleted
// such unrelated manual entries whenever a same-valued, never-promoted IOC
// happened to expire -- caught by the final whole-branch review, not by
// any task-level review.
function ioc_unpromote(int $id): array {
    $row = ioc_get($id);
    if ($row === null) return [true, ''];

    switch ($row['type']) {
        case 'ip':
            if ($row['promoted_at'] === null) return [true, ''];
            list_remove('block', strtolower($row['value']));
            try {
                $stmt = _ioc_db()->prepare('UPDATE iocs SET promoted_at = NULL WHERE id = :id');
                $stmt->execute([':id' => $id]);
            } catch (Throwable $e) { /* best-effort: enforcement already removed */ }
            return [true, ''];

        case 'domain':
        case 'url':
            if ($row['promoted_at'] === null) return [true, ''];
            $prev = (int) $row['promoted_at'];
            try {
                $stmt = _ioc_db()->prepare('UPDATE iocs SET promoted_at = NULL WHERE id = :id');
                $stmt->execute([':id' => $id]);
            } catch (Throwable $e) {
                return [false, t('Adatbázis hiba.')];
            }
            if (_ioc_block_hosts_compile()) return [true, ''];
            try {
                $stmt = _ioc_db()->prepare('UPDATE iocs SET promoted_at = :t WHERE id = :id');
                $stmt->execute([':t' => $prev, ':id' => $id]);
            } catch (Throwable $e) { /* best-effort rollback */ }
            return [false, t('Nem sikerült írni a blokklistát.')];

        default:
            return [true, ''];
    }
}

// Self-gated dispatcher for every IOC-tab POST action, delegated to from
// handle_post() in actions.php. Mirrors handle_admin_post()'s self-gating
// style (checks its own permission rather than relying on the caller).
function handle_ioc_action(string $action): void {
    if (!can('admin')) { header('Location: ?'); exit; }

    switch ($action) {
        case 'ioc_extract':
            $uid = $_POST['msg_uid'] ?? '';
            if (!valid_uid($uid)) { header('Location: ?arc=1'); exit; }
            $cmd = SUDO . ' ' . QA_DOVEADM . ' fetch-text ' . escapeshellarg(ARCHIVE_USER)
                 . ' ' . escapeshellarg(ARCHIVE_MAILBOX) . ' ' . escapeshellarg($uid)
                 . ' 2>/dev/null | ' . PYTHON3 . ' ' . escapeshellarg(PARSE_EMAIL_PY);
            $json   = shell_exec($cmd);
            $parsed = $json ? json_decode($json, true) : null;
            if (!is_array($parsed) || isset($parsed['error'])) {
                header('Location: ?ioc=1&msg=ioc_extract_err'); exit;
            }
            $_SESSION['ioc_review'] = ['uid' => $uid, 'candidates' => ioc_extract_candidates($parsed)];
            audit_log('ioc-extract', ARCHIVE_USER, ARCHIVE_MAILBOX, $uid);
            header('Location: ?ioc=1'); exit;

        case 'ioc_confirm':
            $review = $_SESSION['ioc_review'] ?? null;
            unset($_SESSION['ioc_review']);
            $picked = $_POST['ioc_pick'] ?? [];
            $n = 0;
            if (is_array($review) && is_array($picked)) {
                foreach ($picked as $idxRaw) {
                    $idx = (int)$idxRaw;
                    if (!isset($review['candidates'][$idx])) continue;
                    $cand = $review['candidates'][$idx];
                    $conf = $_POST['ioc_conf'][$idx] ?? 'medium';
                    $note = trim((string)($_POST['ioc_note'][$idx] ?? ''));
                    [$ok] = ioc_add([
                        'type' => $cand['type'], 'value' => $cand['value'],
                        'source' => 'quarantine-confirm', 'confidence' => $conf,
                        'notes' => $note, 'added_by' => qa_user(),
                        'source_ref' => (string)($review['uid'] ?? ''),
                    ]);
                    if ($ok) $n++;
                }
            }
            if ($n > 0) audit_log('ioc-confirm', (string)($review['uid'] ?? ''), '', (string)$n);
            header('Location: ?ioc=1&msg=' . ($n > 0 ? 'ioc_confirmed' : 'ioc_none')); exit;

        case 'ioc_expire':
            $id = (int)($_POST['ioc_id'] ?? 0);
            $ok = $id > 0 && ioc_expire($id);
            if ($ok) audit_log('ioc-expire', (string)$id, '', '');
            header('Location: ?ioc=1&msg=' . ($ok ? 'ioc_expired' : 'ioc_err')); exit;

        case 'ioc_lookup':
            $id = (int)($_POST['ioc_id'] ?? 0);
            $isAjax = ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'XMLHttpRequest';
            if ($id <= 0) {
                if ($isAjax) {
                    header('Content-Type: application/json; charset=utf-8');
                    echo json_encode(['ok' => false, 'results' => [], 'errors' => ['_' => t('Érvénytelen indikátor.')]]);
                    exit;
                }
                header('Location: ?ioc=1&msg=ioc_lookup_err'); exit;
            }
            $result = ioc_lookup_run($id);
            $ok = count($result['results']) > 0 || count($result['errors']) === 0;
            audit_log('ioc-lookup', (string)$id, '', (string)count($result['results']));
            if ($isAjax) {
                header('Content-Type: application/json; charset=utf-8');
                echo json_encode([
                    'ok' => $ok, 'results' => $result['results'], 'errors' => $result['errors'],
                    'confidence' => ioc_lookup_confidence($result['results']),
                ]);
                exit;
            }
            header('Location: ?ioc=1&msg=' . ($ok ? 'ioc_lookup_ok' : 'ioc_lookup_err')); exit;

        case 'ioc_promote':
            $id = (int)($_POST['ioc_id'] ?? 0);
            if ($id <= 0) { header('Location: ?ioc=1&msg=ioc_promote_err'); exit; }
            [$ok, $err] = ioc_promote($id);
            if ($ok) audit_log('ioc-promote', (string)$id, '', '');
            $loc = '?ioc=1&msg=' . ($ok ? 'ioc_promote_ok' : 'ioc_promote_err');
            if ($err) $loc .= '&err=' . urlencode($err);
            header('Location: ' . $loc); exit;

        case 'ioc_unpromote':
            $id = (int)($_POST['ioc_id'] ?? 0);
            if ($id <= 0) { header('Location: ?ioc=1&msg=ioc_unpromote_err'); exit; }
            [$ok, $err] = ioc_unpromote($id);
            if ($ok) audit_log('ioc-unpromote', (string)$id, '', '');
            $loc = '?ioc=1&msg=' . ($ok ? 'ioc_unpromote_ok' : 'ioc_unpromote_err');
            if ($err) $loc .= '&err=' . urlencode($err);
            header('Location: ' . $loc); exit;

        case 'ioc_add':
            $expiresDays = (int)($_POST['ioc_expires_days'] ?? 0);
            [$ok, $err, $id] = ioc_add([
                'type'       => $_POST['ioc_type']   ?? '',
                'value'      => $_POST['ioc_value']  ?? '',
                'source'     => $_POST['ioc_source'] ?? 'manual',
                'confidence' => $_POST['ioc_confidence'] ?? 'medium',
                'notes'      => $_POST['ioc_notes']  ?? '',
                'tags'       => $_POST['ioc_tags']   ?? '',
                'added_by'   => qa_user(),
                'expires_at' => $expiresDays > 0 ? time() + $expiresDays * 86400 : null,
            ]);
            if ($ok) audit_log('ioc-add', (string)($_POST['ioc_value'] ?? ''), (string)($_POST['ioc_type'] ?? ''), (string)$id);
            $loc = '?ioc=1&msg=' . ($ok ? 'ioc_saved' : 'ioc_err');
            if ($err) $loc .= '&err=' . urlencode($err);
            header('Location: ' . $loc); exit;

        case 'ioc_bulk_import':
            $raw = (string)($_POST['ioc_bulk_hashes'] ?? '');
            if (trim($raw) === '') { header('Location: ?sysconfig=1&msg=ioc_bulk_import_err'); exit; }
            $confidence = in_array($_POST['ioc_bulk_confidence'] ?? '', IOC_CONFIDENCE_LEVELS, true)
                ? $_POST['ioc_bulk_confidence'] : 'medium';
            $result = ioc_bulk_import_hashes($raw, $confidence, qa_user());
            if ($result['added'] > 0) {
                audit_log('ioc-bulk-import', '', 'hash', (string)$result['added']);
            }
            header('Location: ?sysconfig=1&msg=ioc_bulk_import_ok'
                . '&added=' . $result['added']
                . '&dup=' . $result['duplicate']
                . '&inv=' . $result['invalid']);
            exit;

        default:
            header('Location: ?ioc=1'); exit;
    }
}

// True if $ip is a public/global address. Wraps
// FILTER_VALIDATE_IP|FILTER_FLAG_NO_PRIV_RANGE|FILTER_FLAG_NO_RES_RANGE, but
// those flags alone do NOT recognise the IPv4-mapped-IPv6 form
// ("::ffff:a.b.c.d") as being in the IPv4 private/loopback/reserved range
// even when the embedded IPv4 address plainly is -- "::ffff:10.0.0.1" and
// "::ffff:127.0.0.1" both pass the flags unmodified. So: if $ip is that
// mapped form, unwrap it and re-run the same check against the embedded
// IPv4 address instead.
//
// Unwraps via inet_pton()/binary inspection, not a textual regex: a purely
// textual "^::ffff:d.d.d.d$" pattern misses other valid spellings of the
// same mapped address -- the fully expanded form ("0:0:0:0:0:ffff:10.0.0.1")
// and the hex-notation trailing pair ("::ffff:7f00:1", = 127.0.0.1). Binary
// inspection of the parsed 16-byte form is spelling-agnostic and catches all
// of them.
function qa_is_public_ip(string $ip): bool {
    if (filter_var($ip, FILTER_VALIDATE_IP) === false) return false;
    $probe = $ip;
    $bin = @inet_pton($ip);
    if ($bin !== false && strlen($bin) === 16
        && substr($bin, 0, 12) === "\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xff\xff") {
        $probe = inet_ntop(substr($bin, 12));
    }
    return filter_var($probe, FILTER_VALIDATE_IP,
        FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false;
}

// Extracts every distinct public (non-private, non-reserved) bracketed
// IPv4/IPv6 literal from Received:-header lines found anywhere in
// $headerText, in first-seen order. Matches the optional RFC 5321 "IPv6:"
// literal prefix case-insensitively (e.g. "[IPv6:2a00:1450:400d:80d::200e]")
// -- the plain "[0-9a-fA-F:.]+" class used to exclude I/P/v, so those
// literals never matched.
//
// This is the general-purpose IP-from-Received extractor: every candidate,
// matched anywhere on any Received: line found in $headerText, for a human
// to review (ioc_extract_candidates() -- an admin picks which candidate, if
// any, to add). It does NOT back qa_topmost_received_client_ip() below --
// that function needs a single, automated, non-reviewed answer, which
// requires bounding the scan to physical line 1 of ONE specific Received
// block (see its own doc comment for why: this function's whole-block scan
// was tried there in an earlier version and was proven attacker-forgeable).
// The two therefore carry two DELIBERATELY SEPARATE copies of the bracket
// regex, at two different scopes -- this is not an accidental duplication
// to "clean up" by making one call the other; doing so would reopen the
// vulnerability qa_topmost_received_client_ip() exists to close. What IS
// shared, and must stay the single copy, is the public/private-address
// FILTER via qa_is_public_ip() -- both functions call it, neither
// re-implements it.
function qa_public_ips_in(string $headerText): array {
    $seen = [];
    $out  = [];
    if (preg_match_all('/^Received:.*$/mi', $headerText, $hdrMatches)) {
        foreach ($hdrMatches[0] as $hdrLine) {
            if (preg_match_all('/\[(?:IPv6:)?([0-9a-fA-F:.]+)\]/i', $hdrLine, $ipMatches)) {
                foreach ($ipMatches[1] as $ip) {
                    if (isset($seen[$ip])) continue;
                    if (qa_is_public_ip($ip)) {
                        $seen[$ip] = true;
                        $out[] = $ip;
                    }
                }
            }
        }
    }
    return $out;
}

// Selects the ONE trustworthy client IP out of a topmost Received: header
// this server's own Postfix wrote (never call this against a second,
// forwarded/attacker-controlled Received: block -- it applies no such
// distinction itself; that isolation is Task 1's job, done to
// $cur['hdr_received'] before this text ever reaches here).
//
// SUPERSEDED TWICE before landing on this version -- both prior attempts
// scanned the WHOLE (possibly multi-line, possibly unfolded) header value
// and were each defeated by finding a way to put attacker text later in
// that scanned text than Postfix's own client-IP group:
//   v1 "first bracket after the HELO token": defeated by a HELO containing
//      its own embedded parenthesised bracket group, e.g.
//      `EHLO x (evil [1.2.3.4])` -- reachable via any authenticated (incl.
//      stolen/brute-forced) SASL session, since smtpd_helo_restrictions on
//      this server evaluates permit_sasl_authenticated before
//      reject_invalid_hostname.
//   v2 "last bracket anywhere in the unfolded header, plus strip <...>
//      spans": defeated WITHOUT any authentication at all. Postfix's
//      cleanup process runs smtpd's own Received: header through the same
//      MIME-folding state machine as the client's message content
//      (mime_state.c's IS_SPACE_TAB branch has no guard distinguishing
//      smtpd-generated lines from client content); a message whose first
//      DATA line begins with a space or TAB is therefore folded onto this
//      header as an attacker-authored CONTINUATION line, which doveadm
//      returns verbatim and parse_fetch()'s accumulator (Task 1) accepts
//      (only a bare column-0 line stops it). Unfolding then placed that
//      attacker text AFTER Postfix's own group, and "last bracket wins"
//      handed it back. No exotic HELO or RCPT needed -- ordinary spam with
//      an unlucky first body line was enough.
// Both versions' comments claimed a "nothing can land later in the string"
// invariant; both claims were false because neither version bounded the
// scanned text to the region Postfix itself controls. Do not reintroduce
// either approach, and do not re-add an unfold.
//
// THE ACTUAL INVARIANT: smtpd emits this header as a single internal
// record, `"Received: from %s (%s [%s])"` (HELO, rDNS-or-"unknown", real
// client IP) -- and that record is exactly, and only, PHYSICAL LINE 1 of
// the stored header (verified against 2530 real messages: the genuine
// client-IP group was on line 1 in every one that had a "from" clause at
// all; 0 were only-on-continuation). Everything from "by <us> (Postfix)
// ..." onward -- including any attacker-influenced fold-in -- is written to
// continuation lines, never line 1. So: scan ONLY line 1, never unfold, and
// the HELO argument is once again a pure prefix on that single line,
// restoring the "last bracket on the line is Postfix's own" argument on a
// region that is actually bounded to what smtpd wrote.
//
// Two runtime-checked anchors, not assumptions: `^\s*from ` requires line 1
// to actually be a "from" record; a trailing `\])$` requires line 1 to be
// that record IN FULL. This rule's dependency is narrow and checked at
// runtime (either anchor can fail closed); v1/v2's dependency was an
// unverifiable claim about the entire rest of the header.
//
// NO "<...>" STRIP -- a prior version of this function had one, on the
// (false) theory it was a harmless leftover from scanning the whole header.
// On line 1 specifically it can only ever DELETE trustworthy content, never
// remove attacker text -- proved with a discriminating input (one where the
// raw and stripped forms actually disagree, not one where they happen to
// agree): `from x [9.9.9.9]) <trailing text>` ends in `t>` on line 1, so the
// anchor correctly fails closed to '' -- UNTIL the strip deletes the
// "<trailing text>" span, leaving `from x [9.9.9.9])`, which now matches and
// wrongly returns the earlier, otherwise-irrelevant [9.9.9.9]. Not reachable
// today -- Postfix's own smtpd writes nothing after the real group's
// closing ")" on line 1, and state->name is hostname-filtered (no "<"/">")
// or the literal "unknown" -- but it is dead code that is a live hazard the
// moment line 1's shape ever changes, for a clause ("for <addr>") that is
// already out of scope by construction (always on a later, unscanned line).
// Do not re-add it.
//
// LENGTH CAP -- not a hardening flourish, closes a live-comment-contradicts-
// reality gap: the DELIBERATE BEHAVIOUR CHANGE paragraph below claims a
// Postfix-folded long line 1 always degrades to ''. That is true only when
// the fold lands inside or before Postfix's own group. An authenticated
// (SASL-bypasses-reject_invalid_hostname) sender can pad a HELO so that an
// attacker-authored "(x [1.2.3.4])" sits immediately before the byte where a
// delivery agent's line-folding lands -- then line 1 ends in "])" right
// after the ATTACKER's bracket, and the anchor matches it instead of
// Postfix's real, not-yet-appended group. Per the final whole-branch review
// (task-3-final-review.md §1.4, not independently re-run here): not live on
// THIS server today -- virtual_transport = virtual, and virtual(8)
// reconstructs long lines on delivery rather than folding them; postmap -q
// against all 16 local domains found none routing through lmtp:/smtp:,
// which are the transports that fold at
// smtp_line_length_limit/lmtp_line_length_limit instead -- but that safety
// is an unstated, unchecked property of the delivery agent, not of this
// function, and moving mail delivery to Dovecot LMTP (the mainstream
// layout) would make it live with no other change. Cap line 1 at 600 bytes
// so the function is safe independent of which delivery agent is
// configured: worst-case LEGITIMATE line 1, per that same review, counted
// so the threshold is auditable rather than asserted --
// "from " (5) + HELO (valid_hostname() caps at 255) + " (" (2) + rDNS (255)
// + " [" (2) + an IPv6:-prefixed full-form literal (45) + "])" (2) =
// 566 bytes. The real corpus on this server tops out at 145 bytes (5000-
// message sample, p99 = 120). 600 therefore never truncates a genuine
// result and reliably makes an over-long (attacker-extended or otherwise)
// line 1 unmatchable, degrading to '' exactly as the next paragraph claims.
//
// DELIBERATE BEHAVIOUR CHANGE, do not "fix" it back: a long HELO/rDNS pair
// that Postfix itself folds so the bracketed IP lands on a continuation
// line (not line 1) now returns '' instead of that IP -- whether via the
// line-1-only scope above, or via the length cap once line 1 itself grows
// past 600 bytes. Measured as vanishingly rare (0/2530 in the real corpus)
// and the correct trade -- empty degrades to "no IP reputation shown"
// (safe); resuming a whole-header scan (or dropping the cap) to recover
// that rare case is exactly what reopened the last two vulnerabilities.
//
// RESIDUAL ASSUMPTION, not fixed here (no cheap check exists): this
// function trusts that the topmost Received: it's given was written by
// THIS server's own smtpd -- true for every SMTP-delivered message, but not
// for one placed into a mailbox via IMAP APPEND (e.g. a user copying mail
// in from another account), whose own topmost Received: can be wholly
// attacker-authored. An attacker able to forge the first occurrence could
// also forge a plausible "by <ourhost> (Postfix) ..." trailer, so there is
// no purely textual fix; this is a documentation gap, not an actionable one.
//
// Verified against: the body fold-in Critical (leading space and leading
// TAB), the padded-HELO-plus-fold length-cap attack, the <...>-delete case
// above, a bare "[8.8.8.8]" HELO literal, a HELO with one/multiple embedded
// fake "(evil [ip])" group(s), a HELO embedding an entire fake
// " by ... (Postfix) ... for <x>; <date>" trailer with its own fake
// bracket, IPv6 and IPv6-mapped forms, "no from clause at all"
// (local/pickup delivery), "private client IP", and a domain-literal
// "for <addr@[ip]>" trailer -- all of the latter group resolve to ''
// (no from-clause / no bracket / over-length cases) or the real IP, never
// an attacker-chosen one. Real with-received.txt fixture: uid 10/11 ->
// 85.25.172.24, uid 12-15 -> 147.45.178.119, unchanged by this rewrite.
//
// Returns '' -- never a sender-controlled fallback -- when line 1 exceeds
// 600 bytes, doesn't match the anchored "from ... [ip])" shape in full, or
// the literal isn't a public address. An empty sender IP degrades to
// "no IP reputation shown", which is safe; a wrong one is not.
function qa_topmost_received_client_ip(string $rawReceivedBlock): string {
    $lines = explode("\n", $rawReceivedBlock);
    $line1 = rtrim($lines[0] ?? '', " \t\r");
    // Since the LMTP delivery switch (2026-08-21) our own Dovecot prepends
    // ONE more Received above smtpd's record: "from <our-host>" with no
    // bracketed IP, continuation "by <host> with LMTP". Both identifying
    // features are required before anything is skipped, and exactly one
    // header is skipped -- its record ends at the first line not starting
    // with whitespace, which is smtpd's own physical line 1, evaluated
    // under the unchanged strict rule below. An attacker still cannot get
    // above smtpd's record, so the trust argument is exactly as before;
    // any shape mismatch still fails to '' (no flag) rather than guessing.
    if (preg_match('/^\s*from \S+$/i', $line1)
        && isset($lines[1]) && stripos($lines[1], 'with LMTP') !== false) {
        $i = 1;
        while (isset($lines[$i]) && ($lines[$i][0] ?? '') !== '' && strpos(" \t", $lines[$i][0]) !== false) $i++;
        $line1 = rtrim($lines[$i] ?? '', " \t\r");
    }
    if (strlen($line1) > 600) {
        return '';
    }
    if (!preg_match('/^\s*from .*\[(?:IPv6:)?([0-9a-fA-F:.]+)\]\)$/i', $line1, $m)) {
        return '';
    }
    return qa_is_public_ip($m[1]) ? $m[1] : '';
}

// Isolates the bare address out of a decoded From: header the same way
// quar_row_indicators() (src/quar_lookup.php) does for what actually gets
// domain-graded -- take the LAST "<...>" angle-addr, not the first: RFC 5322
// puts the real mailbox in the final angle-addr, and a sender-controlled
// display-name/quoted-string earlier in the header can itself contain
// "<...>"-shaped text (e.g. `"click <phish@evil.com>" <user@real.example>`).
// Falls through to the raw string when there's no angle-addr at all (a bare
// "user@domain" From: header).
//
// This is intentionally the SAME logic as quar_row_indicators()'s inline
// extraction, not a call to it: that function lives in src/quar_lookup.php,
// out of scope for this pass, and stays the single source of truth for what
// gets graded. Verified byte-for-byte identical output against it. Used by
// views/quarantine.php so the Feladó column's displayed address and the
// reputation badge's graded address can never name a different domain --
// before the badge existed this was a cosmetic display quirk (the shown
// name/email could differ from what a "block sender" action targeted); now
// that a reputation verdict sits next to it, showing a verdict beside an
// address it was never computed for is a real, actionable misread.
function qa_last_angle_addr(string $from): string {
    if (preg_match_all('/<([^>]+)>/', $from, $fm) && $fm[1]) {
        return end($fm[1]);
    }
    return $from;
}

// Parses the same associative array parse_email.py emits (and handle_view()
// already decodes) for candidate indicators. Returns suggestions only --
// nothing here writes to the DB. Caps URL candidates at 15: HTML newsletters
// routinely embed dozens of tracking links, and a single message proposing
// that many candidates would make the review screen unusable.
function ioc_extract_candidates(array $parsed): array {
    $seen = [];
    $out  = [];
    $add  = function (string $type, string $value) use (&$seen, &$out): bool {
        $key = $type . '|' . $value;
        if (isset($seen[$key])) return false;
        $seen[$key] = true;
        $out[] = ['type' => $type, 'value' => $value];
        return true;
    };

    // Sender IPs: every bracketed IPv4/IPv6 literal in a Received: header,
    // filtered to public/global addresses only. Extract only the RFC822
    // header block (before the first blank line) to avoid matching fake
    // Received: lines in the attacker-controlled message body. The
    // regex+filter itself lives in qa_public_ips_in() (shared with
    // parse_fetch()'s sender-IP derivation) -- do not duplicate it here.
    $source = (string)($parsed['source'] ?? '');
    $headerBlockEnd = preg_match('/\r?\n\r?\n/', $source, $m, PREG_OFFSET_CAPTURE)
        ? $m[0][1] : strlen($source);
    $headerBlock = substr($source, 0, $headerBlockEnd);
    foreach (qa_public_ips_in($headerBlock) as $ip) {
        $add('ip', $ip);
    }

    // From-domain.
    $from = (string)($parsed['from'] ?? '');
    if (preg_match('/@([a-z0-9.-]+\.[a-z]{2,})/i', $from, $m)) {
        $domain = strtolower($m[1]);
        if (_ioc_valid_value('domain', $domain)) $add('domain', $domain);
    }

    // URLs in the plain-text body, capped at 15 distinct candidates.
    // Count only newly added URLs (via $add's return value), not duplicates,
    // so repeated URLs don't starve out distinct ones.
    $body = (string)($parsed['body'] ?? '');
    if (preg_match_all('#https?://[^\s"\'<>]+#i', $body, $urlMatches)) {
        $count = 0;
        foreach ($urlMatches[0] as $url) {
            if ($count >= 15) break;
            $url = rtrim($url, '.,;)]');
            if (_ioc_valid_value('url', $url) && $add('url', $url)) $count++;
        }
    }

    // Attachment hashes (Task 5's parse_email.py addition).
    foreach ((array)($parsed['attachments'] ?? []) as $att) {
        $hash = (string)($att['sha256'] ?? '');
        if (_ioc_valid_value('hash', $hash)) $add('hash', $hash);
    }

    return $out;
}

// Marks every active row whose expires_at has passed as inactive. Returns
// the count affected (or that would be affected, under dry-run). Run
// nightly from cron as the apache user -- no root, no sudo helper: this is
// a plain DB write against a file PHP (running as apache) already owns.
function ioc_expire_sweep(bool $dryRun = false): int {
    try {
        $now = time();
        if ($dryRun) {
            $stmt = _ioc_db()->prepare(
                'SELECT COUNT(*) FROM iocs WHERE active = 1 AND expires_at IS NOT NULL AND expires_at <= :now');
            $stmt->execute([':now' => $now]);
            return (int) $stmt->fetchColumn();
        }
        $stmt = _ioc_db()->prepare(
            'SELECT id FROM iocs
             WHERE active = 1 AND expires_at IS NOT NULL AND expires_at <= :now');
        $stmt->execute([':now' => $now]);
        $ids = $stmt->fetchAll(PDO::FETCH_COLUMN);
        $ready = [];
        foreach ($ids as $pid) {
            [$unpromoted] = ioc_unpromote((int) $pid);
            if ($unpromoted) $ready[] = (int) $pid;
        }
        if (empty($ready)) return 0;
        $placeholders = implode(',', array_fill(0, count($ready), '?'));
        $stmt = _ioc_db()->prepare("UPDATE iocs SET active = 0 WHERE id IN ($placeholders)");
        $stmt->execute($ready);
        return $stmt->rowCount();
    } catch (Throwable $e) {
        return 0;
    }
}
