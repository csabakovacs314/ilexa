<?php
// Re-send a copy of an archived message to a recipient (default: header To).
// Sends the ORIGINAL raw message via a fresh injection.

// Outcome message for a Ham/Spam learn action. Single source of truth --
// also called from views/archive.php's $arc_notices banner array, so the
// wording never has to be kept in sync by hand in two places.
function arc_learn_message(string $class, string $outcome): string {
    $map = [
        'spam' => [
            'learned' => t('Az üzenet spamként megtanítva.'),
            'skipped' => t('Az rspamd már magabiztosan spamként ismerte fel - nem volt szükség tanításra.'),
            'failed'  => t('A tanítás nem sikerült - lásd a naplót.'),
        ],
        'ham' => [
            'learned' => t('Az üzenet hamként megtanítva.'),
            'skipped' => t('Az rspamd már magabiztosan hamként ismerte fel - nem volt szükség tanításra.'),
            'failed'  => t('A tanítás nem sikerült - lásd a naplót.'),
        ],
    ];
    return $map[$class][$outcome] ?? t('A tanítás nem sikerült - lásd a naplót.');
}

function archive_resend(string $uid, string $rcpt): bool {
    if (!valid_uid($uid)) return false;
    if (!filter_var($rcpt, FILTER_VALIDATE_EMAIL)) {
        $to = qa_da(['fetch-hdr-to', ARCHIVE_USER, ARCHIVE_MAILBOX, $uid]);
        if (preg_match('/[\w.+\-]+@[\w.\-]+\.[A-Za-z]{2,}/', $to, $m)) $rcpt = $m[0];
    }
    if (!filter_var($rcpt, FILTER_VALIDATE_EMAIL)) {
        audit_log('arc-resend-FAIL', ARCHIVE_USER, ARCHIVE_MAILBOX, $uid);
        return false;
    }
    $cmd = SUDO . ' ' . QA_DOVEADM . ' fetch-text ' . escapeshellarg(ARCHIVE_USER)
         . ' ' . escapeshellarg(ARCHIVE_MAILBOX) . ' ' . escapeshellarg($uid)
         . ' 2>/dev/null | tail -n +2'
         . ' | ' . SENDMAIL . ' -i -f ' . escapeshellarg(POSTMASTER_FROM) . ' ' . escapeshellarg($rcpt)
         . ' 2>&1; echo "__RC:$?"';
    $raw = (string) shell_exec($cmd);
    $rc  = preg_match('/__RC:(\d+)\s*$/', $raw, $m) ? (int) $m[1] : -1;
    // Record the destination, and whether sendmail actually accepted it - a
    // resend that silently failed used to look identical to one that worked.
    audit_log($rc === 0 ? 'arc-resend' : 'arc-resend-FAIL', $rcpt, ARCHIVE_MAILBOX, $uid);
    return $rc === 0;
}

// Record that an admin already taught rspamd this verdict for this archived
// message, so the Archívum list can show it instead of risking a duplicate
// teach. Only called after rspamd_learn() reports a confirmed live success -
// never for a dry-run/log-only "learn" (nothing was actually taught) or a
// failed one. Best-effort: audit_db()'s column-scoped UPDATE grant covers
// exactly learned_as/learned_at, nothing else, and a failure here (e.g. DB
// briefly unavailable) does not affect rspamd already having learned it.
// rspamd's ORIGINAL verdict for a message, or null if it is not indexed.
//
// Needed so the UI can say that an admin's teaching disagreed with the filter.
// Read before archive_mark_learned() overwrites nothing (is_spam is untouched
// by teaching) -- teaching records what the admin decided, it does not rewrite
// what rspamd decided, and both are worth keeping: the disagreement is the
// signal that tells you the filter needs tuning.
function archive_original_is_spam(string $uid): ?bool {
    $db = audit_db();
    if (!$db) return null;
    try {
        $st = $db->prepare('SELECT is_spam FROM archive_index WHERE uid = ?');
        $st->execute([$uid]);
        $v = $st->fetchColumn();
        return $v === false ? null : (bool)(int)$v;
    } catch (Throwable $e) {
        return null;
    }
}

function archive_mark_learned(string $uid, string $class): void {
    $db = audit_db();
    if (!$db) return;
    try {
        $st = $db->prepare('UPDATE archive_index SET learned_as = ?, learned_at = ? WHERE uid = ?');
        $st->execute([$class, time(), $uid]);
    } catch (Throwable $e) {
        // Silently best-effort, per the comment above.
    }
}

// Query the archive metadata index (postfix.archive_index). Never touches doveadm/FTS.
// Returns [rows, total, err].
function archive_search(array $f, int $page, int $per_page): array {
    $db = audit_db();
    if (!$db) return [[], 0, 'db'];
    $w = []; $p = [];
    if (($f['domain'] ?? '') !== '') { $w[] = '(from_addr LIKE :dom OR to_addr LIKE :dom)'; $p[':dom'] = '%@' . $f['domain'] . '%'; }
    if ($f['since']  !== '') { $w[] = 'ts >= :since';  $p[':since']  = strtotime($f['since']  . ' 00:00:00'); }
    if ($f['before'] !== '') { $w[] = 'ts < :before';  $p[':before'] = strtotime($f['before'] . ' 00:00:00') + 86400; }
    if ($f['from']    !== '') { $w[] = 'from_addr LIKE :frm'; $p[':frm']  = '%' . $f['from'] . '%'; }
    if ($f['to']      !== '') { $w[] = 'to_addr LIKE :to';    $p[':to']   = '%' . $f['to'] . '%'; }
    if ($f['subject'] !== '') { $w[] = 'subject LIKE :subj';  $p[':subj'] = '%' . $f['subject'] . '%'; }
    if ($f['status'] === 'spam')     $w[] = 'is_spam = 1';
    elseif ($f['status'] === 'ham')  $w[] = 'is_spam = 0';
    $wsql = $w ? ('WHERE ' . implode(' AND ', $w)) : '';
    try {
        $c = $db->prepare("SELECT COUNT(*) FROM archive_index $wsql");
        $c->execute($p);
        $total = (int) $c->fetchColumn();
        $off = ($page - 1) * $per_page;
        $oc = in_array($_GET['asort'] ?? '', ['ts','from_addr','to_addr','subject','rspamd_score','is_spam','sender_cc'], true)
              ? $_GET['asort'] : 'ts';
        $od = strtoupper($_GET['adir'] ?? '') === 'ASC' ? 'ASC' : 'DESC';
        $q = $db->prepare("SELECT uid, ts, from_addr, to_addr, subject, rspamd_score, is_spam, learned_as, learned_at,
                                  sender_ip, sender_cc
                           FROM archive_index $wsql ORDER BY $oc $od, ts DESC LIMIT $per_page OFFSET $off");
        $q->execute($p);
        return [$q->fetchAll(PDO::FETCH_ASSOC), $total, ''];
    } catch (Throwable $e) {
        return [[], 0, 'query'];
    }
}

// Dashboard stats: rspamd scan/learn totals + archive volume/top-senders.
function dashboard_data(): array {
    $d = ['rspamc' => [], 'week' => ['total'=>0,'spam'=>0], 'month' => ['total'=>0,'spam'=>0],
          'daily' => [], 'hourly' => [], 'err' => ''];

    $stat = (string) shell_exec(RSPAMC . ' stat 2>/dev/null');
    if ($stat !== '') {
        if (preg_match('/Messages scanned:\s*(\d+)/', $stat, $m))               $d['rspamc']['scanned'] = (int)$m[1];
        if (preg_match('/treated as spam:\s*(\d+),\s*([\d.]+)%/', $stat, $m))    { $d['rspamc']['spam'] = (int)$m[1]; $d['rspamc']['spam_pct'] = $m[2]; }
        if (preg_match('/treated as ham:\s*(\d+),\s*([\d.]+)%/', $stat, $m))     { $d['rspamc']['ham']  = (int)$m[1]; }
        if (preg_match('/Messages learned:\s*(\d+)/', $stat, $m))               $d['rspamc']['learned'] = (int)$m[1];
        if (preg_match('/BAYES_SPAM[^\n]*learned:\s*(\d+)/', $stat, $m))         $d['rspamc']['bayes_spam'] = (int)$m[1];
        if (preg_match('/BAYES_HAM[^\n]*learned:\s*(\d+)/', $stat, $m))          $d['rspamc']['bayes_ham'] = (int)$m[1];
    }

    $db = audit_db();
    if (!$db) { $d['err'] = 'db'; return $d; }
    try {
        $since7 = strtotime('-7 days'); $since30 = strtotime('-30 days');
        foreach (['week' => $since7, 'month' => $since30] as $k => $ts) {
            $st = $db->prepare("SELECT COUNT(*) c, COALESCE(SUM(is_spam),0) s FROM archive_index WHERE ts >= ?");
            $st->execute([$ts]);
            $r = $st->fetch(PDO::FETCH_ASSOC);
            $d[$k] = ['total' => (int)$r['c'], 'spam' => (int)$r['s']];
        }
        $d['hourly']  = hourly_bars($db);
        $d['daily']   = daily_bars($db, 7);
        $d['daily30'] = daily_bars($db, 30);
    } catch (Throwable $e) {
        $d['err'] = 'query';
    }
    return $d;
}

// Exactly $days calendar-day buckets ending today (not a rolling N*24h window,
// so "7 days" always means 7 bars), zero-filled for days with no archived mail.
function daily_bars(PDO $db, int $days): array {
    $since = strtotime('today') - ($days - 1) * 86400;
    $st = $db->prepare("SELECT FROM_UNIXTIME(ts,'%Y-%m-%d') d, COUNT(*) c, COALESCE(SUM(is_spam),0) s FROM archive_index WHERE ts >= ? GROUP BY d ORDER BY d");
    $st->execute([$since]);
    $by_day = [];
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $by_day[$r['d']] = $r;
    $out = [];
    for ($i = $days - 1; $i >= 0; $i--) {
        $day = date('Y-m-d', strtotime("today -$i days"));
        $out[] = $by_day[$day] ?? ['d' => $day, 'c' => 0, 's' => 0];
    }
    return $out;
}

// Last 24 hours as 24 HOURLY buckets, same shape as daily_bars() so the
// dashboard's bar chart renders it without a second code path.
//
// Hourly rather than a single 24h total: one bar carries no more information
// than the number already shown elsewhere on the page, whereas the intraday
// shape is the thing a daily/weekly view cannot show -- a spam burst at 03:00
// is invisible in a day column that also contains normal business traffic.
//
// Buckets are the last 24 CLOCK hours ending with the current one, not
// "today's hours": at 09:00 the useful question is what arrived since 09:00
// yesterday, not the nine bars since midnight. The label is the hour alone
// ("14"), with the full timestamp in the bar's title.
function hourly_bars(PDO $db): array {
    $since = strtotime(date('Y-m-d H:00:00')) - 23 * 3600;
    $st = $db->prepare("SELECT FROM_UNIXTIME(ts,'%Y-%m-%d %H') h, COUNT(*) c, COALESCE(SUM(is_spam),0) s
                        FROM archive_index WHERE ts >= ? GROUP BY h ORDER BY h");
    $st->execute([$since]);
    $by_hour = [];
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $by_hour[$r['h']] = $r;
    $out = [];
    for ($i = 23; $i >= 0; $i--) {
        $ts  = $since + (23 - $i) * 3600;
        $key = date('Y-m-d H', $ts);
        $row = $by_hour[$key] ?? ['c' => 0, 's' => 0];
        // 'd' is what the shared bar template reads for its label/title.
        $out[] = ['d' => $key, 'c' => (int)$row['c'], 's' => (int)$row['s'],
                  'label' => date('H', $ts)];
    }
    return $out;
}

// Parse the Archívum filter GET params (shared by archive view + CSV export).
function parse_af(): array {
    return [
        'domain'  => preg_match('/^[a-z0-9.-]{1,64}$/i', (string)($_GET['adomain'] ?? '')) ? strtolower((string)$_GET['adomain']) : '',
        'from'    => mb_substr(trim((string)($_GET['afrom']    ?? '')), 0, 120),
        'to'      => mb_substr(trim((string)($_GET['ato']      ?? '')), 0, 120),
        'subject' => mb_substr(trim((string)($_GET['asubject'] ?? '')), 0, 120),
        'since'   => valid_date($_GET['asince']  ?? '') ? ($_GET['asince']  ?? '') : date('Y-m-d', strtotime('-30 days')),
        'before'  => valid_date($_GET['abefore'] ?? '') ? ($_GET['abefore'] ?? '') : '',
        'status'  => in_array($_GET['astatus'] ?? '', ['spam', 'ham'], true) ? ($_GET['astatus'] ?? '') : '',
    ];
}

// Hidden filter fields carried through archive POST actions (PRG round-trip).
function arc_hidden(array $af, int $page): string {
    $f = ['af_domain' => $af['domain'], 'af_from' => $af['from'], 'af_to' => $af['to'], 'af_subject' => $af['subject'],
          'af_status' => $af['status'], 'af_since' => $af['since'], 'af_before' => $af['before'],
          'af_page' => $page];
    $out = '';
    foreach ($f as $k => $v) $out .= '<input type="hidden" name="' . $k . '" value="' . h((string)$v) . '">';
    return $out;
}

// A one-button inline POST form for an archive learn action.
// Row buttons post through ONE shared form (see arc_shared_form below) instead
// of carrying their own. Each per-row form previously re-serialised all eleven
// filter fields, so a 25-row page built ~100 forms and ~1200 inputs.
function arc_action_form(string $action, string $uid, array $af, int $page, string $label, string $confirm, string $class = ''): string {
    return '<button type="button" class="btn btn-sm' . ($class !== '' ? ' ' . h($class) : '') . '"'
        . ' onclick="arcSubmit(' . htmlspecialchars(json_encode($action), ENT_QUOTES)
        . ',' . (int)$uid . ',null,' . htmlspecialchars(json_encode($confirm), ENT_QUOTES) . ')">'
        . $label . '</button>';
}

// The single form every row button posts through. Rendered once per page.
function arc_shared_form(array $af, int $page): string {
    return '<form id="arcActionForm" method="post" action="" style="display:none">'
        . csrf_field()
        . '<input type="hidden" name="action"  id="arcActX">'
        . '<input type="hidden" name="msg_uid" id="arcActUid">'
        . '<input type="hidden" name="sender"  id="arcActSender">'
        . '<input type="hidden" name="back"    value="arc">'
        . arc_hidden($af, $page)
        . '</form>';
}

// Inline POST form to block/whitelist the sender of an archived message.
function sender_list_form(string $which, string $sender, array $af, int $page, string $label, string $confirm, string $class = 'btn-secondary'): string {
    $action = $which === 'white' ? 'quick_white' : 'quick_block';
    return '<button type="button" class="btn btn-sm' . ($class !== '' ? ' ' . h($class) : '') . '"'
        . ' onclick="arcSubmit(' . htmlspecialchars(json_encode($action), ENT_QUOTES)
        . ',null,' . htmlspecialchars(json_encode($sender), ENT_QUOTES)
        . ',' . htmlspecialchars(json_encode($confirm), ENT_QUOTES) . ')">'
        . $label . '</button>';
}
