<?php
// Feed quality: entry-count history and the health verdict derived from it.
//
// Why history exists at all: cron-alert.sh already surfaces a feed job that
// FAILS. What was invisible is a feed that keeps succeeding while its content
// degrades -- an upstream returning a truncated list looks identical to a
// healthy one, because every status sample used to be rendered and discarded.

const FEED_SAMPLE_KEEP_DAYS = 90;
// The trailing window every history read and the baseline share.
const FEED_HISTORY_DAYS = 14;

// Records one sample. Returns false rather than throwing so a sampler run can
// report a partial failure without aborting the remaining feeds.
function feed_sample_record(string $feed, int $count, int $age, int $now = 0): bool {
    if ($feed === '' || $count < 0) return false;
    try {
        $st = _ioc_db()->prepare(
            'INSERT INTO feed_samples (feed, sampled_at, count, age) VALUES (?, ?, ?, ?)'
        );
        return $st->execute([$feed, $now ?: time(), $count, $age]);
    } catch (\Throwable $e) {
        return false;
    }
}

function feed_samples_prune(int $keepDays = FEED_SAMPLE_KEEP_DAYS): int {
    try {
        $st = _ioc_db()->prepare('DELETE FROM feed_samples WHERE sampled_at < ?');
        $st->execute([time() - $keepDays * 86400]);
        return $st->rowCount();
    } catch (\Throwable $e) {
        return 0;
    }
}

// Oldest-first, so a caller can render a left-to-right trend without reversing.
function feed_history(string $feed, int $days = FEED_HISTORY_DAYS): array {
    try {
        $st = _ioc_db()->prepare(
            'SELECT sampled_at, count FROM feed_samples
              WHERE feed = ? AND sampled_at >= ?
              ORDER BY sampled_at ASC'
        );
        $st->execute([$feed, time() - $days * 86400]);
        return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (\Throwable $e) {
        return [];
    }
}

// Collapses raw samples into one point per 24h bucket, oldest-first, keeping
// the most recent reading in each bucket.
//
// Buckets are measured back from now, NOT aligned to UTC midnight: age-based
// bucketing over a D-day window yields at most D points, whereas midnight
// alignment yields D+1 whenever the window opens mid-day -- which would make
// the "14 nap" label overstate its own content, the exact mismatch this
// helper exists to remove.
function feed_history_daily(array $hist, int $now = 0, int $days = FEED_HISTORY_DAYS): array {
    $now   = $now ?: time();
    $byDay = [];
    foreach ($hist as $r) {
        $d = intdiv($now - (int) $r['sampled_at'], 86400);
        // feed_history()'s cutoff is inclusive and is evaluated against a slightly
        // earlier time() than this helper's, so a sample on the boundary can age
        // into bucket $days. Clamping here is what makes "at most $days points"
        // -- and the "14 nap" label built on it -- true rather than nearly true.
        // The $d < 0 half guards a future-dated sampled_at (clock skew on a
        // restored backup), which krsort() would otherwise place last, silently
        // reordering the series.
        if ($d < 0 || $d >= $days) continue;
        // feed_history() is ASC, so a later sample overwrites an earlier one
        // in the same bucket -- the most recent reading of that day wins.
        $byDay[$d] = (int) $r['count'];
    }
    // Key is age in days, so DESCENDING key order is oldest-first. krsort(),
    // never ksort() -- ksort() would silently render every trend backwards.
    krsort($byDay);
    return array_values($byDay);
}

// How far below its own baseline a feed must fall to count as collapsed.
// Per-feed by construction: these sources range from ~364 to ~35,652 entries,
// so a single global entry-count threshold would be meaningless.
const FEED_COLLAPSE_RATIO = 0.5;
// Minimum number of distinct *days* of history before a baseline is
// trustworthy -- days, not raw samples: the shipped sampler cron runs hourly,
// so five raw samples can be five readings of the same unchanged file, a fake
// sample count with zero smoothing. Below this the feed is 'unknown' rather
// than healthy -- claiming health from two readings is worse than admitting
// there is not enough history yet.
const FEED_BASELINE_MIN_DAYS = 5;

function feed_health(string $feed, array $status, int $cadence): array {
    $out = ['state' => 'unknown', 'baseline' => null, 'pct' => null, 'samples' => 0, 'history' => []];

    // One point per 24h bucket, shared by the baseline and by the caller's
    // trend tooltip, so the two always reconcile. 'samples' therefore counts
    // DAYS of history, not raw rows.
    $hist  = feed_history($feed, FEED_HISTORY_DAYS);
    $daily = feed_history_daily($hist);
    $out['samples'] = count($daily);
    $out['history'] = $daily;

    $age = (int) ($status['age'] ?? -1);
    // Staleness first, reusing the thresholds views/admin_system.php already
    // applies to these same feeds -- one definition of "stale" in the product.
    $stale = 'unknown';
    if ($age >= 0)                    $stale = 'ok';
    if ($age >= $cadence * 1.5)       $stale = 'stale';
    if ($age >= $cadence * 3.0)       $stale = 'old';

    // A missing or non-numeric count ("N/A", an absent key, an empty $status)
    // must not be coerced to 0 -- that fabricates a reading indistinguishable
    // from a feed that genuinely reports zero entries, and a fabricated zero
    // against a healthy baseline would manufacture a false collapse. Skip the
    // comparison, not the whole verdict: staleness still comes from $age and
    // is unaffected by whether the count was usable.
    $hasCount = array_key_exists('count', $status) && is_numeric($status['count']);

    if ($hasCount && count($daily) >= FEED_BASELINE_MIN_DAYS) {
        // Copy before sorting: $out['history'] must stay oldest-first.
        $counts = $daily;
        sort($counts);
        $n = count($counts);
        // Median, not mean and not the previous sample: one anomalous reading
        // must neither trip a false collapse nor become the baseline that
        // hides a real one.
        //
        // Accepted property: this is a TRAILING median over the same 14-day
        // window, so a collapse that persists longer than half the window
        // eventually pulls the median down to the collapsed level and the
        // alarm self-clears. That is inherent to a trailing baseline (the
        // alternative is a frozen reference nobody maintains) and is not a
        // bug to fix here.
        $mid = intdiv($n, 2);
        // Computed as a+floor((b-a)/2) rather than intdiv(a+b, 2): counts are
        // stored without an upper bound, and summing two values each near
        // PHP_INT_MAX overflows to float, which intdiv() then throws on.
        // Sorted ascending, so counts[mid] >= counts[mid-1] and the
        // subtraction below never goes negative or overflows.
        $baseline = ($n % 2)
            ? $counts[$mid]
            : $counts[$mid - 1] + intdiv($counts[$mid] - $counts[$mid - 1], 2);
        $out['baseline'] = $baseline;
        $cur = (int) $status['count'];
        if ($baseline > 0) {
            $out['pct'] = (int) round($cur * 100 / $baseline);
            if ($cur < $baseline * FEED_COLLAPSE_RATIO) {
                // Collapse outranks staleness: a feed that refreshed on time
                // and came back nearly empty is the more urgent signal.
                $out['state'] = 'collapsed';
                return $out;
            }
        }
    }

    $out['state'] = $stale;
    return $out;
}
