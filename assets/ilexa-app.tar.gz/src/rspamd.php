<?php
function learn_log(string $line): void {
    @file_put_contents(LEARN_LOG, '[' . date('Y-m-d H:i:s') . '] ' . $line . "\n",
                       FILE_APPEND | LOCK_EX);
}

// Train rspamd on a message before it leaves the quarantine folder.
//   $class = 'ham'  → on release (confirmed false-positive)
//   $class = 'spam' → on delete  (confirmed spam)
// Log-only unless LEARN_FLAG exists. Called BEFORE the move/expunge.
// Returns one of:
//   'learned' - rspamc exit 0 AND rspamd's own response body says
//               `success = true`: a real training event happened.
//   'skipped' - rspamc exit 0 but rspamd explicitly denied the learn (most
//               commonly because the message is already confidently
//               classified in that class, so training it again would be a
//               no-op). rc is 0 in this case too, so exit status alone
//               cannot tell 'learned' from 'skipped'.
//   'failed'  - every other path: dry-run/log-only mode, empty fetch,
//               missing controller password, or rspamc itself failing
//               (non-zero exit).
// Callers that need to know whether teaching actually happened (not just
// that it was requested) rely on this three-way distinction.
function rspamd_learn(string $class, string $user, string $folder, string $uid): string {
    if ($class !== 'ham' && $class !== 'spam') return 'failed';
    $cmd_name = 'learn_' . $class;
    $live     = is_file(LEARN_FLAG);

    // Strip scanner-added verdict headers (name + folded continuations) from the
    // header block only, so Bayes isn't taught rspamd's/MailScanner's own tokens.
    $strip = ' | awk \'BEGIN{h=1} h&&/^\r?$/{h=0} {if(h){if($0~/^[ \t]/){if(s)next}else{s=($0~/^([Xx]-[Ss]pam|[Xx]-[Ss]pamd-[Rr]esult|[Xx]-[Rr]spamd|[Xx]-[A-Za-z0-9-]*[Mm]ail[Ss]canner)/)?1:0;if(s)next}} print}\'';

    // Raw RFC822: strip doveadm's leading "text:" line, then the verdict headers.
    $fetch = SUDO . ' ' . QA_DOVEADM . ' fetch-text ' . escapeshellarg($user)
           . ' ' . escapeshellarg($folder) . ' ' . escapeshellarg($uid)
           . ' 2>/dev/null | tail -n +2' . $strip;

    $ctx = "user=$user folder=$folder uid=$uid";

    if (!$live) {
        $size = (int) trim((string) shell_exec($fetch . ' | wc -c'));
        if ($size <= 0) { learn_log("SKIP (empty fetch) [$cmd_name] $ctx"); return 'failed'; }
        learn_log("DRY-RUN would $cmd_name $ctx bytes=$size via 'rspamc -h " . RSPAMD_CTRL . " $cmd_name'");
        return 'failed';
    }

    if (!is_readable(RSPAMC_PW_FILE)) {
        learn_log("ABORT live [$cmd_name]: missing/unreadable " . RSPAMC_PW_FILE . " - not learned. $ctx");
        return 'failed';
    }
    // Distinguish the three outcomes instead of logging whatever came back:
    // an empty fetch (message gone / wrong uid) is not the same as rspamc
    // refusing the sample, and neither is the same as a successful learn.
    $size = (int) trim((string) shell_exec($fetch . ' | wc -c'));
    if ($size <= 0) {
        learn_log("FAIL live [$cmd_name]: fetch returned no data - not learned. $ctx");
        return 'failed';
    }
    $cmd = $fetch . ' | ' . RSPAMC
         . ' -h ' . escapeshellarg(RSPAMD_CTRL)
         . ' -P "$(cat ' . escapeshellarg(RSPAMC_PW_FILE) . ')"'
         . ' ' . $cmd_name . ' 2>&1; echo "__RC:$?"';
    $raw = (string) shell_exec($cmd);
    $rc  = -1;
    if (preg_match('/__RC:(\d+)\s*$/', $raw, $m)) {
        $rc  = (int) $m[1];
        $raw = (string) preg_replace('/__RC:\d+\s*$/', '', $raw);
    }
    $out = preg_replace('/\s+/', ' ', trim($raw));
    $out = ($out === '' ? '(no output)' : $out);
    // rspamc exits 0 whether rspamd actually trained on the sample or denied
    // the request (e.g. the message is already learned in that class with
    // high confidence) -- the real outcome is only in the response body.
    $learned = $rc === 0 && (bool) preg_match('/\bsuccess\s*=\s*true\b/', $raw);
    $outcome = $rc !== 0 ? 'failed' : ($learned ? 'learned' : 'skipped');
    $label = $rc !== 0 ? "LIVE FAIL $cmd_name rc=$rc" : ($learned ? "LIVE OK $cmd_name" : "LIVE DENIED $cmd_name");
    learn_log("$label $ctx bytes=$size result=$out");
    return $outcome;
}
