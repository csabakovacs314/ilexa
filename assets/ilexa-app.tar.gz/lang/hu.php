<?php
/**
 * Hungarian - the source language. t() returns its argument unchanged when
 * the active language is Hungarian (see LANG_DEFAULT in src/i18n.php), so
 * this file carries no translation entries - only the display name, so
 * Hungarian is discoverable by the same lang/*.php folder scan as every
 * other language.
 */
return [
    '_name' => 'Magyar',
];
