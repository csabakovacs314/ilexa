#!/usr/bin/env bash
#
# Deploy this repo to the live webroot - safely.
#
# Why this exists: on 2026-08-08 a bare `rsync -a` from this tree to the
# webroot silently destroyed a day of UI work (logo/favicons, ClamAV widgets,
# a mobile menu) that had been edited directly in the webroot and never
# committed here. rsync does not need --delete to do that; overwriting is
# enough, and the originals were unrecoverable.
#
# So: this script REFUSES to deploy while the webroot holds anything the repo
# does not. Port the drift back into the repo, commit it, then deploy.
#
#   ./deploy.sh          check for drift, then deploy if clean
#   ./deploy.sh --check  report drift and exit, never writes
#
set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DST=/var/www/html/quarantine-admin

# The rsync-exclude set now lives in tools/deploy-tree.sh (shared with
# install/qa-update-apply.sh's Phase 4) -- this list is DIFF_IGNORES only,
# for the drift check below. .superpowers/ already reached the live webroot
# once, readable by any authenticated console user, before its exclude
# existed, and .claude/worktrees/ did the same before this one did (a stale
# worktree copy blocked a deploy on 2026-08-11); index.php.bak-* is a
# pre-refactor backup that lives only in the webroot.
DIFF_IGNORES=(-x '.git' -x '.gitignore' -x 'INSTALL.md' -x 'README.md'
              -x 'deploy.sh' -x 'install' -x 'docs' -x '.superpowers'
              -x '.claude' -x 'index.php.bak-*')

check_drift() {
    local drift=0 line

    # Fatal: files the webroot has and the repo does not. These are exactly
    # what a plain rsync would erase without a word.
    while IFS= read -r line; do
        [[ -z "$line" ]] && continue
        printf '  WEBROOT-ONLY: %s\n' "$line"
        drift=1
    done < <(diff -rq "${DIFF_IGNORES[@]}" "$SRC" "$DST" 2>/dev/null \
             | sed -n "s|^Only in ${DST}[/]*\(.*\): \(.*\)$|\1/\2|p" | sed 's|^/||')

    # Fatal: a deployed file newer than its source counterpart. Means someone
    # edited the live copy after the last deploy, so the repo is behind.
    while IFS= read -r line; do
        local rel="${line#$SRC/}"
        [[ -f "$DST/$rel" ]] || continue
        if [[ "$DST/$rel" -nt "$line" ]] && ! diff -q "$line" "$DST/$rel" >/dev/null 2>&1; then
            printf '  WEBROOT NEWER: %s\n' "$rel"
            drift=1
        fi
    done < <(find "$SRC" -type f -not -path '*/.git/*' -not -path '*/install/*')

    return $drift
}

echo "Linting $SRC ..."
# Invoked via bash, NOT as ./tools/lint-all.sh: the installer's 55-ilexa module
# chmods the whole extracted tree to 640/750 (the web server must not be able to
# execute anything in its own docroot), which strips the exec bit from this
# script. Calling it directly then failed with "Permission denied" -- and the
# old message below reported that as "php -l found a syntax error", asserting a
# cause it had not established. Distinguish the two: a linter that cannot run is
# not the same as code that does not parse.
# `set -e` (line 17) aborts on a FAILING assignment, so the plain
# `lint_out=$(...); lint_rc=$?` form killed this script at the assignment --
# before lint_rc was read and before anything was printed. The gate still
# refused to deploy, but silently, with a bare exit 1 and no reason: the
# "REFUSING TO DEPLOY" messages below were unreachable for every failure
# type. `|| lint_rc=$?` makes it a compound command, which set -e permits.
lint_rc=0
lint_out=$(bash "$SRC/tools/lint-all.sh" --quiet 2>&1) || lint_rc=$?
if [ "$lint_rc" -ne 0 ]; then
    printf '%s\n' "$lint_out" >&2
    if printf '%s' "$lint_out" | grep -q "SYNTAX ERROR\|MISSING en.php\|PLACEHOLDER\|HELPER MISMATCH\|VIEW "; then
        echo "REFUSING TO DEPLOY - the checks above failed. Fix them and re-run." >&2
    else
        echo "REFUSING TO DEPLOY - could not run tools/lint-all.sh (exit $lint_rc). This is a problem with the check itself, not necessarily with the code." >&2
    fi
    exit 1
fi
printf '%s\n' "$lint_out"
echo "  checks passed."

echo "Checking $DST against $SRC ..."
if ! check_drift; then
    cat >&2 <<'MSG'

REFUSING TO DEPLOY - the webroot holds work this repo does not.

Deploying now would overwrite it, and it is not recoverable afterwards.
Copy each file listed above into the repo, commit it, then run this again.
MSG
    exit 1
fi
echo "  no drift."

# /usr/local/sbin helpers are NOT deployed by this script (see the excludes
# above -- install/ is deliberately not rsynced into the webroot). They still
# drift, in both directions, and used to do so invisibly: this script printed
# a static "diff them separately" reminder that named no files, so nobody did.
# Reported, not enforced: this deploy does not write to /usr/local/sbin, so
# sbin drift is not a reason a webroot deploy is unsafe -- blocking on it
# would strand an urgent UI fix behind an unrelated stale helper. Loud and
# specific beats blocking here.
echo "Checking /usr/local/sbin against $SRC/install ..."
if bash "$SRC/tools/check-sbin-drift.sh"; then
    :
else
    cat >&2 <<'MSG'
  ^ Helper scripts differ from this repo. Not blocking the deploy (this
    script does not write to /usr/local/sbin), but fix them: port a live
    hotfix back into install/ and commit it, or install a committed change
    onto the host. Re-run tools/check-sbin-drift.sh to confirm.
MSG
fi

if [[ "${1:-}" == "--check" ]]; then
    echo "Check only; nothing written."
    exit 0
fi

echo "Deploying ..."
bash "$SRC/tools/deploy-tree.sh" "$SRC" "$DST"

echo "Deployed. (install/*.sh and install/*.py belong in /usr/local/sbin and are"
echo "not deployed here -- the sbin drift check above reports them by name.)"

# Post-deploy smoke: render every top-level request path through the real
# stack and fail loudly if any page broke. This runs AFTER the rsync on
# purpose -- the suite needs the deployed tree (config.php lives only in the
# webroot, and the repo under /root is unreadable by the web user), so it
# cannot gate the deploy itself; what it can do is make a broken deploy
# impossible to miss, at the moment it happened rather than at the next
# operator login. lint-all (above) is the pre-deploy gate; this is the
# post-deploy verification.
echo "Running smoke tests against $DST ..."
if ! bash "$SRC/tools/smoke-test.sh" "$DST"; then
    cat >&2 <<'MSG'

DEPLOY IS LIVE BUT BROKEN - the smoke tests above failed against the
deployed tree. Fix forward or redeploy the previous commit now.
MSG
    exit 1
fi
