#!/usr/bin/env bash
#
# Deploy this repo to the live webroot - safely.
#
# Why this exists: on 2026-08-08 a bare `rsync -a` from this tree to the
# webroot silently destroyed a day of UI work (logo/favicons, ClamAV widgets,
# a mobile menu) that had been edited directly in the webroot and never
# committed here. rsync does not need --delete to do that; overwriting is
# enough, and the originals were unrecoverable.
#
# So: this script REFUSES to deploy while the webroot holds anything the repo
# does not. Port the drift back into the repo, commit it, then deploy.
#
#   ./deploy.sh          check for drift, then deploy if clean
#   ./deploy.sh --check  report drift and exit, never writes
#
set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DST=/var/www/html/quarantine-admin

# Deliberately not deployed: INSTALL.md/README.md/docs/ would expose infra
# paths and design internals over HTTP; .superpowers/ and .claude/ are SDD
# execution scratch (ledgers, task briefs, review packages, git worktrees)
# with the same problem -- .superpowers/ already reached the live webroot
# once, readable by any authenticated console user, before its exclude
# existed, and .claude/worktrees/ did the same before this one did (a stale
# worktree copy blocked a deploy on 2026-08-11); index.php.bak-* is a
# pre-refactor backup that lives only in the webroot; install/ holds host
# scripts that belong in /usr/local/sbin.
EXCLUDES=(--exclude='.git' --exclude='.gitignore' --exclude='INSTALL.md'
          --exclude='README.md' --exclude='deploy.sh' --exclude='install/'
          --exclude='docs/' --exclude='.superpowers/' --exclude='.claude/')
DIFF_IGNORES=(-x '.git' -x '.gitignore' -x 'INSTALL.md' -x 'README.md'
              -x 'deploy.sh' -x 'install' -x 'docs' -x '.superpowers'
              -x '.claude' -x 'index.php.bak-*')

check_drift() {
    local drift=0 line

    # Fatal: files the webroot has and the repo does not. These are exactly
    # what a plain rsync would erase without a word.
    while IFS= read -r line; do
        [[ -z "$line" ]] && continue
        printf '  WEBROOT-ONLY: %s\n' "$line"
        drift=1
    done < <(diff -rq "${DIFF_IGNORES[@]}" "$SRC" "$DST" 2>/dev/null \
             | sed -n "s|^Only in ${DST}[/]*\(.*\): \(.*\)$|\1/\2|p" | sed 's|^/||')

    # Fatal: a deployed file newer than its source counterpart. Means someone
    # edited the live copy after the last deploy, so the repo is behind.
    while IFS= read -r line; do
        local rel="${line#$SRC/}"
        [[ -f "$DST/$rel" ]] || continue
        if [[ "$DST/$rel" -nt "$line" ]] && ! diff -q "$line" "$DST/$rel" >/dev/null 2>&1; then
            printf '  WEBROOT NEWER: %s\n' "$rel"
            drift=1
        fi
    done < <(find "$SRC" -type f -not -path '*/.git/*' -not -path '*/install/*')

    return $drift
}

echo "Linting $SRC ..."
# Invoked via bash, NOT as ./tools/lint-all.sh: the installer's 55-ilexa module
# chmods the whole extracted tree to 640/750 (the web server must not be able to
# execute anything in its own docroot), which strips the exec bit from this
# script. Calling it directly then failed with "Permission denied" -- and the
# old message below reported that as "php -l found a syntax error", asserting a
# cause it had not established. Distinguish the two: a linter that cannot run is
# not the same as code that does not parse.
# `set -e` (line 17) aborts on a FAILING assignment, so the plain
# `lint_out=$(...); lint_rc=$?` form killed this script at the assignment --
# before lint_rc was read and before anything was printed. The gate still
# refused to deploy, but silently, with a bare exit 1 and no reason: the
# "REFUSING TO DEPLOY" messages below were unreachable for every failure
# type. `|| lint_rc=$?` makes it a compound command, which set -e permits.
lint_rc=0
lint_out=$(bash "$SRC/tools/lint-all.sh" --quiet 2>&1) || lint_rc=$?
if [ "$lint_rc" -ne 0 ]; then
    printf '%s\n' "$lint_out" >&2
    if printf '%s' "$lint_out" | grep -q "SYNTAX ERROR\|MISSING en.php\|PLACEHOLDER\|HELPER MISMATCH\|VIEW "; then
        echo "REFUSING TO DEPLOY - the checks above failed. Fix them and re-run." >&2
    else
        echo "REFUSING TO DEPLOY - could not run tools/lint-all.sh (exit $lint_rc). This is a problem with the check itself, not necessarily with the code." >&2
    fi
    exit 1
fi
printf '%s\n' "$lint_out"
echo "  checks passed."

echo "Checking $DST against $SRC ..."
if ! check_drift; then
    cat >&2 <<'MSG'

REFUSING TO DEPLOY - the webroot holds work this repo does not.

Deploying now would overwrite it, and it is not recoverable afterwards.
Copy each file listed above into the repo, commit it, then run this again.
MSG
    exit 1
fi
echo "  no drift."

if [[ "${1:-}" == "--check" ]]; then
    echo "Check only; nothing written."
    exit 0
fi

echo "Deploying ..."
rsync -a "${EXCLUDES[@]}" "$SRC/" "$DST/"

# PHP-FPM cannot read root-owned 640 files, which is how the editor tools
# leave them; assets must stay world-readable for Apache.
#
# The web user is NOT the same everywhere: EL runs PHP-FPM as "apache",
# Debian/Ubuntu as "www-data". This was hardcoded to apache:apache, so on an
# Ubuntu host the chown failed with "invalid user: apache" and the deploy
# aborted midway -- rsync had already run, but nothing was chowned, leaving a
# webroot PHP-FPM could not read. Detect it instead, preferring an explicit
# override for anything exotic.
WEB_USER="${WEB_USER:-}"
if [[ -z "$WEB_USER" ]]; then
    for _u in apache www-data; do
        if id -u "$_u" >/dev/null 2>&1; then WEB_USER="$_u"; break; fi
    done
fi
[[ -n "$WEB_USER" ]] || { echo "cannot determine the web user (tried apache, www-data); set WEB_USER=" >&2; exit 1; }
WEB_GROUP="${WEB_GROUP:-$(id -gn "$WEB_USER")}"
echo "  web user: ${WEB_USER}:${WEB_GROUP}"

find "$DST" -name '*.php' -exec chown "$WEB_USER:$WEB_GROUP" {} + -exec chmod 640 {} +
# Files 644, directories 755 -- NOT a blanket `chmod 644 assets/*`, which was
# the previous form. That glob also matched any SUBDIRECTORY of assets/ and
# stripped its execute bit, leaving a directory Apache cannot traverse: the
# files inside became 403 (not 401), i.e. served-but-forbidden rather than
# auth-required. It went unnoticed for as long as assets/ held only files;
# assets/flags/ was the first subdirectory and hit it immediately.
if [[ -d "$DST/assets" ]]; then
  chown -R "$WEB_USER:$WEB_GROUP" "$DST/assets"
  find "$DST/assets" -type d -exec chmod 755 {} +
  find "$DST/assets" -type f -exec chmod 644 {} +
fi
# parse_email.py is executed, not served - it stays root-owned and executable.
chown root:root "$DST/parse_email.py" && chmod 755 "$DST/parse_email.py"

echo "Deployed. Reminder: install/*.sh and install/*.py are NOT deployed here;"
echo "they belong in /usr/local/sbin and drift silently - diff them separately."
