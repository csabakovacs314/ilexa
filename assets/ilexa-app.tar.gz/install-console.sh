#!/usr/bin/env bash
#
# install-console.sh — install the ilexa console onto an EXISTING mail server.
#
# This is for a host that already runs Postfix + Dovecot + rspamd, however it
# was built (by hand, iRedMail, mailcow on the host, ilexa-installer, ...). It
# installs only the console: the web app, the root-owned helper scripts it
# shells out to, a sudoers entry, and a vhost. It does NOT touch Postfix,
# Dovecot or rspamd configuration, and it does not install packages.
#
# For a bare machine with no mail server at all, use ilexa-installer instead --
# that builds the whole stack. The two share every template in install/, so a
# console installed either way is configured identically.
#
#   ./install-console.sh                  detect, ask, install
#   ./install-console.sh --dry-run        show what it would do, change nothing
#   ./install-console.sh --answers FILE   non-interactive (KEY=VALUE file)
#   ./install-console.sh --help
#
# Values are auto-detected from the running system where that is possible and
# reliable; anything detected can be overridden in an answers file. See
# --dry-run output for what was detected and from where.
set -uo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DRY=0
ANSWERS=""

# --- output -----------------------------------------------------------------
c_ok=$'\033[32m'; c_warn=$'\033[33m'; c_err=$'\033[31m'; c_dim=$'\033[2m'; c_off=$'\033[0m'
[ -t 1 ] || { c_ok=""; c_warn=""; c_err=""; c_dim=""; c_off=""; }
say()  { printf '%s\n' "$*"; }
info() { printf '  %s\n' "$*"; }
ok()   { printf '  %s✓%s %s\n' "$c_ok" "$c_off" "$*"; }
warn() { printf '  %s!%s %s\n' "$c_warn" "$c_off" "$*"; }
die()  { printf '\n%sERROR%s %s\n' "$c_err" "$c_off" "$*" >&2; exit 1; }
step() { printf '\n%s\n' "$*"; }
# Callers pass a single pre-quoted command string, so eval is deliberate here:
# it is what lets one call site both print the command in dry-run and execute it
# with its quoting intact.
# shellcheck disable=SC2294
run()  { if [ "$DRY" = 1 ]; then printf '  %s[dry-run]%s %s\n' "$c_dim" "$c_off" "$*"; else eval "$*"; fi; }

usage() { sed -n '2,26p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'; }

while [ $# -gt 0 ]; do
  case "$1" in
    --dry-run) DRY=1; shift ;;
    --answers) ANSWERS="${2:?--answers needs a file}"; shift 2 ;;
    --help|-h) usage; exit 0 ;;
    *) die "unknown argument: $1  (try --help)" ;;
  esac
done

[ "$(id -u)" = 0 ] || die "must run as root (it writes /usr/local/sbin, /etc/sudoers.d and the web root)"

# ---------------------------------------------------------------------------
# 1. Preflight. Refuse early and name exactly what is missing -- a stranger's
#    first run failing halfway through is the difference between a fixable
#    message and a bug report.
# ---------------------------------------------------------------------------
step "Checking prerequisites"
missing=()
need() { # binary  human-name  hint
  if command -v "$1" >/dev/null 2>&1; then ok "$2 ($(command -v "$1"))"
  else missing+=("$2 — $3"); fi
}
need postconf "Postfix"   "install postfix, or use ilexa-installer for a full stack"
need doveadm  "Dovecot"   "install dovecot-core; the console reads mail only through doveadm"
need php      "PHP"       "install php-cli php-fpm (8.0+)"
need python3  "Python 3"  "install python3; parse_email.py renders message bodies"
need htpasswd "htpasswd"  "install apache2-utils (Debian) or httpd-tools (EL)"

# rspamd is needed for spam/ham learning but the console runs without it.
if command -v rspamc >/dev/null 2>&1; then ok "rspamd ($(command -v rspamc))"
else warn "rspamd not found — quarantine works, spam/ham learning will be disabled"; fi

php_ver=$(php -r 'echo PHP_MAJOR_VERSION;' 2>/dev/null || echo 0)
[ "${php_ver:-0}" -ge 8 ] 2>/dev/null && ok "PHP major version $php_ver" \
  || missing+=("PHP 8+ — found major version ${php_ver:-unknown}")

# The full set the console actually uses. mbstring is not optional:
# accent-insensitive filtering depends on it.
for ext in pdo_mysql mbstring iconv json session filter; do
  if php -m 2>/dev/null | grep -qix "$ext"; then ok "php extension $ext"
  else missing+=("php extension $ext — install the matching php-$ext package"); fi
done

# Apache modules. Without proxy_fcgi the vhost's SetHandler cannot reach PHP-FPM
# and every .php request returns a 503 or downloads as text, with the app itself
# perfectly fine -- a confusing failure worth catching before it happens.
#
# Enumeration differs by family and one of the two lies: on EL, `apachectl -M`
# prints "The -M option is not supported" AND EXITS 0, so trusting it would
# silently yield an empty module list and condemn every module. httpd -M works
# there; apachectl -M works on Debian. If neither produces output, skip rather
# than guess.
apache_mods=$( { httpd -M 2>/dev/null || apachectl -M 2>/dev/null; } | grep -oE '[a-z_]+_module' | sort -u)
if [ -z "$apache_mods" ]; then
  warn "could not enumerate Apache modules — verify proxy_fcgi, authn_core and authz_user are enabled"
else
  for m in proxy_fcgi authn_core authz_user; do
    if grep -qx "${m}_module" <<<"$apache_mods"; then ok "apache module $m"
    else missing+=("apache module $m — a2enmod $m (Debian) or enable it in /etc/httpd/conf.modules.d (EL)"); fi
  done
fi

command -v setfacl >/dev/null 2>&1 && ok "setfacl (acl)" \
  || warn "setfacl missing — Audit > Logins needs it to read the Apache access log"

if [ ${#missing[@]} -gt 0 ]; then
  say ""
  say "${c_err}Cannot continue.${c_off} Missing:"
  for m in "${missing[@]}"; do say "  · $m"; done
  die "install the above, then re-run"
fi

# ---------------------------------------------------------------------------
# 2. Detect. Every probe here was verified against a live EL9 and a live
#    Ubuntu 24.04 host; see docs/standalone-console.md for the table.
# ---------------------------------------------------------------------------
step "Detecting configuration"
detected=()
setv() { # NAME VALUE SOURCE
  local n="$1" v="$2" s="$3"
  if [ -n "${!n:-}" ]; then detected+=("$n|${!n}|answers file"); return 0; fi
  printf -v "$n" '%s' "$v" 2>/dev/null || eval "$n=\$v"
  detected+=("$n|$v|$s")
}

# An answers file wins over detection, so load it first.
if [ -n "$ANSWERS" ]; then
  [ -r "$ANSWERS" ] || die "answers file not readable: $ANSWERS"
  # shellcheck disable=SC1090
  . "$ANSWERS"
  info "loaded overrides from $ANSWERS"
fi

setv MAIL_FQDN   "$(postconf -h myhostname 2>/dev/null)"            "postconf myhostname"
[ -n "${MAIL_FQDN:-}" ] || die "could not determine the mail FQDN; set MAIL_FQDN in an answers file"

# always_bcc IS the archive account when the archive feature is in use. Deriving
# it rather than guessing avoids the failure where the gateway compares against
# an account that does not exist and refuses every archive fetch.
_bcc=$(postconf -h always_bcc 2>/dev/null)
setv ARCHIVE_USER "${_bcc:-}"                                        "postconf always_bcc"

_ml=$(doveconf -h mail_location 2>/dev/null | head -1)
# maildir:/data/mail/%d/%u -> /data/mail   (strip scheme, then the first %-part)
_store=$(printf '%s' "$_ml" | sed -E 's|^[a-z]+:||; s|/%[du].*$||; s|:.*$||')
setv MAIL_STORE  "${_store:-/var/vmail}"                             "doveconf mail_location"

_ctrl=$(grep -rhoE 'bind_socket[[:space:]]*=[[:space:]]*"?[^";]+' \
          /etc/rspamd/worker-controller.inc /etc/rspamd/local.d/worker-controller.inc 2>/dev/null \
        | grep -oE '[0-9.]+:[0-9]+' | head -1)
setv RSPAMD_CTRL "${_ctrl:-127.0.0.1:11334}"                         "rspamd worker-controller"

setv TIMEZONE    "$(timedatectl show -p Timezone --value 2>/dev/null || cat /etc/timezone 2>/dev/null)" "timedatectl"

if id -u apache >/dev/null 2>&1;   then _wu=apache
elif id -u www-data >/dev/null 2>&1; then _wu=www-data
else die "cannot find a web user (looked for apache, www-data); set WEB_USER in an answers file"; fi
setv WEB_USER  "$_wu"                                                "system accounts"
setv WEB_GROUP "$(id -gn "$WEB_USER")"                               "primary group of $WEB_USER"

if   [ -d /etc/httpd/conf.d ];      then _wc=/etc/httpd/conf.d;         _wl=/var/log/httpd
elif [ -d /etc/apache2/conf-available ]; then _wc=/etc/apache2/conf-available; _wl=/var/log/apache2
else die "cannot find an Apache config directory; set WEB_CONFD in an answers file"; fi
setv WEB_CONFD   "$_wc"                                              "filesystem layout"
setv WEB_LOG_DIR "$_wl"                                              "filesystem layout"

setv POSTMASTER_FROM  "postmaster@${MAIL_FQDN#*.}"                   "derived from MAIL_FQDN"
setv HTPASSWD_BIN     "$(command -v htpasswd)"                       "PATH"
# The Basic Auth file path is needed here, not just in the Basic Auth step
# below: htpasswd-manage.sh.tmpl bakes it in, and the console's user-management
# panel edits whatever it was given. A path that disagrees with the vhost's
# AuthUserFile is how that panel silently edited a file Apache never read.
setv ILEXA_HTPASSWD   "${WEB_CONFD%/*}/ilexa.htpasswd"               "derived from WEB_CONFD"
setv POSTFIXADMIN_URL ""                                             "default (menu entry hidden)"
setv DOCROOT          "/var/www/html/quarantine-admin"               "default"
setv DOCROOT_BASE     "$(basename "${DOCROOT}")"                     "derived from DOCROOT"
setv SITE_TITLE       "ilexa - Mail Security Operations Console"      "default"

# Probe for a real socket rather than assuming a path: EL uses
# /run/php-fpm/www.sock, Debian an "alternatives" symlink at
# /run/php/php-fpm.sock pointing at a version-specific file. A wrong path here
# makes every .php request return 503 with the app itself perfectly fine.
_sock=""
for c in /run/php-fpm/www.sock /run/php/php-fpm.sock /run/php/php*-fpm.sock; do
  [ -S "$c" ] && { _sock="$c"; break; }
done
setv PHP_FPM_SOCK "${_sock:-/run/php-fpm/www.sock}" \
     "$([ -n "$_sock" ] && echo "probed live socket" || echo "fallback, NOT probed")"

printf '\n  %-22s %-34s %s\n' "SETTING" "VALUE" "SOURCE"
printf '  %-22s %-34s %s\n' "----------------------" "----------------------------------" "------"
for d in "${detected[@]}"; do
  IFS='|' read -r n v s <<<"$d"
  printf '  %-22s %-34s %s%s%s\n' "$n" "${v:-(empty)}" "$c_dim" "$s" "$c_off"
done

# ---------------------------------------------------------------------------
# 3. Ask for what cannot be reliably detected.
# ---------------------------------------------------------------------------
step "Settings that need a decision"
ask() { # NAME PROMPT DEFAULT
  local n="$1" p="$2" def="$3" reply
  if [ -n "${!n:-}" ]; then info "$n = ${!n}  (from answers file)"; return 0; fi
  if [ ! -t 0 ]; then eval "$n=\$def"; info "$n = $def  (default; no TTY to ask)"; return 0; fi
  # shellcheck disable=SC2034  # consumed by the eval below, not directly
  read -rp "  $p [$def]: " reply
  eval "$n=\${reply:-\$def}"
  info "$n = ${!n}"
}

# Folder names vary by deployment and cannot be inferred: an empty Junk folder
# looks identical to one that is simply unused. Offer what actually exists.
_seen=""
_probe_user=$(doveadm user '*' 2>/dev/null | head -1)
if [ -n "$_probe_user" ]; then
  for f in Junk Spam Quarantine; do
    doveadm mailbox list -u "$_probe_user" 2>/dev/null | grep -qx "$f" && _seen="${_seen}${_seen:+ }$f"
  done
  [ -n "$_seen" ] && info "folders present on $_probe_user: $_seen"
fi
ask QUARANTINE_FOLDERS "Quarantine folders (space-separated)" "${_seen:-Junk Spam}"
ask ILEXA_URL_PREFIX   "URL path to serve the console at"     "/ilexa/"
if [ -z "${ARCHIVE_USER:-}" ]; then
  warn "no always_bcc found, so there is no central archive on this host"
  ask ARCHIVE_USER "Archive mailbox (blank = no Archive tab)" ""
fi

# The archive account must exist, or the gateway refuses every archive fetch
# and the console shows no content with nothing explaining why.
if [ -n "${ARCHIVE_USER:-}" ] && ! doveadm user "$ARCHIVE_USER" >/dev/null 2>&1; then
  die "archive account '$ARCHIVE_USER' is not a known mailbox — fix it or leave it blank"
fi

# ---------------------------------------------------------------------------
# 4. Render. Same @@KEY@@ templates ilexa-installer uses, so a console
#    installed by either route is configured identically.
# ---------------------------------------------------------------------------
step "Rendering configuration"
render() { # template dest
  local t="$1" d="$2" tmp k v var out
  [ -r "$t" ] || die "template missing: $t"
  out=$(cat "$t")
  for k in $(grep -oE '@@[A-Z0-9_]+@@' "$t" | tr -d '@' | sort -u); do
    var="$k"
    case "$k" in
      QUARANTINE_FOLDERS)     v=$(printf '"%s" ' $QUARANTINE_FOLDERS) ;;
      QUARANTINE_FOLDERS_PHP) v=$(printf "'%s', " $QUARANTINE_FOLDERS | sed 's/, $//') ;;
      *) v="${!var-}"
         # An unset placeholder would silently render the literal @@KEY@@ into a
         # live config file, so fail instead.
         [ -n "${!var+x}" ] || die "template $t needs @@${k}@@ but $k is not set" ;;
    esac
    out=${out//"@@${k}@@"/$v}
  done
  if [ "$DRY" = 1 ]; then
    printf '  %s[dry-run]%s would render %s -> %s\n' "$c_dim" "$c_off" "$(basename "$t")" "$d"
    return 0
  fi
  [ -e "$d" ] && cp -p "$d" "${d}.bak-$(date +%Y%m%d-%H%M%S)"
  tmp=$(mktemp) || die "mktemp failed"
  printf '%s\n' "$out" > "$tmp"
  install -m 0640 "$tmp" "$d"
  rm -f "$tmp"
  ok "rendered $(basename "$t") -> $d"
}

render "$SRC/install/config.php.tmpl" "$SRC/config.php"
[ "$DRY" = 1 ] || chown "$WEB_USER:$WEB_GROUP" "$SRC/config.php"

render "$SRC/install/qa-doveadm.sh.tmpl"      /usr/local/sbin/qa-doveadm.sh
render "$SRC/install/htpasswd-manage.sh.tmpl" /usr/local/sbin/htpasswd-manage.sh
render "$SRC/install/fts-manage.sh.tmpl"      /usr/local/sbin/fts-manage.sh
run "chmod 0755 /usr/local/sbin/qa-doveadm.sh /usr/local/sbin/htpasswd-manage.sh /usr/local/sbin/fts-manage.sh"

# ---------------------------------------------------------------------------
# 5. Helpers + sudoers.
# ---------------------------------------------------------------------------
step "Installing helper scripts"
n=0
# Read from install/helpers.list -- the single source shared with
# ilexa-installer's 55-ilexa.sh and verified against sudoers.example by
# tools/check-helpers.php. Only source=list entries are copied here; the
# templated ones are rendered above.
for h in $(awk '$1 !~ /^#/ && NF >= 3 && $3 == "list" { print $1 }' "$SRC/install/helpers.list"); do
  [ -f "$SRC/install/$h" ] || continue
  run "install -m 0755 -o root -g root '$SRC/install/$h' '/usr/local/sbin/$h'"
  n=$((n+1))
done
ok "$n helper scripts installed to /usr/local/sbin"

# Seed the on-demand IOC lookup services that need NO API key (HRBL,
# Mailspike, url.vet) as enabled -- once, only when no config exists yet, so
# a re-run never overrides what an operator toggled in Rendszer since. The
# keyed services (VT, URLhaus, OTX, YARAify, ThreatFox) stay off until their
# key arrives; keyless ones being off too just made a fresh console's IOC
# page show zero reputation columns for no discoverable reason.
if [ ! -f /etc/ilexa/ioc_lookup.conf ]; then
  if [ "$DRY" = 1 ]; then info "[dry-run] would enable keyless IOC lookups: hrbl mailspike urlvet"
  else
    for s in hrbl mailspike urlvet; do
      /usr/local/sbin/qa-ioclookup-config.sh enable "$s" >/dev/null 2>&1 \
        && ok "IOC lookup enabled by default (keyless): $s" \
        || info "could not enable IOC lookup '$s' (enable it later in Rendszer)"
    done
  fi
fi

step "Installing sudoers rule"
if [ "$DRY" = 1 ]; then
  info "[dry-run] would install /etc/sudoers.d/ilexa for user $WEB_USER"
else
  tmp=$(mktemp) || die "mktemp failed"
  sed "s/^apache /${WEB_USER} /" "$SRC/install/sudoers.example" > "$tmp"
  # visudo -c BEFORE installing: a malformed sudoers file can lock out sudo
  # entirely, so it must never be written unvalidated.
  if visudo -cqf "$tmp" >/dev/null 2>&1; then
    install -m 0440 -o root -g root "$tmp" /etc/sudoers.d/ilexa
    ok "/etc/sudoers.d/ilexa installed (web user: $WEB_USER)"
  else
    rm -f "$tmp"
    die "generated sudoers failed visudo validation — nothing written"
  fi
  rm -f "$tmp"
fi

# ---------------------------------------------------------------------------
# 6. Runtime directories, Basic Auth, vhost, and the app itself.
# ---------------------------------------------------------------------------
step "Creating runtime directories"
for d in /var/cache/quarantine-admin /var/lib/quarantine-admin; do
  run "install -d -m 0750 -o '$WEB_USER' -g '$WEB_GROUP' '$d'"
done
ok "cache and list directories ready"

step "Basic Auth"
if [ "$DRY" = 1 ]; then
  info "[dry-run] would ensure $ILEXA_HTPASSWD exists"
elif [ -s "$ILEXA_HTPASSWD" ]; then
  ok "$ILEXA_HTPASSWD already exists ($(grep -c : "$ILEXA_HTPASSWD") account(s)) — left alone"
else
  ADMIN_USER="${ADMIN_USER:-admin}"
  ADMIN_PASSWORD="${ADMIN_PASSWORD:-$(head -c 15 /dev/urandom | base64 | tr -d '/+=' | head -c 16)}"
  htpasswd -cbB "$ILEXA_HTPASSWD" "$ADMIN_USER" "$ADMIN_PASSWORD" >/dev/null 2>&1 \
    || die "htpasswd failed; the console would be unreachable"
  chmod 0640 "$ILEXA_HTPASSWD"; chgrp "$WEB_GROUP" "$ILEXA_HTPASSWD"
  ok "created $ILEXA_HTPASSWD"
  say ""
  say "  ${c_warn}Console login:${c_off} $ADMIN_USER / $ADMIN_PASSWORD"
  say "  ${c_dim}Change it in the console under Admin, or with htpasswd-manage.sh.${c_off}"
fi

step "Deploying the application"
if [ "$DRY" = 1 ]; then
  info "[dry-run] would sync the app to $DOCROOT and write a vhost to $WEB_CONFD/ilexa.conf"
else
  install -d -m 0750 -o "$WEB_USER" -g "$WEB_GROUP" "$DOCROOT"
  rsync -a --exclude='.git' --exclude='install/' --exclude='docs/' --exclude='tools/' \
        --exclude='deploy.sh' --exclude='install-console.sh' --exclude='README.md' \
        --exclude='INSTALL.md' --exclude='.claude' --exclude='.superpowers' \
        "$SRC/" "$DOCROOT/"
  chown -R "$WEB_USER:$WEB_GROUP" "$DOCROOT"
  find "$DOCROOT" -type d -exec chmod 750 {} +
  find "$DOCROOT" -type f -exec chmod 640 {} +
  # parse_email.py is executed by the console, not served.
  [ -f "$DOCROOT/parse_email.py" ] && chown root:root "$DOCROOT/parse_email.py" \
    && chmod 0755 "$DOCROOT/parse_email.py"
  [ -d "$DOCROOT/assets" ] && chmod 644 "$DOCROOT"/assets/* 2>/dev/null
  ok "app deployed to $DOCROOT"
fi

# ---------------------------------------------------------------------------
# 6b. Web server config.
#
# An Alias snippet, not a <VirtualHost>: this host already has its own vhosts,
# TLS and ServerName, and claiming any of those would fight it.
#
# The ordering here is the whole point. Apache config that does not parse stops
# the web server from STARTING, not just from serving this app -- so validate
# first, and if validation fails put the machine back exactly as it was rather
# than leaving a server that will not come up on next boot.
# ---------------------------------------------------------------------------
step "Configuring the web server"
VHOST="$WEB_CONFD/ilexa.conf"
if [ "$DRY" = 1 ]; then
  info "[dry-run] would render apache-ilexa.conf.tmpl -> $VHOST"
  [ -d /etc/apache2 ] && info "[dry-run] would run a2enconf ilexa"
  info "[dry-run] would apachectl configtest, then reload only if it passes"
else
  vhost_existed=0; vhost_backup=""
  if [ -e "$VHOST" ]; then
    vhost_existed=1
    vhost_backup="${VHOST}.bak-$(date +%Y%m%d-%H%M%S)"
    cp -p "$VHOST" "$vhost_backup"
    info "existing $VHOST backed up to $(basename "$vhost_backup")"
  fi

  render "$SRC/install/apache-ilexa.conf.tmpl" "$VHOST"
  chmod 0644 "$VHOST"

  # Debian's apache2 does not auto-glob conf-available/ the way EL's httpd
  # globs conf.d/ -- it needs an explicit symlink into conf-enabled/.
  enabled_link=""
  if command -v a2enconf >/dev/null 2>&1; then
    a2enconf ilexa >/dev/null 2>&1 && enabled_link=/etc/apache2/conf-enabled/ilexa.conf
  fi

  # Capture the output NOW, while the failing config is still in place. Running
  # configtest again after the rollback reports "Syntax OK" -- the restored
  # config is valid -- so the operator got a contradiction instead of the error.
  ct_out=$(apachectl configtest 2>&1); ct_rc=$?
  if [ "$ct_rc" -eq 0 ]; then
    ok "apachectl configtest passes"
    svc=$(systemctl list-units --type=service --no-legend 2>/dev/null \
          | grep -oE '^\s*(httpd|apache2)\.service' | head -1 | tr -d ' ')
    svc="${svc:-$([ -d /etc/apache2 ] && echo apache2.service || echo httpd.service)}"
    if systemctl reload "$svc" >/dev/null 2>&1 || systemctl restart "$svc" >/dev/null 2>&1; then
      ok "$svc reloaded — console served at $ILEXA_URL_PREFIX"
    else
      warn "$svc would not reload; config is valid, so reload it yourself"
    fi
  else
    # Undo everything we just added, then report. A half-added Alias that
    # breaks configtest is the one outcome that must never be left behind.
    [ -n "$enabled_link" ] && a2disconf ilexa >/dev/null 2>&1
    if [ "$vhost_existed" = 1 ]; then cp -p "$vhost_backup" "$VHOST"
    else rm -f "$VHOST"; fi
    say ""
    say "  Apache reported:"
    printf '%s\n' "$ct_out" | head -6 | sed 's/^/      /'
    die "apachectl configtest FAILED with the ilexa config in place (error above) — it has been removed and the web server left exactly as it was."
  fi
fi

# ---------------------------------------------------------------------------
# 7. Verify what was just installed, rather than assuming it worked.
# ---------------------------------------------------------------------------
step "Verifying"
# Delegated to install/qa-verify-console.sh, the same script ilexa-installer's
# 99-verify.sh runs. These checks used to be duplicated here and had already
# diverged from that module's copy on the first day -- it checked the folder
# allowlist, this checked sudo reachability, neither checked both.
fail=0
if [ "$DRY" = 1 ]; then
  info "[dry-run] skipping verification"
elif [ -x /usr/local/sbin/qa-verify-console.sh ]; then
  while IFS='|' read -r verdict label remedy; do
    case "$verdict" in
      OK)   ok "$label" ;;
      SKIP) info "skipped: $label — $remedy" ;;
      FAIL) warn "$label — $remedy"; fail=$((fail+1)) ;;
    esac
  done < <(/usr/local/sbin/qa-verify-console.sh \
             --config "$DOCROOT/config.php" --web-user "$WEB_USER" 2>/dev/null)
else
  warn "qa-verify-console.sh was not installed — cannot verify"
  fail=$((fail+1))
fi

say ""
if [ "$DRY" = 1 ]; then
  say "${c_ok}Dry run complete.${c_off} Nothing was changed."
elif [ "$fail" -eq 0 ]; then
  say "${c_ok}Console installed.${c_off} Browse to ${ILEXA_URL_PREFIX} on this host."
else
  say "${c_warn}Console installed with $fail issue(s) above.${c_off} Fix those, then re-run to re-verify."
fi
