#!/usr/bin/env python3
"""Parse doveadm fetch 'text' output and return email fields as JSON."""
import sys, email, email.policy, email.header, json, re, html as html_mod, hashlib

TEXT_CAP = 8000        # plain-text display cap
HTML_CAP = 200000      # rendered-HTML cap (~200 KB)
SOURCE_CAP = 400000    # raw RFC822 source cap (~400 KB)

# Remote-resource references (tracking pixels etc.) - used to decide whether the
# UI should offer a "load remote images" button.
REMOTE_RE = re.compile(r'''(?:src|background)\s*=\s*['"]?\s*https?:|url\(\s*['"]?\s*https?:''',
                       re.IGNORECASE)


def safe_decode(b, charset):
    """Decode bytes to str, never raising. Try the declared charset, then a
    fallback chain; skip None/'unknown-8bit' (the email module's pseudo-charset
    for undeclared 8-bit data - not a real codec, would raise LookupError)."""
    tried = []
    for cs in (charset, 'utf-8', 'cp1252', 'iso-8859-2', 'latin-1'):
        if not cs or cs.lower() == 'unknown-8bit' or cs in tried:
            continue
        tried.append(cs)
        try:
            return b.decode(cs)
        except (LookupError, UnicodeDecodeError):
            continue
    return b.decode('utf-8', errors='replace')


def strip_html(html):
    html = re.sub(r'<style[^>]*?>.*?</style>', '', html, flags=re.DOTALL | re.IGNORECASE)
    html = re.sub(r'<script[^>]*?>.*?</script>', '', html, flags=re.DOTALL | re.IGNORECASE)
    html = re.sub(r'<[^>]+>', ' ', html)
    html = re.sub(r'[ \t]+', ' ', html)
    html = re.sub(r'\n{3,}', '\n\n', html)
    return html_mod.unescape(html).strip()


def sanitize_html(html):
    """Defense-in-depth for the sandboxed-iframe render: drop <script> blocks.
    The iframe's `sandbox` attribute + injected CSP are the real security boundary."""
    html = re.sub(r'<script[^>]*?>.*?</script>', '', html, flags=re.DOTALL | re.IGNORECASE)
    html = re.sub(r'<script[^>]*?/?>', '', html, flags=re.IGNORECASE)
    return html


def decode_header(val):
    if not val:
        return ''
    out = []
    for part, charset in email.header.decode_header(val):
        if isinstance(part, bytes):
            out.append(safe_decode(part, charset))
        else:
            out.append(str(part))
    return ' '.join(out)


try:
    raw = sys.stdin.buffer.read()
    # Strip doveadm 'text:\n' field prefix (byte level - stdin is raw RFC822 bytes,
    # NOT locale-decoded text; that is what fixes the UTF/Latin-2 mangling).
    if raw.startswith(b'text:\n'):
        raw = raw[6:]
    elif raw.startswith(b'text: '):
        raw = raw[6:]
    elif raw.startswith(b'text:'):
        raw = raw[5:].lstrip(b'\n')
    # Strip form-feed record separators
    raw = raw.strip(b'\x0c')

    msg = email.message_from_bytes(raw, policy=email.policy.compat32)

    body_plain  = ''
    body_html   = ''
    attachments = []

    def _is_attachment_part(part):
        disp = str(part.get('Content-Disposition', '') or '')
        return bool(part.get_filename()) or 'attachment' in disp.lower()

    def _maybe_attachment(part):
        if not _is_attachment_part(part):
            return
        payload = part.get_payload(decode=True)
        if not payload:
            return
        attachments.append({
            'filename':     decode_header(part.get_filename()) if part.get_filename() else '',
            'content_type': part.get_content_type(),
            'size':         len(payload),
            'sha256':       hashlib.sha256(payload).hexdigest(),
        })

    if msg.is_multipart():
        for part in msg.walk():
            ct = part.get_content_type()
            if ct == 'text/plain' and not body_plain and not _is_attachment_part(part):
                payload = part.get_payload(decode=True)
                if payload:
                    body_plain = safe_decode(payload, part.get_content_charset())
            elif ct == 'text/html' and not body_html and not _is_attachment_part(part):
                payload = part.get_payload(decode=True)
                if payload:
                    body_html = safe_decode(payload, part.get_content_charset())
            else:
                _maybe_attachment(part)
    else:
        payload = msg.get_payload(decode=True)
        if payload:
            decoded = safe_decode(payload, msg.get_content_charset())
            if msg.get_content_type() == 'text/html':
                body_html = decoded
            else:
                body_plain = decoded

    # Plain-text display body (fallback = HTML stripped to text). strip_html already
    # unescapes entities, so only unescape on the plain path (avoids double-unescape).
    if body_plain:
        text = html_mod.unescape(body_plain)
    elif body_html:
        text = strip_html(body_html)
    else:
        text = ''
    display_body = text[:TEXT_CAP]
    truncated = len(text) > TEXT_CAP

    # Rendered-HTML body (for the sandboxed-iframe view).
    html_out = ''
    html_truncated = False
    html_has_remote = False
    if body_html:
        html_out = sanitize_html(body_html)
        html_has_remote = bool(REMOTE_RE.search(html_out))
        if len(html_out) > HTML_CAP:
            html_out = html_out[:HTML_CAP]
            html_truncated = True

    # rspamd verdict ("Miért spam?"): parse the headers the milter added at delivery.
    # X-Spamd-Result carries "default: True [8.90 / 15.00]" plus symbol lines when the
    # extended-symbols header is enabled. No re-scan needed.
    def hdr(name):
        return re.sub(r'\s+', ' ', str(msg.get(name, '') or '')).strip()
    spamd_result = hdr('X-Spamd-Result')
    spam_action  = hdr('X-Rspamd-Action') or hdr('X-Spam-Status')
    m = re.search(r'\[\s*(-?\d+(?:\.\d+)?)\s*/\s*(-?\d+(?:\.\d+)?)\s*\]', spamd_result)
    spam_score     = m.group(1) if m else ''
    spam_threshold = m.group(2) if m else ''
    # Symbol names (e.g. BAYES_SPAM(4.0)…) if the header lists them.
    symbols = re.findall(r'[A-Z][A-Z0-9_]{3,}(?:\([-\d.]+\))?', spamd_result)

    # Raw RFC822 exactly as stored, for the Source view. Decoded leniently: the
    # point is to show the bytes that are actually there, so undecodable ones are
    # replaced rather than failing the whole response.
    source_text = raw.decode('utf-8', errors='replace')
    source_truncated = len(source_text) > SOURCE_CAP
    if source_truncated:
        source_text = source_text[:SOURCE_CAP]

    print(json.dumps({
        'attachments':     attachments,
        'from':            decode_header(msg.get('from', '')),
        'to':              decode_header(msg.get('to', '')),
        'subject':         decode_header(msg.get('subject', '')),
        'date':            str(msg.get('date', '')),
        'body':            display_body,
        'truncated':       truncated,
        'has_html':        bool(body_html),
        'html':            html_out,
        'html_truncated':  html_truncated,
        'html_has_remote': html_has_remote,
        'spamd_result':    spamd_result,
        'spam_action':     spam_action,
        'spam_score':      spam_score,
        'spam_threshold':  spam_threshold,
        'spam_symbols':    symbols,
        'source':            source_text,
        'source_truncated':  source_truncated,
    }, ensure_ascii=False))

except Exception as e:
    print(json.dumps({'error': str(e)}, ensure_ascii=False))
