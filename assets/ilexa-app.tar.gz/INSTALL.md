# Installing ilexa

## Will this work on my server?

Answer that before installing anything. If you already run Postfix, Dovecot and
rspamd, clone this repo and ask it:

```bash
sudo ./install-console.sh --dry-run
```

It checks every prerequisite, prints what it detected from your running system
and where each value came from, and changes nothing. If something is missing it
names the package to install. Nothing is written until you run it without
`--dry-run`.

You need: **PHP 8.1+** with FPM (`pdo_mysql`, `mbstring`, `iconv`, `json`,
`session`, `filter`), **Apache 2.4** with `proxy_fcgi`, `authn_core` and
`authz_user`, **Dovecot 2.3+**, **Postfix 3.x**, **MariaDB 10.x**, **Python 3.6+**,
`htpasswd` and `setfacl`. rspamd 3.x is needed for spam/ham learning; without it
the quarantine still works. ClamAV is only needed for the antivirus panel.

There are two ways to install, and which one is right is decided by the machine, not
by preference: **[method 2](#2-adding-ilexa-to-an-existing-mail-server) if it already
runs a mail server**, method 1 only if it does not.

---

## 1. Whole-server install — for a machine with no mail server yet

`ilexa-installer` builds the entire stack on a **fresh** host - Postfix, Dovecot,
MariaDB, PostfixAdmin, Roundcube, rspamd, ClamAV, TLS, fail2ban - and installs ilexa on
top of it, wired up and working. It overwrites `/etc/postfix`, `/etc/dovecot` and the
databases with its own templates, so it is for a new machine, not one already carrying
mail you care about.

Supported targets and how far each is actually verified: **EL9** in production;
**Ubuntu 24.04** on a real host; **EL10** and **Ubuntu 22.04 / 26.04** share the same
code paths and are resolved at runtime, but have not yet had a full install run on real
hardware. If you are on one of those three, expect to be the first.

```bash
git clone <ilexa-installer>  /root/ilexa-installer
cd /root/ilexa-installer
./deploy.sh --dry-run                        # show what would happen, change nothing
./deploy.sh                                  # interactive wizard
```

It asks for the hostname, domains, mail store, TLS mode and any API keys, saves every
answer to an answers file, and can then rebuild an identical machine unattended with
`./deploy.sh --answers <file>`.

Relevant answers: `ENABLE_ILEXA`, `ILEXA_URL_PREFIX`, `ENABLE_ARCHIVE`, `ENABLE_FEEDS`,
`ENABLE_BREACH_CHECK`. Credentials it generates - the console admin, database roles, the
rspamd controller password - are written to `/root/ilexa-install-credentials.txt` (0600).

**Only EL9** (RHEL / AlmaLinux / Rocky 9) is supported today. The installer refuses
anything else rather than half-working; `lib/os.sh` is where a second profile goes.

---

## 2. Adding ilexa to an existing mail server

Use this when Postfix, Dovecot and rspamd already run - however that machine was
built - and you only want the console. It installs no packages and does not touch
your Postfix, Dovecot or rspamd configuration.

```bash
git clone <this repo> && cd quarantine-admin
sudo ./install-console.sh --dry-run     # see what it would do
sudo ./install-console.sh               # do it
```

It detects eight of its ten settings from the running system (mail FQDN and
archive account from `postconf`, mail store from `doveconf`, the rspamd
controller, timezone, web user, and the Apache layout), asks only for the
quarantine folder names and the URL prefix, renders the config and the doveadm
gateway from `install/*.tmpl`, installs the helper scripts and a validated
sudoers rule, writes an Apache `Alias` snippet - never a `<VirtualHost>`, so it
coexists with what you already serve - and finishes by verifying what it just
wrote. If the Apache config it generates does not pass `configtest`, it removes
it and leaves the web server exactly as it was.

Re-running is safe: an existing Basic Auth file is left alone, and every file it
replaces is backed up first.

To use a non-default path, folder set or docroot without being prompted, put the
values in a file and pass `--answers`:

```bash
printf 'QUARANTINE_FOLDERS="Junk Spam"\nILEXA_URL_PREFIX=/mailadmin/\n' > /root/ilexa.conf
sudo ./install-console.sh --answers /root/ilexa.conf
```

### Doing it by hand

The steps below are what `install-console.sh` automates. You should not need
them, but they document what it does and are the reference if it fails partway
on an unusual host. `modules/55-ilexa.sh` in `ilexa-installer` is the other
executable version of the same list.

### Requirements

- PHP 8.1+ FPM with `pdo_mysql`, `mbstring`, `iconv`, `json`, `session`, `filter`
  (**`mbstring` is required** - accent-insensitive filtering uses it)
- Apache 2.4 with `mod_proxy_fcgi`, `mod_authn_core`, `mod_authz_user`
- Dovecot 2.3+, rspamd 3.x with its controller reachable on `127.0.0.1:11334`,
  Postfix 3.x, MariaDB 10.x, Python 3.6+, `httpd-tools`, `acl`
- ClamAV + `clamav-unofficial-sigs` if you want the antivirus panel

### Steps

1. **Deploy the code.** Use `./deploy.sh` from the app directory. Never `rsync` by hand:
   the script refuses to overwrite work that exists only in the webroot, and it sets the
   ownership PHP-FPM needs. A bare `rsync` once destroyed a day of work here.

2. **Directories** - the cache directory must be *writable* by the web user; it holds the
   language file, the learning flag, `roles.json` and the status caches.
   ```bash
   install -d -m 0750 -o apache -g apache /var/log/quarantine-admin
   install -d -m 0700 -o apache -g apache /var/cache/quarantine-admin
   install -d -m 0755 -o apache -g apache /var/lib/quarantine-admin
   ```

3. **Host helpers** - everything in `install/` goes to `/usr/local/sbin` as `root:root 0755`.
   Two of them, `qa-doveadm.sh` and `fts-manage.sh`, carry site-specific values
   (`ARCHIVE_USER`, `ALLOWED_FOLDERS`, `MAIL_DIR`) that **must agree with `config.php`**.
   If they disagree the console still renders and silently returns nothing.

   The community-feed loader is the one exception to the flat `/usr/local/sbin` rule:
   `qa-community-feed-lib.php`, `qa-community-feed-loader.php`, and
   `qa-community-feed-refresh.sh` still go to `/usr/local/sbin` but as `root:root 0750`
   (apache never accesses them directly, only via sudo, so group/other read isn't
   needed), and `qa-community-feed.cron` goes to `/etc/cron.d/qa-community-feed`
   (root:root 0644) rather than `/usr/local/sbin` - it's a cron registration file, not
   an executable.

4. **sudo** - install `install/sudoers.example` as `/etc/sudoers.d/ilexa`, mode `0440`,
   and validate with `visudo -c`. The web user gets **no direct `doveadm` rights**: all
   mail access goes through `qa-doveadm.sh`, which fixes each command's shape. The three
   status helpers are granted without a wildcard because they take no arguments - do not
   add one.

5. **Apache** - render `install/apache-ilexa.conf.tmpl` (an `Alias` matching `cookie_path` in `config.php`, Basic auth
   (`REMOTE_USER` is the app's entire identity; without it the app returns 401), the
   FPM handler, and `Require all denied` on `config|src|install|lang`. If this install
   includes the SHA256 hash-export sub-project, also add the `<Files "export-hashes.php">
   Require all granted </Files>` carve-out from `install/apache-ilexa.conf.tmpl` - that one
   file must stay reachable without Basic auth, since it's fetched by an external
   firewall's unattended scheduler, not a logged-in admin. Then:
   ```bash
   htpasswd -cB /etc/httpd/ilexa.htpasswd admin
   setfacl -m u:apache:rx /var/log/httpd     # or Audit > Logins is silently empty
   ```

6. **Database** - a read-only role and its credentials file:
   ```sql
   CREATE USER 'qaudit_ro'@'localhost' IDENTIFIED BY '<pw>';
   GRANT SELECT ON postfix.last_login   TO 'qaudit_ro'@'localhost';
   GRANT SELECT ON postfix.archive_index TO 'qaudit_ro'@'localhost';
   ```
   `/var/cache/quarantine-admin/db.php`, mode 600, owned by the web user:
   ```php
   <?php return ['socket'=>'/var/lib/mysql/mysql.sock','db'=>'postfix',
                 'user'=>'qaudit_ro','pass'=>'<pw>'];
   ```

7. **rspamd** - the six multimap rules pointing at `/var/lib/quarantine-admin/*.map`
   (see `modules/40-rspamd.sh`), and the four map files seeded at 0644 so `_rspamd` can
   read them. The `message` strings in those rules are load-bearing: the blocked-mail
   counter classifies `maillog` by matching them.

8. **Optional pieces** - the central archive (`always_bcc`, indexer, retention),
   the reputation feeds, and the breach checker. Feeds are managed from
   **Admin → feed sources**; a source without its API key stays disabled.

9. **Verify** - as the web user, not as root:
   ```bash
   sudo -u apache sudo -n /usr/local/sbin/qa-doveadm.sh users   # must list mailboxes
   curl -sk -o /dev/null -w '%{http_code}\n' https://<host><prefix>   # must be 401
   ```
   Then walk every tab in every installed language (Admin → language
   selector lists whatever is in `lang/*.php` - currently Hungarian,
   English, German, Spanish).

---

## Configuration

All site-specific settings live in `config.php` - with the exception noted in step 3.
`site_title` is a proper noun and is deliberately not translated. `credit_idea` and
`credit_code` appear on the About page.

The **selected language is state, not configuration**: it lives in
`/var/cache/quarantine-admin/language` and is changed from Admin. Hungarian is the source
language - every `t('...')` call site in the code uses the Hungarian string itself as the
lookup key - so an untranslated string renders as Hungarian rather than as a raw key.

**Available languages come from `lang/*.php`, not a hardcoded list.** Each file returns
`['_name' => 'Display Name', ...]`; the Admin language selector shows whatever it finds.
`lang/hu.php` carries only `_name` (Hungarian needs no translation entries, per above).
To add a language, copy `lang/en.php` (it has the full, current key set - the authoritative
list of every translatable string) to `lang/<code>.php`, translate every value, keep every
key byte-for-byte identical to `en.php`'s, and add `'_name' => '<Native name>'`. No other
file needs to change - the selector picks it up automatically.

## Upgrading

`git pull && ./deploy.sh`. The script refuses to run if the webroot contains anything the
repository does not, so edits made directly on the server are never silently discarded.
`install/` is **not** deployed - those files live in `/usr/local/sbin` and drift silently;
diff them after an upgrade.
