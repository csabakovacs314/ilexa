# quarantine-admin

A PHP web UI for managing a [Dovecot](https://dovecot.org/) + [rspamd](https://rspamd.com/) mail server quarantine. Provides browser-based access to spam queues, a central mail archive, sender block/whitelist management, audit logging, and full administration - all behind Apache Basic Auth with role-based access control.

---

## Features

| Tab | What it does |
|-----|-------------|
| **Dashboard** | 7-day and 30-day mail volume stats, spam ratio, rspamd Bayes totals, daily bar chart |
| **Quarantine** | Browse per-user Spam folders; release (→ Inbox + learn ham) or delete (+ learn spam); bulk actions; quick-block sender |
| **Archive** | Search the central 30-day mail archive (Postfix `always_bcc`); view body; re-classify as ham/spam; re-deliver to any address |
| **Blocklist** | Reject-on-SMTP sender/IP rules: domain, exact address, wildcard, CIDR - compiled to rspamd multimap |
| **Whitelist** | Force-pass rules with the same pattern types; score −100 (virus/forced-reject still applies) |
| **Audit** | Operation log (release/delete with who/when/IP) and admin login history parsed from the Apache access log |
| **Admin** | rspamd Bayes learning toggle, runtime settings editor, RBAC user management, Xapian FTS index cleanup, live disk/memory stats |

### RBAC roles

| Role | Permissions |
|------|-------------|
| **Admin** | Full access including the Admin tab and user management |
| **Operator** | Release/delete, rspamd training, block/whitelist, archive - no Admin tab |
| **Viewer** | Read-only: quarantine list and archive |
| **Domain-admin** | Operator-level access restricted to a specific set of domains |

Roles are enforced via Apache Basic Auth for credentials (`htpasswd`) and a `roles.json` file for role assignments. If no `roles.json` exists, every authenticated user is Admin (backward-compatible default).

---

## Stack

- **PHP 8.1+** - FPM mode; `pdo_mysql`, `iconv`, `json`
- **Apache httpd 2.4** - `mod_proxy_fcgi`, Basic Auth
- **Dovecot 2.3+** - `doveadm` via `sudo` (no shell access required)
- **rspamd 3.x** - Controller HTTP API + multimap plugin
- **MariaDB / MySQL** - Archive index and audit login data (optional)
- **Python 3** - `parse_email.py` for inline message body rendering
- Mobile-responsive, no JavaScript framework - vanilla JS only

---

## Quick start

Already running Postfix, Dovecot and rspamd? Ask the installer whether this host
qualifies — it checks every prerequisite and changes nothing:

```bash
git clone <this repo> && cd quarantine-admin
sudo ./install-console.sh --dry-run     # prints what it detected, and from where
sudo ./install-console.sh               # installs
```

It detects most of its configuration from the running system, asks only for the
quarantine folder names and the URL to serve at, and installs no packages. It
does not modify your Postfix, Dovecot or rspamd configuration. If the Apache
snippet it generates fails `configtest`, it removes it and leaves the web server
untouched.

No mail server on the box yet? Use
[ilexa-installer](../ilexa-installer) instead, which builds the whole stack
(Postfix, Dovecot, MariaDB, PostfixAdmin, Roundcube, rspamd, ClamAV, TLS,
fail2ban) and installs the console on top. It is for a fresh machine: it
overwrites `/etc/postfix`, `/etc/dovecot` and the databases with its own
templates.

**[INSTALL.md](INSTALL.md)** covers prerequisites in full, the manual procedure
the script automates, `config.php` reference, the central archive, enabling live
Bayes learning (off by default), and upgrade/rollback.

### Updating an existing install

```bash
./deploy.sh          # refuses if the webroot holds work the repo does not
```

`deploy.sh` lints the tree, guards against overwriting uncommitted webroot edits,
and fixes the ownership PHP-FPM needs. Never `rsync` to the webroot by hand — a
bare `rsync` once destroyed a day of work here, which is why that guard exists.

---

## File layout

```
quarantine-admin/
├── config.php            ← site config (edit per deployment)
├── index.php             ← entry point
├── parse_email.py        ← email body parser (root:root 755)
├── src/                  ← PHP logic
│   ├── bootstrap.php
│   ├── rbac.php
│   ├── actions.php
│   ├── admin.php
│   ├── archive.php
│   ├── audit.php
│   ├── doveadm.php
│   ├── helpers.php
│   ├── lists.php
│   ├── rspamd.php
│   ├── session.php
│   └── validators.php
├── views/                ← HTML templates
│   ├── layout_head.php
│   ├── layout_header.php
│   ├── layout_foot.php
│   ├── admin.php
│   ├── archive.php
│   ├── audit.php
│   ├── dashboard.php
│   ├── lists.php
│   └── quarantine.php
└── install/              ← reference snippets (not served)
    ├── apache-ilexa.conf.tmpl
    └── sudoers.example
```

---

## Security notes

- All PHP files must be owned `apache:apache 640` - any root-owned `.php` causes a 500 error from PHP-FPM
- CSRF tokens protect every state-changing POST
- `sudo` rules are whitelisted to specific `doveadm` subcommands only
- The `src/` and `install/` directories are blocked from direct HTTP access
- Passwords are stored as bcrypt hashes via `htpasswd -B`; the htpasswd helper passes passwords through stdin (`proc_open`) to avoid process-list exposure
- Settings overlay (`settings.json`) merges only three whitelisted integer keys - no arbitrary config injection

---

## License

MIT
