# ilexa (quarantine-admin)

A PHP web console for operating a [Postfix](https://www.postfix.org/) +
[Dovecot](https://dovecot.org/) + [rspamd](https://rspamd.com/) mail server:
quarantine management, a searchable central mail archive, sender
block/whitelist rules, an IOC store with multi-service reputation lookups,
threat-feed management, campaign tracking, audit logging with failed-login
visibility, and optional SIEM export — all behind Apache Basic Auth with
role-based access control.

---

## Features

| Tab | What it does |
|-----|-------------|
| **Dashboard** | 7/30-day mail volume, spam ratio, rspamd Bayes totals, daily chart, incident/breach cards, host identity & resource status |
| **Quarantine** | Browse per-user Spam folders; release (→ Inbox + learn ham) or delete (+ learn spam); bulk actions; quick-block sender; per-row sender-domain/IP reputation check |
| **Archive** | Search the central 30-day archive (Postfix `always_bcc`); view body (policy-gated, see below); re-classify ham/spam with a learned-row indicator; re-deliver to any address; one-click IOC extraction; CSV export |
| **Blocklist / Whitelist** | Reject-on-SMTP / force-pass sender rules (domain, exact, wildcard, CIDR) compiled to rspamd multimap; duplicate prevention; per-entry reputation checks |
| **IOC** | Curated indicator store (IP/domain/URL/hash/email) with provenance; on-demand reputation from 8 services (VirusTotal, URLhaus, OTX, HRBL, Mailspike, url.vet, YARAify, ThreatFox) aggregated into a weighted confidence score; bulk hash import; SHA256 hash export as CSV **and** as a token+IP-gated pull endpoint (`export-hashes.php`) for external firewalls/EDR |
| **Campaigns** | Group related quarantined spam into campaigns; one-click promote an indicator to the IOC store |
| **Audit** | Operation log (release/delete/view with who/when/IP) and login history — console admin logins **and failed logins across console, POP3/IMAP and webmail** — each exportable as CSV |
| **Rendszer** (System) | Feed sources with real enable/disable lifecycle + per-feed quality baseline; IOC-lookup service toggles and API keys; **brand-impersonation guard (see below)**; neural-network status (training progress per symbol set, with a shadow/live switch for its weights); Spamhaus DQS / Abusix key management; SIEM export (collector, TLS + CA paste, health check); GDPR content-view policy; rspamd Bayes learning; ClamAV signature/YARA panels; system status |
| **Admin** | Runtime settings editor, RBAC user management, Xapian FTS index cleanup, live disk/memory stats |
| **PostfixAdmin** | Embedded mailbox/domain management (when PostfixAdmin is installed; hidden otherwise) |
| **About** | In-app documentation, including a where-to-get-each-API-key guide |

### Brand-impersonation guard

Rendszer → **Márkavédelem** manages an rspamd rule
(`lua.local.d/brand_guard.lua`) that catches mail claiming to come from a
brand it does not send from — a common consumer-phishing pattern, and one
that reputation filtering handles poorly when the sender is a *hijacked
legitimate account*: SPF, DKIM, DMARC and IP reputation all describe the
server, not the human at the keyboard.

Brand-impersonation detection is standard in commercial mail-security
products, and the matching techniques here are well known (see
[sublime-rules](https://github.com/sublime-security/sublime-rules), MIT, for
an extensive public example). What this implementation adds for a self-hosted
rspamd stack is an admin-editable brand database with a UI, and Hungarian
brand coverage that off-the-shelf brand lists do not carry.

The guard scores five independent signals, all conditioned on "the From-domain
is not one of this brand's real domains":

| Symbol | Score | Fires on |
|--------|-------|----------|
| `BRAND_DN_SPOOF` | 2.5 | display name resembles a brand — fuzzily |
| `BRAND_ADDR_SPOOF` | 1.0 | From localpart claims a brand (`magyarposta@gmail.com`) |
| `BRAND_SUBJ_SPOOF` | 1.0 | Subject names a brand plainly (weak on purpose: webshops write "GLS") |
| `BRAND_SUBJ_OBFUS` | 3.0 | Subject names a brand *only after* un-disguising it |
| `BRAND_LURE` | 2.0 | classic phishing wording **alongside** any of the above |

"Fuzzily" means the matcher folds case, accents, Cyrillic/Greek homoglyphs and
lookalike digits, then allows one edit of distance: `0TP`, `ОТР` (Cyrillic),
`Micr0soft`, `Magyar Pósta` and `MAGYARP0STA` all resolve to the brand they
imitate. A mention that survives only the *aggressive* fold and not the plain
one was deliberately disguised — which is exactly why `BRAND_SUBJ_OBFUS`
scores three times what a plain subject mention does.

`BRAND_LURE` never fires alone. "Please verify your account within 24 hours"
is also what a genuine password reset says; it is evidence only next to an
impersonation signal. That pairing is what keeps the phrase list aggressive
without generating false positives.

Everything is data, editable in the UI and hot-managed by
`qa-brand-guard.sh` (each save restarts rspamd, because Lua rules load once at
worker start):

* **Brands** — `local.d/brand_definitions.json`, seeded with 16 Hungarian and
  30 international brands (banks, couriers, authorities, marketplaces, cloud
  and crypto). Each brand carries name variants and its real sending domains.
  A variant written `=wise` matches only as a *whole* display name, which is
  how ordinary words (Visa, Apple, Meta, Booking, Steam) are protected without
  flagging "Visa Application Center" or "Booking Confirmation".
* **Lure phrases** — `local.d/brand_lures.json`, seeded with English and
  Hungarian. **A new language is a new key**: the matching code is
  language-neutral by construction, so adding German or Slovak is a data edit
  in the UI, not a code change.

Free-mail domains are deliberately *not* listed as any brand's real domain,
even where the brand owns one — exempting `outlook.com` would whitelist the
classic "Microsoft" phish sent from a free account.

### CSV exports

`?export=` serves CSV for: the archive message list (policy-gated), the audit
operation log, IOC SHA256 hashes, user logins, admin logins, admin login
failures, and mail auth failures. Each export enforces the same RBAC
permission as the tab it belongs to.

### Content-viewing policy (GDPR)

Whether message *bodies* can be opened at all is a three-state admin setting —
`none` / `spam only` / `all` — and **defaults to deny**. It gates viewing,
resending and the archive CSV alike. Every view/release/resend is audit-logged
with the operator's account name.

### RBAC roles

| Role | Permissions |
|------|-------------|
| **Admin** | Full access including Rendszer/Admin and user management |
| **Operator** | Release/delete, rspamd training, block/whitelist, archive — no admin tabs |
| **Viewer** | Read-only: quarantine list and archive |
| **Domain-admin** | Operator-level access restricted to a set of domains |

Credentials are Apache Basic Auth (`htpasswd`); roles come from `roles.json`.
With no `roles.json`, every authenticated user is Admin (backward-compatible
default); once it exists, unknown accounts default to Viewer.

### Languages

Hungarian (source) and English ship today. The UI language is switched at
runtime from Admin; adding a language is one translated `lang/<code>.php` file,
no code changes (see INSTALL.md).

---

## Stack

- **PHP 8.1+** — FPM mode; `pdo_mysql`, `mbstring`, `iconv`, `json`
- **Apache httpd 2.4** — `mod_proxy_fcgi`, Basic Auth
- **Dovecot 2.3+** — `doveadm` via a fixed-shape `sudo` gateway (no shell access)
- **rspamd 3.x** — Controller HTTP API + multimap plugin
- **MariaDB / MySQL** — archive index and login data (optional)
- **Python 3** — `parse_email.py` for inline message body rendering
- Mobile-responsive, vanilla JS only — no framework

---

## Quick start

Already running Postfix, Dovecot and rspamd? Ask the installer whether this host
qualifies — it checks every prerequisite and changes nothing:

```bash
git clone <this repo> && cd quarantine-admin
sudo ./install-console.sh --dry-run     # prints what it detected, and from where
sudo ./install-console.sh               # installs
```

It detects most of its configuration from the running system, asks only for the
quarantine folder names and the URL to serve at, and installs no packages. It
does not modify your Postfix, Dovecot or rspamd configuration. If the Apache
snippet it generates fails `configtest`, it removes it and leaves the web server
untouched.

No mail server on the box yet? Use
[ilexa-installer](../ilexa-installer) instead, which builds the whole stack
(Postfix, Dovecot, MariaDB, PostfixAdmin, Roundcube, rspamd, ClamAV, TLS,
fail2ban) and installs the console on top. It is for a fresh machine: it
overwrites `/etc/postfix`, `/etc/dovecot` and the databases with its own
templates.

**[INSTALL.md](INSTALL.md)** covers prerequisites in full, the manual procedure
the script automates, `config.php` reference, the central archive, enabling live
Bayes learning (off by default), and upgrade/rollback.

### Updating an existing install

```bash
./deploy.sh          # refuses if the webroot holds work the repo does not
```

`deploy.sh` lints the tree (`tools/lint-all.sh`: PHP syntax, i18n completeness,
helper/view consistency), guards against overwriting uncommitted webroot edits,
fixes the ownership PHP-FPM needs, and finishes by running the smoke-test suite
(`tools/smoke-test.sh`: every tab rendered through the real stack as the web
user, plus 401 / RBAC / CSRF negative cases) against the deployed tree. Never
`rsync` to the webroot by hand — a bare `rsync` once destroyed a day of work
here, which is why that guard exists.

---

## File layout

```
quarantine-admin/
├── config.php            ← site config (edit per deployment)
├── index.php             ← entry point: auth → early endpoints → view dispatch
├── export-hashes.php     ← token+IP-gated IOC hash feed for external firewalls
├── parse_email.py        ← email body parser (root:root 755)
├── src/                  ← PHP logic (bootstrap, rbac, i18n, validators,
│                            doveadm/rspamd/postfix gateways, quarantine
│                            actions, archive, lists, audit, admin,
│                            ioc + ioc_lookup/_enforce/_export, campaigns,
│                            list/quar/arc lookups, feed_health)
├── views/                ← one template per tab + layout_* shells
├── lang/                 ← hu (source) + en; drop-in extensible
├── tools/                ← lint-all.sh, check-* consistency gates,
│                            smoke-test.sh + smoke/ harness
└── install/              ← host-side helpers + templates installed to
                             /usr/local/sbin by install-console.sh (not served)
```

---

## Security notes

- All PHP files must be owned `apache:apache 640` — any root-owned `.php` causes a 500 from PHP-FPM
- CSRF tokens protect every state-changing POST (AJAX gets a JSON refusal, not a redirect)
- API keys live in root-only files under `/etc/ilexa/secrets/`; the web user never reads them — root-owned helpers make the external calls via a whitelisted `sudo` gateway, and keys are passed on stdin, never argv
- `sudo` rules are fixed-shape: no wildcards on helpers that take no arguments, and all `doveadm` access goes through `qa-doveadm.sh`
- The `config|src|install|lang` directories are blocked from direct HTTP access
- Message bodies are policy-gated (default deny) and every view/release/resend is audit-logged
- Passwords are stored as bcrypt via `htpasswd -B`, passed through stdin to avoid process-list exposure
- Settings overlay (`settings.json`) merges only whitelisted integer keys — no config injection

---

## License

GPL-3.0-or-later — see [LICENSE](LICENSE).
