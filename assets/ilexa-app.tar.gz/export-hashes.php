<?php
// Token+IP-gated pull endpoint for external firewalls/EDR to fetch
// confirmed SHA256 hash IOCs (docs/superpowers/specs/2026-08-11-ioc-hash-
// export-import-design.md). Deliberately NOT using session-based auth --
// index.php calls that unconditionally before any endpoint, which would
// fail-closed-reject every request here since this is fetched by an
// unattended script, not a logged-in admin browser session. Auth here is a
// static token (constant-time compared) plus an IP allowlist instead.
require __DIR__ . '/src/bootstrap.php';

$token = (string)($_GET['token'] ?? '');
$ip    = (string)($_SERVER['REMOTE_ADDR'] ?? '');

if (!ioc_export_pull_allowed($token, $ip)) {
    audit_log('ioc-export-denied', '-', '', '');
    http_response_code(403);
    exit("403 Forbidden\n");
}

audit_log('ioc-export-pull', '-', '', '');

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="ioc_hashes_' . date('Y-m-d') . '.csv"');
$out = fopen('php://output', 'w');
fwrite($out, "\xEF\xBB\xBF");
fputcsv($out, ['sha256']);
foreach (ioc_export_hashes_csv() as $h) fputcsv($out, [$h]);
fclose($out);
