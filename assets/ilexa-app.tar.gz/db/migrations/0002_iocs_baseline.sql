-- ilexa-migration: 0002
-- store: iocs
-- description: baseline -- all five iocs.db tables as created by _ioc_db(), moved here verbatim
-- tables: iocs, ioc_lookups, list_lookups, feed_samples, campaigns
-- kind: ddl
-- reversible: no
--
-- SQLite CREATE TABLE/INDEX IF NOT EXISTS is natively idempotent, so most of
-- this needs no guard. The one exception is the `promoted_at` column, added
-- to an already-shipped `iocs` table after the fact -- SQLite has no ADD
-- COLUMN IF NOT EXISTS, so it keeps the PRAGMA table_info() check the app
-- already used, expressed as this framework's @GUARD syntax (see
-- db/migrations/README.md). Transcribed verbatim from src/ioc.php's
-- _ioc_db() 2026-08-25.
-- @UP
CREATE TABLE IF NOT EXISTS iocs (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    type          TEXT NOT NULL,
    value         TEXT NOT NULL,
    source        TEXT NOT NULL DEFAULT 'manual',
    confidence    TEXT NOT NULL DEFAULT 'medium',
    notes         TEXT NOT NULL DEFAULT '',
    tags          TEXT NOT NULL DEFAULT '',
    added_by      TEXT NOT NULL DEFAULT '',
    source_ref    TEXT NOT NULL DEFAULT '',
    created_at    INTEGER NOT NULL,
    last_seen_at  INTEGER NOT NULL,
    expires_at    INTEGER,
    active        INTEGER NOT NULL DEFAULT 1,
    UNIQUE(type, value)
);

CREATE INDEX IF NOT EXISTS idx_iocs_type_active ON iocs(type, active);

CREATE TABLE IF NOT EXISTS ioc_lookups (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ioc_id      INTEGER NOT NULL REFERENCES iocs(id),
    service     TEXT NOT NULL,
    verdict     TEXT NOT NULL,
    detail      TEXT NOT NULL DEFAULT '',
    raw_json    TEXT NOT NULL DEFAULT '',
    checked_at  INTEGER NOT NULL,
    UNIQUE(ioc_id, service)
);

CREATE INDEX IF NOT EXISTS idx_ioc_lookups_ioc ON ioc_lookups(ioc_id);

CREATE TABLE IF NOT EXISTS list_lookups (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    type        TEXT NOT NULL,
    value       TEXT NOT NULL,
    service     TEXT NOT NULL,
    verdict     TEXT NOT NULL,
    detail      TEXT NOT NULL DEFAULT '',
    raw_json    TEXT NOT NULL DEFAULT '',
    checked_at  INTEGER NOT NULL,
    UNIQUE(type, value, service)
);

CREATE INDEX IF NOT EXISTS idx_list_lookups_type_value ON list_lookups(type, value);

CREATE TABLE IF NOT EXISTS feed_samples (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    feed        TEXT NOT NULL,
    sampled_at  INTEGER NOT NULL,
    count       INTEGER NOT NULL,
    age         INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_feed_samples ON feed_samples(feed, sampled_at);

-- @GUARD: NOT column_exists(iocs, promoted_at)
ALTER TABLE iocs ADD COLUMN promoted_at INTEGER;

CREATE TABLE IF NOT EXISTS campaigns (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    from_domain        TEXT NOT NULL,
    subject_signature  TEXT NOT NULL,
    subject_sample     TEXT NOT NULL,
    message_count      INTEGER NOT NULL,
    first_seen_at      INTEGER NOT NULL,
    last_seen_at       INTEGER NOT NULL,
    status             TEXT NOT NULL DEFAULT 'new',
    created_at         INTEGER NOT NULL,
    UNIQUE(from_domain, subject_signature)
);
-- @DOWN
-- No down migration -- see 0001_mysql_baseline.sql's identical note; this is
-- the baseline, reversal means dropping live IOC data, real rollback is the
-- pre-update sqlite3 .backup restored by the apply path's Phase 5b.
SELECT 1;
