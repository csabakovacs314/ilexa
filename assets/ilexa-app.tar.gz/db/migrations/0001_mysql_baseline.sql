-- ilexa-migration: 0001
-- store: mysql
-- description: baseline -- archive_index as created/upgraded by 55-ilexa.sh, moved here verbatim
-- tables: archive_index
-- kind: ddl
-- reversible: no
--
-- Every statement below is IF NOT EXISTS-guarded, which is what makes this
-- file safe to run against BOTH a virgin host (creates the schema) and every
-- host that has been running since before this migration framework existed
-- (a clean no-op, since it already has this exact schema by way of
-- ilexa-installer/modules/55-ilexa.sh's own inline CREATE TABLE + ALTER
-- TABLE). Transcribed verbatim from that file 2026-08-25 -- do not
-- "simplify" the guards, they are the entire baselining strategy documented
-- in db/migrations/README.md.
--
-- KNOWN, PRE-EXISTING DRIFT -- found while verifying this migration against
-- a structure-only copy of hawking's real archive_index, 2026-08-25. The
-- CREATE TABLE below (verbatim from 55-ilexa.sh, i.e. what a FRESH install
-- creates today) does not match hawking's actual live column types:
--   uid/ts:  BIGINT (this file) vs the live table's INT UNSIGNED
--   subject: VARCHAR(998) nullable, unindexed (this file)
--            vs VARCHAR(512) NOT NULL DEFAULT '', indexed, live
--   from_addr/to_addr: nullable, unindexed (this file)
--            vs NOT NULL DEFAULT '', indexed, live
-- This migration does NOT reconcile that drift, and verified empirically
-- that it doesn't need to in order to be safe: CREATE TABLE IF NOT EXISTS
-- is a full no-op against an existing table regardless of column-level
-- differences, so running this against hawking changes nothing and errors
-- on nothing (confirmed against a structure-only mysqldump copy of the real
-- table). A fresh install and hawking therefore end up with two genuinely
-- different archive_index schemas after this migration -- reconciling that
-- (widening a live, indexed, 4800+-row column) is a real, separate,
-- deliberate migration for someone to write later, not something to fold
-- silently into the baseline.
-- @UP
CREATE TABLE IF NOT EXISTS archive_index (
    uid BIGINT UNSIGNED NOT NULL PRIMARY KEY,
    ts BIGINT NOT NULL,
    from_addr VARCHAR(320),
    to_addr VARCHAR(320),
    subject VARCHAR(998),
    rspamd_score FLOAT DEFAULT NULL,
    is_spam TINYINT(1) NOT NULL DEFAULT 0,
    indexed_at BIGINT UNSIGNED NOT NULL,
    learned_as ENUM('spam','ham') DEFAULT NULL,
    learned_at INT UNSIGNED DEFAULT NULL,
    sender_ip VARCHAR(45) DEFAULT NULL,
    sender_cc CHAR(2) DEFAULT NULL,
    INDEX(ts), INDEX(is_spam), INDEX(sender_cc)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE archive_index
    ADD COLUMN IF NOT EXISTS sender_ip VARCHAR(45) DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS sender_cc CHAR(2) DEFAULT NULL,
    ADD INDEX IF NOT EXISTS idx_sender_cc (sender_cc);
-- @DOWN
-- Deliberately no down migration: this is the baseline. Reversing it means
-- dropping the table an admin's whole archive search depends on. A real
-- rollback restores from the pre-update mysqldump instead (see the apply
-- path's Phase 2/5b) -- this DOWN section exists only so the file format is
-- uniform and the lint doesn't have to special-case migration 0001.
SELECT 1;
