# Migration file format

One global `NNNN` sequence across three independent stores (`mysql`, `iocs`,
`logins`). The number routes nothing by itself — the `store:` header field
does — it exists only so migration files sort chronologically together in
one directory instead of three separately-numbered ones.

```sql
-- ilexa-migration: 0007
-- store: mysql
-- description: archive_index gains message_id for dedupe
-- tables: archive_index
-- kind: ddl
-- reversible: yes
-- @UP
ALTER TABLE archive_index
  ADD COLUMN IF NOT EXISTS message_id VARCHAR(255) DEFAULT NULL,
  ADD INDEX IF NOT EXISTS idx_message_id (message_id);
-- @DOWN
ALTER TABLE archive_index
  DROP INDEX IF EXISTS idx_message_id,
  DROP COLUMN IF EXISTS message_id;
```

Header fields, all required:

- `ilexa-migration` — the `NNNN`, must match the filename prefix exactly.
- `store` — `mysql` | `iocs` | `logins`. Routes the file to the right connection.
- `description` — one line, human-readable.
- `tables` — comma-separated. **Enforced against an allowlist** (see below);
  `tools/check-migrations.php` and the runtime runner both reject a migration
  naming a table outside it.
- `kind` — `ddl` (schema change) or `data` (backfill/repair). `data`
  migrations must be chunked with an explicit row cap and run inside a real
  transaction on both engines — they are not exempt from the atomicity rules
  below, they are the one case those rules were relaxed *for*.
- `reversible` — `yes` | `no`. `no` means `@DOWN` is a documentation-only
  `SELECT 1;` (see the baseline files) — legitimate for a migration whose
  only real undo is "restore the pre-update dump", which is what the apply
  path's rollback actually does. `@DOWN` is **never executed automatically**
  during a failure — see "Why `@DOWN` is not the rollback mechanism" below.

## Table allowlist

`mysql` migrations may only name: **`archive_index`, `schema_migrations`**.

Nothing else. In particular **not** `postfix.last_login` — that table is
created and owned by Dovecot's last-login dict plugin
(`ilexa-installer/modules/25-dovecot.sh`), not by this app. The console only
ever reads it (`qaudit_ro`'s `SELECT`-only grant on it, unchanged by this
framework). A schema change to `last_login` is out of scope here by
definition — it belongs in a Dovecot module, not a console migration.

This allowlist is not bureaucracy: it is what makes the update-apply path's
pre-migration `mysqldump` a *sufficient* rollback substrate. A migration
touching a mailbox/alias/domain table would put live mail delivery inside
the blast radius of a console self-update, which must never happen.

## Atomicity — read this before writing a DDL migration

**MariaDB/InnoDB DDL is not transactional.** `ALTER TABLE` implicitly
commits and cannot be rolled back by a surrounding transaction — there is no
way around this, and pretending otherwise is how migration frameworks lose
data. So: **every mysql DDL statement must be individually idempotent**,
via `IF NOT EXISTS` / `IF EXISTS` (MariaDB supports this on
`ADD/DROP COLUMN`, `ADD/DROP INDEX`, `CREATE/DROP TABLE`). This is not new —
it is exactly what `0001_mysql_baseline.sql` already does, because it's a
verbatim transcription of the one real upgrade this app has ever shipped.
`tools/check-migrations.php` rejects any mysql `ALTER TABLE` clause lacking
the guard. A migration that dies mid-file leaves a partially-applied file on
disk, but **re-running it converges** to the same end state, because every
statement is a no-op once already applied — that convergence property, not
a transaction, is what makes replay safe.

**SQLite DDL *is* transactional.** `iocs`/`logins` migrations run inside
`BEGIN`/`COMMIT` and a failure rolls the whole file back cleanly.

## `@GUARD` — for the one thing SQLite can't guard natively

`CREATE TABLE IF NOT EXISTS` and `CREATE INDEX IF NOT EXISTS` are already
idempotent in SQLite. The one gap is `ALTER TABLE ... ADD COLUMN`, which
SQLite has no `IF NOT EXISTS` form for at all. For that case only, precede
the statement with a guard comment:

```sql
-- @GUARD: NOT column_exists(iocs, promoted_at)
ALTER TABLE iocs ADD COLUMN promoted_at INTEGER;
```

The guard applies to exactly the next statement (up to its terminating
`;`). Three predicates only, deliberately — this is a baselining aid, not a
general expression language:

- `table_exists(table)`
- `column_exists(table, column)`
- `index_exists(index)`

Each may be prefixed with `NOT`. The runner evaluates the guard against
`sqlite_master`/`PRAGMA table_info` before deciding whether to run the
statement; a guard that evaluates false makes that one statement a no-op,
not an error.

This is a direct generalisation of the exact check
`src/ioc.php`'s `_ioc_db()` already performed by hand
(`PRAGMA table_info(iocs)` → conditional `ALTER TABLE ... ADD COLUMN`)
before this framework existed.

## `schema_migrations` — the ledger

A real table, one instance per store (`postfix.schema_migrations` for
mysql; a table of the same name and shape inside each of `iocs.db` and
`logins.db`) — not a file. A file desyncs from the schema it describes the
moment someone restores a dump; the ledger has to live in the same durable
object as the schema it's tracking.

```sql
CREATE TABLE schema_migrations (
    id          INTEGER  NOT NULL PRIMARY KEY,   -- the migration's NNNN
    applied_at  INTEGER  NOT NULL,               -- unix time
    checksum    TEXT     NOT NULL,               -- sha256 of the file body
    duration_ms INTEGER,
    applied_by  TEXT     NOT NULL DEFAULT ''      -- 'baseline-adopt' | os user | 'update-apply'
);
```

`checksum` is compared against the on-disk file's current checksum on every
`--status`/`--apply` run; a mismatch on an *already-applied* migration is a
hard error (`migration_checksum_drift()`) — it means a released migration
was edited after the fact, which is exactly the silent-corruption failure
mode this ledger exists to catch. **Never edit a migration file that has
already shipped in a release.** Write a new one instead.

## Known pre-existing schema drift

`0001_mysql_baseline.sql`'s header documents a real finding from verifying
it: the reference host's live `archive_index` does not match what
`55-ilexa.sh`'s `CREATE TABLE` (and so this baseline) would create on a
*fresh* install — different `uid`/`ts` width, `subject` length, and
NOT-NULL/index state on a few columns. Verified this is harmless (`CREATE
TABLE IF NOT EXISTS` no-ops against an existing table regardless), but it
means a fresh install and the reference host end up with two genuinely
different schemas after baselining. Read that migration's header before
writing anything that assumes `archive_index`'s exact column types.

## Baselining — why "any older version → newest" actually works

`0001_mysql_baseline.sql`, `0002_iocs_baseline.sql`, and
`0003_logins_baseline.sql` are **verbatim transcriptions** of this app's
schema exactly as it existed inline in
`ilexa-installer/modules/55-ilexa.sh` and in `_ioc_db()`/`_signin_db()`
before this framework existed. Because every statement in them was already
`IF NOT EXISTS`/`@GUARD`-idempotent for an unrelated reason (an ad hoc
upgrade path added in August), running the baseline files against an
already-running host is a full no-op, and running them against a virgin
host creates the schema from nothing. **Same file, both cases, no branch,
no schema-fingerprinting heuristic, no "detect current version" step.**

**Do not "clean up" the `IF NOT EXISTS`/`@GUARD` guards in the baseline
files.** They are not incidental — removing them breaks baselining for
every host that adopts this framework from an unversioned installation,
which as of this framework's introduction is every host that exists.

Mechanically, "any older version → newest" is: for each store,
`pending = files not yet in that store's ledger`, applied in ascending id
order. A host with an empty ledger just runs everything starting at `0001`
— safely, because of the baseline property above. There is no N→N+1 chain
and no upgrade matrix to maintain.

## Why `@DOWN` is not the rollback mechanism

Migrations may declare a `@DOWN` section, and the lint encourages one for
`reversible: yes` migrations. **The update-apply path's automatic rollback
does not execute it.** It restores from the pre-update dump instead (see
the apply path design). A `@DOWN` section is only as correct as its
author's imagination, and it would be executed for the first time in the
exact moment something has already gone wrong — the dump is the path that
is *certainly* correct. Treat `@DOWN` as executable documentation of
intent and as a tool for a *manual*, operator-driven partial revert, not as
the safety net.

## Directory listing convention

`0001_mysql_baseline.sql`, `0002_iocs_baseline.sql`,
`0003_logins_baseline.sql` reserve `0001`–`0003`. The next real migration —
mysql, iocs, or logins — is `0004`, regardless of which store it targets.
