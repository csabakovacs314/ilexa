-- ilexa-migration: 0003
-- store: logins
-- description: baseline -- both logins.db tables as created by _signin_db(), moved here verbatim
-- tables: signin_events, signin_places
-- kind: ddl
-- reversible: no
--
-- Both CREATE TABLE/INDEX IF NOT EXISTS statements are natively idempotent
-- in SQLite, so no @GUARD is needed anywhere in this file. Transcribed
-- verbatim from src/signin.php's _signin_db() 2026-08-25.
-- @UP
CREATE TABLE IF NOT EXISTS signin_events (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    ts       INTEGER NOT NULL,
    user     TEXT NOT NULL,
    ip       TEXT NOT NULL,
    proto    TEXT NOT NULL,
    status   TEXT NOT NULL,
    cc       TEXT NOT NULL DEFAULT '',
    asn      INTEGER,
    lat      REAL,
    lon      REAL,
    score    INTEGER,
    tier     TEXT,
    reasons  TEXT NOT NULL DEFAULT '',
    notified INTEGER NOT NULL DEFAULT 0,
    UNIQUE(user, ip, ts, proto, status)
);

CREATE INDEX IF NOT EXISTS idx_signin_user_ts ON signin_events(user, ts);

CREATE TABLE IF NOT EXISTS signin_places (
    user       TEXT NOT NULL,
    kind       TEXT NOT NULL,
    value      TEXT NOT NULL,
    first_seen INTEGER NOT NULL,
    last_seen  INTEGER NOT NULL,
    hits       INTEGER NOT NULL DEFAULT 1,
    PRIMARY KEY(user, kind, value)
);
-- @DOWN
-- No down migration -- see 0001_mysql_baseline.sql's identical note; real
-- rollback is the pre-update sqlite3 .backup restored by the apply path's
-- Phase 5b.
SELECT 1;
