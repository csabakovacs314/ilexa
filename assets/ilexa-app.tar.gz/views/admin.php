<?php
// Admin tab view.
// Variables from index.php: $admin_settings, $admin_sysinfo, $admin_users

$rules   = _admin_rules();
$ovr     = $admin_settings;
$msg     = $_GET['msg'] ?? '';
$err_msg = h(urldecode($_GET['err'] ?? ''));

$valid_roles = ['admin' => 'Admin', 'operator' => t('Operátor'), 'viewer' => t('Megfigyelő'), 'domain_admin' => t('Domain-admin')];

$ADMIN_TAB = 'admin=1';

$notices = [
    'alerts_set'       => ['ok',  t('Értesítési cím elmentve. Innentől ide érkeznek a háttérfolyamatok hibajelzései.')],
    'alerts_off'       => ['ok',  t('Értesítések kikapcsolva. A hibák továbbra is bekerülnek a rendszernaplóba.')],
    'alerts_err'       => ['err', t('Az értesítési cím mentése sikertelen: ') . $err_msg],
    'setting_saved'    => ['ok',  t('Beállítás elmentve. Az új érték a következő oldalbetöltéstől aktív.')],
    'setting_reset'    => ['ok',  t('Beállítás visszaállítva az alapértelmezett értékre.')],
    'setting_err'      => ['err', t('Hiba a mentés során: ') . $err_msg],
    'user_added'       => ['ok',  t('Felhasználó sikeresen létrehozva.')],
    'user_deleted'     => ['ok',  t('Felhasználó törölve.')],
    'role_saved'       => ['ok',  t('Szerepkör elmentve.')],
    'pw_saved'         => ['ok',  t('Jelszó megváltoztatva.')],
    'user_err'         => ['err', t('Hiba: ') . $err_msg],
    'lang_saved'       => ['ok',  t('A nyelv megváltozott.')],
    'lang_err'         => ['err', t('A nyelv módosítása sikertelen: ') . $err_msg],
    'view_policy_saved' => ['ok',  t('Adatvédelmi beállítás elmentve.')],
    'view_policy_err'   => ['err', t('Az adatvédelmi beállítás mentése sikertelen: ') . $err_msg],
    'password_expiry_toggle_saved' => ['ok',  t('Jelszó-lejárati kényszerítés beállítása elmentve.')],
    'password_expiry_toggle_err'   => ['err', t('A mentés sikertelen: ') . $err_msg],
    'siem_saved'        => ['ok',  t('SIEM-exportálás beállítása elmentve.')],
    'siem_err'          => ['err', t('A SIEM-exportálás beállításának mentése sikertelen: ') . $err_msg],
    'signin_notify_saved' => ['ok',  t('Bejelentkezési anomália-értesítés beállítása elmentve.')],
    'signin_notify_err'   => ['err', t('A mentés sikertelen: ') . $err_msg],
];
?>
<h1 class="page-title"><?= h(t('Admin')) ?></h1>
<?php if (isset($notices[$msg])):
    [$nt, $nm] = $notices[$msg];
?>
<div class="notice notice-<?= $nt ?>">
    <?= $nt === 'ok' ? '<svg class="icon"><use href="#icon-check"></use></svg>' : '<svg class="icon"><use href="#icon-warning"></use></svg>' ?> <?= $nm ?>
</div>
<?php endif; ?>

<?php
// A root-owned sudo helper failed while building this page, so at least one
// value below reads as "not configured" when it is really "could not be read".
// Independent of the $notices chain above (not an elseif): a save can succeed
// while an unrelated getter fails. See qa_sudo_read() in src/helpers.php.
// Rendered after every getter above has already run.
$qa_sudo_fail = qa_sudo_failures();
if (!empty($qa_sudo_fail)): ?>
<div class="notice notice-err">
    <svg class="icon"><use href="#icon-warning"></use></svg>
    <?= h(sprintf(
        t('Egy vagy több segédszkript hibára futott (%s), ezért az alábbi értékek közül néhány "nincs beállítva"-ként jelenhet meg, holott csak nem sikerült beolvasni. Nézd meg a webszerver hibanaplóját.'),
        implode(', ', $qa_sudo_fail)
    )) ?>
</div>
<?php endif; ?>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- 0. Nyelv                                                                   -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<details class="sys-sec results-card" id="nyelv" style="margin-bottom:20px">
    <summary class="results-header"><h2><?= h(t('Kezelőfelület nyelve')) ?></h2>
        <span class="sys-sec-desc"><?= h(t('A kezelőfelület nyelve minden adminisztrátor számára.')) ?></span></summary>
    <div style="padding:16px 20px;display:flex;align-items:center;gap:14px;flex-wrap:wrap">
        <form method="post" action="?admin=1" style="display:flex;gap:8px;align-items:center">
            <?= csrf_field() ?>
            <input type="hidden" name="admin_action" value="set_language">
            <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
            <select name="lang" style="padding:7px 10px">
                <?php foreach (available_languages() as $lk => $lv): ?>
                <option value="<?= h($lk) ?>" <?= qa_lang() === $lk ? 'selected' : '' ?>><?= h($lv) ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-primary"><?= h(t('Ment')) ?></button>
        </form>
        <span style="font-size:.8rem;color:var(--text-subtle)">
            <?= h(t('A beállítás az egész felületre érvényes, minden adminisztrátornak.')) ?>
        </span>
    </div>
</details>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- 0b. Adatvédelem: levéltartalom megtekintése                                -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<?php $_vp = qa_view_policy(); ?>
<details class="sys-sec results-card" id="adatvedelem" style="margin-bottom:20px">
    <summary class="results-header"><h2><?= h(t('Levéltartalom megtekintése (adatvédelem)')) ?></h2>
        <span class="sys-sec-desc"><?= h(t('Megnyithatják-e az adminisztrátorok a levelek tartalmát. Alapértelmezés: letiltva.')) ?></span></summary>
    <div class="filter-hint" style="margin:16px 20px 4px">
        <?= h(t('Szabályozza, hogy az adminisztrátorok megnyithatják-e a levelek tartalmát. A beállítás az egész felületre érvényes, és csak szűkíti a szerepkörök jogosultságait - nem ad új jogot. Alapértelmezés: letiltva.')) ?>
    </div>
    <div style="padding:16px 20px;display:flex;align-items:center;gap:14px;flex-wrap:wrap">
        <form method="post" action="?admin=1" style="display:flex;gap:8px;align-items:center"
              onsubmit="return qaGdprGate(this)">
            <?= csrf_field() ?>
            <input type="hidden" name="admin_action" value="set_view_policy">
            <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
            <select name="view_policy" style="padding:7px 10px">
                <option value="none" <?= $_vp === 'none' ? 'selected' : '' ?>><?= h(t('Letiltva - senki nem nyithatja meg')) ?></option>
                <option value="spam" <?= $_vp === 'spam' ? 'selected' : '' ?>><?= h(t('Csak a jelentett spam tartalma')) ?></option>
                <option value="all"  <?= $_vp === 'all'  ? 'selected' : '' ?>><?= h(t('Minden levél tartalma (archívum is)')) ?></option>
            </select>
            <button type="submit" class="btn btn-primary"><?= h(t('Ment')) ?></button>
        </form>
        <span style="font-size:.8rem;color:var(--text-subtle)">
            <?= h(t('A "Minden levél" az archívumot is megnyitja, amely minden felhasználó teljes levelezésének 30 napos másolatát tartalmazza.')) ?>
        </span>
    </div>
</details>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- Jelszó-lejárati kényszerítés (Roundcube banner/redirect + a napi           -->
<!-- előzetes értesítő) -- projekt szüneteltetve 2026-08-23, kódban marad,      -->
<!-- alapértelmezés szerint kikapcsolva.                                       -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<?php $_pwx_on = qa_password_expiry_enabled(); ?>
<details class="sys-sec results-card" id="jelszo-lejarat" style="margin-bottom:20px">
    <summary class="results-header"><h2><?= h(t('Jelszó-lejárati kényszerítés')) ?></h2>
        <span class="sys-sec-desc"><?= h(t('Roundcube-figyelmeztetés és napi e-mail a jelszó lejárta előtt. Alapértelmezés: kikapcsolva.')) ?></span></summary>
    <div class="filter-hint" style="margin:16px 20px 4px">
        <?= h(t('Bekapcsolva a Roundcube figyelmezteti a felhasználót a lejárat előtt, lejárat után pedig jelszóváltoztatásra irányítja - és a napi ellenőrzés e-mailt küld a lejárat előtt 7, 3 és 1 nappal. Kikapcsolva egyik sem történik meg, de a lejárati dátumok és a beállítás megmaradnak, bármikor visszakapcsolható. Alapértelmezés: kikapcsolva.')) ?>
    </div>
    <div style="padding:16px 20px;display:flex;align-items:center;gap:14px;flex-wrap:wrap">
        <form method="post" action="?admin=1" style="display:flex;gap:8px;align-items:center">
            <?= csrf_field() ?>
            <input type="hidden" name="admin_action" value="set_password_expiry_enabled">
            <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
            <select name="password_expiry_enabled" style="padding:7px 10px">
                <option value="0" <?= !$_pwx_on ? 'selected' : '' ?>><?= h(t('Kikapcsolva')) ?></option>
                <option value="1" <?= $_pwx_on  ? 'selected' : '' ?>><?= h(t('Bekapcsolva')) ?></option>
            </select>
            <button type="submit" class="btn btn-primary"><?= h(t('Ment')) ?></button>
        </form>
        <span style="font-size:.8rem;color:var(--text-subtle)">
            <?= h(t('Jelenlegi állapot: ')) ?><strong><?= $_pwx_on ? h(t('bekapcsolva')) : h(t('kikapcsolva')) ?></strong>.
        </span>
    </div>
</details>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- Bejelentkezési anomália-értesítés (src/signin.php) -- ingest+pontszámítás  -->
<!-- mindig fut; ez a kapcsoló csak a "was this you?" e-mail kiküldését        -->
<!-- vezérli. Alapértelmezés szerint kikapcsolva, ugyanazon okból, mint a      -->
<!-- fenti jelszó-lejárati értesítés: éles forgalmon még nem igazolt küszöbök. -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<?php $_signin_on = signin_notify_enabled(); ?>
<details class="sys-sec results-card" id="bejelentkezesi-anomalia" style="margin-bottom:20px">
    <summary class="results-header"><h2><?= h(t('Bejelentkezési anomália-értesítés')) ?></h2>
        <span class="sys-sec-desc"><?= h(t('E-mail a postafiók tulajdonosának minden gyanús új bejelentkezésről. Alapértelmezés: kikapcsolva.')) ?></span></summary>
    <div class="filter-hint" style="margin:16px 20px 4px">
        <?= h(t('Bekapcsolva a rendszer e-mailt küld a postafiók tulajdonosának minden magas kockázatúnak minősített új bejelentkezésről (új ország, lehetetlen utazási sebesség stb.) - a Gmail "új bejelentkezés" értesítéséhez hasonlóan. Kikapcsolva a bejelentkezések figyelése és pontozása továbbra is fut és az Audit fülön látható, csak az e-mail-küldés marad el. Alapértelmezés: kikapcsolva.')) ?>
    </div>
    <div style="padding:16px 20px;display:flex;align-items:center;gap:14px;flex-wrap:wrap">
        <form method="post" action="?admin=1" style="display:flex;gap:8px;align-items:center">
            <?= csrf_field() ?>
            <input type="hidden" name="admin_action" value="set_signin_notify_enabled">
            <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
            <select name="signin_notify_enabled" style="padding:7px 10px">
                <option value="0" <?= !$_signin_on ? 'selected' : '' ?>><?= h(t('Kikapcsolva')) ?></option>
                <option value="1" <?= $_signin_on  ? 'selected' : '' ?>><?= h(t('Bekapcsolva')) ?></option>
            </select>
            <button type="submit" class="btn btn-primary"><?= h(t('Ment')) ?></button>
        </form>
        <span style="font-size:.8rem;color:var(--text-subtle)">
            <?= h(t('Jelenlegi állapot: ')) ?><strong><?= $_signin_on ? h(t('bekapcsolva')) : h(t('kikapcsolva')) ?></strong>.
        </span>
    </div>
</details>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- Értesítési cím (cron-alert.sh)                                             -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<?php $_alert_to = admin_alerts_get_recipient(); ?>
<details class="sys-sec results-card" id="ertesitesek" style="margin-bottom:20px">
    <summary class="results-header"><h2><?= h(t('Hibaértesítések e-mail címe')) ?></h2>
        <span class="sys-sec-desc"><?= h(t('Ide érkeznek a háttérfolyamatok hibajelzései. Üresen hagyva nem küld értesítést.')) ?></span></summary>
    <div class="filter-hint" style="margin:16px 20px 4px">
        <?= h(t('Ide küldi a rendszer a háttérfolyamatok (DNSBL-figyelő, hírnév-források frissítése, tanúsítvány-lejárat) hibajelzéseit. Üresen hagyva semmilyen értesítés nem megy ki - ez az alapértelmezés. A hibák ilyenkor is bekerülnek a rendszernaplóba.')) ?>
    </div>
    <div style="padding:16px 20px;display:flex;align-items:center;gap:14px;flex-wrap:wrap">
        <form method="post" action="?admin=1" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
            <?= csrf_field() ?>
            <input type="hidden" name="admin_action" value="set_alert_recipient">
            <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
            <input type="email" name="alert_recipient" value="<?= h($_alert_to) ?>"
                   placeholder="<?= h(t('nincs beállítva - nem küld értesítést')) ?>"
                   style="padding:7px 10px;min-width:22rem;max-width:100%">
            <button type="submit" class="btn btn-primary"><?= h(t('Ment')) ?></button>
        </form>
        <span style="font-size:.8rem;color:var(--text-subtle)">
            <?php if ($_alert_to === ''): ?>
                <?= h(t('Jelenleg kikapcsolva.')) ?>
            <?php else: ?>
                <?= h(t('Jelenlegi címzett: ')) ?><strong><?= h($_alert_to) ?></strong>.
                <?= h(t('A mező kiürítésével és mentésével kapcsolható ki.')) ?>
            <?php endif; ?>
        </span>
    </div>
</details>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- SIEM-exportálás (qa-siem-config.sh)                                       -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<?php $_siem = admin_siem_get(); ?>
<details class="sys-sec results-card" id="siem-export" style="margin-bottom:20px">
    <summary class="results-header"><h2><?= h(t('SIEM-exportálás')) ?></h2>
        <span class="sys-sec-desc"><?= h(t('Fail2Ban-, Apache-SSL- és audit-események továbbítása külső syslog-gyűjtőre (SIEM).')) ?></span></summary>
    <div class="filter-hint" style="margin:16px 20px 4px">
        <?= h(t('A Fail2Ban tiltásokat, az Apache SSL-vhost hibanaplóját (admin belépési kísérletek) és ennek a konzolnak a saját audit-naplóját (kiadás/törlés, adatvédelmi beállítás módosítása, IOC-változások) tovább küldi egy külső syslog-gyűjtőre (SIEM). Kikapcsolva semmi nem hagyja el ezt a szervert.')) ?>
    </div>
    <form method="post" action="?admin=1" style="padding:16px 20px;display:flex;align-items:center;gap:14px;flex-wrap:wrap">
        <?= csrf_field() ?>
        <input type="hidden" name="admin_action" value="set_siem_export">
        <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
        <label style="display:flex;align-items:center;gap:6px;font-weight:600">
            <input type="checkbox" name="siem_enabled" <?= $_siem['enabled'] === 'yes' ? 'checked' : '' ?>>
            <?= h(t('Küldés bekapcsolva')) ?>
        </label>
        <input type="text" name="siem_host" value="<?= h($_siem['host']) ?>"
               placeholder="<?= h(t('gyűjtő címe (host vagy IP)')) ?>"
               style="padding:7px 10px;min-width:16rem;max-width:100%">
        <input type="number" id="siemPort" name="siem_port" value="<?= h($_siem['port']) ?>" min="1" max="65535"
               style="padding:7px 10px;width:6rem" aria-label="<?= h(t('Port')) ?>">
        <select id="siemProtocol" name="siem_protocol" style="padding:7px 10px" aria-label="<?= h(t('Protokoll')) ?>">
            <option value="udp" <?= $_siem['protocol'] === 'udp' ? 'selected' : '' ?>>UDP</option>
            <option value="tcp" <?= $_siem['protocol'] === 'tcp' ? 'selected' : '' ?>>TCP</option>
            <option value="tls" <?= $_siem['protocol'] === 'tls' ? 'selected' : '' ?>>TLS</option>
        </select>
        <div id="siemCaRow" style="display:<?= $_siem['protocol'] === 'tls' ? 'flex' : 'none' ?>;flex-direction:column;gap:6px;width:100%">
            <label for="siemCaCertPem" style="font-size:.8rem;color:var(--text-subtle)">
                <?= h(t('CA-tanúsítvány beillesztése (PEM, opcionális):')) ?>
                <?php if ($_siem['ca_cert_configured'] === 'yes'): ?>
                    <?= h(t('Jelenleg beállítva: ')) ?><strong><?= h($_siem['ca_cert_subject']) ?></strong>
                    (<?= h(t('lejár: ')) ?><?= h($_siem['ca_cert_expiry']) ?>)
                <?php endif; ?>
            </label>
            <textarea id="siemCaCertPem" name="siem_ca_cert_pem" rows="4" spellcheck="false"
                      placeholder="-----BEGIN CERTIFICATE-----&#10;...&#10;-----END CERTIFICATE-----"
                      style="padding:8px 10px;width:100%;max-width:100%;font-family:monospace;font-size:.8rem;resize:vertical"></textarea>
            <span style="font-size:.75rem;color:var(--text-subtle)">
                <?= h(t('Hagyja üresen a jelenlegi tanúsítvány (vagy annak hiánya) megtartásához. Beillesztéskor a rendszer ellenőrzi, hogy érvényes X.509 tanúsítvány-e, mentés előtt.')) ?>
                <?php if ($_siem['ca_cert_configured'] === 'yes'): ?>
                    <label style="margin-left:10px;white-space:nowrap">
                        <input type="checkbox" name="siem_ca_remove"> <?= h(t('beállított CA-tanúsítvány eltávolítása (vissza anonim TLS-re)')) ?>
                    </label>
                <?php endif; ?>
            </span>
        </div>
        <button type="submit" class="btn btn-primary"><?= h(t('Ment')) ?></button>
        <span style="font-size:.8rem;color:var(--text-subtle);width:100%">
            <?php if ($_siem['enabled'] === 'yes' && $_siem['host'] !== ''): ?>
                <?= h(t('Jelenleg küld: ')) ?><strong><?= h($_siem['host']) ?>:<?= h($_siem['port']) ?>/<?= h(strtoupper($_siem['protocol'])) ?></strong>.
            <?php else: ?>
                <?= h(t('Jelenleg kikapcsolva. A Fail2Ban/Apache-SSL-hiba/audit események helyben, a rendszernaplóba (rsyslog local2-4) még így is bekerülnek - csak a külső gyűjtőre küldés van kikapcsolva.')) ?>
            <?php endif; ?>
            <?php if ($_siem['protocol'] === 'tls'): ?>
                <?php if ($_siem['ca_cert_configured'] === 'yes'): ?>
                    <br><?= h(t('TLS: a gyűjtő tanúsítványát a beállított CA-fájl alapján ellenőrzi (x509/certvalid) - névellenőrzés (hostname/SAN) nincs.')) ?>
                <?php else: ?>
                    <br><?= h(t('TLS: a kapcsolat titkosított, de a gyűjtő tanúsítványát nem ellenőrzi (anonim TLS) - illesszen be egy CA-tanúsítványt a valódi hitelesítéshez.')) ?>
                <?php endif; ?>
            <?php endif; ?>
        </span>
    </form>
    <script>
    // Auto-fills the standard syslog port for whichever protocol is picked
    // (UDP=514/RFC3164, TCP=601/RFC5426, TLS=6514/RFC5425), but only while
    // the port field still holds one of those three (or is empty) -- the
    // moment an admin types a genuinely custom port, switching protocol
    // must not silently overwrite their deliberate choice. Also shows/hides
    // the CA-cert field, which only matters for TLS.
    (function () {
        var STANDARD_PORTS = { udp: '514', tcp: '601', tls: '6514' };
        var protocolEl = document.getElementById('siemProtocol');
        var portEl = document.getElementById('siemPort');
        var caRow = document.getElementById('siemCaRow');
        if (!protocolEl || !portEl) return;
        var knownPorts = Object.keys(STANDARD_PORTS).map(function (k) { return STANDARD_PORTS[k]; });
        protocolEl.addEventListener('change', function () {
            var current = portEl.value.trim();
            if (current === '' || knownPorts.indexOf(current) !== -1) {
                portEl.value = STANDARD_PORTS[protocolEl.value] || current;
            }
            if (caRow) caRow.style.display = (protocolEl.value === 'tls') ? 'flex' : 'none';
        });
    })();
    </script>
</details>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- Jelszó-visszaállítási cím lefedettsége (password-expiry Phase 1)          -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<?php $_pwx = $admin_pwexpiry_coverage ?? null; ?>
<details class="sys-sec results-card" id="pwexpiry-coverage" style="margin-bottom:20px">
    <summary class="results-header"><h2><?= h(t('Jelszó-visszaállítási cím lefedettsége')) ?></h2>
        <span class="sys-sec-desc"><?= h(t('Hány postafióknak van visszaállítási e-mail címe. Csak mér, nem korlátoz.')) ?></span></summary>
    <div class="filter-hint" style="margin:16px 20px 4px">
        <?= h(t('A jövőbeli jelszó-lejárati kényszerítés csak azoknál a postafiókoknál alkalmazható biztonságosan, amelyeknek van beállított visszaállítási e-mail címe (Roundcube → Beállítások → Másodlagos e-mail cím) - enélkül a felhasználó véglegesen kizárná magát. Ez a kártya csak mér, semmit nem korlátoz.')) ?>
    </div>
    <?php if ($_pwx === null): ?>
    <div class="filter-hint" style="margin:0 20px 16px">
        <svg class="icon"><use href="#icon-warning"></use></svg>
        <?= h(t('Az adatbázis-kapcsolat jelenleg nem érhető el, a lefedettség nem olvasható be.')) ?>
    </div>
    <?php else: ?>
    <div class="filter-hint" style="margin:0 20px 16px">
        <strong><?= (int)$_pwx['with_recovery'] ?> / <?= (int)$_pwx['total'] ?></strong>
        <?= h(t('postafiók rendelkezik visszaállítási címmel')) ?>
        (<?= $_pwx['total'] > 0 ? (int)round($_pwx['with_recovery'] / $_pwx['total'] * 100) : 0 ?>%).
    </div>
    <table class="msg-table" style="table-layout:fixed">
        <colgroup>
            <col style="width:40%">
            <col style="width:20%">
            <col style="width:20%">
            <col style="width:20%">
        </colgroup>
        <thead>
            <tr>
                <th scope="col"><?= h(t('Domain')) ?></th>
                <th scope="col"><?= h(t('Postafiókok')) ?></th>
                <th scope="col"><?= h(t('Van visszaállítási cím')) ?></th>
                <th scope="col"><?= h(t('Arány')) ?></th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($_pwx['domains'] as $_d): ?>
            <tr>
                <td data-label="<?= h(t('Domain')) ?>"><?= h($_d['domain']) ?></td>
                <td data-label="<?= h(t('Postafiókok')) ?>"><?= (int)$_d['total'] ?></td>
                <td data-label="<?= h(t('Van visszaállítási cím')) ?>"><?= (int)$_d['with_recovery'] ?></td>
                <td data-label="<?= h(t('Arány')) ?>"><?= $_d['total'] > 0 ? (int)round($_d['with_recovery'] / $_d['total'] * 100) : 0 ?>%</td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</details>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- 3. Futtatókörnyezet beállításai                                            -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<details class="sys-sec results-card" id="runtime" style="margin-bottom:20px">
    <summary class="results-header">
        <h2><?= t('Futtatókörnyezet beállításai') ?></h2>
        <span class="meta"><?= t('Azonnal életbe lép, újraindítás nélkül') ?></span>
        <span class="sys-sec-desc"><?= h(t('Élő beállítások, amelyek felülbírálják a config.php alapértelmezettjeit - újraindítás nélkül.')) ?></span>
    </summary>

    <div class="filter-hint" style="margin:16px 20px 4px">
        <?= t('Az itt módosított értékek a') ?> <code>/var/cache/quarantine-admin/settings.json</code> <?= t('fájlban tárolódnak és felülbírálják a') ?> <code>config.php</code> <?= t('alapértelmezettjeit - nem kell szerkeszteni a konfigurációs fájlt, és Apache / PHP-FPM újraindítás sem szükséges. Az') ?> <em><?= t('alapértelmezett') ?></em> <?= t('link visszaállítja az eredeti értéket.') ?>
    </div>

    <table class="msg-table" style="table-layout:fixed">
        <colgroup>
            <col style="width:36%">
            <col style="width:11%">
            <col style="width:24%">
            <col style="width:29%">
        </colgroup>
        <thead>
            <tr><th scope="col"><?= t('Beállítás') ?></th><th scope="col"><?= t('Érték') ?></th><th scope="col"><?= t('Módosítás') ?></th><th scope="col"></th></tr>
        </thead>
        <tbody>
        <?php
        $setting_help = [
            'per_page'          => t('Hány sor jelenjen meg oldalanként az összes listanézetben (spam-sor, archívum, audit).'),
            'user_cache_ttl'    => t('Meddig tárolódjon a felhasználólista a gyorsítótárban (mp). Lejárat után a doveadm-től frissül. Növelése csökkenti a terhelést, de lassítja az új postaládák megjelenését.'),
            'admin_session_gap' => t('Ennyi másodperc tétlenség után számít új belépési eseménynek az Apache access-naplóban az Audit → Belépések nézetben. (Az Apache Basic Auth minden kérésnél újraküldi a hitelesítési fejlécet, ezért az egymás utáni kérések összevonva jelennek meg.)'),
        ];
        foreach ($rules as $key => $r):
            $cur_val = constant($r['const']);
            $is_ovr  = isset($ovr[$key]);
        ?>
        <tr>
            <td>
                <strong><?= h($r['label']) ?></strong>
                <?php if ($is_ovr): ?>
                <span style="font-size:.7rem;background:var(--warning-light);color:var(--warning);
                             padding:1px 5px;border-radius:3px;margin-left:5px;vertical-align:middle"
                      title="A config.php alapértelmezettjét felülírja a settings.json"><?= t('felülírva') ?></span>
                <?php endif; ?>
                <div style="font-size:.78rem;color:var(--text-subtle);margin-top:3px;line-height:1.4">
                    <?= h($setting_help[$key] ?? '') ?>
                </div>
            </td>
            <td style="font-variant-numeric:tabular-nums;font-weight:600">
                <?= h((string)$cur_val) ?>
            </td>
            <td>
                <form method="post" action="?admin=1" style="display:flex;gap:5px;align-items:center">
                    <?= csrf_field() ?>
                    <input type="hidden" name="admin_action" value="save_setting">
                    <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                    <input type="hidden" name="setting_key"  value="<?= h($key) ?>">
                    <input type="number" name="setting_val" aria-label="<?= h(t('Érték')) ?>"
                           value="<?= h((string)$cur_val) ?>"
                           min="<?= $r['min'] ?>" max="<?= $r['max'] ?>"
                           style="width:85px;padding:4px 6px;border:1px solid var(--border);
                                  border-radius:var(--radius-sm);font-size:.875rem">
                    <button type="submit" class="btn btn-sm btn-secondary">Ment</button>
                </form>
            </td>
            <td style="font-size:.8rem;color:var(--text-subtle)">
                <?= $r['min'] ?>–<?= $r['max'] ?>
                <?php if ($is_ovr): ?>
                &nbsp;&middot;&nbsp;
                <form method="post" action="?admin=1" style="display:inline">
                    <?= csrf_field() ?>
                    <input type="hidden" name="admin_action" value="reset_setting">
                    <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                    <input type="hidden" name="setting_key"  value="<?= h($key) ?>">
                    <button type="submit"
                            style="background:none;border:none;padding:0;cursor:pointer;
                                   color:var(--danger);font-size:.8rem;text-decoration:underline">
                        <?= t('alapértelmezett') ?>
                    </button>
                </form>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</details>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- 3. Felhasználók és RBAC                                                    -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<details class="sys-sec results-card" id="users" style="margin-bottom:20px">
    <summary class="results-header">
        <h2><?= t('Felhasználók és szerepkörök') ?></h2>
        <span class="meta"><?= count($admin_users) ?> <?= t('kezelt felhasználó') ?></span>
        <span class="sys-sec-desc"><?= h(t('Konzol-felhasználók és szerepköreik (Admin, Operátor, Megfigyelő, Domain-admin) kezelése.')) ?></span>
    </summary>

    <div class="filter-hint" style="margin:16px 20px 4px">
        <?= t('A felhasználók az') ?> <strong>Apache Basic Auth</strong> <?= t('htpasswd fájljából hitelesítve lépnek be. A') ?> <strong><?= t('szerepkör') ?></strong> <?= t('határozza meg, mit láthatnak és mit tehetnek az alkalmazásban:') ?><br>
        <strong>Admin</strong> <?= t('- teljes hozzáférés, beleértve ezt az Admin lapot és a felhasználókezelést.') ?><br>
        <strong><?= t('Operátor') ?></strong> <?= t('- levél felszabadítás/törlés, rspamd tanítás, blokk-/fehérlista kezelés, archívum - Admin lap nélkül.') ?><br>
        <strong><?= t('Megfigyelő') ?></strong> <?= t('- csak olvasás: látja a spam-sort és az archívumot, de nem végezhet műveleteket.') ?><br>
        <strong>Domain-admin</strong> <?= t('- Operátor szintű jogok, de csak a saját tartomány(ok)ára szűrt nézetben.') ?><br>
        Ha a <code>roles.json</code> <?= t('még nem létezik (nincs felhasználó felvéve), mindenki Admin jogokkal rendelkezik - ez az eredeti állapot.') ?>
    </div>

    <?php if (!empty($admin_users)): ?>
    <table class="msg-table" style="table-layout:fixed">
        <colgroup>
            <col style="width:22%">
            <col style="width:22%">
            <col style="width:20%">
            <col style="width:20%">
            <col style="width:16%">
        </colgroup>
        <thead>
            <tr><th scope="col"><?= t('Felhasználó') ?></th><th scope="col"><?= t('Szerepkör') ?></th><th scope="col"><?= t('Tartomány(ok)') ?></th><th scope="col"><?= t('Jelszócsere') ?></th><th scope="col"></th></tr>
        </thead>
        <tbody>
        <?php foreach ($admin_users as $u):
            $is_self = $u['is_self'];
            $uname   = $u['username'];
        ?>
        <tr>
            <?php /* overflow-wrap:anywhere -- usernames run to 32 chars
                     (^[a-zA-Z0-9._-]{2,32}$) with no guaranteed break
                     opportunity, in a table-layout:fixed 22% column. Measured
                     bleed past the cell box: 161px at 768px for the 32-char
                     maximum, and 61.9px even for a realistic 25-char name;
                     contained at every width with this, and short names render
                     unchanged. Scoped to this cell, not the blanket
                     .list-table rule that was tried and reverted. */ ?>
            <td style="font-weight:600;overflow-wrap:anywhere">
                <?= h($uname) ?>
                <?php if ($is_self): ?>
                <span style="font-size:.7rem;background:var(--primary-light);color:var(--primary);
                             padding:1px 5px;border-radius:3px;margin-left:4px">te</span>
                <?php endif; ?>
            </td>
            <td>
                <form method="post" action="?admin=1" style="display:flex;gap:5px;align-items:center;flex-wrap:wrap">
                    <?= csrf_field() ?>
                    <input type="hidden" name="admin_action" value="user_set_role">
                    <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                    <input type="hidden" name="ur_username"  value="<?= h($uname) ?>">
                    <select name="ur_role" style="padding:3px 5px;border:1px solid var(--border);
                                                  border-radius:var(--radius-sm);font-size:.875rem"
                            onchange="this.closest('form').querySelector('.domain-row').style.display=
                                      this.value==='domain_admin'?'flex':'none'">
                        <?php foreach ($valid_roles as $rk => $rl): ?>
                        <option value="<?= $rk ?>" <?= $u['role'] === $rk ? 'selected' : '' ?>
                                <?= ($is_self && $rk !== 'admin') ? 'disabled' : '' ?>><?= $rl ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" class="btn btn-sm btn-secondary" <?= $is_self ? 'title="' . h(t('Saját szerepköröd nem változtatható meg')) . '"' : '' ?>>Ment</button>
                    <div class="domain-row" style="display:<?= $u['role'] === 'domain_admin' ? 'flex' : 'none' ?>;
                         gap:4px;width:100%;margin-top:4px;align-items:center">
                        <input type="text" name="ur_domains" aria-label="<?= h(t('Tartomány(ok)')) ?>"
                               value="<?= h(implode(', ', $u['domains'])) ?>"
                               placeholder="domain1.hu, domain2.hu"
                               style="flex:1;padding:3px 5px;border:1px solid var(--border);
                                      border-radius:var(--radius-sm);font-size:.8rem">
                    </div>
                </form>
            </td>
            <td style="font-size:.8rem;color:var(--text-muted)">
                <?= $u['domains'] ? h(implode(', ', $u['domains'])) : '-' ?>
            </td>
            <td>
                <details style="font-size:.875rem">
                    <summary style="cursor:pointer;color:var(--primary);user-select:none"><?= t('Jelszócsere') ?></summary>
                    <form method="post" action="?admin=1" style="margin-top:6px;display:flex;gap:4px">
                        <?= csrf_field() ?>
                        <input type="hidden" name="admin_action" value="user_set_password">
                        <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                        <input type="hidden" name="up_username"  value="<?= h($uname) ?>">
                        <input type="password" name="up_password" aria-label="<?= h(t('Jelszó')) ?>" placeholder="Új jelszó (min. 8 kar.)"
                               required minlength="8" autocomplete="new-password"
                               style="flex:1;padding:3px 5px;border:1px solid var(--border);
                                      border-radius:var(--radius-sm);font-size:.8rem">
                        <button type="submit" class="btn btn-sm btn-secondary">Ment</button>
                    </form>
                </details>
            </td>
            <td>
                <?php if (!$is_self): ?>
                <form method="post" action="?admin=1"
                      onsubmit="return confirm('<?= t('Törli') ?> <?= h(addslashes($uname)) ?> <?= t('felhasználót?') ?>')">
                    <?= csrf_field() ?>
                    <input type="hidden" name="admin_action" value="user_delete">
                    <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                    <input type="hidden" name="ud_username"  value="<?= h($uname) ?>">
                    <button type="submit" class="btn btn-sm btn-danger"><?= t('Töröl') ?></button>
                </form>
                <?php else: ?>
                <span style="font-size:.8rem;color:var(--text-subtle)">-</span>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php else: ?>
    <div class="empty-state">
        <p><?= t('Még nincs felhasználó kezelve (roles.json üres).') ?><br>
        <?= t('Amíg nincs legalább egy felhasználó felvéve, mindenki Admin jogokkal rendelkezik.') ?></p>
    </div>
    <?php endif; ?>

    <!-- ── Új felhasználó felvétele ── -->
    <div style="padding:16px 20px;border-top:1px solid var(--border);background:var(--neutral-light)">
        <h3 style="margin:0 0 12px;font-size:.9375rem"><?= t('Új felhasználó hozzáadása') ?></h3>
        <form method="post" action="?admin=1" id="addUserForm">
            <?= csrf_field() ?>
            <input type="hidden" name="admin_action" value="user_add">
            <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
            <div class="admin-add-user-row" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end">
                <div>
                    <label style="display:block;font-size:.8rem;color:var(--text-muted);margin-bottom:3px"><?= t('Felhasználónév') ?></label>
                    <input type="text" name="ua_username" aria-label="<?= h(t('Felhasználónév')) ?>" required
                           pattern="[a-zA-Z0-9._-]{2,32}" title="<?= h(t('2–32 karakter: betű, szám, . _ -')) ?>"
                           placeholder="pl. helpdesk"
                           style="width:140px;padding:5px 8px;border:1px solid var(--border);
                                  border-radius:var(--radius-sm);font-size:.875rem">
                </div>
                <div>
                    <label style="display:block;font-size:.8rem;color:var(--text-muted);margin-bottom:3px"><?= t('Jelszó') ?></label>
                    <input type="password" name="ua_password" aria-label="<?= h(t('Jelszó')) ?>" required minlength="8"
                           placeholder="min. 8 karakter" autocomplete="new-password"
                           style="width:160px;padding:5px 8px;border:1px solid var(--border);
                                  border-radius:var(--radius-sm);font-size:.875rem">
                </div>
                <div>
                    <label style="display:block;font-size:.8rem;color:var(--text-muted);margin-bottom:3px"><?= t('Szerepkör') ?></label>
                    <select name="ua_role" id="ua_role"
                            onchange="document.getElementById('ua_domains_wrap').style.display=
                                      this.value==='domain_admin'?'block':'none'"
                            style="padding:5px 8px;border:1px solid var(--border);
                                   border-radius:var(--radius-sm);font-size:.875rem">
                        <?php foreach ($valid_roles as $rk => $rl): ?>
                        <option value="<?= $rk ?>"><?= $rl ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div id="ua_domains_wrap" style="display:none">
                    <label style="display:block;font-size:.8rem;color:var(--text-muted);margin-bottom:3px">
                        <?= t('Tartomány(ok)') ?> <span style="font-weight:normal"><?= t('(vesszővel elválasztva)') ?></span>
                    </label>
                    <input type="text" name="ua_domains" aria-label="<?= h(t('Tartomány(ok)')) ?>" placeholder="pl. example.com, example.org"
                           style="width:220px;padding:5px 8px;border:1px solid var(--border);
                                  border-radius:var(--radius-sm);font-size:.875rem">
                </div>
                <div>
                    <button type="submit" class="btn btn-primary" style="padding:6px 16px">
                        <svg class="icon"><use href="#icon-plus"></use></svg> <?= t('Hozzáad') ?>
                    </button>
                </div>
            </div>
            <p style="margin:8px 0 0;font-size:.78rem;color:var(--text-subtle)">
                <?= t('A felhasználó azonnal bejelentkezhet. Az Apache Basic Auth hitelesíti (') ?><code>/etc/httpd/quarantine-admin.htpasswd</code><?= t('), a szerepkör a') ?>
                <code>roles.json</code> <?= t('fájlban tárolódik.') ?>
            </p>
        </form>
    </div>
</details>

