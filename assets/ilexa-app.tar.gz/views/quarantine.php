<?php
// Outcome banner for the release/delete just performed (see handle_post PRG).
$_op   = $_GET['op']   ?? '';
$_done = isset($_GET['done']) ? (int)$_GET['done'] : -1;
$_fail = isset($_GET['fail']) ? (int)$_GET['fail'] : 0;
?>
<h1 class="page-title"><?= h(t('Jelentett spam')) ?></h1>
<p class="filter-hint" style="margin-bottom:16px">
    <?= t('A felhasználók által') ?> <strong><?= t('spamnek jelölt levelek') ?></strong> (a <strong>Spam</strong>
    <?= t('mappák tartalma, felhasználónként) - ide a webmail "Kéretlennek jelölés" gombja, a Thunderbird‑ből a') ?> <strong>spam@</strong> <?= t('címre küldött jelentés, vagy a kézi áthelyezés teszi a levelet. A') ?> <strong><?= t('Felszabadít') ?></strong> <?= t('visszahelyezi a Beérkező levelek közé (és jó levélként tanítja az rspamd‑nek), a') ?> <strong><?= t('Törlés') ?></strong>
    <?= t('végleg törli (és spamként tanítja). A leveleket a rendszer') ?> <strong>14 nap</strong>
    <?= t('után automatikusan törli.') ?>
</p>
<?php if (in_array($_op, ['release', 'delete'], true) && $_done >= 0):
    $_verb = $_op === 'release' ? t('felszabadítva') : t('törölve');
    $_lrn  = $_op === 'release' ? t('ham-ként tanítva') : t('spam-ként tanítva');
?>
<div class="notice notice-<?= $_fail > 0 ? 'err' : 'ok' ?>">
    <?= $_fail > 0 ? '<svg class="icon"><use href="#icon-warning"></use></svg>' : '<svg class="icon"><use href="#icon-check"></use></svg>' ?>
    <?= h(sprintf(t('%d levél %s'), $_done, $_verb)) ?>
    <?php if ($_done > 0 && is_file(LEARN_FLAG)): ?>
        &middot; <?= h(sprintf(t('%d levél %s'), $_done, $_lrn)) ?>
    <?php endif; ?>
    <?php if ($_fail > 0): ?>
        &middot; <strong><?= h(sprintf(t('%d sikertelen'), $_fail)) ?></strong>
        <span style="font-weight:400">(<?= h(t('részletek: Audit → Spam műveletek')) ?>)</span>
    <?php endif; ?>
</div>
<?php endif; ?>
<p class="filter-hint" style="margin-bottom:16px">
    A <strong><?= t('Feladó') ?></strong> <?= t('és') ?> <strong><?= t('Tárgy') ?></strong> <?= t('mezők a megadott szövegrészletre szűrnek (kis/nagybetű nem számít). Üresen hagyva nincs szűrés.') ?>
</p>
<!-- ── Filter form ── -->
<div class="filter-card">
    <h2><?= t('Szűrők') ?></h2>
    <form method="get" action="">
        <input type="hidden" name="quar" value="1">
        <div class="filter-row">

            <div class="filter-group">
                <label for="f_domain">Domain</label>
                <select name="domain" id="f_domain" onchange="this.form.submit()">
                    <option value="" <?= $f_domain === '' ? 'selected' : '' ?>><?= t('- összes domain -') ?></option>
                    <?php foreach ($domains as $d): ?>
                    <option value="<?= h($d) ?>" <?= $f_domain === $d ? 'selected' : '' ?>>
                        <?= h($d) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="filter-group">
                <label for="f_user"><?= t('Felhasználó') ?></label>
                <select name="user" id="f_user">
                    <option value=""><?= t('- összes felhasználó -') ?></option>
                    <?php
                    $user_list = $f_domain ? $domain_users : ($f_user ? get_users() : []);
                    foreach ($user_list as $u): ?>
                    <option value="<?= h($u) ?>" <?= $f_user === $u ? 'selected' : '' ?>>
                        <?= h($u) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Folder filter retired: Spam is the only quarantine folder now. -->
            <input type="hidden" name="folder" value="Spam">

            <div class="filter-group">
                <label for="f_since"><?= t('Dátumtól') ?></label>
                <input type="date" name="since" id="f_since" value="<?= h($f_since) ?>">
            </div>

            <div class="filter-group">
                <label for="f_before"><?= t('Dátumig') ?></label>
                <input type="date" name="before" id="f_before" value="<?= h($f_before) ?>">
            </div>

            <div class="filter-group">
                <label for="f_from"><?= t('Feladó') ?></label>
                <input type="text" name="from" id="f_from" value="<?= h($f_from) ?>"
                       placeholder="név vagy e-mail…" autocomplete="off">
            </div>

            <div class="filter-group">
                <label for="f_subject"><?= t('Tárgy') ?></label>
                <input type="text" name="subject" id="f_subject" value="<?= h($f_subject) ?>"
                       placeholder="tárgy részlete…" autocomplete="off">
            </div>

            <div class="filter-group">
                <label>&nbsp;</label>
                <button type="submit" name="search" value="1" class="btn btn-primary">
                    <svg class="icon"><use href="#icon-search"></use></svg> <?= t('Keresés') ?>
                </button>
            </div>

            <div class="filter-group">
                <label>&nbsp;</label>
                <a href="?quar=1" class="btn btn-secondary" title="Minden szűrő visszaállítása alaphelyzetbe">
                    <svg class="icon"><use href="#icon-refresh"></use></svg> <?= t('Szűrők törlése') ?>
                </a>
            </div>

        </div>
    </form>
</div>

<!-- ── Results ── -->
<?php if ($do_search): ?>
<div class="results-card">
    <?php
    // Quick ranges: the same three windows get re-typed constantly.
    $_qr = function (int $days) use ($pfilters) {
        $q = $pfilters;
        $q['since']  = date('Y-m-d', strtotime("-$days days"));
        $q['before'] = '';
        $q['search'] = '1'; $q['quar'] = '1';
        return '?' . http_build_query(array_filter($q, fn($v) => $v !== '' && $v !== null));
    };
    $_qr_active = fn(int $d) => $f_since === date('Y-m-d', strtotime("-$d days")) && $f_before === '';
    ?>
    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:0 0 12px">
        <span style="font-size:.78rem;color:var(--text-subtle);font-weight:700;text-transform:uppercase;letter-spacing:.04em">
            <?= h(t('Gyors időszak')) ?>
        </span>
        <?php foreach ([1 => t('24 óra'), 7 => t('7 nap'), 30 => t('30 nap')] as $_d => $_lbl): ?>
        <a href="<?= h($_qr($_d)) ?>" class="btn btn-sm <?= $_qr_active($_d) ? 'btn-primary' : 'btn-secondary' ?>"><?= h($_lbl) ?></a>
        <?php endforeach; ?>
        <?php if (!empty($folder_counts)): ?>
        <span style="margin-left:auto;font-size:.8rem;color:var(--text-muted)">
            <?php foreach ($folder_counts as $_fn => $_fc): ?>
            <span style="margin-left:10px"><strong><?= h($_fn) ?></strong> <?= (int)$_fc ?></span>
            <?php endforeach; ?>
        </span>
        <?php endif; ?>
    </div>

    <div class="kb-help" id="kbHelp">
        <strong style="color:var(--text)"><?= h(t('Billentyűk')) ?></strong>
        <span><kbd>j</kbd>/<kbd>k</kbd> <?= h(t('sor')) ?></span>
        <span><kbd>o</kbd> <?= h(t('megnyitás')) ?></span>
        <span><kbd>r</kbd> <?= h(t('felszabadítás')) ?></span>
        <span><kbd>d</kbd> <?= h(t('törlés')) ?></span>
        <span><kbd>/</kbd> <?= h(t('keresés')) ?></span>
        <span><kbd>?</kbd> <?= h(t('elrejtés')) ?></span>
    </div>

    <div class="results-header">
        <h2>Jelentett spam</h2>
        <span class="meta">
            <?php if ($total > 0): ?>
                <?= (($page - 1) * $per_page) + 1 ?>&ndash;<?= min($page * $per_page, $total) ?> / <?= $total ?> <?= t('levél') ?>
            <?php else: ?>
                <?= t('0 levél') ?>
            <?php endif; ?>
            - <?= $search_time ?>s
            <?php if ($f_domain || $f_user): ?>
             - <?= h($f_user ?: ('*@' . $f_domain)) ?>
            <?php endif; ?>
        </span>
    </div>

    <?php if (!qa_view_allowed(false)): ?>
    <p class="filter-hint" style="padding:12px 16px 8px">
        <svg class="icon"><use href="#icon-lock"></use></svg>
        <?= h(t('A levelek tartalma nem nyitható meg: az adatvédelmi beállítás jelenleg letiltja. Adminisztrátor az Admin lapon módosíthatja.')) ?>
    </p>
    <?php endif; ?>

    <?php
    $chips = [];
    if ($f_domain)           $chips[] = 'Domain: ' . h($f_domain);
    if ($f_user)             $chips[] = t('Felhasználó: ') . h($f_user);
    if ($f_from !== '')      $chips[] = t('Feladó ⊇ "') . h($f_from) . '"';
    if ($f_subject !== '')   $chips[] = t('Tárgy ⊇ "') . h($f_subject) . '"';
    $chips[] = t('Időszak') . ': ' . h($f_since ?: '-') . ' – ' . h($f_before ?: t('ma'));
    ?>
    <div class="active-filters">
        <span class="af-label"><?= t('Aktív szűrők:') ?></span>
        <?php foreach ($chips as $c): ?><span class="chip"><?= $c ?></span><?php endforeach; ?>
        <a href="?quar=1" class="chip chip-clear" title="Alaphelyzet"><svg class="icon"><use href="#icon-refresh"></use></svg> <?= t('Szűrők törlése') ?></a>
    </div>

    <?php if (empty($results)): ?>
    <div class="empty-state">
        <div style="font-size:2em"><svg class="icon"><use href="#icon-calendar"></use></svg></div>
        <p><?= t('Nincs jelentett spam a megadott feltételekkel.') ?></p>
        <?php if ($f_from !== '' || $f_subject !== ''): ?>
        <p style="margin-top:4px"><?= t('Próbálja tágabb feladó-/tárgyszűrővel vagy hosszabb időszakkal.') ?></p>
        <?php endif; ?>
    </div>

    <?php else: ?>
    <form method="post" action="">
        <?= csrf_field() ?>
        <?= $filter_hidden ?>

        <?php if (can('action')): ?>
        <div class="bulk-bar">
            <input type="checkbox" id="chk_all" title="Összes kijelölése"
                   onchange="document.querySelectorAll('input.row-chk').forEach(c=>c.checked=this.checked)">
            <label for="chk_all"><?= t('Összes kijelölése') ?></label>
            <input type="hidden" name="action" value="bulk">
            <button type="submit" name="bulk_action" value="release" class="btn btn-success btn-sm">
                <svg class="icon"><use href="#icon-play"></use></svg> <?= t('Kijelöltek visszahelyezése') ?>
            </button>
            <button type="submit" name="bulk_action" value="delete" class="btn btn-danger btn-sm"
                    onclick="return confirm('<?= t('Törli a kijelölt leveleket?') ?>')">
                <svg class="icon"><use href="#icon-x"></use></svg> <?= t('Kijelöltek törlése') ?>
            </button>
        </div>
        <?php endif; ?>

        <?php
            $qcur = ['date'=>'date','user'=>'user','from'=>'from','subject'=>'subject'][$_GET['qsort'] ?? ''] ?? 'date';
            $qdirc = strtoupper($_GET['qdir'] ?? '') === 'ASC' ? 'ASC' : 'DESC';
            $qsortth = function (string $col, string $label) use ($pfilters, $page, $qcur, $qdirc) {
                $next = ($qcur === $col && $qdirc === 'ASC') ? 'DESC' : 'ASC';
                $ind  = $qcur === $col ? ($qdirc === 'ASC' ? ' <svg class="icon icon-rot-270"><use href="#icon-chevron"></use></svg>' : ' <svg class="icon icon-rot-90"><use href="#icon-chevron"></use></svg>') : '';
                $url  = '?' . http_build_query(array_filter([
                    'quar'=>'1','search'=>'1',
                    'domain'=>$pfilters['domain'],'user'=>$pfilters['user'],'folder'=>$pfilters['folder'],
                    'since'=>$pfilters['since'],'before'=>$pfilters['before'],'from'=>$pfilters['from'],'subject'=>$pfilters['subject'],
                    'qsort'=>$col,'qdir'=>$next,'page'=>$page,
                ]));
                return '<a class="sort-th' . ($qcur === $col ? ' active' : '') . '" href="' . h($url) . '">' . $label . $ind . '</a>';
            };
            // Same four sprite symbols the IOC/Block-Whitelist pages use, so
            // this page's badges read as one family with theirs. Shared via
            // QA_VERDICT_ICON (src/ioc_lookup.php) with those pages.
        ?>
<?php if (can('lists')): ?><div style="overflow-x:auto"><?php endif; ?>
        <table<?= can('lists') ? ' class="quar-table"' : '' ?>>
            <thead>
                <tr>
                    <th scope="col"></th>
                    <th scope="col"><?= $qsortth('user', t('Felhasználó')) ?></th>
                    <th scope="col">Mappa</th>
                    <th scope="col"><?= $qsortth('from', t('Feladó')) ?></th>
                    <th scope="col"><?= $qsortth('subject', t('Tárgy')) ?> <small style="font-weight:normal;opacity:.7"><?= t('(kattintson a megtekintéshez)') ?></small></th>
                    <th scope="col"><?= $qsortth('date', t('Érkezett')) ?></th>
<?php if (can('lists')): ?>
                    <th scope="col" class="col-quar-conf" style="white-space:normal;overflow-wrap:anywhere"><?= t('Összesített %') ?></th>
                    <th scope="col" class="col-quar-rep"><?= t('Hírnév') ?></th>
<?php endif; ?>
                    <?php if (can('action')): ?><th scope="col"><?= t('Műveletek') ?></th><?php endif; ?>
                </tr>
            </thead>
            <tbody>
            <?php $ri = 0; foreach ($page_results as $msg): $ri++;
                $uid     = $msg['uid']           ?? '';
                $user    = $msg['user']          ?? '';
                $folder  = $msg['folder']        ?? '';
                $from    = decode_subject($msg['hdr_from'] ?? '');
                $subject = decode_subject($msg['hdr_subject'] ?? t('(nincs tárgy)'));
                $date    = $msg['date_received'] ?? '';
                $date_ts = $date ? (int)strtotime($date) : 0;
                $item_id = h($user . '|' . $folder . '|' . $uid);
                $row_key = h($user . '__' . $folder . '__' . $uid);

                // $from_name is purely cosmetic (the label shown above the
                // address). $from_email is the address itself -- shown,
                // used for the block-sender action, and (via
                // qa_last_angle_addr(), the SAME rule quar_row_indicators()
                // uses to pick what gets domain-graded) must name the same
                // address the reputation badge next to it is judging.
                $from_name  = '';
                $from_email = qa_last_angle_addr($from);
                if (preg_match('/^"?([^"<]+)"?\s*<([^>]+)>/', $from, $fm)) {
                    $from_name = trim($fm[1], ' "');
                }
            ?>
                <tr class="data-row<?= $ri % 2 === 0 ? ' alt' : '' ?> f-<?= h($folder) ?>" id="row-<?= $row_key ?>">
                    <td class="col-check" data-label="Kijelöl">
                        <input type="checkbox" class="row-chk" name="items[]" value="<?= $item_id ?>">
                    </td>
                    <td class="col-user" data-label="Felhasználó"><?= h($user) ?></td>
                    <td class="col-folder" data-label="Mappa">
                        <span class="folder-tag folder-<?= h($folder) ?>"><?= h($folder) ?></span>
                    </td>
                    <td class="col-from" data-label="Feladó">
                        <?php if ($from_name): ?>
                        <div class="from-name"><?= hl($from_name, $f_from) ?></div>
                        <div class="from-email"><?= hl($from_email, $f_from) ?></div>
                        <?php else: ?>
                        <div><?= hl($from_email, $f_from) ?></div>
                        <?php endif; ?>
                    </td>
                    <?php if (qa_view_allowed(false)): ?>
                    <td class="col-subject subject-link" data-label="Tárgy"
                        data-user="<?= h($user) ?>"
                        data-folder="<?= h($folder) ?>"
                        data-uid="<?= h($uid) ?>"
                        onclick="toggleDetail(this)">
                        <span class="subject-arrow" id="arr-<?= $row_key ?>"><svg class="icon"><use href="#icon-chevron"></use></svg></span><?= hl($subject, $f_subject) ?>
                    </td>
                    <?php else: ?>
                    <td class="col-subject" data-label="Tárgy"><?= hl($subject, $f_subject) ?></td>
                    <?php endif; ?>
                    <td class="col-date local-ts" data-label="Érkezett" data-ts="<?= $date_ts ?>"><?= h($date) ?></td>
<?php if (can('lists')):
                        // Reused wholesale from src/quar_lookup.php (Task 5) --
                        // the handler derives indicators the exact same way, so
                        // this render and what a click actually checks can never
                        // disagree.
                        $q_ind = quar_row_indicators($msg);

                        // Filtered at the assignment (not just at
                        // ioc_lookup_confidence() below), same reasoning as
                        // views/lists.php:122-130: filtering only at the
                        // confidence call produces "4 icons, % from 3", and
                        // skipping the filter entirely makes a since-disabled
                        // service's stale icon render then vanish on the next
                        // check.
                        $q_dom_cached = $q_ind['domain'] !== null
                            ? array_intersect_key(list_lookup_cached('domain', $q_ind['domain']),
                                                   array_flip(ioc_lookup_services_for('domain', 'quarantine')))
                            : [];
                        $q_ip_cached  = $q_ind['ip'] !== null
                            ? array_intersect_key(list_lookup_cached('ip', $q_ind['ip']),
                                                   array_flip(ioc_lookup_services_for('ip', 'quarantine')))
                            : [];
                        $q_dom_conf = $q_dom_cached ? ioc_lookup_confidence($q_dom_cached) : null;
                        $q_ip_conf  = $q_ip_cached  ? ioc_lookup_confidence($q_ip_cached)  : null;

                        // Higher of the two wins the displayed tier; both values
                        // still named in the title so neither is hidden.
                        $q_best = $q_dom_conf;
                        if ($q_ip_conf !== null && ($q_best === null || $q_ip_conf['pct'] > $q_best['pct'])) {
                            $q_best = $q_ip_conf;
                        }
                        $q_pct_str = fn(?array $c) => $c !== null ? $c['pct'] . '%' : '—';
                        $q_conf_title = sprintf(
                            t('Domain: %1$s · IP: %2$s'),
                            $q_pct_str($q_dom_conf), $q_pct_str($q_ip_conf)
                        );

                        $q_has_indicator = $q_ind['domain'] !== null || $q_ind['ip'] !== null;
                    ?>
                    <td class="col-quar-conf" data-label="<?= t('Összesített %') ?>" id="quar-conf-<?= $row_key ?>">
                        <?php if ($q_best !== null): ?>
                        <span class="conf-<?= h($q_best['tier']) ?>" title="<?= h($q_conf_title) ?>"><?= (int)$q_best['pct'] ?>%</span>
                        <?php endif; ?>
                    </td>
                    <td class="col-quar-rep" data-label="<?= t('Hírnév') ?>" id="quar-rep-<?= $row_key ?>">
                        <?php if (!$q_has_indicator):
                            // Both indicators absent: fold in WHY when it's a
                            // deliberate skip (local domain / no public IP)
                            // rather than plain absence, otherwise fall back to
                            // the same generic message the POST handler itself
                            // uses for "nothing checkable" (src/quar_lookup.php).
                            $q_notes = array_filter([
                                $q_ind['skip']['domain'] === 'local'
                                    ? t('A feladó domainje ezen a szerveren van, ezért a hírnév-ellenőrzés nem értelmezhető rá.') : null,
                                $q_ind['skip']['ip'] === 'private'
                                    ? t('Nincs nyilvános feladó IP-cím (belső hálózat vagy hitelesített küldés).') : null,
                            ]);
                            $q_dash_title = $q_notes ? implode(' ', $q_notes) : t('Ehhez a levélhez nincs ellenőrizhető adat.');
                        ?>
                        <span style="color:var(--text-subtle)" title="<?= h($q_dash_title) ?>">—</span>
                        <?php else: ?>
                            <!-- Wrapper so the tags/icons/button can wrap onto their
                                 own lines on mobile instead of overflowing the row
                                 card -- tr.data-row td is a nowrap flex container at
                                 the 720px breakpoint (layout_head.php), and without
                                 this wrapper 3+ cached verdicts push the button off
                                 the visible edge. Same pattern .col-actions already
                                 uses for .action-btns. Mirrored exactly in
                                 applyQuarLookupResult() (views/layout_foot.php) so
                                 the server-rendered and AJAX-repainted shapes match. -->
                            <div class="quar-rep-badges">
                            <?php if ($q_ind['domain'] !== null): ?>
                            <div class="quar-rep-label"><?= h(t('Domain')) ?></div>
                            <div class="quar-rep-syms">
                            <?php foreach ($q_dom_cached as $q_svc => $q_lk):
                                $q_detail_prefix = $q_lk['detail'] !== '' ? $q_lk['detail'] . ' — ' : '';
                                $q_title = t('Domain') . ' — ' . $q_svc . ' — ' . $q_lk['verdict'] . ' — ' . $q_detail_prefix . date('Y-m-d H:i', (int)$q_lk['checked_at']);
                                $q_icon  = QA_VERDICT_ICON[$q_lk['verdict']] ?? 'icon-info';
                            ?>
                            <span class="verdict verdict-<?= h($q_lk['verdict']) ?>" title="<?= h($q_title) ?>" aria-label="<?= h($q_svc . ': ' . $q_lk['verdict']) ?>"><svg class="icon"><use href="#<?= h($q_icon) ?>"></use></svg></span>
                            <?php endforeach; ?>
                            </div>
                            <?php endif; ?>
                            <?php if ($q_ind['ip'] !== null): ?>
                            <div class="quar-rep-label"><?= h(t('IP-cím')) ?></div>
                            <div class="quar-rep-syms">
                            <?php foreach ($q_ip_cached as $q_svc => $q_lk):
                                $q_detail_prefix = $q_lk['detail'] !== '' ? $q_lk['detail'] . ' — ' : '';
                                $q_title = 'IP — ' . $q_svc . ' — ' . $q_lk['verdict'] . ' — ' . $q_detail_prefix . date('Y-m-d H:i', (int)$q_lk['checked_at']);
                                $q_icon  = QA_VERDICT_ICON[$q_lk['verdict']] ?? 'icon-info';
                            ?>
                            <span class="verdict verdict-<?= h($q_lk['verdict']) ?>" title="<?= h($q_title) ?>" aria-label="<?= h($q_svc . ': ' . $q_lk['verdict']) ?>"><svg class="icon"><use href="#<?= h($q_icon) ?>"></use></svg></span>
                            <?php endforeach; ?>
                            </div>
                            <?php endif; ?>
                            <div class="quar-rep-act">
                            <button type="button" class="quar-lookup-btn btn btn-sm btn-secondary"
                                    data-row-id="<?= $row_key ?>"
                                    data-user="<?= h($user) ?>"
                                    data-folder="<?= h($folder) ?>"
                                    data-uid="<?= h($uid) ?>">
                                <svg class="icon"><use href="#icon-search"></use></svg> <?= t('Ellenőrzés') ?>
                            </button>
                            </div>
                            </div>
                        <?php endif; ?>
                    </td>
<?php endif; ?>
                    <?php if (can('action')): ?>
                    <td class="col-actions" data-label="Műveletek">
                        <div class="action-btns">
                            <button type="submit"
                                    name="action" value="release"
                                    class="btn btn-success btn-sm"
                                    title="<?= h(t('Visszahelyezés Beérkező levelekbe')) ?>"
                                    formnovalidate
                                    onclick="
                                        if (!confirmRelease(this)) return false;
                                        document.querySelector('[name=msg_user]').value='<?= h($user) ?>';
                                        document.querySelector('[name=msg_folder]').value='<?= h($folder) ?>';
                                        document.querySelector('[name=msg_uid]').value='<?= h($uid) ?>';
                                    "
                                    data-rel-to="<?= h($user) ?>"
                                    data-rel-from="<?= h($from) ?>"
                                    data-rel-subj="<?= h($subject) ?>">
                                <svg class="icon"><use href="#icon-play"></use></svg> <?= t('Felszabadít') ?>
                            </button>
                            <button type="submit"
                                    name="action" value="delete"
                                    class="btn btn-danger btn-sm"
                                    title="Törlés"
                                    formnovalidate
                                    onclick="
                                        if(!confirm('<?= t('Törli ezt a levelet?') ?>')) return false;
                                        document.querySelector('[name=msg_user]').value='<?= h($user) ?>';
                                        document.querySelector('[name=msg_folder]').value='<?= h($folder) ?>';
                                        document.querySelector('[name=msg_uid]').value='<?= h($uid) ?>';
                                    ">
                                <svg class="icon"><use href="#icon-x"></use></svg>
                            </button>
                            <button type="submit"
                                    name="action" value="quick_block"
                                    class="btn btn-secondary btn-sm"
                                    title="Feladó tiltása (blokklista)"
                                    formnovalidate
                                    data-sender="<?= h($from_email) ?>"
                                    onclick="
                                        var s = this.dataset.sender;
                                        if (!confirm('<?= t('Blokklistára teszed a feladót?') ?>\n' + s)) return false;
                                        document.querySelector('[name=sender]').value = s;
                                    ">
                                <svg class="icon"><use href="#icon-block"></use></svg>
                            </button>
                        </div>
                    </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
<?php if (can('lists')): ?>
        </div>
        <div class="filter-hint" style="margin:12px 20px 4px">
<?php
            $q_legend_labels = ['malicious' => t('kártékony'), 'suspicious' => t('gyanús'), 'clean' => t('tiszta'), 'unknown' => t('ismeretlen')];
            $q_legend_i = 0; $q_legend_n = count(QA_VERDICT_ICON);
            foreach (QA_VERDICT_ICON as $q_legend_v => $q_legend_ic) {
                $q_legend_i++;
                // ?? $q_legend_v: a verdict added to QA_VERDICT_ICON without a
                // matching entry here labels itself instead of emitting
                // "Undefined array key" and rendering blank -- see the
                // co-dependency note on QA_VERDICT_ICON (src/ioc_lookup.php).
                echo '            <span class="verdict verdict-' . $q_legend_v . '" style="font-size:1.3em"><svg class="icon"><use href="#' . $q_legend_ic . '"></use></svg></span> ' . ($q_legend_labels[$q_legend_v] ?? $q_legend_v);
                // The leading spaces and trailing \n below are byte-significant:
                // PHP's closing tag above swallows one newline, so this literal
                // reproduces the pre-refactor template's exact output bytes.
                // Do not "tidy" this string without re-checking that fact.
                if ($q_legend_i < $q_legend_n) echo "            &nbsp;·&nbsp;\n";
            }
?>
            <br><?= t('Üres Hírnév oszlop = még nincs ellenőrizve. Vigye az egeret egy ikon fölé a szolgáltatás nevéért és a részletekért.') ?>
            <br><?= t('A "D" a feladó domainjének, az "IP" a kapcsolódási IP-címnek a hírnevét jelöli.') ?>
            <div style="margin-top:6px">
                <?= h(t('Az url.vet nem hírnév-adatbázis: a domain szerkezetét elemzi (kor, ismertség, márkanév-utánzás), ezért az összesített százalékba nem számít bele. Lassabb domainek esetén kimaradhat.')) ?>
            </div>
        </div>
<?php endif; ?>

        <!-- Hidden fields for single-row actions -->
        <input type="hidden" name="msg_user"   value="">
        <input type="hidden" name="msg_folder" value="">
        <input type="hidden" name="msg_uid"    value="">
        <input type="hidden" name="sender"     value="">
    </form>

    <div class="results-footer">
        <?= render_pager($page, $total_pages, fn(int $p) => page_url($p, $pfilters)) ?>
        <a href="<?= page_url(1, $pfilters) ?>" class="btn btn-primary"><svg class="icon"><use href="#icon-search"></use></svg> <?= t('Új keresés') ?></a>
    </div>

    <?php endif; ?>
</div>
<?php else: ?>
<div class="results-card">
    <div class="empty-state">
        <div style="font-size:2em"><svg class="icon"><use href="#icon-lock"></use></svg></div>
        <p><?= t('Válasszon szűrőket, majd kattintson a') ?> <strong><?= t('Keresés') ?></strong> gombra.</p>
    </div>
</div>
<?php endif; ?>
