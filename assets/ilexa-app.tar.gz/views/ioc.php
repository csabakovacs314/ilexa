<?php
// IOC (indicator-of-compromise) tab: search/list/add/expire, plus (Task 7)
// the extracted-candidate review screen. Reached only when can('admin').

$ioc_msg = $_GET['msg'] ?? '';
$ioc_err = h(urldecode($_GET['err'] ?? ''));
$ioc_notices = [
    'ioc_saved'     => ['ok',  t('Indikátor elmentve.')],
    'ioc_err'       => ['err', t('Mentés sikertelen: ') . $ioc_err],
    'ioc_expired'   => ['ok',  t('Indikátor lejáratva.')],
    'ioc_confirmed' => ['ok',  t('Kijelölt indikátorok elmentve.')],
    'ioc_none'      => ['ok',  t('Nem lett indikátor kiválasztva.')],
    'ioc_extract_err' => ['err', t('Nem sikerült feldolgozni az üzenetet indikátor-kinyeréshez.')],
    'ioc_lookup_ok'  => ['ok',  t('Ellenőrzés lefutott.')],
    'ioc_lookup_err' => ['err', t('Az ellenőrzés sikertelen volt minden szolgáltatásnál.')],
    'ioc_promote_ok'     => ['ok',  t('Indikátor élesítve.')],
    'ioc_promote_err'    => ['err', t('Élesítés sikertelen: ') . $ioc_err],
    'ioc_unpromote_ok'   => ['ok',  t('Élesítés visszavonva.')],
    'ioc_unpromote_err'  => ['err', t('Visszavonás sikertelen: ') . $ioc_err],
];
?>
<h1 class="page-title"><?= h(t('IOC')) ?></h1>
<?php if (isset($ioc_notices[$ioc_msg])):
    [$ioc_cls, $ioc_text] = $ioc_notices[$ioc_msg];
?>
<div class="notice notice-<?= h($ioc_cls) ?>"><?= $ioc_text ?></div>
<?php endif; ?>

<div class="filter-hint" style="margin-bottom:16px">
    <p style="margin:0 0 8px"><?= h(t('Az IOC (indicator of compromise) fenyegetéshez köthető technikai azonosító: IP-cím, domain, URL, e-mail vagy fájl-hash. A tételek archivált levélből kinyerve és jóváhagyva (quarantine-confirm), a Kampányok lapról egy kattintással (campaign), a Rendszer lapon tömeges hash-importból (bulk-import), vagy kézzel (manual) kerülnek a listába.')) ?></p>
    <p style="margin:0"><?= h(t('A "Megbízhatóság" a felvevő által megadott érték (low/medium/high), nem mérés eredménye. Az "Összesített %" ezzel szemben számított: a hírnév-szolgáltatások (VirusTotal, Mailspike, URLhaus, OTX, HRBL) eredményeiből áll elő, súlyozva — az url.vet ebbe szándékosan nem számít bele, mert az nem hírnév-adatbázis, hanem a domain szerkezetét elemzi (kor, ismertség, márkanév-utánzás), és külön oszlopban jelenik meg. Az "Ellenőrzés" lefuttatja az engedélyezett szolgáltatásokat (az eredmény 24 óráig gyorsítótárazott; a szolgáltatások a Rendszer lapon kapcsolhatók be). Az "Élesítés" éles blokkolást hoz létre: IP-cím esetén az IP a blokklistára kerül (SMTP-szintű elutasítás), domain/URL esetén az adott hosztra mutató hivatkozást tartalmazó levél kerül elutasításra — URL-nél csak a host számít, az útvonal figyelmen kívül marad, így az adott hoszthoz mutató összes hivatkozás blokkolódik. A "Lejáratás" deaktiválja az indikátort, megszünteti az élesítést, és a tétel eltűnik a listáról.')) ?></p>
</div>

<?php require __DIR__ . '/ioc_review.php'; ?>

<?php
$ioc_prefill_type  = $_GET['ioc_prefill_type']  ?? '';
$ioc_prefill_value = $_GET['ioc_prefill_value'] ?? '';
?>
<div class="results-card" style="margin-bottom:20px">
    <div class="results-header"><h2><?= t('Indikátor hozzáadása') ?></h2></div>
    <form method="post" action="?ioc=1" style="display:flex;gap:8px;align-items:flex-end;flex-wrap:wrap;padding:14px 20px">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="ioc_add">
        <div>
            <label style="display:block;font-size:.75rem;color:var(--text-subtle)"><?= t('Típus') ?></label>
            <select name="ioc_type" style="padding:5px">
                <?php foreach (IOC_TYPES as $ty): ?>
                <option value="<?= h($ty) ?>" <?= $ty === $ioc_prefill_type ? 'selected' : '' ?>><?= h($ty) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div style="flex:1;min-width:200px">
            <label style="display:block;font-size:.75rem;color:var(--text-subtle)"><?= t('Érték') ?></label>
            <input type="text" name="ioc_value" required style="width:100%;padding:5px" value="<?= h($ioc_prefill_value) ?>">
        </div>
        <div>
            <label style="display:block;font-size:.75rem;color:var(--text-subtle)"><?= t('Megbízhatóság') ?></label>
            <select name="ioc_confidence" style="padding:5px">
                <?php foreach (IOC_CONFIDENCE_LEVELS as $cf): ?>
                <option value="<?= h($cf) ?>" <?= $cf === 'medium' ? 'selected' : '' ?>><?= h($cf) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div>
            <label style="display:block;font-size:.75rem;color:var(--text-subtle)"><?= t('Lejárat (nap, üres = soha)') ?></label>
            <input type="number" name="ioc_expires_days" min="1" style="width:90px;padding:5px">
        </div>
        <button type="submit" class="btn btn-sm btn-primary"><?= t('Hozzáadás') ?></button>
    </form>
</div>

<?php
$ioc_f_type   = $_GET['ity'] ?? '';
$ioc_f_source = trim((string)($_GET['isrc'] ?? ''));
$ioc_f_tag    = trim((string)($_GET['itag'] ?? ''));
$ioc_f_q      = trim((string)($_GET['iq']   ?? ''));
$ioc_page     = max(1, (int)($_GET['ip'] ?? 1));
[$ioc_rows, $ioc_total] = ioc_list(array_filter([
    'type' => $ioc_f_type, 'source' => $ioc_f_source, 'tag' => $ioc_f_tag, 'q' => $ioc_f_q,
]), $ioc_page, QA_PER_PAGE_IOC);
$ioc_pages = max(1, (int) ceil($ioc_total / QA_PER_PAGE_IOC));
$ioc_url   = fn(int $p): string => '?' . http_build_query(array_filter([
    'ioc' => 1, 'ity' => $ioc_f_type, 'isrc' => $ioc_f_source, 'itag' => $ioc_f_tag,
    'iq' => $ioc_f_q, 'ip' => $p,
]));
$ioc_blocked_ips = [];
foreach (list_load('block') as $e) {
    if (!empty($e['ip'])) $ioc_blocked_ips[$e['ip']] = true;
}
?>
<div class="results-card">
    <div class="results-header"><h2><?= t('Indikátorok') ?></h2></div>
    <form method="get" action="?ioc=1" style="display:flex;gap:8px;align-items:center;padding:12px 20px;flex-wrap:wrap">
        <input type="hidden" name="ioc" value="1">
        <select name="ity" style="padding:5px">
            <option value=""><?= t('Minden típus') ?></option>
            <?php foreach (IOC_TYPES as $ty): ?>
            <option value="<?= h($ty) ?>" <?= $ioc_f_type === $ty ? 'selected' : '' ?>><?= h($ty) ?></option>
            <?php endforeach; ?>
        </select>
        <input type="text" name="isrc" value="<?= h($ioc_f_source) ?>" placeholder="<?= h(t('forrás')) ?>" style="padding:5px">
        <input type="text" name="iq"   value="<?= h($ioc_f_q) ?>"   placeholder="<?= h(t('keresés (érték/megjegyzés)')) ?>" style="padding:5px;flex:1;min-width:160px">
        <button type="submit" class="btn btn-sm btn-primary"><?= t('Szűrés') ?></button>
    </form>
    <?php if (empty($ioc_rows)): ?>
    <div class="empty-state"><p><?= t('Nincs a szűrésnek megfelelő indikátor.') ?></p></div>
    <?php else: ?>
    <?php
    $_il_label = ['virustotal' => 'VirusTotal', 'urlhaus' => 'URLhaus', 'otx' => 'OTX', 'hrbl' => 'HRBL', 'mailspike' => 'Mailspike', 'urlvet' => 'url.vet', 'yaraify' => 'YARAify', 'threatfox' => 'ThreatFox'];
    // Service columns are only ~5% wide (they hold a single icon), so these
    // one-word headers must wrap. Without an explicit break opportunity,
    // overflow-wrap:anywhere splits them at arbitrary points ("VirusT/otal").
    // <wbr> puts the break at each name's own camel-case/compound seam.
    // Hardcoded literals, never user input -- safe to emit unescaped.
    $_il_header = ['virustotal' => 'Virus<wbr>Total', 'urlhaus' => 'URL<wbr>haus', 'mailspike' => 'Mail<wbr>spike', 'urlvet' => 'url.vet', 'yaraify' => 'YARAify', 'threatfox' => 'Threat<wbr>Fox'];
    // Per-service verdict cells render an icon, not the verdict word: an icon
    // stays correct across both shipped UI languages (hu/en), where a
    // text badge like "SUSPICIOUS"/"VERDÄCHTIG" would not (illustrative --
    // German isn't a shipped language; the point is the technique is robust
    // to a translated word's length in general). See
    // docs/superpowers/notes/2026-08-13-ioc-table-fit-fix.md.
    $ioc_enabled_svcs = array_values(array_filter(array_keys($_il_label), 'ioc_lookup_service_enabled'));
    $ioc_svc_count = count($ioc_enabled_svcs);
    // Fixed columns for the real ~1018-1298px card (Típus 7, Forrás 8,
    // Megbízhatóság 14, Összesített % 8, Utoljára látva 9, Művelet 14 = 60),
    // measured empirically across the 4 UI languages shipped at the time
    // (hu/en/de/es; only hu/en ship now, but the German-driven floor below
    // is still the binding constraint) and against
    // stricter per-column legibility criteria, not just "doesn't overflow"
    // (see docs/superpowers/notes/2026-08-13-ioc-table-fit-fix.md):
    // - Megbízhatóság/Művelet stay at their German-driven 14% floor --
    //   "Vertrauenswürdigkeit" is one unbreakable 20-char word, and (before
    //   the promoted-badge/revoke-button layout was stacked) "Aktiv
    //   Widerrufen" was the single widest thing in Művelet. Unaffected by
    //   the icon change below.
    // - Típus must render every value ("domain"/"hash"/"ip"/"url"/"email")
    //   on exactly ONE line, not just avoid overflowing via a mid-word
    //   break; 5% failed this ("domain" split into 2 lines), 7% passes.
    // - Utoljára látva must render "YYYY-MM-DD HH:MM" in at most 2 lines
    //   (breaking at the space, not further); 7-8% still forced a 3rd line
    //   at the tightest (1280px) viewport, 9% is the measured floor.
    // - The 5 per-service columns render an ICON, not the verdict word (an
    //   icon stays correct across both shipped languages, hu/en, where a
    //   text badge wouldn't).
    //   That icon is only ~30px, so these columns can go much narrower than
    //   before -- down to 5% each (25% total), with the service-name header
    //   ("VirusTotal", "Mailspike") explicitly ALLOWED to wrap onto a 2nd
    //   line at any point (not just a natural boundary), since there's no
    //   badge word competing for the space anymore. Only a 3rd line (a
    //   genuinely fragmented header) is disallowed.
    // Érték and the service budget split the remainder (40) between them:
    // the budget takes what it needs to hold the per-service floor and
    // Érték gets the rest. With 0 services the budget is 0 and Érték takes
    // the whole 40.
    // The service budget GROWS to hold the 5% per-column floor described
    // above rather than staying pinned at 25: at 6 services a fixed 25
    // would give intdiv(25,6) = 4% each, below the measured floor, and the
    // headers would wrap to a disallowed 3rd line. Érték gives up the
    // difference, which it can afford (monospace + word-break:break-all).
    // At 5 services this is arithmetically identical to the previous fixed
    // 25/15 split, so the current layout is unchanged.
    // NOTE: 8 services exist today (this NOTE previously said 6 and was
    // already stale before threatfox was added -- yaraify had pushed it to 7
    // without an update). At 8 enabled simultaneously the budget hits its
    // 5*8=40 ceiling and Érték drops to 12%, tighter than the 17% this NOTE
    // was originally warning about but not yet at the 5% floor the warning
    // describes -- still an accepted squeeze (monospace + break-all), not a
    // redesign. In practice $ioc_enabled_svcs is rarely all 8 at once (most
    // installs run a subset), so re-verify against the real enabled count
    // before assuming this is fine at whatever count comes next.
    // Megbízhatóság dropped 14% -> 8% when its cell became an ICON (see
    // QA_IOC_CONFIDENCE_ICON): the 14% floor existed to hold the German word
    // "Vertrauenswürdigkeit" plus a text VALUE in the cell. With the value gone
    // the column only has to hold its own header, and the measured floor for
    // "Megbízhatóság" compacted is ~122px on ONE line / ~69px on two. 8% is
    // 81-104px across the real 1018-1298px card, i.e. a 2-line header, which is
    // what the service columns already do and what this table permits (3 lines
    // is the disallowed case). The freed 6% goes to Érték, which is the column
    // that actually holds long unbreakable strings.
    // Típus and Forrás became icon cells too, so their widths now only have to
    // hold their own (short) headers rather than the longest value word:
    // Típus 7->5, Forrás 8->6. Forrás keeps the extra point because an unmapped
    // free-text source still falls back to a word there (Típus cannot -- its set
    // is closed). "Összesített %" shrank to the single character "%" (the full
    // phrase moved to the header's title), so 8->5.
    // Every point freed goes to Érték, which holds long unbreakable indicator
    // strings and is the only column that genuinely wants more room: 16 -> 23,
    // up from 10 before this pair of changes.
    // Típus is 6, not 5, even though its CELL is now a 17px icon: at 5% the
    // HEADER broke as "Típu|s" at the 1018px card, orphaning a letter (measured
    // in Chromium -- "Típus" needs ~51px including the 8px header padding, and
    // 5% of 1018 is exactly 51px). The cell no longer drives these widths; the
    // header does.
    $ioc_type_width  = 6;
    $ioc_src_width   = 6;
    $ioc_agg_width   = 5;
    $ioc_conf_width  = 8;
    $ioc_svc_budget  = $ioc_svc_count > 0 ? max(25, 5 * $ioc_svc_count) : 0;
    $ioc_value_width = 52 - $ioc_svc_budget;
    // Labels for the confidence icon's tooltip/legend. Local to this view by the
    // same convention as $ioc_legend_labels below -- see the co-dependency note
    // on QA_IOC_CONFIDENCE_ICON.
    $ioc_conf_labels = ['high' => t('magas'), 'medium' => t('közepes'), 'low' => t('alacsony')];
    $ioc_svc_widths  = [];
    if ($ioc_svc_count > 0) {
        $ioc_svc_base = intdiv($ioc_svc_budget, $ioc_svc_count);
        $ioc_svc_rem  = $ioc_svc_budget % $ioc_svc_count;
        foreach ($ioc_enabled_svcs as $i => $svc) {
            $ioc_svc_widths[$svc] = $ioc_svc_base + ($i < $ioc_svc_rem ? 1 : 0);
        }
    }
    ?>
    <div style="overflow-x:auto">
    <table class="msg-table ioc-table" style="table-layout:fixed">
        <colgroup>
            <col style="width:<?= (int)$ioc_type_width ?>%"><col style="width:<?= (int)$ioc_value_width ?>%"><col style="width:<?= (int)$ioc_src_width ?>%"><col style="width:<?= (int)$ioc_conf_width ?>%">
            <col style="width:<?= (int)$ioc_agg_width ?>%">
            <?php foreach ($ioc_enabled_svcs as $svc): ?><col style="width:<?= (int)$ioc_svc_widths[$svc] ?>%"><?php endforeach; ?>
            <col style="width:9%"><col style="width:14%">
        </colgroup>
        <thead><tr>
            <th scope="col"><?= t('Típus') ?></th><th scope="col"><?= t('Érték') ?></th>
            <th scope="col"><?= t('Forrás') ?></th><th scope="col" class="ioc-th-hyphen" style="white-space:normal;overflow-wrap:anywhere"><?= t('Megbízhatóság') ?></th>
            <?php /* Header is just "%" so the column can be narrow; the full
               phrase stays reachable as the tooltip, and the explanation
               paragraph above the table defines it in full. */ ?>
            <th scope="col" style="text-align:center" title="<?= h(t('Összesített %')) ?>">%</th>
            <?php foreach ($ioc_enabled_svcs as $svc): ?><th scope="col" style="white-space:normal;overflow-wrap:anywhere"><?= $_il_header[$svc] ?? h($_il_label[$svc]) ?></th><?php endforeach; ?>
            <th scope="col" style="white-space:normal"><?= t('Utoljára látva') ?></th><th scope="col"><?= t('Művelet') ?></th>
        </tr></thead>
        <tbody>
        <?php foreach ($ioc_rows as $row):
            $ioc_svcs   = ioc_lookup_services_for($row['type'], 'ioc');
            $ioc_cached = ioc_lookup_cached((int)$row['id']);
            $conf       = ioc_lookup_confidence(array_intersect_key($ioc_cached, array_flip($ioc_enabled_svcs)));
        ?>
        <tr class="data-row">
            <?php $ioc_ty_ico = QA_IOC_TYPE_ICON[$row['type']] ?? null; ?>
            <td data-label="<?= h(t('Típus')) ?>" style="text-align:center">
                <?php if ($ioc_ty_ico): ?>
                <span class="ioc-gi" title="<?= h($row['type']) ?>"><svg class="icon" aria-hidden="true"><use href="#<?= h($ioc_ty_ico) ?>"></use></svg><span class="sr-only"><?= h($row['type']) ?></span></span>
                <?php else: ?><span style="white-space:normal;overflow-wrap:anywhere"><?= h($row['type']) ?></span><?php endif; ?>
            </td>
            <td data-label="<?= h(t('Érték')) ?>" style="font-family:monospace;word-break:break-all"><?= h($row['value']) ?></td>
            <?php $ioc_so_ico = QA_IOC_SOURCE_ICON[$row['source']] ?? null; ?>
            <td data-label="<?= h(t('Forrás')) ?>" style="text-align:center">
                <?php if ($ioc_so_ico): ?>
                <span class="ioc-gi" title="<?= h($row['source']) ?>"><svg class="icon" aria-hidden="true"><use href="#<?= h($ioc_so_ico) ?>"></use></svg><span class="sr-only"><?= h($row['source']) ?></span></span>
                <?php else: /* free-text source: no icon exists, show the word */ ?>
                <span style="white-space:normal;overflow-wrap:anywhere;font-size:.85em" title="<?= h($row['source']) ?>"><?= h($row['source']) ?></span>
                <?php endif; ?>
            </td>
            <?php
            // Unknown/legacy values fall back to showing the raw text rather than
            // rendering nothing -- a blank cell would silently hide a value the
            // operator did set.
            $ioc_cf     = (string)$row['confidence'];
            $ioc_cf_ico = QA_IOC_CONFIDENCE_ICON[$ioc_cf] ?? null;
            $ioc_cf_lbl = $ioc_conf_labels[$ioc_cf] ?? $ioc_cf;
            ?>
            <td data-label="<?= h(t('Megbízhatóság')) ?>" style="text-align:center">
                <?php if ($ioc_cf_ico): ?>
                <span class="ioc-conf <?= h($ioc_cf_ico['class']) ?>" title="<?= h($ioc_cf_lbl) ?>">
                    <svg class="icon" aria-hidden="true"><use href="#<?= h($ioc_cf_ico['icon']) ?>"></use></svg>
                    <span class="sr-only"><?= h($ioc_cf_lbl) ?></span>
                </span>
                <?php else: ?>
                <span style="white-space:normal;overflow-wrap:anywhere"><?= h($ioc_cf) ?></span>
                <?php endif; ?>
            </td>
            <td data-label="<?= h(t('Összesített %')) ?>" id="ioc-conf-<?= (int)$row['id'] ?>">
                <?php if ($conf !== null): ?>
                <span class="conf-<?= h($conf['tier']) ?>"><?= (int)$conf['pct'] ?>%</span>
                <?php endif; ?>
            </td>
            <?php foreach ($ioc_enabled_svcs as $svc):
                $ioc_applicable = in_array($svc, $ioc_svcs, true);
                $lk = $ioc_cached[$svc] ?? null;
            ?>
            <td data-label="<?= h($_il_label[$svc]) ?>"<?= $ioc_applicable ? ' id="ioc-rep-' . (int)$row['id'] . '-' . h($svc) . '"' : '' ?>>
                <?php if (!$ioc_applicable): ?>
                <span style="color:var(--text-subtle)"><?= t('N/A') ?></span>
                <?php elseif ($lk):
                    // Tooltip carries the verdict word since it's no longer
                    // visible as text on the badge itself (icon-only).
                    $ioc_detail_prefix = $lk['detail'] !== '' ? $lk['detail'] . ' — ' : '';
                    $ioc_lk_title = $lk['verdict'] . ' — ' . $ioc_detail_prefix . date('Y-m-d H:i', (int)$lk['checked_at']);
                    $ioc_icon = QA_VERDICT_ICON[$lk['verdict']] ?? 'icon-info';
                ?>
                <span class="verdict verdict-<?= h($lk['verdict']) ?>" title="<?= h($ioc_lk_title) ?>" aria-label="<?= h($lk['verdict']) ?>"><svg class="icon"><use href="#<?= h($ioc_icon) ?>"></use></svg></span>
                <?php endif; ?>
            </td>
            <?php endforeach; ?>
            <td data-label="<?= h(t('Utoljára látva')) ?>" class="local-ts" data-ts="<?= (int)$row['last_seen_at'] ?>"><?= h(date('Y-m-d H:i', (int)$row['last_seen_at'])) ?></td>
            <td data-label="<?= h(t('Művelet')) ?>">
                <?php if (!empty($ioc_svcs)): ?>
                <form method="post" action="?ioc=1" class="ioc-lookup-form" style="display:block;margin-bottom:4px">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="ioc_lookup">
                    <input type="hidden" name="ioc_id" value="<?= (int)$row['id'] ?>">
                    <button type="submit" class="btn btn-sm btn-secondary"><svg class="icon"><use href="#icon-search"></use></svg> <?= t('Ellenőrzés') ?></button>
                </form>
                <?php endif; ?>
                <?php if (in_array($row['type'], ['ip', 'domain', 'url'], true)):
                    $ioc_is_promoted = $row['type'] === 'ip'
                        ? isset($ioc_blocked_ips[strtolower($row['value'])])
                        : $row['promoted_at'] !== null;
                ?>
                    <?php if ($ioc_is_promoted): ?>
                    <div style="margin-bottom:4px">
                        <span class="verdict verdict-malicious"><svg class="icon"><use href="#icon-shield"></use></svg> <?= t('Élesítve') ?></span>
                        <?php /* Stacked (not inline next to the badge): in some
                        languages the badge+button combo on one line is the
                        single widest thing in this column (e.g. German "Aktiv
                        Widerrufen" ~166px vs. either element alone ~90-120px) --
                        see docs/superpowers/notes/2026-08-13-ioc-table-fit-fix.md. */ ?>
                        <form method="post" action="?ioc=1" style="display:block;margin-top:2px"
                              onsubmit="return confirm('<?= h(t('Visszavonja az élesítést?')) ?>')">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="ioc_unpromote">
                            <input type="hidden" name="ioc_id" value="<?= (int)$row['id'] ?>">
                            <button type="submit" class="btn btn-sm btn-secondary"><?= t('Visszavonás') ?></button>
                        </form>
                    </div>
                    <?php else: ?>
                    <form method="post" action="?ioc=1" style="display:block;margin-bottom:4px"
                          onsubmit="return confirm('<?= h(t('Élesíti ezt az indikátort?')) ?>')">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="ioc_promote">
                        <input type="hidden" name="ioc_id" value="<?= (int)$row['id'] ?>">
                        <button type="submit" class="btn btn-sm btn-secondary"><svg class="icon"><use href="#icon-shield"></use></svg> <?= t('Élesítés') ?></button>
                    </form>
                    <?php endif; ?>
                <?php endif; ?>
                <form method="post" action="?ioc=1" style="display:block;margin-bottom:4px"
                      onsubmit="return confirm('<?= h(t('Lejáratja ezt az indikátort?')) ?>')">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="ioc_expire">
                    <input type="hidden" name="ioc_id" value="<?= (int)$row['id'] ?>">
                    <button type="submit" class="btn btn-sm btn-secondary"><?= t('Lejáratás') ?></button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    <div class="filter-hint" style="margin:12px 20px 4px">
<?php
        $ioc_legend_labels = ['malicious' => t('kártékony'), 'suspicious' => t('gyanús'), 'clean' => t('tiszta'), 'unknown' => t('ismeretlen')];
        $ioc_legend_i = 0; $ioc_legend_n = count(QA_VERDICT_ICON);
        foreach (QA_VERDICT_ICON as $ioc_legend_v => $ioc_legend_ic) {
            $ioc_legend_i++;
            // ?? $ioc_legend_v: a verdict added to QA_VERDICT_ICON without a
            // matching entry here labels itself instead of emitting
            // "Undefined array key" and rendering blank -- see the
            // co-dependency note on QA_VERDICT_ICON (src/ioc_lookup.php).
            echo '        <span class="verdict verdict-' . $ioc_legend_v . '" style="font-size:1.3em"><svg class="icon"><use href="#' . $ioc_legend_ic . '"></use></svg></span> ' . ($ioc_legend_labels[$ioc_legend_v] ?? $ioc_legend_v);
            // The leading spaces and trailing \n below are byte-significant:
            // PHP's closing tag above swallows one newline, so this literal
            // reproduces the pre-refactor template's exact output bytes.
            // Do not "tidy" this string without re-checking that fact.
            if ($ioc_legend_i < $ioc_legend_n) echo "        &nbsp;·&nbsp;\n";
        }
?>
        <br><?= t('N/A = a szolgáltatás nem támogatja ezt az indikátortípust; üres cella = még nincs ellenőrizve') ?>
        <br><?= t('Típus:') ?>
<?php
        // Típus/Forrás/Megbízhatóság are all icon-only columns now, so each set
        // needs decoding on the page itself -- a tooltip is unreachable on touch.
        // The type/source keys are technical identifiers ("domain", "bulk-import")
        // and are shown verbatim, exactly as the old text cells did, so they need
        // no translation.
        $ioc_ti = 0; $ioc_tn = count(QA_IOC_TYPE_ICON);
        foreach (QA_IOC_TYPE_ICON as $ioc_tk => $ioc_tv) {
            $ioc_ti++;
            echo ' <span class="ioc-gi"><svg class="icon" aria-hidden="true"><use href="#' . h($ioc_tv) . '"></use></svg></span> ' . h($ioc_tk);
            if ($ioc_ti < $ioc_tn) echo '&nbsp;·&nbsp;';
        }
?>
        <br><?= t('Forrás:') ?>
<?php
        $ioc_si = 0; $ioc_sn = count(QA_IOC_SOURCE_ICON);
        foreach (QA_IOC_SOURCE_ICON as $ioc_sk => $ioc_sv) {
            $ioc_si++;
            echo ' <span class="ioc-gi"><svg class="icon" aria-hidden="true"><use href="#' . h($ioc_sv) . '"></use></svg></span> ' . h($ioc_sk);
            if ($ioc_si < $ioc_sn) echo '&nbsp;·&nbsp;';
        }
?>
        <br><?= t('Megbízhatóság:') ?>
<?php
        // The Megbízhatóság column shows only an icon, so its three levels have to
        // be decodable somewhere on the page -- the tooltip alone is not enough on
        // touch devices, which have no hover.
        $ioc_cl_i = 0; $ioc_cl_n = count(QA_IOC_CONFIDENCE_ICON);
        foreach (QA_IOC_CONFIDENCE_ICON as $ioc_cl_k => $ioc_cl_v) {
            $ioc_cl_i++;
            echo ' <span class="ioc-conf ' . h($ioc_cl_v['class']) . '"><svg class="icon" aria-hidden="true"><use href="#'
               . h($ioc_cl_v['icon']) . '"></use></svg></span> ' . h($ioc_conf_labels[$ioc_cl_k] ?? $ioc_cl_k);
            if ($ioc_cl_i < $ioc_cl_n) echo '&nbsp;·&nbsp;';
        }
?>
    </div>
    <div class="results-footer"><?= render_pager($ioc_page, $ioc_pages, $ioc_url, number_format($ioc_total) . ' ' . t('indikátor')) ?></div>
    <?php endif; ?>
</div>
