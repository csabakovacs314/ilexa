<?php
// IOC (indicator-of-compromise) tab: search/list/add/expire, plus (Task 7)
// the extracted-candidate review screen. Reached only when can('admin').

$ioc_msg = $_GET['msg'] ?? '';
$ioc_err = h(urldecode($_GET['err'] ?? ''));
$ioc_notices = [
    'ioc_saved'     => ['ok',  t('Indikátor elmentve.')],
    'ioc_err'       => ['err', t('Mentés sikertelen: ') . $ioc_err],
    'ioc_expired'   => ['ok',  t('Indikátor lejáratva.')],
    'ioc_confirmed' => ['ok',  t('Kijelölt indikátorok elmentve.')],
    'ioc_none'      => ['ok',  t('Nem lett indikátor kiválasztva.')],
    'ioc_extract_err' => ['err', t('Nem sikerült feldolgozni az üzenetet indikátor-kinyeréshez.')],
    'view_policy_denied' => ['err', t('A művelet le van tiltva az adatvédelmi beállítás miatt.')],
    'ioc_lookup_ok'  => ['ok',  t('Ellenőrzés lefutott.')],
    'ioc_lookup_err' => ['err', t('Az ellenőrzés sikertelen volt minden szolgáltatásnál.')],
    'ioc_promote_ok'     => ['ok',  t('Indikátor élesítve.')],
    'ioc_promote_err'    => ['err', t('Élesítés sikertelen: ') . $ioc_err],
    'ioc_unpromote_ok'   => ['ok',  t('Élesítés visszavonva.')],
    'ioc_unpromote_err'  => ['err', t('Visszavonás sikertelen: ') . $ioc_err],
];
?>
<h1 class="page-title"><?= h(t('IOC')) ?></h1>
<?php if (isset($ioc_notices[$ioc_msg])):
    [$ioc_cls, $ioc_text] = $ioc_notices[$ioc_msg];
?>
<div class="notice notice-<?= h($ioc_cls) ?>"><?= $ioc_text ?></div>
<?php endif; ?>

<?php /* The page opened with two long paragraphs of help text always on
   screen, pushing the actual work below the fold. Folded into the same
   <details class="sys-sec"> the Rendszer and Admin pages use, with no `open`
   attribute, so it is closed on a fresh visit and the id lets the script in
   layout_foot.php reopen it across a save round-trip like every other
   section. Native fold -- no JavaScript and no CSS added for this. */ ?>
<details class="sys-sec results-card" id="ioc-help" style="margin-bottom:20px">
    <summary class="results-header"><h2><?= t('Mi az IOC?') ?></h2>
        <span class="sys-sec-desc"><?= h(t('Fogalmak, a megbízhatósági és összesített értékek jelentése, valamint mit csinál az Ellenőrzés, az Élesítés és a Lejáratás.')) ?></span></summary>
    <div class="filter-hint" style="margin-top:0;padding:14px 20px 18px">
        <p style="margin:0 0 8px"><?= h(t('Az IOC (indicator of compromise) fenyegetéshez köthető technikai azonosító: IP-cím, domain, URL, e-mail vagy fájl-hash. A tételek archivált levélből kinyerve és jóváhagyva (quarantine-confirm), a Kampányok lapról egy kattintással (campaign), a Beállítások lapon tömeges hash-importból (bulk-import), vagy kézzel (manual) kerülnek a listába.')) ?></p>
        <p style="margin:0"><?= h(t('A "Megbízhatóság" a felvevő által megadott érték (low/medium/high), nem mérés eredménye. Az "Összesített %" ezzel szemben számított: a hírnév-szolgáltatások (VirusTotal, Mailspike, URLhaus, OTX, HRBL) eredményeiből áll elő, súlyozva — az url.vet ebbe szándékosan nem számít bele, mert az nem hírnév-adatbázis, hanem a domain szerkezetét elemzi (kor, ismertség, márkanév-utánzás), és külön oszlopban jelenik meg. Az "Ellenőrzés" lefuttatja az engedélyezett szolgáltatásokat (az eredmény 24 óráig gyorsítótárazott; a szolgáltatások a Beállítások lapon kapcsolhatók be). Az "Élesítés" éles blokkolást hoz létre: IP-cím esetén az IP a blokklistára kerül (SMTP-szintű elutasítás), domain/URL esetén az adott hosztra mutató hivatkozást tartalmazó levél kerül elutasításra — URL-nél csak a host számít, az útvonal figyelmen kívül marad, így az adott hoszthoz mutató összes hivatkozás blokkolódik. A "Lejáratás" deaktiválja az indikátort, megszünteti az élesítést, és a tétel eltűnik a listáról.')) ?></p>
    </div>
</details>

<?php require __DIR__ . '/ioc_review.php'; ?>

<?php
$ioc_prefill_type  = $_GET['ioc_prefill_type']  ?? '';
$ioc_prefill_value = $_GET['ioc_prefill_value'] ?? '';
?>
<div class="results-card" style="margin-bottom:20px">
    <div class="results-header"><h2><?= t('Indikátor hozzáadása') ?></h2></div>
    <form method="post" action="?ioc=1" style="display:flex;gap:8px;align-items:flex-end;flex-wrap:wrap;padding:14px 20px">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="ioc_add">
        <div>
            <label for="ioc_add_type" style="display:block;font-size:.75rem;color:var(--text-muted)"><?= t('Típus') ?></label>
            <select name="ioc_type" id="ioc_add_type" style="padding:5px">
                <?php foreach (IOC_TYPES as $ty): ?>
                <option value="<?= h($ty) ?>" <?= $ty === $ioc_prefill_type ? 'selected' : '' ?>><?= h($ty) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div style="flex:1;min-width:200px">
            <label for="ioc_add_value" style="display:block;font-size:.75rem;color:var(--text-muted)"><?= t('Érték') ?></label>
            <input type="text" name="ioc_value" id="ioc_add_value" required style="width:100%;padding:5px" value="<?= h($ioc_prefill_value) ?>">
        </div>
        <div>
            <label for="ioc_add_conf" style="display:block;font-size:.75rem;color:var(--text-muted)"><?= t('Megbízhatóság') ?></label>
            <select name="ioc_confidence" id="ioc_add_conf" style="padding:5px">
                <?php foreach (IOC_CONFIDENCE_LEVELS as $cf): ?>
                <option value="<?= h($cf) ?>" <?= $cf === 'medium' ? 'selected' : '' ?>><?= h($cf) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div>
            <label for="ioc_add_exp" style="display:block;font-size:.75rem;color:var(--text-muted)"><?= t('Lejárat (nap, üres = soha)') ?></label>
            <input type="number" name="ioc_expires_days" id="ioc_add_exp" min="1" style="width:90px;padding:5px">
        </div>
        <button type="submit" class="btn btn-sm btn-primary"><?= t('Hozzáadás') ?></button>
    </form>
</div>

<?php
$ioc_f_type   = $_GET['ity'] ?? '';
$ioc_f_source = trim((string)($_GET['isrc'] ?? ''));
$ioc_f_tag    = trim((string)($_GET['itag'] ?? ''));
$ioc_f_q      = trim((string)($_GET['iq']   ?? ''));
$ioc_page     = max(1, (int)($_GET['ip'] ?? 1));
[$ioc_rows, $ioc_total] = ioc_list(array_filter([
    'type' => $ioc_f_type, 'source' => $ioc_f_source, 'tag' => $ioc_f_tag, 'q' => $ioc_f_q,
]), $ioc_page, QA_PER_PAGE_IOC);
$ioc_pages = max(1, (int) ceil($ioc_total / QA_PER_PAGE_IOC));
$ioc_url   = fn(int $p): string => '?' . http_build_query(array_filter([
    'ioc' => 1, 'ity' => $ioc_f_type, 'isrc' => $ioc_f_source, 'itag' => $ioc_f_tag,
    'iq' => $ioc_f_q, 'ip' => $p,
]));
$ioc_blocked_ips = [];
foreach (list_load('block') as $e) {
    if (!empty($e['ip'])) $ioc_blocked_ips[$e['ip']] = true;
}
?>
<div class="results-card">
    <div class="results-header"><h2><?= t('Indikátorok') ?></h2></div>
    <form method="get" action="?ioc=1" style="display:flex;gap:8px;align-items:center;padding:12px 20px;flex-wrap:wrap">
        <input type="hidden" name="ioc" value="1">
        <label for="ioc_f_type" class="sr-only"><?= t('Típus') ?></label>
        <select name="ity" id="ioc_f_type" style="padding:5px">
            <option value=""><?= t('Minden típus') ?></option>
            <?php foreach (IOC_TYPES as $ty): ?>
            <option value="<?= h($ty) ?>" <?= $ioc_f_type === $ty ? 'selected' : '' ?>><?= h($ty) ?></option>
            <?php endforeach; ?>
        </select>
        <label for="ioc_f_src" class="sr-only"><?= t('Forrás') ?></label>
        <input type="text" name="isrc" id="ioc_f_src" value="<?= h($ioc_f_source) ?>" placeholder="<?= h(t('forrás')) ?>" style="padding:5px">
        <label for="ioc_f_q" class="sr-only"><?= t('Keresés') ?></label>
        <input type="text" name="iq" id="ioc_f_q" value="<?= h($ioc_f_q) ?>"   placeholder="<?= h(t('keresés (érték/megjegyzés)')) ?>" style="padding:5px;flex:1;min-width:160px">
        <button type="submit" class="btn btn-sm btn-primary"><?= t('Szűrés') ?></button>
    </form>
    <?php if (empty($ioc_rows)): ?>
    <div class="empty-state"><p><?= t('Nincs a szűrésnek megfelelő indikátor.') ?></p></div>
    <?php else: ?>
    <?php
    $_il_label = ['virustotal' => 'VirusTotal', 'urlhaus' => 'URLhaus', 'otx' => 'OTX', 'hrbl' => 'HRBL', 'mailspike' => 'Mailspike', 'urlvet' => 'url.vet', 'yaraify' => 'YARAify', 'threatfox' => 'ThreatFox', 'xposedornot' => 'XposedOrNot', 'leakcheck' => 'LeakCheck', 'hudsonrock' => 'Hudson Rock'];
    foreach (array_keys(ioc_lookup_custom_services()) as $_csvc) { $_il_label[$_csvc] = $_csvc; }
    // The services whose chips can appear in a Hírnév cell: runnable, not
    // merely enabled (an enabled-but-keyless service can only error until its
    // key arrives -- same reasoning as ioc_lookup_services_for()), and
    // applicable to some indicator type on this page.
    $ioc_page_types  = array_unique(array_column($ioc_rows, 'type'));
    $ioc_applicable  = [];
    foreach ($ioc_page_types as $_pt) {
        foreach (ioc_lookup_services_for($_pt, 'ioc') as $_ps) $ioc_applicable[$_ps] = true;
    }
    $ioc_enabled_svcs = array_values(array_filter(
        array_keys($_il_label),
        fn(string $s): bool => isset($ioc_applicable[$s]) && ioc_lookup_service_runnable($s)));
    // Layout (usability rework, 2026-10-14). The table used to give every
    // applicable reputation service its own ~5% column -- 5 to 9 of them --
    // which squeezed Érték until a SHA-256 wrapped to four lines, filled the
    // grid with "N/A" for types a service cannot answer, and made the column
    // set change with the page's contents. One "Hírnév" cell now holds a
    // labelled chip per service that has actually answered for THIS row (no
    // N/A, nothing for unchecked), headed by the aggregate %. A separate
    // Állapot column says whether the indicator is armed, so Művelet holds
    // only actions. Fixed layout still (long unbreakable values), and the
    // lessons of docs/superpowers/notes/2026-08-13-ioc-table-fit-fix.md still
    // hold: widths are set by the HEADERS, which may wrap to two lines but
    // never three, and Érték is the column that gets the slack.
    $ioc_conf_labels = ['high' => t('magas'), 'medium' => t('közepes'), 'low' => t('alacsony')];
    $ioc_svc_label_js = [];
    foreach ($ioc_enabled_svcs as $svc) $ioc_svc_label_js[$svc] = $_il_label[$svc];
    ?>
    <div style="overflow-x:auto">
    <table class="msg-table ioc-table" style="table-layout:fixed" data-svc-labels="<?= h(json_encode($ioc_svc_label_js)) ?>">
        <colgroup>
            <col style="width:8%"><col style="width:27%"><col style="width:6%"><col style="width:8%">
            <col style="width:19%"><col style="width:9%"><col style="width:11%"><col style="width:12%">
        </colgroup>
        <thead><tr>
            <th scope="col"><?= t('Típus') ?></th><th scope="col"><?= t('Érték') ?></th>
            <th scope="col"><?= t('Forrás') ?></th><th scope="col" class="ioc-th-hyphen" style="white-space:normal;overflow-wrap:anywhere"><?= t('Megbízhatóság') ?></th>
            <th scope="col"><?= t('Hírnév') ?></th>
            <th scope="col"><?= t('Állapot') ?></th>
            <th scope="col" style="white-space:normal"><?= t('Utoljára látva') ?></th><th scope="col"><?= t('Művelet') ?></th>
        </tr></thead>
        <tbody>
        <?php foreach ($ioc_rows as $row):
            $ioc_svcs   = ioc_lookup_services_for($row['type'], 'ioc');
            $ioc_cached = array_intersect_key(ioc_lookup_cached((int)$row['id']), array_flip($ioc_enabled_svcs));
            $conf       = ioc_lookup_confidence($ioc_cached);
            $ioc_armable = in_array($row['type'], ['ip', 'domain', 'url'], true);
            $ioc_is_promoted = $ioc_armable && ($row['type'] === 'ip'
                ? isset($ioc_blocked_ips[strtolower($row['value'])])
                : $row['promoted_at'] !== null);
            $ioc_val_short = mb_strimwidth((string)$row['value'], 0, 60, '…');
        ?>
        <tr class="data-row">
            <?php $ioc_ty_ico = QA_IOC_TYPE_ICON[$row['type']] ?? null; ?>
            <td data-label="<?= h(t('Típus')) ?>" class="ioc-type-cell">
                <?php if ($ioc_ty_ico): ?><svg class="icon ioc-gi" aria-hidden="true"><use href="#<?= h($ioc_ty_ico) ?>"></use></svg><?php endif; ?>
                <span class="ioc-type-word"><?= h($row['type']) ?></span>
            </td>
            <td data-label="<?= h(t('Érték')) ?>" class="ioc-value"><?= h($row['value']) ?></td>
            <?php $ioc_so_ico = QA_IOC_SOURCE_ICON[$row['source']] ?? null; ?>
            <td data-label="<?= h(t('Forrás')) ?>" style="text-align:center">
                <?php if ($ioc_so_ico): ?>
                <span class="ioc-gi" title="<?= h($row['source']) ?>"><svg class="icon" aria-hidden="true"><use href="#<?= h($ioc_so_ico) ?>"></use></svg><span class="sr-only"><?= h($row['source']) ?></span></span>
                <?php else: /* free-text source: no icon exists, show the word */ ?>
                <span style="white-space:normal;overflow-wrap:anywhere;font-size:.85em" title="<?= h($row['source']) ?>"><?= h($row['source']) ?></span>
                <?php endif; ?>
            </td>
            <?php
            // Unknown/legacy values fall back to showing the raw text rather than
            // rendering nothing -- a blank cell would silently hide a value the
            // operator did set.
            $ioc_cf     = (string)$row['confidence'];
            $ioc_cf_ico = QA_IOC_CONFIDENCE_ICON[$ioc_cf] ?? null;
            $ioc_cf_lbl = $ioc_conf_labels[$ioc_cf] ?? $ioc_cf;
            ?>
            <td data-label="<?= h(t('Megbízhatóság')) ?>" style="text-align:center">
                <?php if ($ioc_cf_ico): ?>
                <span class="ioc-conf <?= h($ioc_cf_ico['class']) ?>" title="<?= h($ioc_cf_lbl) ?>">
                    <svg class="icon" aria-hidden="true"><use href="#<?= h($ioc_cf_ico['icon']) ?>"></use></svg>
                    <span class="sr-only"><?= h($ioc_cf_lbl) ?></span>
                </span>
                <?php else: ?>
                <span style="white-space:normal;overflow-wrap:anywhere"><?= h($ioc_cf) ?></span>
                <?php endif; ?>
            </td>
            <?php /* Mirrored by applyIocLookupResult() (views/layout_foot.php):
                     same chip markup, same order (service registry order). */ ?>
            <td data-label="<?= h(t('Hírnév')) ?>" class="ioc-rep-cell" id="ioc-repcell-<?= (int)$row['id'] ?>">
                <div class="ioc-rep-conf" id="ioc-conf-<?= (int)$row['id'] ?>"><?php if ($conf !== null): ?><span class="conf-<?= h($conf['tier']) ?>" title="<?= h($conf['title'] ?? '') ?>"><?= h(t('Összesített')) ?>: <?= (int)$conf['pct'] ?>%</span><?php endif; ?></div>
                <div class="ioc-rep-chips">
                <?php foreach ($ioc_enabled_svcs as $svc):
                    if (!in_array($svc, $ioc_svcs, true) || empty($ioc_cached[$svc])) continue;
                    $lk = $ioc_cached[$svc];
                    $ioc_detail_prefix = $lk['detail'] !== '' ? $lk['detail'] . ' — ' : '';
                    $ioc_lk_title = $_il_label[$svc] . ' — ' . $lk['verdict'] . ' — ' . $ioc_detail_prefix . date('Y-m-d H:i', (int)$lk['checked_at']);
                    $ioc_icon = QA_VERDICT_ICON[$lk['verdict']] ?? 'icon-info';
                ?>
                    <span class="verdict verdict-<?= h($lk['verdict']) ?> ioc-chip" data-ioc-svc="<?= h($svc) ?>" title="<?= h($ioc_lk_title) ?>"><svg class="icon" aria-hidden="true"><use href="#<?= h($ioc_icon) ?>"></use></svg> <?= h($_il_label[$svc]) ?><span class="sr-only">: <?= h($lk['verdict']) ?></span></span>
                <?php endforeach; ?>
                </div>
                <?php if (!$ioc_cached && !empty($ioc_svcs)): ?>
                <span class="ioc-rep-none"><?= h(t('még nincs ellenőrizve')) ?></span>
                <?php elseif (empty($ioc_svcs)): ?>
                <span class="ioc-rep-none"><?= h(t('nincs ezt a típust ismerő szolgáltatás')) ?></span>
                <?php endif; ?>
            </td>
            <td data-label="<?= h(t('Állapot')) ?>">
                <?php if ($ioc_is_promoted): ?>
                <span class="ioc-state ioc-state-armed"><svg class="icon" aria-hidden="true"><use href="#icon-shield"></use></svg> <?= t('Élesítve') ?></span>
                <?php elseif ($ioc_armable): ?>
                <span class="ioc-state"><?= h(t('Csak tárolva')) ?></span>
                <?php else: ?>
                <span class="ioc-state" title="<?= h(t('Ez a típus nem élesíthető: csak bizonyítékként és exportra tárolódik.')) ?>"><?= h(t('Csak tárolva')) ?></span>
                <?php endif; ?>
            </td>
            <td data-label="<?= h(t('Utoljára látva')) ?>" class="local-ts" data-ts="<?= (int)$row['last_seen_at'] ?>"><?= h(date('Y-m-d H:i', (int)$row['last_seen_at'])) ?></td>
            <td data-label="<?= h(t('Művelet')) ?>">
                <?php if (!empty($ioc_svcs)): ?>
                <form method="post" action="?ioc=1" class="ioc-lookup-form" style="display:block;margin-bottom:4px">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="ioc_lookup">
                    <input type="hidden" name="ioc_id" value="<?= (int)$row['id'] ?>">
                    <button type="submit" class="btn btn-sm btn-secondary"><svg class="icon" aria-hidden="true"><use href="#icon-search"></use></svg> <?= t('Ellenőrzés') ?></button>
                </form>
                <?php endif; ?>
                <?php /* Confirmations name the value and what the action does to
                         mail -- promoting is a live SMTP block. */ ?>
                <?php if ($ioc_armable && $ioc_is_promoted): ?>
                <form method="post" action="?ioc=1" style="display:block;margin-bottom:4px"
                      data-confirm="<?= h(sprintf(t('Visszavonja az élesítést: %s? Az ide mutató levelek ezután ismét átjuthatnak.'), $ioc_val_short)) ?>"
                      onsubmit="return confirm(this.dataset.confirm)">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="ioc_unpromote">
                    <input type="hidden" name="ioc_id" value="<?= (int)$row['id'] ?>">
                    <button type="submit" class="btn btn-sm btn-secondary"><?= t('Visszavonás') ?></button>
                </form>
                <?php elseif ($ioc_armable): ?>
                <form method="post" action="?ioc=1" style="display:block;margin-bottom:4px"
                      data-confirm="<?= h(sprintf($row['type'] === 'ip'
                          ? t('Élesíti: %s? Az IP-cím a blokklistára kerül, a levelei SMTP-szinten elutasításra kerülnek.')
                          : t('Élesíti: %s? Az erre a hosztra hivatkozó levelek elutasításra kerülnek.'), $ioc_val_short)) ?>"
                      onsubmit="return confirm(this.dataset.confirm)">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="ioc_promote">
                    <input type="hidden" name="ioc_id" value="<?= (int)$row['id'] ?>">
                    <button type="submit" class="btn btn-sm btn-danger-outline"><svg class="icon" aria-hidden="true"><use href="#icon-shield"></use></svg> <?= t('Élesítés') ?></button>
                </form>
                <?php endif; ?>
                <form method="post" action="?ioc=1" style="display:block;margin-bottom:4px"
                      data-confirm="<?= h(sprintf(t('Lejáratja: %s? Az indikátor kikerül a listáról, és ha élesítve volt, a blokkolás is megszűnik.'), $ioc_val_short)) ?>"
                      onsubmit="return confirm(this.dataset.confirm)">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="ioc_expire">
                    <input type="hidden" name="ioc_id" value="<?= (int)$row['id'] ?>">
                    <button type="submit" class="btn btn-sm btn-danger-outline"><svg class="icon" aria-hidden="true"><use href="#icon-trash"></use></svg> <?= t('Lejáratás') ?></button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    <div class="filter-hint" style="margin:12px 20px 4px">
<?php
        $ioc_legend_labels = ['malicious' => t('kártékony'), 'suspicious' => t('gyanús'), 'clean' => t('tiszta'), 'unknown' => t('ismeretlen')];
        $ioc_legend_i = 0; $ioc_legend_n = count(QA_VERDICT_ICON);
        foreach (QA_VERDICT_ICON as $ioc_legend_v => $ioc_legend_ic) {
            $ioc_legend_i++;
            // ?? $ioc_legend_v: a verdict added to QA_VERDICT_ICON without a
            // matching entry here labels itself instead of emitting
            // "Undefined array key" and rendering blank -- see the
            // co-dependency note on QA_VERDICT_ICON (src/ioc_lookup.php).
            echo '        <span class="verdict verdict-' . $ioc_legend_v . '" style="font-size:1.3em"><svg class="icon"><use href="#' . $ioc_legend_ic . '"></use></svg></span> ' . ($ioc_legend_labels[$ioc_legend_v] ?? $ioc_legend_v);
            // The leading spaces and trailing \n below are byte-significant:
            // PHP's closing tag above swallows one newline, so this literal
            // reproduces the pre-refactor template's exact output bytes.
            // Do not "tidy" this string without re-checking that fact.
            if ($ioc_legend_i < $ioc_legend_n) echo "        &nbsp;·&nbsp;\n";
        }
?>
        <br><?= t('A Hírnév oszlop csak a már válaszolt szolgáltatásokat mutatja; a részletekért vigye az egeret egy jelvény fölé.') ?>
        <br><?= t('Típus:') ?>
<?php
        // Típus/Forrás/Megbízhatóság are all icon-only columns now, so each set
        // needs decoding on the page itself -- a tooltip is unreachable on touch.
        // The type/source keys are technical identifiers ("domain", "bulk-import")
        // and are shown verbatim, exactly as the old text cells did, so they need
        // no translation.
        $ioc_ti = 0; $ioc_tn = count(QA_IOC_TYPE_ICON);
        foreach (QA_IOC_TYPE_ICON as $ioc_tk => $ioc_tv) {
            $ioc_ti++;
            echo ' <span class="ioc-gi"><svg class="icon" aria-hidden="true"><use href="#' . h($ioc_tv) . '"></use></svg></span> ' . h($ioc_tk);
            if ($ioc_ti < $ioc_tn) echo '&nbsp;·&nbsp;';
        }
?>
        <br><?= t('Forrás:') ?>
<?php
        $ioc_si = 0; $ioc_sn = count(QA_IOC_SOURCE_ICON);
        foreach (QA_IOC_SOURCE_ICON as $ioc_sk => $ioc_sv) {
            $ioc_si++;
            echo ' <span class="ioc-gi"><svg class="icon" aria-hidden="true"><use href="#' . h($ioc_sv) . '"></use></svg></span> ' . h($ioc_sk);
            if ($ioc_si < $ioc_sn) echo '&nbsp;·&nbsp;';
        }
?>
        <br><?= t('Megbízhatóság:') ?>
<?php
        // The Megbízhatóság column shows only an icon, so its three levels have to
        // be decodable somewhere on the page -- the tooltip alone is not enough on
        // touch devices, which have no hover.
        $ioc_cl_i = 0; $ioc_cl_n = count(QA_IOC_CONFIDENCE_ICON);
        foreach (QA_IOC_CONFIDENCE_ICON as $ioc_cl_k => $ioc_cl_v) {
            $ioc_cl_i++;
            echo ' <span class="ioc-conf ' . h($ioc_cl_v['class']) . '"><svg class="icon" aria-hidden="true"><use href="#'
               . h($ioc_cl_v['icon']) . '"></use></svg></span> ' . h($ioc_conf_labels[$ioc_cl_k] ?? $ioc_cl_k);
            if ($ioc_cl_i < $ioc_cl_n) echo '&nbsp;·&nbsp;';
        }
?>
    </div>
    <div class="results-footer"><?= render_pager($ioc_page, $ioc_pages, $ioc_url, number_format($ioc_total) . ' ' . t('indikátor')) ?></div>
    <?php endif; ?>
</div>
