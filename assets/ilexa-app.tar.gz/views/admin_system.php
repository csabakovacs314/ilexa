<?php
// System-config tab view (?sysconfig=1): mail-security configuration -
// rspamd Bayes learning, blocklist/reputation feeds, ClamAV, community IP feeds,
// Postfix (network/TLS/restrictions), FTS Xapian index management, IOC lookup
// services + hash export/import (moved here from the IOC tab).
// Variables from index.php: $admin_settings is NOT used here (ilexa-settings only);
// this file uses $admin_fts, $admin_feeds, $admin_clamav,
// $feed_sources, $geoblock_countries, $postfix_settings.

$ADMIN_TAB = 'sysconfig=1';

$msg     = $_GET['msg'] ?? '';
$err_msg = h(urldecode($_GET['err'] ?? ''));

$notices = [
    'learning_on'      => ['ok',  t('rspamd Bayes-tanulás <strong>bekapcsolva</strong> (éles mód).')],
    'learning_off'     => ['ok',  t('rspamd Bayes-tanulás <strong>kikapcsolva</strong> (napló-mód).')],
    'fts_deleted'      => ['ok',  t('FTS-index törölve. A keresési index az IMAP-hozzáféréskor automatikusan újraépül.')],
    'rmod_ok'          => ['ok',  t('Az rspamd modul állapota módosítva, a konfiguráció újratöltve.')],
    'rmod_err'         => ['err', t('A modul átállítása sikertelen: ') . $err_msg],
    'hu_classify_on'   => ['ok',  t('A nyelv-alapú spam-jelzők modulja bekapcsolva.')],
    'hu_classify_off'  => ['ok',  t('A nyelv-alapú spam-jelzők modulja kikapcsolva.')],
    'hu_classify_err'  => ['err', t('A modul átállítása sikertelen: ') . $err_msg],
    'hu_report_saved'  => ['ok',  t('Az értesítési cím elmentve.')],
    'hu_report_err'    => ['err', t('Az értesítési cím mentése sikertelen: ') . $err_msg],
    'hu_weight_saved'  => ['ok',  t('A jelzés súlya módosítva, az rspamd újraindult.')],
    'hu_weight_err'    => ['err', t('A súly módosítása sikertelen: ') . $err_msg],
    'hu_measure_started' => ['ok', t('Az újramérés elindult a háttérben. Az eredmény néhány perc múlva jelenik meg ezen az oldalon.')],
    'hu_measure_err'   => ['err', t('Az újramérés indítása sikertelen: ') . $err_msg],
    'fts_opt_on'       => ['ok',  t('A heti FTS-index tömörítés bekapcsolva.')],
    'fts_opt_off'      => ['ok',  t('A heti FTS-index tömörítés kikapcsolva. Az ütemezés megmarad, a feladat csak nem csinál semmit.')],
    'fts_opt_err'      => ['err', t('Az FTS-tömörítés átállítása sikertelen: ') . $err_msg],
    'fts_err'          => ['err', t('FTS-index törlése sikertelen: ') . $err_msg],
    'feed_refresh_ok'  => ['ok',  t('A forrás frissítése elindult a háttérben. Az eredmény néhány perc múlva látható.')],
    'feed_running'     => ['ok',  t('Ez a forrás már frissítés alatt áll.')],
    'feed_err'         => ['err', t('Hiba a frissítés indításakor: ') . $err_msg],
    'clamav_saved'     => ['ok',  t('ClamAV aláírás-forrás módosítva. A változás a következő clamav-unofficial-sigs futáskor lép életbe.')],
    'clamav_err'       => ['err', t('ClamAV módosítás sikertelen: ') . $err_msg],
    'postfix_setting_saved' => ['ok',  t('Postfix-beállítás elmentve és alkalmazva.')],
    'postfix_setting_err'   => ['err', t('A beállítás mentése sikertelen: ') . $err_msg],
    'postfix_restriction_saved' => ['ok',  t('Korlátozási lánc elmentve és alkalmazva.')],
    'postfix_restriction_err'   => ['err', t('A korlátozási lánc mentése sikertelen: ') . $err_msg],
    'feed_saved'       => ['ok',  t('Forrás állapota módosítva.')],
    'feed_key_saved'   => ['ok',  t('API-kulcs elmentve. A forrás a következő futáskor frissül.')],
    'feed_cfg_err'     => ['err', t('A forrás módosítása sikertelen: ') . $err_msg],
    'geoblock_saved'   => ['ok',  t('Geoblokk országlista mentve, a frissítés elindult a háttérben.')],
    'geoblock_running' => ['ok',  t('Az országlista mentve; egy korábbi frissítés még fut, az új lista a következő frissítéskor lép életbe.')],
    'geoblock_off'     => ['ok',  t('Az országlista mentve; a forrás ki van kapcsolva, frissítés nem indult.')],
    'geoblock_ref_err' => ['err', t('Az országlista mentve, de a frissítés indítása sikertelen: ') . $err_msg],
    'geoblock_err'     => ['err', t('Az országlista mentése sikertelen: ') . $err_msg],
    'rspamc_pw_saved'  => ['ok',  t('rspamd vezérlő-jelszó elmentve.')],
    'rspamc_pw_err'    => ['err', t('A jelszó mentése sikertelen: ') . $err_msg],
    'community_feed_saved'        => ['ok',  t('Közösségi forrás mentve.')],
    'community_feed_deleted'      => ['ok',  t('Közösségi forrás törölve, a blokkolás feloldva.')],
    'community_feed_err'          => ['err', t('Hiba: ') . $err_msg],
    'community_feed_refresh_ok'   => ['ok',  t('A közösségi forrás frissítése elindult a háttérben.')],
    'community_feed_running'      => ['ok',  t('Ez a forrás már frissítés alatt áll.')],
    'ioclookup_saved'     => ['ok',  t('Szolgáltatás állapota módosítva.')],
    'ioclookup_key_saved' => ['ok',  t('API-kulcs elmentve.')],
    'ioclookup_err'       => ['err', t('A szolgáltatás módosítása sikertelen: ') . $err_msg],
    'spamhaus_key_saved'  => ['ok',  t('Spamhaus DQS kulcs elmentve, az rspamd újratöltve.')],
    'spamhaus_err'        => ['err', t('A Spamhaus DQS kulcs mentése sikertelen: ') . $err_msg],
    'spamhaus_test_ok'    => ['ok',  t('A kulcs érvényes, a Spamhaus válaszolt a teszt-lekérdezésre.') . ($err_msg !== '' ? ' (' . $err_msg . ')' : '')],
    'spamhaus_test_err'   => ['err', t('A teszt-lekérdezés sikertelen: ') . $err_msg],
    'psdnsbl_saved'       => ['ok',  t('Postscreen DNSBL beállítás elmentve, a postfix újratöltve.')],
    'psdnsbl_err'         => ['err', t('A postscreen DNSBL módosítása sikertelen: ') . $err_msg],
    'neural_saved'        => ['ok',  t('Neurális háló beállítás elmentve, az rspamd újratöltve.')],
    'neural_err'          => ['err', t('A neurális háló módosítása sikertelen: ') . $err_msg],
    'brand_saved'         => ['ok',  t('Márkavédelmi beállítás elmentve, az rspamd újraindítva.')],
    'brand_err'           => ['err', t('A márkavédelem módosítása sikertelen: ') . $err_msg],
    'abusix_key_saved'    => ['ok',  t('Abusix kulcs elmentve, az rspamd újratöltve. Az Állapot oszlop élő lekérdezéssel mutatja, hogy a forrás válaszol-e.')],
    'abusix_err'          => ['err', t('Az Abusix kulcs mentése sikertelen: ') . $err_msg],
    'abusix_test_ok'      => ['ok',  t('Az Abusix válaszolt a teszt-lekérdezésre - a kulcs rendben van.') . ($err_msg !== '' ? ' (' . $err_msg . ')' : '')],
    'abusix_test_err'     => ['err', t('Az Abusix teszt sikertelen: ') . $err_msg],
    'ioc_export_token_regen'  => ['ok',  t('Új export-token generálva. A régi token azonnal érvénytelenné vált.')],
    'ioc_export_token_err'    => ['err', t('Nem sikerült új tokent generálni és menteni.')],
    'ioc_export_allow_added'  => ['ok',  t('IP-cím hozzáadva az engedélyezési listához.')],
    'ioc_export_allow_err'    => ['err', t('Az IP-cím hozzáadása sikertelen: ') . $err_msg],
    'ioc_export_allow_removed' => ['ok', t('IP-cím eltávolítva az engedélyezési listából.')],
    'ioc_bulk_import_err' => ['err', t('Nincs megadva hash az importáláshoz.')],
];

$ioc_bulk_added = (int)($_GET['added'] ?? 0);
$ioc_bulk_dup   = (int)($_GET['dup']   ?? 0);
$ioc_bulk_inv   = (int)($_GET['inv']   ?? 0);
if ($msg === 'ioc_bulk_import_ok') {
    $notices['ioc_bulk_import_ok'] = ['ok',
        t('Tömeges importálás kész: ') . $ioc_bulk_added . ' ' . t('hozzáadva') . ', '
        . $ioc_bulk_dup . ' ' . t('már létezett') . ', '
        . $ioc_bulk_inv . ' ' . t('érvénytelen') . '.'];
}

if (isset($notices[$msg])):
    [$nt, $nm] = $notices[$msg];
?>
<div class="notice notice-<?= $nt ?>">
    <?= $nt === 'ok' ? '<svg class="icon"><use href="#icon-check"></use></svg>' : '<svg class="icon"><use href="#icon-warning"></use></svg>' ?> <?= $nm ?>
</div>
<?php endif; ?>

<h1 class="page-title"><?= h(t('Rendszer beállítások')) ?></h1>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- rspamd Bayes-tanulás                                                       -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<details class="sys-sec results-card" id="learning" style="margin-bottom:20px">
    <summary class="results-header"><h2><?= t('rspamd Bayes-tanulás') ?></h2>
        <span class="sys-sec-desc"><?= h(t('A statisztikai spamszűrő tanítási módja és eddig tanult mintái.')) ?></span></summary>
    <div style="padding:18px 20px">

        <div class="filter-hint" style="margin:0 0 16px">
            <?= t('Az rspamd Bayes-szűrője statisztikai alapon tanulja meg, mi a spam és mi a ham (normál levél).') ?>
            <strong><?= t('Éles módban') ?></strong> <?= t('minden felszabadítás ham-példaként, minden törlés (spam) spam-példaként kerül el az rspamd-nek (') ?><code>rspamc learn_ham</code> / <code>rspamc learn_spam</code><?= t('). A tanítás hatása fokozatos: néhány száz minta után érezhető javulás várható.') ?>
            <strong><?= t('Napló-módban') ?></strong> <?= t('a felhasználói döntések csak a tanítási naplóba kerülnek (') ?><code><?= h(LEARN_LOG) ?></code><?= t('), rspamd nem kap visszajelzést - biztonságos tesztelési állapot.') ?>
        </div>

        <?php $live = is_file(LEARN_FLAG); ?>
        <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap">
            <span class="learn-badge <?= $live ? 'learn-live' : 'learn-log' ?>"
                  style="font-size:.9375rem;padding:6px 16px">
                <svg class="icon"><use href="#icon-info"></use></svg> <?= $live ? t('ÉLES tanulás aktív') : t('Napló-mód (tanulás inaktív)') ?>
            </span>
            <form method="post" action="?admin=1">
                <?= csrf_field() ?>
                <input type="hidden" name="admin_action" value="toggle_learning">
                <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                <button type="submit" class="btn <?= $live ? 'btn-danger' : 'btn-primary' ?>">
                    <?= $live ? '<svg class="icon"><use href="#icon-stop"></use></svg> ' . t('Kikapcsol') : '<svg class="icon"><use href="#icon-play"></use></svg> ' . t('Bekapcsol') ?>
                </button>
            </form>
        </div>

        <?php
        $_pw_has = admin_rspamc_pw_present();
        [$_pw_ok, $_pw_msg] = admin_rspamc_pw_check();
        ?>
        <div style="margin-top:18px;padding-top:14px;border-top:1px solid var(--border)">
            <div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap">
                <strong style="font-size:.9rem"><?= h(t('rspamd vezérlő-jelszó')) ?></strong>
                <span style="font-size:.82rem;color:<?= $_pw_has ? '#27ae60' : 'var(--text-subtle)' ?>">
                    <?= $_pw_has ? '<svg class="icon"><use href="#icon-check"></use></svg> ' . h(t('megadva')) : h(t('nincs megadva')) ?>
                </span>
                <span style="font-size:.82rem;color:<?= $_pw_ok ? '#27ae60' : 'var(--danger)' ?>;font-weight:600">
                    <?= $_pw_ok ? '&#9679; ' . h(t('a vezérlő válaszol')) : '&#9679; ' . h(t('a vezérlő NEM válaszol')) ?>
                </span>
                <form method="post" action="?admin=1" style="display:flex;gap:6px;align-items:center;margin-left:auto">
                    <?= csrf_field() ?>
                    <input type="hidden" name="admin_action" value="rspamc_pw">
                    <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                    <input type="password" name="rspamc_pw" autocomplete="new-password"
                           aria-label="<?= h(t('rspamd vezérlő-jelszó')) ?>"
                           placeholder="<?= $_pw_has ? h(t('új jelszó (üres = törlés)')) : h(t('jelszó')) ?>"
                           style="padding:5px;font-size:.78rem;width:170px">
                    <button type="submit" class="btn btn-sm btn-secondary"><?= h(t('Ment')) ?></button>
                </form>
            </div>
            <div style="font-size:.78rem;color:var(--text-subtle);margin-top:8px">
                <?= h(t('Az éles tanulás ezzel a jelszóval hívja az rspamd vezérlőt. Ha hiányzik, a tanulás minden alkalommal csendben megszakad - a jelvény akkor is ÉLES-t mutat. A mentett jelszót a felület soha nem jeleníti meg.')) ?>
                <div style="margin-top:6px"><?= h(t('A jelzés csak azt mutatja, hogy a vezérlő válaszol - a jelszó helyességét NEM ellenőrzi. Az rspamd a localhostot jelszó nélkül is megbízhatónak tekinti (secure_ip), így egy elgépelt jelszó is "válaszol" állapotot mutat.')) ?></div>
                <?php if (!$_pw_ok && $_pw_msg !== ''): ?>
                <div style="margin-top:6px"><code><?= h($_pw_msg) ?></code></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</details>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- Hírnevességi és blokklista-források                                        -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<?php
$_feeds_meta = [
    'otx'      => ['label' => 'AlienVault OTX (IP)',      'unit' => 'IP',   'cadence' => 21600,  'refreshable' => true,  'note' => t('firewalld ipset + rbldnsd DNSBL')],
    'otx_dnsbl'=> ['label' => 'OTX DNSBL (rbldnsd)',     'unit' => 'IP',   'cadence' => 21600,  'refreshable' => false, 'note' => t('OTX-ből automatikusan frissül')],
    'otx_uri'  => ['label' => 'OTX URI (SpamAssassin)',   'unit' => 'host', 'cadence' => 86400,  'refreshable' => true,  'note' => t('URI pontozás, nem blokk (FP-biztos)')],
    'urlhaus'  => ['label' => 'URLhaus (rspamd multimap)','unit' => 'host', 'cadence' => 86400,  'refreshable' => true,  'note' => t('aktív malware terjesztők')],
    'spamhaus' => ['label' => 'Spamhaus DROP',             'unit' => 'CIDR', 'cadence' => 86400,  'refreshable' => true,  'note' => t('spam IP-prefixek, firewalld')],
    'c2'       => ['label' => 'Abuse.ch C2',              'unit' => 'IP',   'cadence' => 86400,  'refreshable' => true,  'note' => t('ThreatFox + Feodo, firewalld')],
    'geoblock' => ['label' => 'Geoblock',                 'unit' => 'CIDR', 'cadence' => 604800, 'refreshable' => true,  'note' => t('ország-szintű blokk, firewalld')],
    'firehol'  => ['label' => 'FireHOL Level 1',          'unit' => 'CIDR', 'cadence' => 86400,  'refreshable' => true,  'note' => t('rspamd IP-reputáció - csak pontoz, nem blokkol')],
    'abuseipdb'=> ['label' => 'AbuseIPDB',                'unit' => 'IP',   'cadence' => 86400,  'refreshable' => true,  'note' => t('rspamd IP-reputáció - csak pontoz, nem blokkol')],
    'et'       => ['label' => 'Emerging Threats',         'unit' => 'IP',   'cadence' => 86400,  'refreshable' => true,  'note' => t('rspamd IP-reputáció - csak pontoz, nem blokkol')],
    'rspamd_rules' => ['label' => 'Community Rspamd Rules', 'unit' => t('kategória'), 'cadence' => 86400, 'refreshable' => true, 'note' => t('martinschaible/rspamd-rules - kéretlen/adathalász minta-egyezés (en/de), csak pontoz')],
    'yara_forge' => ['label' => 'YARA Forge (ClamAV)', 'unit' => t('szabály'), 'cadence' => 86400, 'refreshable' => true, 'note' => t('yarahq.github.io "core" csomag a ClamAV-nak - kb. 4200 szabály. FIGYELEM: kb. 100 MB többlet memória a clamd-ben, és újratöltéskor átmenetileg duplán. Alapértelmezetten kikapcsolva.')],
];
$_fs_label = [
    'otx' => 'AlienVault OTX', 'otx_uri' => 'OTX URI', 'urlhaus' => 'URLhaus',
    'c2' => 'Abuse.ch C2 (ThreatFox + Feodo)', 'abuseipdb' => 'AbuseIPDB',
    'spamhaus' => 'Spamhaus DROP', 'firehol' => 'FireHOL Level 1',
    'et' => 'Emerging Threats', 'geoblock' => 'Geoblock',
    'rspamd_rules' => 'Community Rspamd Rules',
    'yara_forge' => 'YARA Forge (ClamAV)',
];
// Health verdict now comes from feed_health() (src/feed_health.php) so one
// function decides ok/stale/old/collapsed/unknown for the whole product,
// instead of this view re-deriving staleness from age alone.
$_fst_labels = ['ok' => 'OK', 'stale' => t('Elavult'), 'old' => t('Régi'), 'unknown' => '?', 'collapsed' => t('Összeomlott')];
$_fst_colors = ['ok' => '#27ae60', 'stale' => 'var(--warning)', 'old' => 'var(--danger)', 'unknown' => 'var(--text-subtle)', 'collapsed' => 'var(--danger)'];
// Spamhaus DQS isn't in $_feeds_meta / $feed_sources -- it has no cron
// cadence or qa-feeds-config.sh entry, so it gets its own row appended after
// the loop below rather than threaded through the shared rendering (that row
// has no count/updated/toggle/refresh, and reusing the loop for one source
// with a different shape was how the yaraify and ClamAV status bugs
// happened). It IS counted in this header's numerator/denominator explicitly
// so "N aktív / M forrás" stays honest instead of undercounting by one.
$_shdqs      = admin_spamhaus_status();
$_abusix     = admin_abusix_status();
$_abusix_has = !empty($_abusix['has_key']);

// Green means "answering", not "configured". A key Abusix does not accept, or a
// resolver that cannot reach them, leaves the feed silently inert -- and this
// row used to show that as green "aktív" purely because the config file was on
// disk, which is the one thing that is never in doubt.
$_abusix_state = (string)($_abusix['state'] ?? 'unknown');
$_abusix_hint  = '';
if (!$_abusix_has) {
    $_abusix_dot   = 'var(--text-subtle)';
    $_abusix_label = t('nincs beállítva');
} elseif (!empty($_abusix['reachable'])) {
    $_abusix_dot   = '#27ae60';
    $_abusix_label = t('aktív');
} else {
    $_abusix_dot   = '#c0392b';
    $_abusix_label = t('nem válaszol');
    $_abusix_hint  = $_abusix_state === 'rejected'
        ? t('az Abusix nem fogadja el a kulcsot')
        : ($_abusix_state === 'unreachable'
            ? t('a DNS-feloldó nem éri el az Abusix névszervereit')
            : t('a kulcs nem olvasható ki a beállításból'));
}
// Spamhaus DQS gets the same treatment as Abusix directly below it, for the
// same reason -- and because two adjacent dots drawn the same way must not mean
// different things. Its helper runs the identical probe.
$_shdqs_has   = !empty($_shdqs['has_key']);
$_shdqs_state = (string)($_shdqs['state'] ?? 'unknown');
$_shdqs_hint  = '';
if (!$_shdqs_has) {
    $_shdqs_dot   = 'var(--text-subtle)';
    $_shdqs_label = t('nincs beállítva');
} elseif (!empty($_shdqs['reachable'])) {
    $_shdqs_dot   = '#27ae60';
    $_shdqs_label = t('aktív');
} else {
    $_shdqs_dot   = '#c0392b';
    $_shdqs_label = t('nem válaszol');
    $_shdqs_hint  = $_shdqs_state === 'rejected'
        ? t('a Spamhaus nem szolgálja ki ezt a kulcsot')
        : ($_shdqs_state === 'unreachable'
            ? t('a DNS-feloldó nem éri el a Spamhaus névszervereit')
            : t('a kulcs nem olvasható ki a beállításból'));
}
// Pre-existing bug, surfaced (not introduced) by adding the DQS row: a plain
// count(array_filter($feed_sources, ...)) undercounts because otx_dnsbl has
// no qa-feeds-config.sh entry (not independently toggleable -- it's derived
// from OTX) and so is absent from $feed_sources entirely, even though its
// row below always renders "aktív". Same "$fv !== null ? enabled : true"
// expression as the row loop's $en (line ~262), evaluated here up front so
// the header total agrees with what the rows actually display -- if that
// per-source default ever changes, change it in both places.
$_feeds_active = 0;
foreach ($_feeds_meta as $_fk => $_fm) {
    $_fv = $feed_sources[$_fk] ?? null;
    if ($_fv !== null ? !empty($_fv['enabled']) : true) $_feeds_active++;
}
// DQS and Abusix are the two rows rendered outside $_feeds_meta, so they are
// added by hand -- both to the count and to the total. The total said "+ 1"
// while two such rows were being drawn, which understated it by one from the
// moment the Abusix row was added.
//
// They count as active only when the probe actually answered. "Active" here
// has to mean the same thing the dot beside the row means, or the header
// contradicts the table it summarises.
if (!empty($_shdqs['reachable']))  $_feeds_active++;
if (!empty($_abusix['reachable'])) $_feeds_active++;
$_feeds_total = count($_feeds_meta) + 2;
?>
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- rspamd modulok — lazily loaded                                             -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<?php
// Deliberately does NOT call admin_rspamd_modules() here. The section is
// collapsed by default, and building the list costs a full `rspamadm
// configdump` (~870ms) -- paid on every page load for a table most loads never
// show. The rows are fetched from ?rmods=1 the first time the section is
// expanded; see loadRspamdModules() in layout_foot.php.
?>
<details class="sys-sec results-card" id="rspamdmods" style="margin-bottom:20px">
    <summary class="results-header">
        <h2><?= h(t('rspamd modulok')) ?></h2>
        <span class="sys-sec-desc"><?= h(t('A levélvizsgáló egyes moduljainak be- és kikapcsolása.')) ?></span>
        <span class="meta" id="rmods-meta"><?= h(t('kinyitáskor töltődik be')) ?></span>
    </summary>

    <div class="filter-hint" style="margin:12px 20px 0">
        <?= h(t('A modul kikapcsolása azonnal érvényes: a beállítás az rspamd konfigurációjába kerül, a rendszer ellenőrzi, hogy értelmezhető-e, és csak utána tölti újra. Ha a változtatás hibás konfigurációt eredményezne, a rendszer visszaállítja az előző állapotot, így az rspamd nem tud elindíthatatlanná válni.')) ?>
        <br><br>
        <strong><?= h(t('A zárral jelölt modulok nem kapcsolhatók ki.')) ?></strong>
        <?= h(t('Ezek nélkül a rendszer nem úgy hibásodik meg, hogy "egy modul ki van kapcsolva", hanem csendben: eltűnik a pontszám-fejléc az archívumból, a szerver pontozni kezdi a saját hitelesített leveleit, a vírusos levél kézbesíthetővé válik, vagy megszűnik a blokk- és fehérlista.')) ?>
    </div>

    <div id="rmods-body" style="padding:12px 20px 16px">
        <span style="color:var(--text-subtle);font-size:.85rem"><?= h(t('Betöltés…')) ?></span>
    </div>
</details>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- Magyar spam-osztályozó — kísérleti, önálló rspamd kiegészítő modul         -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<?php
$_huc = admin_hu_classify_status();
$_huc_days = $_huc['days_enabled'] ?? null;
?>
<?php if (!empty($_huc['installed'])): ?>
<details class="sys-sec results-card" id="huclassify" style="margin-bottom:20px">
    <summary class="results-header">
        <h2><?= h(t('Nyelv-alapú spam-jelzők (magyar + angol, kísérleti)')) ?></h2>
        <span class="sys-sec-desc"><?= h(t('Nyelvfelismerés és szöveg-természetesség vizsgálat magyar és angol levelekhez.')) ?></span>
        <span class="meta">
            <span style="display:inline-flex;align-items:center;gap:5px;font-weight:600;
                         color:<?= !empty($_huc['enabled']) ? '#27ae60' : 'var(--text-subtle)' ?>">
                <span style="width:8px;height:8px;border-radius:50%;flex-shrink:0;display:inline-block;
                             background:<?= !empty($_huc['enabled']) ? '#27ae60' : 'var(--text-subtle)' ?>"></span>
                <?= !empty($_huc['enabled']) ? h(t('bekapcsolva')) : h(t('kikapcsolva')) ?>
            </span>
        </span>
    </summary>

    <?php
        $_hum  = admin_hu_classify_measurement();
        $_hub  = (float)($_hum['spam_base_rate'] ?? 0);
        $_huw  = admin_hu_classify_weights();
        $_husig = [
            'hu_language'    => 'HU_LANGUAGE',
            'hu_naturalness' => 'HU_NATURALNESS',
            'en_language'    => 'EN_LANGUAGE',
            'en_naturalness' => 'EN_NATURALNESS',
            'hu_spam'        => 'HU_SPAM',
        ];
    ?>
    <div class="filter-hint" style="margin:12px 20px 0">
        <?= h(t('Önálló rspamd-modul, nem a fenti listából: minden levélhez lefuttat egy nyelvfelismerést és egy „összefüggő szöveg vagy összekevert karakterhalmaz” vizsgálatot, valamint egy szövegalapú spam-pontszámot, egy erre a gépre telepített különálló szolgáltatáson keresztül.')) ?>
        <br><br>
        <strong><?= h(t('Miért van még megfigyelő módban?')) ?></strong>
        <?= h(t('Mert egy jelzés akkor ér valamit, ha a saját forgalmadon is beválik - nem attól, hogy elméletben jó. Ezért minden jelzés súlya most 0,0: a rendszer minden levélnél kiszámolja és naplózza az értéket, de a besorolást nem befolyásolja. Így kockázat nélkül mérhető, hogy melyik jelzés mennyire válik be ezen a gépen, mielőtt bármelyik beleszólna abba, hogy mi megy spam-be.')) ?>
    </div>

    <?php if (!$_hum): ?>
    <div class="filter-hint" style="margin:12px 20px 0">
        <strong><?= h(t('Még nincs mérési adat ezen a gépen.')) ?></strong>
        <?= h(t('Az első automatikus kiértékelés a következő hónap 1-jén vagy 15-én fut le. Addig a jelzések gyűjtik az adatot, de nincs mit értékelni.')) ?>
    </div>
    <?php else: ?>
    <div style="padding:12px 20px 0">
        <table class="msg-table sys-table" style="table-layout:fixed">
            <colgroup><col style="width:22%"><col style="width:11%"><col style="width:13%"><col style="width:13%"><col style="width:41%"></colgroup>
            <thead><tr>
                <th scope="col"><?= h(t('Jelzés')) ?></th>
                <th scope="col" title="<?= h(t('0,50 = semmilyen információ. Minél távolabb van 0,50-től, annál jobban elkülöníti a spamet a jó levéltől.')) ?>"><?= h(t('Elkülönítés')) ?></th>
                <th scope="col"><?= h(t('Spam átlag')) ?></th>
                <th scope="col"><?= h(t('Jó levél átlag')) ?></th>
                <th scope="col"><?= h(t('Értékelés')) ?></th>
            </tr></thead>
            <tbody>
            <?php foreach ($_husig as $_k => $_label):
                $_m = $_hum['signals'][$_k] ?? null;
                if (!$_m) continue;
                [$_tier, $_advice] = admin_hu_classify_advice($_k, $_m, $_hub);
                $_col = $_tier === 'candidate' ? '#27ae60' : ($_tier === 'watch' ? 'var(--text)' : 'var(--text-subtle)');
            ?>
                <?php
                    $_w      = (float)($_huw[$_label] ?? 0);
                    $_block  = admin_hu_classify_block_reason($_k, $_m);
                    // An already-active signal must ALWAYS be switchable back
                    // to observation, even if its measurement has since fallen
                    // below the activation bar -- otherwise a signal that
                    // degrades could never be turned off from here.
                    $_can_edit = ($_block === '' || $_w != 0);
                ?>
                <tr>
                    <td><code style="font-size:.85em"><?= h($_label) ?></code>
                        <?php if ($_w != 0): ?>
                        <br><span style="font-size:.75rem;color:#27ae60;font-weight:600"><?= h(sprintf(t('éles, súly %s'), qa_num($_w, 2))) ?></span>
                        <?php endif; ?>
                    </td>
                    <td style="font-weight:600;color:<?= $_col ?>"><?= h(qa_num((float)$_m['auc'])) ?></td>
                    <td><?= h(qa_num((float)$_m['spam_median'])) ?></td>
                    <td><?= h(qa_num((float)$_m['ham_median'])) ?></td>
                    <td style="font-size:.85em">
                        <?= h($_advice) ?>
                        <form method="post" style="margin-top:6px;display:flex;gap:6px;align-items:center;flex-wrap:wrap"
                              <?= $_can_edit ? '' : 'title="' . h($_block) . '"' ?>>
                            <?= csrf_field() ?>
                            <input type="hidden" name="admin_action" value="hu_classify_weight">
                            <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                            <input type="hidden" name="hu_weight_sym" value="<?= h($_label) ?>">
                            <input type="number" name="hu_weight_val" step="0.1" min="-5" max="5"
                                   value="<?= h($_w != 0 ? number_format($_w, 1, '.', '') : (($_m['direction'] ?? 'spam') === 'ham' ? '-1.0' : '1.0')) ?>"
                                   style="width:78px" aria-label="<?= h(t('Súly')) ?>"
                                   <?= $_can_edit ? '' : 'disabled' ?>>
                            <button type="submit" class="btn btn-sm <?= $_w != 0 ? 'btn-secondary' : 'btn-primary' ?>"
                                    <?= $_can_edit ? '' : 'disabled title="' . h($_block) . '"' ?>>
                                <?= $_w != 0 ? h(t('Módosít')) : h(t('Élesítés')) ?>
                            </button>
                            <?php if ($_w != 0): ?>
                            <button type="submit" name="hu_weight_val" value="0" class="btn btn-sm btn-secondary"><?= h(t('Vissza megfigyelésre')) ?></button>
                            <?php endif; ?>
                        </form>
                        <?php if (!$_can_edit): ?>
                        <div style="font-size:.75rem;color:var(--text-subtle);margin-top:3px"><?= h($_block) ?></div>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <form method="post" style="float:right;margin:6px 0 0">
            <?= csrf_field() ?>
            <input type="hidden" name="admin_action" value="hu_classify_measure">
            <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
            <button type="submit" class="btn btn-sm btn-secondary"><?= h(t('Újramérés most')) ?></button>
        </form>
        <p class="filter-hint" style="margin:8px 0 0">
            <?= h(sprintf(t('Mérve ezen a gépen: %1$d spam / %2$d jó levél, %3$s. A valós spam-arány a forgalomban %4$s%%.'),
                (int)($_hum['n_spam'] ?? 0), (int)($_hum['n_ham'] ?? 0),
                date('Y-m-d H:i', (int)($_hum['measured_at'] ?? 0)),
                number_format($_hub * 100, 1))) ?>
        </p>
    </div>

    <div class="filter-hint" style="margin:12px 20px 0">
        <strong><?= h(t('Mikor érdemes élesíteni egy jelzést?')) ?></strong>
        <?= h(sprintf(t('Akkor, ha az elkülönítése tartósan 0,70 fölött (vagy 0,30 alatt) van, és a mérés több cikluson át ugyanezt mutatja - nem egyetlen jó eredmény alapján. A döntő kérdés viszont nem ez, hanem hogy a valós %s%%-os spam-arány mellett hány jó levelet jelölne meg tévesen: egy kiegyensúlyozott teszten erősnek látszó jelzés is okozhat több kárt, mint hasznot, ha a forgalom nagy része jó levél. Ezt a kéthetente érkező e-mail számolja ki.'), number_format($_hub * 100, 0))) ?>
        <br><br>
        <?= h(t('Az „Élesítés” gomb minden jelzésnél ott van, de csak akkor kattintható, ha a jelzés eléri ezt a szintet - a többinél kiszürkítve látszik, és a mellette lévő szöveg megírja, mi hiányzik. A megadott súly szorzóként működik: a levél végső pontszámához a súly és a jelzés értékének szorzata adódik hozzá, tehát egy bizonytalan jelzés magától keveset nyom a latban.')) ?>
        <br><br>
        <?= h(t('A nyelvfelismerés (HU_LANGUAGE, EN_LANGUAGE) elvi okból nem kap pontszámot: az, hogy egy levél milyen nyelvű, a feladó tulajdonsága, nem a szándéké - pontozni egy egész nyelvet büntetne.')) ?>
    </div>
    <?php endif; ?>

    <div class="filter-hint" style="margin:12px 20px 0">
        <?= h(t('A ki- és bekapcsolás azonnali: a modul minden levélnél újra megnézi a kapcsoló állását, nincs szükség rspamd-újratöltésre. Kikapcsolt állapotban a háttérszolgáltatás is leáll, memóriát nem használ.')) ?>
        <br><br>
        <strong><?= h(t('Kéthetente automatikus kiértékelés és értesítés.')) ?></strong>
        <?= h(t('A rendszer minden hónap 1-jén és 15-én újraméri a jelzéseket - olyan leveleken, amelyeket a modell korábban nem látott -, majd e-mailt küld az alábbi címre a fenti táblázat friss változatával és a javaslattal. A súlyozáson magától semmi nem változik.')) ?>
        <?php if (!empty($_huc['last_report'])): ?>
            <br><br><?= h(sprintf(t('Utolsó elküldött értesítés: %s'), (string)$_huc['last_report'])) ?>
        <?php endif; ?>
    </div>

    <div style="padding:12px 20px 0;display:flex;gap:10px;align-items:center;flex-wrap:wrap">
        <form method="post" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
            <?= csrf_field() ?>
            <input type="hidden" name="admin_action" value="hu_classify_report_email">
            <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
            <label for="hu_report_email" style="font-size:.85rem"><?= h(t('Értesítési cím')) ?></label>
            <input type="email" id="hu_report_email" name="hu_report_email" style="min-width:240px"
                   value="<?= h(($_huc['report_email_source'] ?? '') === 'explicit' ? (string)($_huc['report_email'] ?? '') : '') ?>"
                   placeholder="<?= h(($_huc['report_email_source'] ?? '') === 'inherited'
                        ? sprintf(t('%s (a riasztási címről)'), (string)($_huc['report_email'] ?? ''))
                        : t('nincs beállítva - nem küld értesítést')) ?>">
            <button type="submit" class="btn btn-sm btn-secondary"><?= h(t('Mentés')) ?></button>
            <span style="font-size:.78rem;color:var(--text-muted)">
                <?= h(t('Üresen hagyva az Admin lapon beállított riasztási címre megy. Ha az sincs beállítva, nem megy értesítés.')) ?>
            </span>
        </form>
    </div>

    <div style="padding:12px 20px 16px;display:flex;gap:10px;align-items:center;flex-wrap:wrap">
        <form method="post" style="display:inline">
            <?= csrf_field() ?>
            <input type="hidden" name="admin_action" value="hu_classify_toggle">
            <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
            <input type="hidden" name="hu_classify_on" value="<?= !empty($_huc['enabled']) ? '0' : '1' ?>">
            <button type="submit" class="btn btn-sm btn-secondary">
                <?= !empty($_huc['enabled']) ? h(t('Kikapcsolás')) : h(t('Bekapcsolás')) ?>
            </button>
        </form>
    </div>
</details>
<?php endif; ?>

<details class="sys-sec results-card" id="feeds" style="margin-bottom:20px">
    <summary class="results-header">
        <h2><?= t('Hírnevességi és blokklista-források') ?></h2>
        <span class="sys-sec-desc"><?= h(t('Külső IP- és URL-blokklisták állapota, kora és kézi frissítése.')) ?></span>
        <span class="meta"><?= h(sprintf(t('%d aktív / %d forrás'), $_feeds_active, $_feeds_total)) ?></span>
    </summary>
    <div class="filter-hint" style="margin:16px 20px 4px">
        <?= t('Az alábbi forrásokat a rendszer automatikusan frissíti (cron). Az') ?> <strong><?= t('Azonnali frissítés') ?></strong>
        <?= t('gomb háttérben indítja el a letöltő szkriptet - az eredmény néhány perc múlva látható. Az') ?> <em><?= t('Állapot') ?></em> <?= t('a legutóbbi frissítés korát mutatja a várt frissítési ütemhez képest. Egy forrás csak akkor kapcsolható be, ha van hozzá API-kulcs - a kulcs nélküli forrás minden futáskor eredmény nélkül lépne ki. A mentett kulcsot a felület soha nem jeleníti meg.') ?>
    </div>
    <?php if (empty($admin_feeds) && empty($feed_sources)): ?>
    <div class="empty-state"><p><?= t('A forrásállapot nem elérhető (ellenőrizze a sudo-konfigurációt).') ?></p></div>
    <?php else: ?>
    <table class="msg-table sys-table" style="table-layout:fixed">
        <colgroup>
            <col style="width:20%">
            <col style="width:9%">
            <col style="width:7%">
            <col style="width:16%">
            <col style="width:10%">
            <col style="width:11%">
            <col style="width:27%">
        </colgroup>
        <thead>
            <tr>
                <th scope="col"><?= t('Forrás') ?></th>
                <th scope="col"><?= t('Bejegyzés') ?></th>
                <th scope="col"><?= t('Egység') ?></th>
                <th scope="col"><?= t('Frissítve') ?></th>
                <th scope="col"><?= t('Állapot') ?></th>
                <th scope="col"><?= t('API-kulcs') ?></th>
                <th scope="col"><?= t('Kezelés') ?></th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($_feeds_meta as $fk => $fm):
            $fd  = $admin_feeds[$fk] ?? [];
            // Called unconditionally: feed_health() handles a missing status on
            // its own -- with an empty $status there is no 'count' key, so its
            // $hasCount guard is false and the collapse branch is unreachable;
            // the verdict falls back to 'unknown' from age alone. What the
            // cells actually print is still decided by the $fd ? ... : '-'
            // ternaries below.
            $fh  = feed_health($fk, $fd, $fm['cadence']);
            $st  = $fh['state'];
            $sc  = $_fst_colors[$st] ?? 'var(--text-subtle)';
            // Trend arrow for the Bejegyzés cell: only meaningful once a
            // baseline exists (same FEED_BASELINE_MIN_DAYS gate feed_health()
            // itself uses for collapse). +-5% of baseline reads as flat.
            $_trend = '';
            if ($fd && $fh['baseline'] !== null && $fh['pct'] !== null) {
                if ($fh['pct'] > 105)     $_trend = '↑';
                elseif ($fh['pct'] < 95)  $_trend = '↓';
                else                      $_trend = '→';
            }
            // feed_health() already fetched and daily-bucketed these rows --
            // one point per 24h, so at most 14 numbers, not one per hourly
            // sample. Still gated on $fd: a feed with no status gets no tooltip.
            $_hist       = $fd ? $fh['history'] : [];
            $_hist_title = $_hist
                ? t('Előzmény (14 nap): ') . implode(' → ', array_map(
                      static fn($c) => number_format($c), $_hist))
                : '';
            // Alapszint below is the median of these same daily points, so the
            // two tooltips reconcile against one series.
            $_st_title = '';
            if ($fh['baseline'] !== null) {
                $_st_title = $fh['pct'] !== null
                    ? sprintf(t('Alapszint: %s, jelenleg: %d%%'), number_format($fh['baseline']), $fh['pct'])
                    : sprintf(t('Alapszint: %s'), number_format($fh['baseline']));
            }
            $fv  = $feed_sources[$fk] ?? null;
            // A source's enabled flag lives in $feed_sources, not $admin_feeds
            // (status only) -- default true so a source absent from $feed_sources
            // (e.g. otx_dnsbl, which isn't independently toggleable) isn't wrongly
            // greyed out.
            $en    = $fv !== null ? !empty($fv['enabled']) : true;
            $needs = $fv !== null && !empty($fv['needs_key']);
            $has   = $fv !== null && !empty($fv['has_key']);
        ?>
        <tr class="data-row">
            <td data-label="<?= h(t('Forrás')) ?>">
                <strong><?= h($_fs_label[$fk] ?? $fm['label']) ?></strong>
                <div style="font-size:.75rem;color:var(--text-subtle);margin-top:2px"><?= h($fm['note']) ?></div>
            </td>
            <td data-label="<?= h(t('Bejegyzés')) ?>" style="font-variant-numeric:tabular-nums;font-weight:600"
                <?= $_hist_title !== '' ? 'title="' . h($_hist_title) . '"' : '' ?>>
                <?= $fd ? number_format((int)($fd['count'] ?? 0)) : '-' ?>
                <?php if ($_trend !== ''): ?><span style="font-weight:400;color:var(--text-subtle)"><?= h($_trend) ?></span><?php endif; ?>
            </td>
            <td data-label="<?= h(t('Egység')) ?>" style="font-size:.8rem;color:var(--text-muted)"><?= h($fm['unit']) ?></td>
            <td data-label="<?= h(t('Frissítve')) ?>" style="font-size:.8rem">
                <?= $fd ? h($fd['updated'] ?? '-') : '-' ?>
                <?php if ($fk === 'otx_dnsbl' && isset($fd['svc'])): ?>
                <span style="display:block;font-size:.7rem;color:var(--text-subtle)">
                    rbldnsd: <?= h($fd['svc']) ?>
                </span>
                <?php endif; ?>
            </td>
            <td data-label="<?= h(t('Állapot')) ?>">
                <span style="display:flex;flex-wrap:wrap;align-items:center;gap:5px;font-size:.8rem;
                             color:<?= $sc ?>;font-weight:600;max-width:100%"
                      <?= $_st_title !== '' ? 'title="' . h($_st_title) . '"' : '' ?>>
                    <span style="width:8px;height:8px;border-radius:50%;background:<?= $sc ?>;
                                 flex-shrink:0;display:inline-block"></span>
                    <span style="overflow-wrap:anywhere;min-width:0"><?= h($_fst_labels[$st] ?? '?') ?></span>
                </span>
            </td>
            <td data-label="<?= h(t('API-kulcs')) ?>" style="font-size:.8rem">
                <?php if ($fv === null): ?>
                <span style="color:var(--text-subtle)"><?= h(t('nem szükséges')) ?></span>
                <?php elseif (!$needs): ?><span style="color:var(--text-subtle)"><?= h(t('nem szükséges')) ?></span>
                <?php elseif ($has): ?><span style="color:#27ae60"><svg class="icon"><use href="#icon-check"></use></svg> <?= h(t('megadva')) ?></span>
                <?php else: ?><span style="color:var(--warning);font-weight:600"><?= h(t('hiányzik')) ?></span><?php endif; ?>
            </td>
            <td data-label="<?= h(t('Kezelés')) ?>">
                <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">
                    <?php if ($fv !== null): ?>
                    <form method="post" action="?admin=1" style="display:inline">
                        <?= csrf_field() ?>
                        <input type="hidden" name="admin_action" value="feed_toggle">
                        <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                        <input type="hidden" name="feed_src" value="<?= h($fk) ?>">
                        <input type="hidden" name="feed_on" value="<?= $en ? '0' : '1' ?>">
                        <button type="submit" class="btn btn-sm <?= $en ? 'btn-secondary' : 'btn-primary' ?>"
                            <?= (!$en && $needs && !$has) ? 'disabled title="' . h(t('Előbb adjon meg API-kulcsot.')) . '"' : '' ?>>
                            <?= $en ? h(t('Kikapcsol')) : h(t('Bekapcsol')) ?>
                        </button>
                    </form>
                    <?php if ($needs): ?>
                    <form method="post" action="?admin=1" style="display:flex;gap:6px;align-items:center">
                        <?= csrf_field() ?>
                        <input type="hidden" name="admin_action" value="feed_key">
                        <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                        <input type="hidden" name="feed_src" value="<?= h($fk) ?>">
                        <input type="password" name="feed_key" autocomplete="new-password"
                               aria-label="<?= h(t('API-kulcs')) ?>"
                               placeholder="<?= $has ? h(t('új kulcs (üres = törlés)')) : h(t('API-kulcs')) ?>"
                               style="padding:5px;font-size:.78rem;width:150px">
                        <button type="submit" class="btn btn-sm btn-secondary"><?= h(t('Ment')) ?></button>
                    </form>
                    <?php endif; ?>
                    <?php if ($fk === 'geoblock'): ?>
                    <form method="post" action="?admin=1" style="display:flex;gap:6px;align-items:center">
                        <?= csrf_field() ?>
                        <input type="hidden" name="admin_action" value="geoblock_set_countries">
                        <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                        <input type="text" name="geoblock_countries"
                               value="<?= h($geoblock_countries) ?>"
                               aria-label="<?= h(t('Blokkolt országkódok')) ?>"
                               placeholder="ru cn br kr"
                               <?= !$en ? 'disabled' : '' ?>
                               style="padding:5px;font-size:.78rem;width:150px">
                        <button type="submit" class="btn btn-sm btn-secondary" <?= !$en ? 'disabled' : '' ?>><?= h(t('Ment')) ?></button>
                    </form>
                    <?php endif; ?>
                    <?php endif; ?>
                    <?php if ($fm['refreshable'] && $en): ?>
                    <form method="post" action="?admin=1"
                          onsubmit="return confirm('<?= t('Elindítja a(z)') ?> <?= h(addslashes($fm['label'])) ?> <?= t('azonnali frissítését?') ?>\n\n<?= t('A folyamat a háttérben fut, néhány percig tarthat.') ?>')">
                        <?= csrf_field() ?>
                        <input type="hidden" name="admin_action" value="feed_refresh">
                        <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                        <input type="hidden" name="feed_name"    value="<?= h($fk) ?>">
                        <button type="submit" class="btn btn-sm btn-secondary"><svg class="icon"><use href="#icon-refresh"></use></svg> <?= t('Frissít') ?></button>
                    </form>
                    <?php elseif ($fm['refreshable']): ?>
                    <span style="font-size:.75rem;color:var(--text-subtle)" title="<?= h(t('A forrás ki van kapcsolva')) ?>"><?= t('kikapcsolva') ?></span>
                    <?php else: ?>
                    <span style="font-size:.75rem;color:var(--text-subtle)">auto</span>
                    <?php endif; ?>
                </div>
            </td>
        </tr>
        <?php endforeach; ?>
        <tr class="data-row">
            <td data-label="<?= h(t('Forrás')) ?>">
                <strong>Spamhaus DQS</strong>
                <div style="font-size:.75rem;color:var(--text-subtle);margin-top:2px"><?= h(t('rspamd RBL (ZEN, DBL) + ZRD - fiókkulcsos, élő lekérdezés')) ?></div>
            </td>
            <td data-label="<?= h(t('Bejegyzés')) ?>">-</td>
            <td data-label="<?= h(t('Egység')) ?>" style="font-size:.8rem;color:var(--text-muted)">-</td>
            <td data-label="<?= h(t('Frissítve')) ?>" style="font-size:.8rem">
                <span style="color:var(--text-subtle)"><?= h(t('nincs értelmezve (élő DNS-lekérdezés minden levélnél)')) ?></span>
            </td>
            <td data-label="<?= h(t('Állapot')) ?>">
                <span style="display:flex;align-items:center;gap:5px;font-size:.8rem;font-weight:600;
                             color:<?= $_shdqs_dot ?>">
                    <span style="width:8px;height:8px;border-radius:50%;flex-shrink:0;display:inline-block;
                                 background:<?= $_shdqs_dot ?>"></span>
                    <?= h($_shdqs_label) ?>
                </span>
                <?php if ($_shdqs_hint !== ''): ?>
                    <div style="font-size:.72rem;color:var(--text-muted);margin-top:2px;max-width:22ch;overflow-wrap:anywhere">
                        <?= h($_shdqs_hint) ?></div>
                <?php endif; ?>
            </td>
            <td data-label="<?= h(t('API-kulcs')) ?>" style="font-size:.8rem">
                <?php if ($_shdqs_has): ?><span style="color:#27ae60"><svg class="icon"><use href="#icon-check"></use></svg> <?= h(t('megadva')) ?></span>
                <?php else: ?><span style="color:var(--text-subtle)"><?= h(t('nincs megadva')) ?></span><?php endif; ?>
            </td>
            <td data-label="<?= h(t('Kezelés')) ?>">
                <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">
                    <form method="post" action="?admin=1" style="display:flex;gap:6px;align-items:center">
                        <?= csrf_field() ?>
                        <input type="hidden" name="admin_action" value="spamhaus_key">
                        <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                        <input type="password" name="spamhaus_key" autocomplete="new-password"
                               aria-label="<?= h(t('Spamhaus DQS fiókkulcs')) ?>"
                               placeholder="<?= $_shdqs_has ? h(t('új kulcs (üres = törlés)')) : h(t('DQS fiókkulcs')) ?>"
                               style="padding:5px;font-size:.78rem;width:150px">
                        <button type="submit" class="btn btn-sm btn-secondary"><?= h(t('Ment')) ?></button>
                    </form>
                    <?php if ($_shdqs_has): ?>
                    <form method="post" action="?admin=1">
                        <?= csrf_field() ?>
                        <input type="hidden" name="admin_action" value="spamhaus_test">
                        <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                        <button type="submit" class="btn btn-sm btn-secondary"><?= h(t('Teszt')) ?></button>
                    </form>
                    <?php endif; ?>
                </div>
            </td>
        </tr>
        <tr class="data-row">
            <td data-label="<?= h(t('Forrás')) ?>" style="font-weight:600">Abusix Mail Intelligence</td>
            <td data-label="<?= h(t('Bejegyzés')) ?>" style="font-size:.8rem;color:var(--text-muted)">-</td>
            <td data-label="<?= h(t('Egység')) ?>" style="font-size:.8rem;color:var(--text-muted)">-</td>
            <td data-label="<?= h(t('Frissítve')) ?>" style="font-size:.8rem">
                <span style="color:var(--text-subtle)"><?= h(t('nincs értelmezve (élő DNS-lekérdezés minden levélnél)')) ?></span>
            </td>
            <td data-label="<?= h(t('Állapot')) ?>">
                <span style="display:flex;align-items:center;gap:5px;font-size:.8rem;font-weight:600;
                             color:<?= $_abusix_dot ?>">
                    <span style="width:8px;height:8px;border-radius:50%;flex-shrink:0;display:inline-block;
                                 background:<?= $_abusix_dot ?>"></span>
                    <?= h($_abusix_label) ?>
                </span>
                <?php if ($_abusix_hint !== ''): ?>
                    <div style="font-size:.72rem;color:var(--text-muted);margin-top:2px;max-width:22ch;overflow-wrap:anywhere">
                        <?= h($_abusix_hint) ?></div>
                <?php endif; ?>
            </td>
            <td data-label="<?= h(t('API-kulcs')) ?>" style="font-size:.8rem">
                <?php if ($_abusix_has): ?><span style="color:#27ae60"><svg class="icon"><use href="#icon-check"></use></svg> <?= h(t('megadva')) ?></span>
                <?php else: ?><span style="color:var(--text-subtle)"><?= h(t('nincs megadva')) ?></span><?php endif; ?>
            </td>
            <td data-label="<?= h(t('Kezelés')) ?>">
                <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">
                    <form method="post" action="?admin=1" style="display:flex;gap:6px;align-items:center">
                        <?= csrf_field() ?>
                        <input type="hidden" name="admin_action" value="abusix_key">
                        <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                        <input type="password" name="abusix_key" autocomplete="new-password"
                               aria-label="<?= h(t('Abusix datafeed kulcs')) ?>"
                               placeholder="<?= $_abusix_has ? h(t('új kulcs (üres = törlés)')) : h(t('datafeed kulcs')) ?>"
                               style="padding:5px;font-size:.78rem;width:150px">
                        <button type="submit" class="btn btn-sm btn-secondary"><?= h(t('Ment')) ?></button>
                    </form>
                    <?php if ($_abusix_has): ?>
                    <form method="post" action="?admin=1">
                        <?= csrf_field() ?>
                        <input type="hidden" name="admin_action" value="abusix_test">
                        <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                        <button type="submit" class="btn btn-sm btn-secondary"><?= h(t('Teszt')) ?></button>
                    </form>
                    <?php endif; ?>
                </div>
            </td>
        </tr>
        </tbody>
    </table>
    <div class="filter-hint" style="margin:4px 20px 16px">
        <?= h(t('A Spamhaus DQS nem letöltött lista, hanem élő DNS-lekérdezés minden levélnél (ezért nincs Bejegyzés/Frissítve értéke és nincs Azonnali frissítés gombja) - fiókkulcsos hozzáférés a nyilvános Spamhaus-zónákhoz (ZEN) és a ZRD (frissen regisztrált domain) jelzéshez. A kulcs beszerzéséről lásd a Névjegy oldalt.')) ?>
    </div>
    <div class="filter-hint" style="margin:4px 20px 16px">
        <strong><?= h(t('Abusix: a kulcs önmagában elég, IP-engedélyezés nem kell.')) ?></strong>
        <?= h(t('A lekérdezést maga a kulcs hitelesíti: mérve, hogy olyan szerverről is válaszol, amelynek IP-címe soha nem került be az Abusix portálba. IP-engedélyezésre tehát nincs szükség. (A panel korábbi szövege azt állította, hogy kötelező - ez téves volt.) Ami viszont csendben elnémítja a forrást: el nem fogadott kulcs (elgépelt, visszavont, lejárt előfizetés), vagy olyan DNS-feloldó, amelyik nem éri el az Abusix névszervereit. Mindkettő üres választ ad, ezért az Állapot oszlop élő lekérdezéssel ellenőrzi, hogy a forrás tényleg válaszol-e, és nem csak azt mutatja, hogy van beállított kulcs.')) ?>
    </div>
    <?php endif; ?>
</details>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- Közösségi IP-források                                                      -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<?php
$_cf_err_labels = [
    'fetch_failed'    => t('Nem sikerült letölteni.'),
    'too_few_entries' => t('Túl kevés bejegyzés a tisztítás után.'),
    'write_failed'    => t('Nem sikerült írni az ipset fájlt.'),
];
?>
<?php
$community_data  = admin_community_feeds_load();
$community_feeds = $community_data['feeds'];
// create() refuses on count($feeds) >= COMMUNITY_FEED_MAX, so that's the
// only thing that should hide this form. next_id and the id ceiling
// (COMMUNITY_FEED_MAX_ID) are a separate, much larger concept now -- ids
// are never reused and next_id only ever increases, but the ceiling is far
// above any realistic lifetime creation count, so it is no longer a
// practical dead-end this gate needs to account for (see
// COMMUNITY_FEED_MAX_ID's comment in src/admin.php).
$community_can_create = count($community_feeds) < COMMUNITY_FEED_MAX;
?>
<?php
// Badge for the collapsed state: a folded section must never hide a fault.
// Counts ENABLED slots whose last refresh failed -- a disabled slot is a
// deliberate choice, not a problem, and an as-yet-unrefreshed one (last_ok
// null) has not failed either.
$_cf_bad = count(array_filter($community_feeds,
    fn($c) => !empty($c['enabled']) && isset($c['last_ok']) && $c['last_ok'] === false));
?>
<details class="sys-sec results-card" id="community-feeds" style="margin-bottom:20px">
    <summary class="results-header">
        <h2><?= t('Közösségi IP-források') ?></h2>
        <span class="sys-sec-desc"><?= h(t('Saját, egyedileg megadott IP-blokklisták legfeljebb öt sávban.')) ?></span>
        <?php if ($_cf_bad > 0): ?>
        <span class="sys-sec-flag" title="<?= h(t('A szakaszt kinyitva látja a részleteket.')) ?>">
            <?= sprintf(t('%d forrás hibás'), $_cf_bad) ?>
        </span>
        <?php endif; ?>
    </summary>
    <div class="filter-hint" style="margin:16px 20px 4px">
        <?= sprintf(t('Legfeljebb %d közösségi IP-blokklista adható meg. Minden bekapcsolt sáv naponta frissül; a Frissítés gomb azonnali, háttérben futó frissítést indít.'), COMMUNITY_FEED_MAX) ?>
    </div>
    <table class="msg-table sys-table" style="table-layout:fixed">
        <colgroup><col style="width:14%"><col style="width:8%"><col style="width:20%">
                  <col style="width:10%"><col style="width:16%"><col style="width:12%"><col style="width:14%"><col style="width:6%"></colgroup>
        <thead><tr>
            <th scope="col"><?= t('Címke') ?></th><th scope="col"><?= t('Sáv') ?></th>
            <th scope="col">URL</th><th scope="col"><?= t('Formátum') ?></th>
            <th scope="col"><?= t('Mező-elérési út') ?></th>
            <th scope="col"><?= t('Utolsó frissítés') ?></th><th scope="col"><?= t('Művelet') ?></th>
            <th scope="col"></th>
        </tr></thead>
        <tbody>
        <?php foreach ($community_feeds as $slotNum => $cf):
            $saveFormId = "cf-save-$slotNum";
            $refreshFormId = "cf-refresh-$slotNum";
        ?>
        <tr class="data-row">
                <td><input type="text" name="cf_label" form="<?= $saveFormId ?>" value="<?= h($cf['label']) ?>" maxlength="80" style="width:100%;padding:4px" placeholder="<?= h(t('Címke')) ?>"></td>
                <td style="text-align:center">
                    <input type="checkbox" name="cf_enabled" form="<?= $saveFormId ?>" value="1" <?= $cf['enabled'] ? 'checked' : '' ?>>
                </td>
                <td><input type="text" name="cf_url" form="<?= $saveFormId ?>" value="<?= h($cf['url']) ?>" style="width:100%;padding:4px;font-family:monospace;font-size:.78rem" placeholder="https://..."></td>
                <td>
                    <select name="cf_format" form="<?= $saveFormId ?>" style="width:100%;padding:4px">
                        <?php foreach (['plain', 'json', 'jsonl'] as $fmt): ?>
                        <option value="<?= h($fmt) ?>" <?= $cf['format'] === $fmt ? 'selected' : '' ?>><?= h($fmt) ?></option>
                        <?php endforeach; ?>
                    </select>
                </td>
                <td><input type="text" name="cf_field_path" form="<?= $saveFormId ?>" value="<?= h($cf['field_path']) ?>" style="width:100%;padding:4px;font-family:monospace;font-size:.78rem" placeholder="<?= h(t('csak JSON/JSONL-hez, pl. data.ip')) ?>"></td>
                <td style="font-size:.78rem">
                    <?php if ($cf['last_refresh_at'] !== null): ?>
                        <span class="local-ts" data-ts="<?= (int)$cf['last_refresh_at'] ?>"><?= h(date('Y-m-d H:i', $cf['last_refresh_at'])) ?></span><br>
                        <?php if ($cf['last_ok'] === false): ?>
                        <span style="color:var(--danger)"><?= h($_cf_err_labels[$cf['last_error']] ?? $cf['last_error']) ?></span>
                        <?php else: ?>
                        <span style="color:var(--text-subtle)"><?= (int) $cf['last_count'] ?> <?= t('bejegyzés') ?></span>
                        <?php endif; ?>
                    <?php else: ?>
                        <span style="color:var(--text-subtle)">-</span>
                    <?php endif; ?>
                </td>
                <td>
                    <button type="submit" form="<?= $saveFormId ?>" class="btn btn-sm btn-primary"><?= t('Mentés') ?></button>
                    <?php if ($cf['enabled']): ?>
                    <button type="submit" form="<?= $refreshFormId ?>" class="btn btn-sm btn-secondary"><svg class="icon"><use href="#icon-refresh"></use></svg> <?= t('Frissít') ?></button>
                    <?php endif; ?>
                </td>
                <td style="text-align:center">
                    <button type="submit" form="cf-delete-<?= $slotNum ?>" class="btn btn-sm btn-secondary"
                            onclick="return confirm(<?= h(json_encode(sprintf(
                                t('Törli ezt a forrást? A(z) "%s" forrás %d blokkolt IP-címe azonnal feloldásra kerül.'),
                                $cf['label'] !== '' ? $cf['label'] : ('#' . $slotNum),
                                (int) ($cf['last_count'] ?? 0)
                            ))) ?>)">
                        <svg class="icon"><use href="#icon-trash"></use></svg>
                    </button>
                </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <div style="padding:12px 20px;display:flex;gap:8px;align-items:center;flex-wrap:wrap">
        <?php if ($community_can_create): ?>
        <form method="post" action="?admin=1" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
            <?= csrf_field() ?>
            <input type="hidden" name="admin_action" value="community_feed_create">
            <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
            <input type="text" name="cf_label" maxlength="80" style="padding:5px" placeholder="<?= h(t('Címke')) ?>">
            <input type="text" name="cf_url" style="padding:5px;min-width:260px" placeholder="https://example.org/list.txt">
            <select name="cf_format" style="padding:5px">
                <option value="plain">plain</option>
                <option value="json">json</option>
                <option value="jsonl">jsonl</option>
            </select>
            <input type="text" name="cf_field_path" style="padding:5px;width:120px" placeholder="<?= h(t('mező')) ?>">
            <label style="display:flex;gap:4px;align-items:center;font-size:.8rem">
                <input type="checkbox" name="cf_enabled" value="1"> <?= h(t('Bekapcsolva')) ?>
            </label>
            <button type="submit" class="btn btn-sm btn-primary"><?= h(t('Új forrás')) ?></button>
        </form>
        <?php else: ?>
        <span style="font-size:.8rem;color:var(--text-subtle)">
            <?= h(sprintf(t('Legfeljebb %d forrás vehető fel.'), COMMUNITY_FEED_MAX)) ?>
        </span>
        <?php endif; ?>
        <span style="font-size:.8rem;color:var(--text-subtle)">
            <?= h(sprintf(t('%d / %d forrás'), count($community_feeds), COMMUNITY_FEED_MAX)) ?>
        </span>
    </div>
</details>
<?php foreach ($community_feeds as $slotNum => $cf):
?>
<form id="cf-save-<?= $slotNum ?>" method="post" action="?admin=1" style="display:none">
    <?= csrf_field() ?>
    <input type="hidden" name="admin_action" value="community_feed_save">
    <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
    <input type="hidden" name="cf_slot" value="<?= $slotNum ?>">
</form>
<?php if ($cf['enabled']): ?>
<form id="cf-refresh-<?= $slotNum ?>" method="post" action="?admin=1" style="display:none">
    <?= csrf_field() ?>
    <input type="hidden" name="admin_action" value="community_feed_refresh">
    <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
    <input type="hidden" name="cf_slot" value="<?= $slotNum ?>">
</form>
<?php endif; ?>
<form id="cf-delete-<?= $slotNum ?>" method="post" action="?admin=1" style="display:none">
    <?= csrf_field() ?>
    <input type="hidden" name="admin_action" value="community_feed_delete">
    <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
    <input type="hidden" name="cf_slot" value="<?= $slotNum ?>">
</form>
<?php endforeach; ?>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- IOC-keresési szolgáltatások                                                -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<?php
$ioclookup_sources = admin_ioclookup_sources();
$_il_label = ['virustotal' => 'VirusTotal', 'urlhaus' => 'URLhaus', 'otx' => 'OTX', 'hrbl' => 'HRBL', 'mailspike' => 'Mailspike', 'urlvet' => 'url.vet', 'yaraify' => 'YARAify', 'threatfox' => 'ThreatFox'];
    foreach (array_keys(ioc_lookup_custom_services()) as $_csvc) { $_il_label[$_csvc] = $_csvc; }
// Sources whose key is entered elsewhere (the feed side) rather than here --
// qa-ioclookup-config.sh's set-key refuses all three with "managed from the
// feed sources". yaraify was missing from this set even though it shares
// urlhaus's exact keyfile (/etc/ilexa/secrets/abuse_api_key) and the same
// shell-side refusal: on a host with no abuse.ch key it showed "hiányzik"
// (missing) instead of the correct redirect, and rendered a set-key form
// that would fail on submit. ONE set, referenced by both the status column
// and the set-key form below, so a future addition here can't repeat that --
// two separate `$lk === 'urlhaus' || $lk === 'otx'` literals is how it
// happened the first time. threatfox shares the same abuse.ch keyfile too
// (see qa-ioclookup-config.sh's SOURCES array) so it belongs in this set from
// the start, not bolted on after the same bug resurfaces a third time.
$_il_key_elsewhere = ['urlhaus', 'otx', 'yaraify', 'threatfox'];
?>
<?php if (!empty($ioclookup_sources)): ?>
<?php $psdnsbl = admin_psdnsbl_list(); ?>
<?php if ($psdnsbl !== null): ?>
<details class="sys-sec results-card" id="psdnsbl" style="margin-bottom:20px">
    <summary class="results-header">
        <h2><?= h(t('Postscreen DNSBL listák')) ?></h2>
        <span class="sys-sec-desc"><?= h(t('Bejövő SMTP-kliensek pontozása DNS-blokklistákkal, még a levél átvétele előtt.')) ?></span>
        <span class="meta"><?= h(sprintf(t('%d lista / küszöb: %d'), count($psdnsbl['sites']), (int)$psdnsbl['threshold'])) ?></span>
    </summary>
    <div class="filter-hint" style="margin:16px 20px 4px">
        <?= h(t('A súlyok összeadódnak; a küszöböt elérő kliens kapcsolatát a postscreen elutasítja. Negatív súly fehérlista-zónát jelent. Minden mentés azonnal érvényes (postfix reload).')) ?>
    </div>
    <table class="msg-table sys-table" style="table-layout:fixed">
        <colgroup><col style="width:44%"><col style="width:28%"><col style="width:28%"></colgroup>
        <thead><tr>
            <th scope="col"><?= h(t('DNSBL zóna')) ?></th>
            <th scope="col"><?= h(t('Súly')) ?></th>
            <th scope="col"><?= h(t('Művelet')) ?></th>
        </tr></thead>
        <tbody>
        <?php foreach ($psdnsbl['sites'] as $ps): ?>
        <tr class="data-row">
            <td data-label="<?= h(t('DNSBL zóna')) ?>"><code><?= h($ps['site']) ?></code></td>
            <td data-label="<?= h(t('Súly')) ?>">
                <form method="post" action="?admin=1" style="display:flex;gap:6px;align-items:center">
                    <?= csrf_field() ?>
                    <input type="hidden" name="admin_action" value="psdnsbl_weight">
                    <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                    <input type="hidden" name="psdnsbl_site" value="<?= h($ps['site']) ?>">
                    <input type="number" name="psdnsbl_weight" value="<?= (int)$ps['weight'] ?>" min="-10" max="10"
                           aria-label="<?= h(t('Súly')) ?>" style="padding:5px;width:70px">
                    <button type="submit" class="btn btn-sm btn-secondary"><?= h(t('Ment')) ?></button>
                </form>
            </td>
            <td data-label="<?= h(t('Művelet')) ?>">
                <form method="post" action="?admin=1" style="display:inline"
                      onsubmit="return confirm(<?= h(json_encode(sprintf(t('Eltávolítod a(z) %s listát a postscreenből?'), $ps['site']))) ?>)">
                    <?= csrf_field() ?>
                    <input type="hidden" name="admin_action" value="psdnsbl_remove">
                    <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                    <input type="hidden" name="psdnsbl_site" value="<?= h($ps['site']) ?>">
                    <button type="submit" class="btn btn-sm btn-danger"><?= h(t('Eltávolít')) ?></button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <div style="display:flex;gap:24px;flex-wrap:wrap;align-items:flex-end;padding:12px 20px 16px">
        <form method="post" action="?admin=1" style="display:flex;gap:6px;align-items:flex-end;flex-wrap:wrap">
            <?= csrf_field() ?>
            <input type="hidden" name="admin_action" value="psdnsbl_add">
            <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
            <label style="display:flex;flex-direction:column;font-size:.78rem;gap:2px"><?= h(t('Új DNSBL zóna')) ?>
                <input type="text" name="psdnsbl_site" placeholder="bl.example.org" required
                       pattern="[a-z0-9]([a-z0-9._-]*[a-z0-9])?" style="padding:5px;width:210px"></label>
            <label style="display:flex;flex-direction:column;font-size:.78rem;gap:2px"><?= h(t('Súly')) ?>
                <input type="number" name="psdnsbl_weight" value="2" min="-10" max="10" style="padding:5px;width:70px"></label>
            <button type="submit" class="btn btn-sm btn-primary"><?= h(t('Hozzáadás')) ?></button>
        </form>
        <form method="post" action="?admin=1" style="display:flex;gap:6px;align-items:flex-end">
            <?= csrf_field() ?>
            <input type="hidden" name="admin_action" value="psdnsbl_threshold">
            <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
            <label style="display:flex;flex-direction:column;font-size:.78rem;gap:2px"><?= h(t('Elutasítási küszöb')) ?>
                <input type="number" name="psdnsbl_threshold" value="<?= (int)$psdnsbl['threshold'] ?>" min="1" max="20" style="padding:5px;width:70px"></label>
            <button type="submit" class="btn btn-sm btn-secondary"><?= h(t('Ment')) ?></button>
        </form>
    </div>
</details>
<?php endif; ?>

<?php $neural = admin_neural_status(); ?>
<?php if ($neural !== null):
    $ntrained = !empty($neural['trained']);
    $nshadow  = !empty($neural['shadow']);
    $nmin     = (int)($neural['min_per_class'] ?? 0);
    $nmax     = (int)($neural['max_trains'] ?? 0);
    // The live profile is the one rspamd is still filling; the others are
    // leftovers from earlier symbol sets and are shown greyed so their large
    // counts are not mistaken for progress.
    $ncur = null;
    foreach ($neural['profiles'] as $p) { if (!empty($p['current'])) { $ncur = $p; break; } }
?>
<details class="sys-sec results-card" id="neural" style="margin-bottom:20px">
    <summary class="results-header">
        <h2><?= h(t('Neurális háló')) ?></h2>
        <span class="sys-sec-desc"><?= h(t('Az összes többi szimbólum együttállásából tanul, nem egyetlen jelből.')) ?></span>
        <span class="meta"><?= h($ntrained
            ? ($nshadow ? t('betanítva — árnyék módban') : t('betanítva — élesben'))
            : t('gyűjtés folyamatban')) ?></span>
    </summary>
    <div class="filter-hint" style="margin:16px 20px 4px">
        <?= h(t('A háló csak élő vizsgálat közben gyűjt mintát, és amíg nincs elég mindkét osztályból, egyáltalán nem jelez — ez kívülről semmiben nem különbözik a jól működő, csendes állapottól. Ezért látszik itt a nyers számláló. Egy minta akkor számít, ha a szimbólumok együttállása különbözik: az azonos kampányból érkező levelek egyetlen mintává olvadnak össze. Betanítás után a számlálók nullázódnak és a következő generáció gyűjtése indul — ez normális, a betanított háló közben végig működik.')) ?>
    </div>
    <div class="filter-hint" style="margin:6px 20px 4px">
        <?= h(t('A készlet azonosítója a bekapcsolt szabályok listájából képzett ujjlenyomat: csak akkor változik, ha szabályt adunk hozzá vagy veszünk el — nem levelenként. Egy érkező levélből legfeljebb egy minta lesz, és csak akkor, ha egyértelműen spam vagy egyértelműen ham, az arányt őrző mintavétel nem hagyja ki, és a szimbólumainak együttállása még nem szerepel a készletben. A legtöbb levél tehát nem növeli a számlálót.')) ?>
    </div>
    <table class="msg-table sys-table" style="table-layout:fixed">
        <colgroup><col style="width:34%"><col style="width:22%"><col style="width:22%"><col style="width:22%"></colgroup>
        <thead><tr>
            <th scope="col"><?= h(t('Tanítókészlet')) ?></th>
            <th scope="col"><?= h(t('Spam minták')) ?></th>
            <th scope="col"><?= h(t('Ham minták')) ?></th>
            <th scope="col"><?= h(t('Állapot')) ?></th>
        </tr></thead>
        <tbody>
        <?php
        // Only the live set belongs in the table. Superseded sets are kept
        // from earlier symbol lists; they never train anything and expire on
        // their own, but their counts are LARGE (a full pre-reset corpus)
        // while the live set restarts near zero, so listing them side by side
        // reads as "we lost our progress". They are summarised below instead.
        $nrows = $ncur === null ? $neural['profiles'] : [$ncur];
        $nstale = $ncur === null ? [] : array_values(array_filter($neural['profiles'], fn($p) => empty($p['current'])));
        foreach ($nrows as $p): $isc = !empty($p['current']); ?>
        <tr class="data-row">
            <td data-label="<?= h(t('Tanítókészlet')) ?>"><code style="font-size:.72rem"><?= h((string)$p['profile']) ?></code></td>
            <td data-label="<?= h(t('Spam minták')) ?>"><?= (int)$p['spam'] ?><?= $isc && $nmin ? ' / ' . $nmin : '' ?></td>
            <td data-label="<?= h(t('Ham minták')) ?>"><?= (int)$p['ham'] ?><?= $isc && $nmin ? ' / ' . $nmin : '' ?></td>
            <td data-label="<?= h(t('Állapot')) ?>"><?= h($isc ? t('aktív') : t('ismeretlen')) ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <div class="filter-hint" style="margin:8px 20px 0">
        <?php if ($ncur === null): ?>
            <?= h(t('Az aktív készlet azonosításához legalább egy új minta kell — nézd meg újra később.')) ?>
        <?php else: ?>
            <?= h(sprintf(t('Küszöb: a nagyobb osztálynak %1$d, a kisebbnek %2$d különböző mintát kell elérnie.'), $nmax, $nmin)) ?>
        <?php endif; ?>
        <?php if ($ntrained && !empty($neural['first_trained'])): ?>
            <?= h(sprintf(t('Első betanítás: %s.'), (string)$neural['first_trained'])) ?>
        <?php endif; ?>
        <?php if (!empty($nstale)): $nsn = count($nstale); ?>
            <?= h(sprintf(t('%d korábbi szimbólumkészlet mintái még a tárolóban vannak (%s); a szimbólumlista változásakor maradtak ott, nem tanítanak semmit, és maguktól lejárnak.'),
                $nsn,
                implode(', ', array_map(fn($p) => $p['spam'] . '/' . $p['ham'], $nstale)))) ?>
        <?php endif; ?>
    </div>
    <div style="padding:12px 20px 16px">
        <?php if (!$ntrained): ?>
            <div class="filter-hint"><?= h(t('Amíg nincs betanított háló, a NEURAL_SPAM/NEURAL_HAM nem jelez semmit. Nincs teendő, csak idő kell hozzá.')) ?></div>
        <?php else: ?>
            <form method="post" action="?admin=1" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap"
                  <?= $nshadow ? 'onsubmit="return confirm(' . h(json_encode(t('Élesítve a háló ±pontot ad a levelekhez. Előbb nézd át a NEURAL_* találatokat a naplóban. Folytatod?'))) . ')"' : '' ?>>
                <?= csrf_field() ?>
                <input type="hidden" name="admin_action" value="neural_mode">
                <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                <input type="hidden" name="neural_mode" value="<?= $nshadow ? 'promote' : 'shadow' ?>">
                <button type="submit" class="btn btn-sm <?= $nshadow ? 'btn-primary' : 'btn-secondary' ?>">
                    <?= h($nshadow ? t('Élesítés (3,0 / -2,0)') : t('Vissza árnyék módba (0 / 0)')) ?>
                </button>
                <span style="font-size:.78rem;opacity:.8"><?= h($nshadow
                    ? t('Most jelez és naplóz, de nem módosít pontszámot.')
                    : t('Most valódi pontot ad a levelekhez.')) ?></span>
            </form>
        <?php endif; ?>
    </div>
</details>
<?php endif; ?>

<?php $brandcfg = admin_brandguard_list(); ?>
<?php if ($brandcfg !== null): ?>
<details class="sys-sec results-card" id="brandguard" style="margin-bottom:20px">
    <summary class="results-header">
        <h2><?= h(t('Márkavédelem')) ?></h2>
        <span class="sys-sec-desc"><?= h(t('Ismert márkák (bankok, futárcégek, hivatalok) nevével visszaélő feladók pontozása.')) ?></span>
        <span class="meta"><?= h(sprintf(t('%d márka / %s'), count($brandcfg['brands']),
            ($brandcfg['enabled'] ?? true) ? t('bekapcsolva') : t('kikapcsolva'))) ?></span>
    </summary>
    <div class="filter-hint" style="margin:16px 20px 4px">
        <?= h(t('Ha a feladó megjelenített neve egy védett márkára hasonlít (ékezet-, kis/nagybetű- és homoglif-eltérésekkel együtt), de a feladó domainje nem a márka valódi domainje, a levél BRAND_DN_SPOOF pontot kap. A tárgysorban vagy a feladó címében szereplő márkanév szintén pontoz (BRAND_SUBJ_SPOOF / BRAND_ADDR_SPOOF), az álcázott tárgysorbeli említés — pl. "0TP" — erősebben (BRAND_SUBJ_OBFUS). Ha a levél emellett klasszikus adathalász fordulatokat is használ (magyarul vagy angolul), BRAND_LURE többletpontot kap; önmagában, márkajelzés nélkül ez sosem pontoz. A "=" előtagú névváltozat csak a teljes megjelenített névre illeszkedik (köznévi márkanevekhez, pl. "=wise"), tárgysorban nem vesz részt. A márkák és a csalinyelvi fordulatok az rspamd local.d/brand_definitions.json és brand_lures.json fájljaiban élnek. Minden mentés újraindítja az rspamd-t (néhány másodperc).')) ?>
    </div>
    <div style="padding:8px 20px 0">
        <form method="post" action="?admin=1" style="display:inline">
            <?= csrf_field() ?>
            <input type="hidden" name="admin_action" value="brand_toggle">
            <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
            <input type="hidden" name="brand_on" value="<?= ($brandcfg['enabled'] ?? true) ? '0' : '1' ?>">
            <button type="submit" class="btn btn-sm <?= ($brandcfg['enabled'] ?? true) ? 'btn-secondary' : 'btn-primary' ?>">
                <?= h(($brandcfg['enabled'] ?? true) ? t('Kikapcsolás') : t('Bekapcsolás')) ?>
            </button>
        </form>
    </div>
    <table class="msg-table sys-table" style="table-layout:fixed">
        <colgroup><col style="width:18%"><col style="width:34%"><col style="width:34%"><col style="width:14%"></colgroup>
        <thead><tr>
            <th scope="col"><?= h(t('Márka')) ?></th>
            <th scope="col"><?= h(t('Névváltozatok')) ?></th>
            <th scope="col"><?= h(t('Valódi domainek')) ?></th>
            <th scope="col"><?= h(t('Művelet')) ?></th>
        </tr></thead>
        <tbody>
        <?php foreach ($brandcfg['brands'] as $bb): $bid = (string)($bb['id'] ?? ''); ?>
        <tr class="data-row">
            <td data-label="<?= h(t('Márka')) ?>">
                <?= h((string)($bb['name'] ?? $bid)) ?><br><code style="font-size:.72rem"><?= h($bid) ?></code>
            </td>
            <?php foreach (['variant' => t('Névváltozatok'), 'domain' => t('Valódi domainek')] as $kind => $klabel):
                  $items = (array)($bb[$kind === 'variant' ? 'variants' : 'domains'] ?? []); ?>
            <td data-label="<?= h($klabel) ?>">
                <div style="display:flex;flex-wrap:wrap;gap:4px;align-items:center">
                    <?php foreach ($items as $it): ?>
                    <form method="post" action="?admin=1" style="display:inline-flex;align-items:center;gap:2px"
                          onsubmit="return confirm(<?= h(json_encode(sprintf(t('Törlöd: %s?'), $it))) ?>)">
                        <?= csrf_field() ?>
                        <input type="hidden" name="admin_action" value="brand_<?= $kind ?>_remove">
                        <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                        <input type="hidden" name="brand_id" value="<?= h($bid) ?>">
                        <input type="hidden" name="brand_value" value="<?= h((string)$it) ?>">
                        <code><?= h((string)$it) ?></code>
                        <button type="submit" class="btn btn-sm btn-secondary" style="padding:0 5px"
                                aria-label="<?= h(sprintf(t('%s törlése'), $it)) ?>">&times;</button>
                    </form>
                    <?php endforeach; ?>
                    <form method="post" action="?admin=1" style="display:inline-flex;gap:2px">
                        <?= csrf_field() ?>
                        <input type="hidden" name="admin_action" value="brand_<?= $kind ?>_add">
                        <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                        <input type="hidden" name="brand_id" value="<?= h($bid) ?>">
                        <input type="text" name="brand_value" required style="padding:3px;width:110px;font-size:.78rem"
                               placeholder="<?= h($kind === 'variant' ? t('új változat') : t('új domain')) ?>"
                               aria-label="<?= h($kind === 'variant' ? sprintf(t('Új névváltozat: %s'), $bid) : sprintf(t('Új domain: %s'), $bid)) ?>">
                        <button type="submit" class="btn btn-sm btn-secondary" style="padding:0 7px">+</button>
                    </form>
                </div>
            </td>
            <?php endforeach; ?>
            <td data-label="<?= h(t('Művelet')) ?>">
                <form method="post" action="?admin=1" style="display:inline"
                      onsubmit="return confirm(<?= h(json_encode(sprintf(t('Eltávolítod a(z) %s márkát minden változatával és domainjével együtt?'), $bb['name'] ?? $bid))) ?>)">
                    <?= csrf_field() ?>
                    <input type="hidden" name="admin_action" value="brand_remove">
                    <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                    <input type="hidden" name="brand_id" value="<?= h($bid) ?>">
                    <button type="submit" class="btn btn-sm btn-danger"><?= h(t('Eltávolít')) ?></button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <div style="padding:12px 20px 16px">
        <form method="post" action="?admin=1" style="display:flex;gap:6px;align-items:flex-end;flex-wrap:wrap">
            <?= csrf_field() ?>
            <input type="hidden" name="admin_action" value="brand_add">
            <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
            <label style="display:flex;flex-direction:column;font-size:.78rem;gap:2px"><?= h(t('Új márka azonosítója')) ?>
                <input type="text" name="brand_id" placeholder="pl. dhl" required
                       pattern="[a-z0-9][a-z0-9_-]*" style="padding:5px;width:130px"></label>
            <label style="display:flex;flex-direction:column;font-size:.78rem;gap:2px"><?= h(t('Megjelenő név')) ?>
                <input type="text" name="brand_name" placeholder="pl. DHL" required maxlength="64"
                       style="padding:5px;width:210px"></label>
            <button type="submit" class="btn btn-sm btn-primary"><?= h(t('Hozzáadás')) ?></button>
        </form>
        <div class="filter-hint" style="margin-top:6px">
            <?= h(t('Új márka felvétele után add meg a névváltozatait és a valódi domainjeit — változat nélkül a márka nem szűr semmit.')) ?>
        </div>
    </div>

    <?php $lures = admin_brandguard_lures(); ?>
    <?php if ($lures !== null): $lureOn = ($lures['enabled'] ?? true); ?>
    <div class="results-header" style="border-top:1px solid var(--border);margin-top:8px">
        <h2 style="font-size:1rem"><?= h(t('Adathalász fordulatok')) ?></h2>
        <span class="sys-sec-desc"><?= h(t('Nyelvenkénti csalinyelvi kifejezések; csak márkajelzés mellett pontoznak (BRAND_LURE).')) ?></span>
        <span class="meta"><?= h(sprintf(t('%1$d nyelv / %2$d kifejezés / %3$s'),
            count($lures['phrases']),
            array_sum(array_map('count', $lures['phrases'])),
            $lureOn ? t('bekapcsolva') : t('kikapcsolva'))) ?></span>
    </div>
    <div class="filter-hint" style="margin:10px 20px 4px">
        <?= h(t('Egy fordulat önmagában sosem pontoz — a valódi jelszó-visszaállító levelek ugyanezt írják. Csak akkor ad plusz pontot, ha a levél emellett márkát is megszemélyesít. Az ékezetek és a kis/nagybetűk nem számítanak. Új nyelv felvételéhez add meg a kétbetűs kódját (pl. de, sk, ro).')) ?>
    </div>
    <div style="padding:4px 20px 0">
        <form method="post" action="?admin=1" style="display:inline">
            <?= csrf_field() ?>
            <input type="hidden" name="admin_action" value="brand_lure_toggle">
            <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
            <input type="hidden" name="brand_on" value="<?= $lureOn ? '0' : '1' ?>">
            <button type="submit" class="btn btn-sm <?= $lureOn ? 'btn-secondary' : 'btn-primary' ?>">
                <?= h($lureOn ? t('Fordulatok kikapcsolása') : t('Fordulatok bekapcsolása')) ?>
            </button>
        </form>
    </div>
    <table class="msg-table sys-table" style="table-layout:fixed">
        <colgroup><col style="width:14%"><col style="width:86%"></colgroup>
        <thead><tr>
            <th scope="col"><?= h(t('Nyelv')) ?></th>
            <th scope="col"><?= h(t('Kifejezések')) ?></th>
        </tr></thead>
        <tbody>
        <?php foreach ($lures['phrases'] as $lang => $plist): $lang = (string)$lang; ?>
        <tr class="data-row">
            <td data-label="<?= h(t('Nyelv')) ?>"><code><?= h($lang) ?></code></td>
            <td data-label="<?= h(t('Kifejezések')) ?>">
                <div style="display:flex;flex-wrap:wrap;gap:4px;align-items:center">
                    <?php foreach ((array)$plist as $p): ?>
                    <form method="post" action="?admin=1" style="display:inline-flex;align-items:center;gap:2px"
                          onsubmit="return confirm(<?= h(json_encode(sprintf(t('Törlöd: %s?'), $p))) ?>)">
                        <?= csrf_field() ?>
                        <input type="hidden" name="admin_action" value="brand_lure_remove">
                        <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                        <input type="hidden" name="brand_lang" value="<?= h($lang) ?>">
                        <input type="hidden" name="brand_value" value="<?= h((string)$p) ?>">
                        <code><?= h((string)$p) ?></code>
                        <button type="submit" class="btn btn-sm btn-secondary" style="padding:0 5px"
                                aria-label="<?= h(sprintf(t('%s törlése'), $p)) ?>">&times;</button>
                    </form>
                    <?php endforeach; ?>
                    <form method="post" action="?admin=1" style="display:inline-flex;gap:2px">
                        <?= csrf_field() ?>
                        <input type="hidden" name="admin_action" value="brand_lure_add">
                        <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                        <input type="hidden" name="brand_lang" value="<?= h($lang) ?>">
                        <input type="text" name="brand_value" required minlength="8" maxlength="64"
                               style="padding:3px;width:180px;font-size:.78rem"
                               placeholder="<?= h(t('új kifejezés')) ?>"
                               aria-label="<?= h(sprintf(t('Új kifejezés (%s)'), $lang)) ?>">
                        <button type="submit" class="btn btn-sm btn-secondary" style="padding:0 7px">+</button>
                    </form>
                </div>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <div style="padding:12px 20px 16px">
        <form method="post" action="?admin=1" style="display:flex;gap:6px;align-items:flex-end;flex-wrap:wrap">
            <?= csrf_field() ?>
            <input type="hidden" name="admin_action" value="brand_lure_add">
            <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
            <label style="display:flex;flex-direction:column;font-size:.78rem;gap:2px"><?= h(t('Új nyelv kódja')) ?>
                <input type="text" name="brand_lang" placeholder="de" required pattern="[a-z]{2,8}"
                       style="padding:5px;width:80px"></label>
            <label style="display:flex;flex-direction:column;font-size:.78rem;gap:2px"><?= h(t('Első kifejezés')) ?>
                <input type="text" name="brand_value" required minlength="8" maxlength="64"
                       placeholder="<?= h(t('pl. ihr konto wurde gesperrt')) ?>" style="padding:5px;width:260px"></label>
            <button type="submit" class="btn btn-sm btn-primary"><?= h(t('Hozzáadás')) ?></button>
        </form>
    </div>
    <?php endif; ?>
</details>
<?php endif; ?>

<details class="sys-sec results-card" id="ioclookup" style="margin-bottom:20px">
    <summary class="results-header">
        <h2><?= h(t('IOC-keresési szolgáltatások')) ?></h2>
        <span class="sys-sec-desc"><?= h(t('Mely külső szolgáltatások kérdezhetők le egy indikátor ellenőrzésekor.')) ?></span>
        <span class="meta"><?= h(sprintf(t('%d aktív / %d szolgáltatás'),
            count(array_filter($ioclookup_sources, fn($f) => !empty($f['enabled']))), count($ioclookup_sources))) ?></span>
    </summary>
    <div class="filter-hint" style="margin:16px 20px 4px">
        <?= h(t('Egyedi, kérésre futó IOC-ellenőrzések – nem azonosak a fenti, ütemezetten frissülő blokklista-forrásokkal (az OTX és az URLhaus mindkét listában külön kapcsolóval szerepel).')) ?>
    </div>
    <table class="msg-table sys-table" style="table-layout:fixed">
        <colgroup><col style="width:30%"><col style="width:14%"><col style="width:16%"><col style="width:40%"></colgroup>
        <thead><tr>
            <th scope="col"><?= h(t('Szolgáltatás')) ?></th>
            <th scope="col"><?= h(t('Állapot')) ?></th>
            <th scope="col"><?= h(t('API-kulcs')) ?></th>
            <th scope="col"><?= h(t('Módosítás')) ?></th>
        </tr></thead>
        <tbody>
        <?php foreach ($ioclookup_sources as $lk => $lv):
            $len = !empty($lv['enabled']); $lhas = !empty($lv['has_key']); ?>
        <tr class="data-row">
            <td data-label="<?= h(t('Szolgáltatás')) ?>"><strong><?= h($_il_label[$lk] ?? $lk) ?></strong>
                <div style="font-size:.72rem;color:var(--text-subtle)"><code><?= h($lk) ?></code></div>
                <?php if ($lk === 'urlvet'): ?>
                <div style="font-size:.72rem;color:var(--warning);margin-top:2px">
                    <?= h(t('Bekapcsolva a vizsgált domaint/URL-t elküldi a külső url.vet szolgáltatásnak.')) ?></div>
                <?php endif; ?>
                <?php if (!empty($lv['custom'])): ?>
                <div style="font-size:.72rem;color:var(--text-subtle);margin-top:2px">
                    <?= h(t('egyéni DNSBL')) ?>: <code><?= h((string)($lv['zone'] ?? '')) ?></code>
                    · <?= h(t('típusok')) ?>: <?= h((string)($lv['types'] ?? '')) ?>
                    · <?= h(t('súly a Megbízhatóságban')) ?>: <?= (int)($lv['weight'] ?? 0) ?></div>
                <?php else: ?>
                <?php // Built-in weight from the same table the aggregate uses --
                      // one source, so this display can never disagree with the math.
                      $_ilw = IOC_CONFIDENCE_WEIGHTS[$lk] ?? null; ?>
                <div style="font-size:.72rem;color:var(--text-subtle);margin-top:2px">
                    <?= h(t('súly a Megbízhatóságban')) ?>:
                    <?= $_ilw !== null ? (int)$_ilw : '–' ?><?= $_ilw === null ? ' ' . h(t('(nem számít bele)')) : '' ?></div>
                <?php endif; ?>
            </td>
            <td data-label="<?= h(t('Állapot')) ?>">
                <span style="font-weight:600;color:<?= $len ? '#27ae60' : 'var(--text-subtle)' ?>">
                    <?= $len ? '&#9679; ' . h(t('aktív')) : '&#9675; ' . h(t('kikapcsolva')) ?></span>
            </td>
            <td data-label="<?= h(t('API-kulcs')) ?>" style="font-size:.8rem">
                <?php if (empty($lv['needs_key'])): ?><span style="color:var(--text-subtle)"><?= h(t('nem szükséges')) ?></span>
                <?php elseif (in_array($lk, $_il_key_elsewhere, true)): ?>
                    <span style="color:<?= $lhas ? 'var(--text-subtle)' : 'var(--warning)' ?>">
                        <?= h(t('a Források listából kezelve')) ?><?= $lhas ? '' : ' – ' . h(t('nincs megadva')) ?>
                    </span>
                <?php elseif ($lhas): ?><span style="color:#27ae60"><svg class="icon"><use href="#icon-check"></use></svg> <?= h(t('megadva')) ?></span>
                <?php else: ?><span style="color:var(--warning);font-weight:600"><?= h(t('hiányzik')) ?></span><?php endif; ?>
            </td>
            <td data-label="<?= h(t('Módosítás')) ?>">
                <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">
                    <form method="post" action="?admin=1" style="display:inline">
                        <?= csrf_field() ?>
                        <input type="hidden" name="admin_action" value="ioclookup_toggle">
                        <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                        <input type="hidden" name="ioclookup_src" value="<?= h($lk) ?>">
                        <input type="hidden" name="ioclookup_on" value="<?= $len ? '0' : '1' ?>">
                        <button type="submit" class="btn btn-sm <?= $len ? 'btn-secondary' : 'btn-primary' ?>">
                            <?= $len ? h(t('Kikapcsol')) : h(t('Bekapcsol')) ?>
                        </button>
                    </form>
                    <?php if (!empty($lv['custom'])): ?>
                    <form method="post" action="?admin=1" style="display:inline"
                          onsubmit="return confirm(<?= h(json_encode(sprintf(t('Eltávolítod a(z) %s egyéni szolgáltatást?'), $lk))) ?>)">
                        <?= csrf_field() ?>
                        <input type="hidden" name="admin_action" value="ioclookup_removecustom">
                        <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                        <input type="hidden" name="cl_name" value="<?= h($lk) ?>">
                        <button type="submit" class="btn btn-sm btn-danger"><?= h(t('Eltávolít')) ?></button>
                    </form>
                    <?php endif; ?>
                    <?php if (!in_array($lk, $_il_key_elsewhere, true) && !empty($lv['needs_key'])): ?>
                    <form method="post" action="?admin=1" style="display:flex;gap:6px;align-items:center">
                        <?= csrf_field() ?>
                        <input type="hidden" name="admin_action" value="ioclookup_key">
                        <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                        <input type="hidden" name="ioclookup_src" value="<?= h($lk) ?>">
                        <input type="password" name="ioclookup_key" autocomplete="new-password"
                               aria-label="<?= h(t('API-kulcs')) ?>"
                               placeholder="<?= $lhas ? h(t('új kulcs (üres = törlés)')) : h(t('API-kulcs')) ?>"
                               style="padding:5px;font-size:.78rem;width:150px">
                        <button type="submit" class="btn btn-sm btn-secondary"><?= h(t('Ment')) ?></button>
                    </form>
                    <?php endif; ?>
                </div>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <div style="padding:12px 20px 16px">
        <form method="post" action="?admin=1" style="display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap">
            <?= csrf_field() ?>
            <input type="hidden" name="admin_action" value="ioclookup_addcustom">
            <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
            <label style="display:flex;flex-direction:column;font-size:.78rem;gap:2px"><?= h(t('Új egyéni DNSBL szolgáltatás')) ?>
                <input type="text" name="cl_name" placeholder="myrbl" required pattern="[a-z0-9][a-z0-9_-]{1,30}" style="padding:5px;width:120px"></label>
            <label style="display:flex;flex-direction:column;font-size:.78rem;gap:2px"><?= h(t('DNSBL zóna')) ?>
                <input type="text" name="cl_zone" placeholder="bl.example.org" required pattern="[a-z0-9]([a-z0-9._-]*[a-z0-9])?" style="padding:5px;width:190px"></label>
            <span style="display:flex;flex-direction:column;font-size:.78rem;gap:2px"><?= h(t('Típusok')) ?>
                <span style="display:flex;gap:10px;padding:6px 0">
                    <label style="font-size:.78rem"><input type="checkbox" name="cl_types[]" value="ip" checked> IP</label>
                    <label style="font-size:.78rem"><input type="checkbox" name="cl_types[]" value="domain"> Domain</label>
                </span></span>
            <label style="display:flex;flex-direction:column;font-size:.78rem;gap:2px"><?= h(t('Súly')) ?>
                <input type="number" name="cl_weight" value="10" min="1" max="40" style="padding:5px;width:70px"></label>
            <button type="submit" class="btn btn-sm btn-primary"><?= h(t('Hozzáadás')) ?></button>
        </form>
        <div class="filter-hint" style="margin-top:8px">
            <?= h(t('DNS-alapú hírnévlisták (RBL/URIBL) vehetők fel kód nélkül: a lekérdezés a megadott zóna ellen fut, minden 127.0.0.x válasz találatnak számít, a súly a Megbízhatóság-számításba kerül. API-alapú szolgáltatás felvételéhez kód szükséges.')) ?>
        </div>
    </div>
</details>
<?php endif; ?>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- IOC hash export – külső tűzfal hozzáférés                                  -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<?php
$ioc_export_cfg = _ioc_export_config();
// Flashed once by handle_admin_post()'s ioc_export_regen_token case, then
// immediately unset -- this is the ONLY point in the app the full token is
// ever readable. The masked display below (last 6 chars only) is what
// persists across every other render, by design: the raw token is never
// stored in a session var that survives more than one request, and never
// appears in a URL/query string (which would land in Apache's access log).
$ioc_export_new_token = $_SESSION['ioc_export_new_token'] ?? null;
unset($_SESSION['ioc_export_new_token']);
?>
<details class="sys-sec results-card" style="margin-bottom:20px">
    <summary class="results-header">
        <h2><?= t('IOC hash export – külső tűzfal hozzáférés') ?></h2>
        <span class="sys-sec-desc"><?= h(t('Token és IP-lista, amivel külső tűzfal lekérheti a hash-listát.')) ?></span>
    </summary>
    <div class="filter-hint" style="margin:16px 20px 4px">
        <?= t('A token és az IP-lista együtt szükséges az export-hashes.php automatikus lekéréséhez. Kézi exportáláshoz és tömeges importáláshoz lásd lentebb.') ?>
    </div>
    <?php if ($ioc_export_new_token !== null): ?>
    <div class="notice notice-ok" style="margin:0 20px 4px">
        <?= t('Az új token (csak most jelenik meg, jegyezze fel):') ?>
        <code><?= h($ioc_export_new_token) ?></code>
    </div>
    <?php endif; ?>
    <div style="padding:14px 20px">
        <div style="margin-bottom:16px">
            <strong><?= t('Token') ?>:</strong>
            <code><?= $ioc_export_cfg['token'] === ''
                ? t('nincs beállítva')
                : '••••••••' . h(substr($ioc_export_cfg['token'], -6)) ?></code>
            <form method="post" action="?admin=1" style="display:inline;margin-left:10px"
                  onsubmit="return confirm('<?= h(t('Új token generálása azonnal érvényteleníti a régit. Folytatja?')) ?>')">
                <?= csrf_field() ?>
                <input type="hidden" name="admin_action" value="ioc_export_regen_token">
                <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                <button type="submit" class="btn btn-sm btn-secondary"><?= t('Új token') ?></button>
            </form>
        </div>
        <div>
            <strong><?= t('Engedélyezett IP-címek') ?>:</strong>
            <ul style="margin:6px 0 10px 0;padding-left:18px">
                <?php foreach ($ioc_export_cfg['allowed_ips'] as $ip): ?>
                <li style="margin-bottom:4px">
                    <code><?= h($ip) ?></code>
                    <form method="post" action="?admin=1" style="display:inline;margin-left:8px">
                        <?= csrf_field() ?>
                        <input type="hidden" name="admin_action" value="ioc_export_allow_remove">
                        <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                        <input type="hidden" name="ioc_export_ip" value="<?= h($ip) ?>">
                        <button type="submit" class="btn btn-sm btn-secondary"><?= t('Eltávolítás') ?></button>
                    </form>
                </li>
                <?php endforeach; ?>
                <?php if (empty($ioc_export_cfg['allowed_ips'])): ?>
                <li style="color:var(--text-subtle)"><?= t('Nincs engedélyezett IP-cím – az automatikus lekérés le van tiltva.') ?></li>
                <?php endif; ?>
            </ul>
            <form method="post" action="?admin=1" style="display:flex;gap:8px;align-items:center">
                <?= csrf_field() ?>
                <input type="hidden" name="admin_action" value="ioc_export_allow_add">
                <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                <input type="text" name="ioc_export_ip" placeholder="203.0.113.10" style="padding:5px">
                <button type="submit" class="btn btn-sm btn-primary"><?= t('Hozzáadás') ?></button>
            </form>
        </div>
    </div>
</details>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- Hash export / import                                                       -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<details class="sys-sec results-card" style="margin-bottom:20px">
    <summary class="results-header"><h2><?= t('Hash export / import') ?></h2>
        <span class="sys-sec-desc"><?= h(t('SHA-256 hash-listák kézi kimentése és beolvasása.')) ?></span></summary>
    <div style="padding:14px 20px;display:flex;flex-direction:column;gap:16px">
        <div>
            <a href="?export=ioc_hashes" class="btn btn-sm btn-secondary"><?= t('SHA256 hash-ek exportálása (CSV)') ?></a>
        </div>
        <form method="post" action="?sysconfig=1" style="display:flex;flex-direction:column;gap:8px;max-width:520px">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="ioc_bulk_import">
            <label style="font-size:.75rem;color:var(--text-subtle)"><?= t('Hash-ek tömeges importálása (soronként vagy vesszővel elválasztva)') ?></label>
            <textarea name="ioc_bulk_hashes" rows="4" style="width:100%;padding:6px;font-family:monospace;font-size:.85rem"></textarea>
            <div style="display:flex;gap:8px;align-items:center">
                <select name="ioc_bulk_confidence" style="padding:5px">
                    <?php foreach (IOC_CONFIDENCE_LEVELS as $cf): ?>
                    <option value="<?= h($cf) ?>" <?= $cf === 'medium' ? 'selected' : '' ?>><?= h($cf) ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn btn-sm btn-primary"><?= t('Importálás') ?></button>
            </div>
        </form>
    </div>
</details>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- Élő DNSBL-ellenőrzések (Postfix)                                           -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<?php
$_dnsbl_labels = [
    'zen.spamhaus.org'        => 'Spamhaus ZEN',
    'b.barracudacentral.org'  => 'Barracuda Reputation',
    'bl.spamcop.net'          => 'SpamCop',
    'dnsbl.sorbs.net'         => 'SORBS',
    'bl.hrbl.hu'              => 'HRBL',
    'otx.rbl'                 => 'AlienVault OTX (helyi rbldnsd)',
];
?>
<details class="sys-sec results-card" style="margin-bottom:20px">
    <summary class="results-header">
        <h2><?= t('Élő DNSBL-ellenőrzések (Postfix)') ?></h2>
        <span class="sys-sec-desc"><?= h(t('A postscreen által minden kapcsolatnál élőben lekérdezett feketelisták.')) ?></span>
        <span class="meta"><?= h(sprintf(t('%d forrás'), count($dnsbl_sites))) ?></span>
    </summary>
    <div class="filter-hint" style="margin:16px 20px 4px">
        <?= t('Ezeket a külső feketelistákat a postscreen minden bejövő kapcsolatnál élőben lekérdezi - nincs helyi frissítés vagy be/ki kapcsoló, a listát a szerveren, a Postfix beállításában lehet módosítani.') ?>
    </div>
    <?php if (empty($dnsbl_sites)): ?>
    <div class="empty-state"><p><?= t('A DNSBL-lista nem elérhető (ellenőrizze a sudo-konfigurációt).') ?></p></div>
    <?php else: ?>
    <table class="msg-table sys-table" style="table-layout:fixed">
        <colgroup><col style="width:70%"><col style="width:30%"></colgroup>
        <thead><tr><th scope="col"><?= t('Forrás') ?></th><th scope="col"><?= t('Súly') ?></th></tr></thead>
        <tbody>
        <?php foreach ($dnsbl_sites as $d): ?>
        <tr class="data-row">
            <td data-label="<?= h(t('Forrás')) ?>">
                <strong><?= h($_dnsbl_labels[$d['host']] ?? $d['host']) ?></strong>
                <div style="font-size:.75rem;color:var(--text-subtle);margin-top:2px"><code><?= h($d['host']) ?></code></div>
            </td>
            <td data-label="<?= h(t('Súly')) ?>" style="font-variant-numeric:tabular-nums;font-weight:600">×<?= h($d['weight']) ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</details>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- ClamAV vírusvédelem                                                        -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<?php
$cv = $admin_clamav;
// clamav-unofficial-sigs is a separate third-party package. Where it is absent
// there is no user.conf to edit, so every control below this line is inert --
// the toggles used to render fully live and only fail on submit, and the source
// table above them showed nine sources "active" that did not exist. Default to
// TRUE when the key is missing so an older clamav-status.sh (or a status entry
// still in the 60s cache from before this deploy) keeps a working panel visible
// rather than blanking it on a host where the package IS installed.
$cv_unof = $cv['unofficial_installed'] ?? true;
$_cv_age = function (int $age, int $warn, int $bad): array {
    if ($age < 0)     return ['unknown', 'nincs adat', 'var(--text-subtle)'];
    if ($age > $bad)  return ['old',     t('régi'),       'var(--danger)'];
    if ($age > $warn) return ['stale',   'elavult',    'var(--warning)'];
    return ['ok', 'friss', '#27ae60'];
};
$_cv_hours = fn(int $s) => $s < 0 ? '-' : ($s < 3600
    ? intdiv($s, 60) . ' perce'
    : sprintf(t('%d órája'), intdiv($s, 3600)));
?>
<details class="sys-sec results-card" id="clamav" style="margin-bottom:20px">
    <summary class="results-header">
        <h2><?= t('ClamAV vírusvédelem') ?></h2>
        <span class="sys-sec-desc"><?= h(t('A vírusadatbázisok kora és a kiegészítő aláírás-források kapcsolói.')) ?></span>
        <?php if ($cv): ?>
        <span class="meta">
            <?php if (!empty($cv['daemon_active'])): ?>
            <span style="color:#27ae60;font-weight:600">&#9679; clamd fut</span>
            <?php else: ?>
            <span style="color:var(--danger);font-weight:600"><?= t('&#9679; clamd áll') ?></span>
            <?php endif; ?>
            &nbsp;/&nbsp; motor <?= h($cv['clam_version'] ?? '?') ?>
        </span>
        <?php endif; ?>
    </summary>

    <?php if (empty($cv)): ?>
    <div class="empty-state"><p><?= t('A ClamAV-állapot nem elérhető (ellenőrizze a sudo-konfigurációt).') ?></p></div>
    <?php else: ?>

    <?php
        [, $dl_lbl, $dl_col] = $_cv_age((int)$cv['daily_age'], 86400, 259200);
        [, $un_lbl, $un_col] = $_cv_age((int)$cv['unofficial_age'], 172800, 604800);
    ?>
    <div style="display:flex;flex-wrap:wrap;gap:10px;padding:16px 20px 4px">
        <div class="cv-stat">
            <span class="cv-stat-k"><?= t('Hivatalos adatbázis') ?></span>
            <span class="cv-stat-v"><?= h($cv['db_version'] ?? '?') ?></span>
            <span class="cv-stat-s"><?= number_format((int)($cv['db_sigs'] ?? 0)) ?> <?= t('aláírás') ?></span>
        </div>
        <div class="cv-stat">
            <span class="cv-stat-k"><?= t('daily.cld frissítve') ?></span>
            <span class="cv-stat-v" style="color:<?= $dl_col ?>"><?= $_cv_hours((int)$cv['daily_age']) ?></span>
            <span class="cv-stat-s"><?= h($cv['daily_updated'] ?? '') ?> &middot; <?= $dl_lbl ?></span>
        </div>
        <?php if ($cv_unof): ?>
        <div class="cv-stat">
            <span class="cv-stat-k"><?= t('Nem hivatalos aláírások') ?></span>
            <span class="cv-stat-v" style="color:<?= $un_col ?>"><?= $_cv_hours((int)$cv['unofficial_age']) ?></span>
            <span class="cv-stat-s"><?= h($cv['unofficial_updated'] ?? '') ?> &middot; <?= $un_lbl ?></span>
        </div>
        <div class="cv-stat">
            <span class="cv-stat-k"><?= t('Alapértelmezett besorolás') ?></span>
            <span class="cv-stat-v"><?= h($cv['default_rating'] ?? '?') ?></span>
            <span class="cv-stat-s"><?= t('felülírás nélküli forrásokra') ?></span>
        </div>
        <?php endif; ?>
    </div>

    <?php if (!$cv_unof): ?>
    <div class="filter-hint" style="margin:12px 20px 16px">
        <?= h(t('A kiegészítő aláírás-források és a YARA szabályok kezeléséhez a clamav-unofficial-sigs csomag szükséges, ami ezen a gépen nincs telepítve - így itt nincs mit beállítani.')) ?>
        <?= h(t('A hivatalos ClamAV adatbázis és a vírusszűrés ettől függetlenül működik, a fenti adatok érvényesek.')) ?>
        <?= h(t('A csomag EL-alapú rendszereken (RHEL, Rocky, Alma) érhető el az EPEL tárolóból; a Debian és Ubuntu jelenlegi kiadásai nem csomagolják.')) ?>
    </div>
    <?php else: ?>
    <div class="filter-hint" style="margin:12px 20px 4px">
        A <strong><?= t('besorolás') ?></strong> <?= t('szabja meg, mennyire agresszív egy aláírás-forrás:') ?>
        <em>LOW</em> <?= t('= csak a legmegbízhatóbb szabályok,') ?> <em>HIGH</em> <?= t('= a kísérleti szabályok is. A') ?> <em>DISABLE</em> <?= t('kikapcsolja a forrást, az') ?> <em><?= t('Alapértelmezett') ?></em> <?= t('pedig törli a helyi felülírást. A módosítás a') ?> <code>user.conf</code><?= t('-ba kerül, és a következő clamav-unofficial-sigs futáskor lép életbe - a már letöltött aláírások addig aktívak.') ?>
    </div>

    <table class="msg-table sys-table" style="table-layout:fixed">
        <colgroup>
            <col style="width:32%"><col style="width:16%"><col style="width:18%"><col style="width:34%">
        </colgroup>
        <thead>
            <tr><th scope="col"><?= t('Aláírás-forrás') ?></th><th scope="col"><?= t('Állapot') ?></th><th scope="col"><?= t('Besorolás') ?></th><th scope="col"><?= t('Módosítás') ?></th></tr>
        </thead>
        <tbody>
        <?php foreach (($cv['sources'] ?? []) as $sk => $sv):
            $master_off = empty($sv['master_enabled']);
            $disabled   = strtoupper($sv['rating'] ?? '') === 'DISABLE';
        ?>
        <tr class="data-row">
            <td data-label="Forrás">
                <strong><?= h($sv['label'] ?? $sk) ?></strong>
                <?php if (!empty($sv['user_override'])): ?>
                <span style="font-size:.68rem;background:var(--primary-light);color:var(--primary);
                             padding:1px 5px;border-radius:3px;margin-left:5px"><?= t('helyi felülírás') ?></span>
                <?php endif; ?>
            </td>
            <td data-label="Állapot" style="font-size:.8rem">
                <?php if ($master_off): ?>
                <span style="color:var(--text-subtle)">a master.conf kikapcsolta</span>
                <?php elseif ($disabled): ?>
                <span style="color:var(--danger);font-weight:600">kikapcsolva</span>
                <?php else: ?>
                <span style="color:#27ae60;font-weight:600"><?= t('aktív') ?></span>
                <?php endif; ?>
            </td>
            <td data-label="Besorolás" style="font-weight:600"><?= h($sv['rating'] ?? '?') ?></td>
            <td data-label="Módosítás">
                <form method="post" action="?admin=1" style="display:flex;gap:6px;align-items:center">
                    <?= csrf_field() ?>
                    <input type="hidden" name="admin_action" value="clamav_toggle">
                    <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                    <input type="hidden" name="cv_source" value="<?= h($sk) ?>">
                    <select name="cv_value" style="padding:5px;font-size:.78rem">
                        <option value="LOW">LOW</option>
                        <option value="MEDIUM">MEDIUM</option>
                        <option value="HIGH">HIGH</option>
                        <option value="DISABLE">DISABLE</option>
                        <option value="ENABLE"><?= t('Alapértelmezett') ?></option>
                    </select>
                    <button type="submit" class="btn btn-sm btn-secondary">Ment</button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

    <div style="display:flex;align-items:center;gap:12px;padding:14px 20px;border-top:1px solid var(--border)">
        <div style="flex:1">
            <strong style="font-size:.88rem"><?= t('YARA szabályok') ?></strong>
            <div style="font-size:.75rem;color:var(--text-subtle);margin-top:2px">
                <?= t('Hamis pozitívra hajlamos heurisztika. Az rspamd külön') ?> <code>CLAM_YARA</code>
                <?= t('szimbólumba irányítja, ami csak pontoz - nem utasít vissza levelet.') ?>
            </div>
        </div>
        <span style="font-weight:600;font-size:.85rem;color:<?= !empty($cv['yara_enabled']) ? '#27ae60' : 'var(--text-subtle)' ?>">
            <?= !empty($cv['yara_enabled']) ? 'bekapcsolva' : 'kikapcsolva' ?>
        </span>
        <form method="post" action="?admin=1"
              onsubmit="return confirm('<?= t('Biztosan') ?> <?= h(!empty($cv['yara_enabled']) ? t('kikapcsolja') : t('bekapcsolja')) ?> <?= t('a YARA szabályokat?') ?>')">
            <?= csrf_field() ?>
            <input type="hidden" name="admin_action" value="clamav_toggle">
            <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
            <input type="hidden" name="cv_source" value="yara">
            <input type="hidden" name="cv_value"  value="<?= !empty($cv['yara_enabled']) ? 'OFF' : 'ON' ?>">
            <button type="submit" class="btn btn-sm btn-secondary">
                <?= !empty($cv['yara_enabled']) ? 'Kikapcsol' : 'Bekapcsol' ?>
            </button>
        </form>
    </div>
    <?php endif; /* $cv_unof */ ?>
    <?php endif; /* $cv */ ?>
</details>

<?php $pf_rules = _postfix_rules(); ?>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- Postfix: hálózat és relézés                                               -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<details class="sys-sec results-card" id="postfix-network" style="margin-bottom:20px">
    <summary class="results-header">
        <h2><?= t('Postfix - hálózat és relézés') ?></h2>
        <span class="sys-sec-desc"><?= h(t('Megbízható hálózatok, kapcsolódási korlátok és továbbítási szabályok.')) ?></span>
        <span class="meta"><?= t('Mentéskor azonnal ellenőrzi (postfix check) és újratölti a szolgáltatást') ?></span>
    </summary>
    <table class="msg-table sys-table" style="table-layout:fixed">
        <colgroup><col style="width:30%"><col style="width:30%"><col style="width:40%"></colgroup>
        <thead><tr><th scope="col"><?= t('Beállítás') ?></th><th scope="col"><?= t('Érték') ?></th><th scope="col"><?= t('Módosítás') ?></th></tr></thead>
        <tbody>
        <?php foreach (['mynetworks', 'relay_domains', 'relayhost', 'message_size_limit'] as $pf_key):
            $r   = $pf_rules[$pf_key];
            $cur = $postfix_settings[$pf_key] ?? '';
        ?>
        <tr>
            <td>
                <strong><?= h($r['label']) ?></strong>
                <div style="font-size:.78rem;color:var(--text-subtle);margin-top:3px;line-height:1.4"><?= h($r['help']) ?></div>
            </td>
            <td style="font-family:monospace;font-size:.82rem;word-break:break-all"><?= h($cur) ?></td>
            <td>
                <form method="post" action="?admin=1" style="display:flex;gap:5px;align-items:center;flex-wrap:wrap">
                    <?= csrf_field() ?>
                    <input type="hidden" name="admin_action" value="postfix_save_setting">
                    <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                    <input type="hidden" name="pf_key" value="<?= h($pf_key) ?>">
                    <input type="<?= $r['type'] === 'number' ? 'number' : 'text' ?>" name="pf_val"
                           aria-label="<?= h(t('Érték')) ?>" value="<?= h($cur) ?>"
                           style="flex:1;min-width:160px;padding:4px 6px;border:1px solid var(--border);
                                  border-radius:var(--radius-sm);font-size:.875rem">
                    <button type="submit" class="btn btn-sm btn-secondary"><?= t('Ment') ?></button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</details>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- Postfix: TLS                                                               -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<details class="sys-sec results-card" id="postfix-tls" style="margin-bottom:20px">
    <summary class="results-header"><h2><?= t('Postfix - TLS') ?></h2>
        <span class="sys-sec-desc"><?= h(t('Titkosítás a beérkező és a kimenő levelekhez.')) ?></span></summary>
    <table class="msg-table sys-table" style="table-layout:fixed">
        <colgroup><col style="width:30%"><col style="width:30%"><col style="width:40%"></colgroup>
        <thead><tr><th scope="col"><?= t('Beállítás') ?></th><th scope="col"><?= t('Jelenlegi') ?></th><th scope="col"><?= t('Módosítás') ?></th></tr></thead>
        <tbody>
        <?php foreach (['smtpd_tls_security_level', 'smtp_tls_security_level',
                         'smtpd_tls_mandatory_protocols', 'smtp_tls_mandatory_protocols'] as $pf_key):
            $r   = $pf_rules[$pf_key];
            $cur = $postfix_settings[$pf_key] ?? '';
        ?>
        <tr>
            <td><strong><?= h($r['label']) ?></strong></td>
            <td style="font-family:monospace;font-size:.82rem;word-break:break-all"><?= h($cur) ?></td>
            <td>
                <form method="post" action="?admin=1" style="display:flex;gap:5px;align-items:center">
                    <?= csrf_field() ?>
                    <input type="hidden" name="admin_action" value="postfix_save_setting">
                    <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                    <input type="hidden" name="pf_key" value="<?= h($pf_key) ?>">
                    <select name="pf_val" style="padding:5px;font-size:.78rem">
                        <?php foreach ($r['options'] as $opt): ?>
                        <option value="<?= h($opt) ?>" <?= $opt === $cur ? 'selected' : '' ?>><?= h($opt) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" class="btn btn-sm btn-secondary"><?= t('Ment') ?></button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php $pf_certs = postfix_tls_cert_info(); ?>
    <div style="padding:12px 20px;border-top:1px solid var(--border);font-size:.78rem;color:var(--text-subtle)">
        <strong style="color:var(--text-muted)"><?= t('Tanúsítvány (csak olvasható, a certbot kezeli)') ?>:</strong>
        <div style="font-family:monospace;margin-top:4px;word-break:break-all"><?= h($pf_certs['smtpd_tls_cert_file'] ?? '') ?></div>
        <div style="font-family:monospace;word-break:break-all"><?= h($pf_certs['smtpd_tls_key_file'] ?? '') ?></div>
    </div>
</details>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- Postfix: korlátozási láncok                                               -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<details class="sys-sec results-card" id="postfix-restrictions" style="margin-bottom:20px">
    <summary class="results-header"><h2><?= t('Postfix - korlátozási láncok') ?></h2>
        <span class="sys-sec-desc"><?= h(t('Milyen feltételekkel fogad el a szerver egy levelet.')) ?></span></summary>

    <div class="filter-hint" style="margin:16px 20px 4px">
        <?= t('Soronként egy elem. A meglévő elemek (pl. check_policy_service, check_sender_access) átrendezhetők vagy törölhetők, de célja nem szerkeszthető innen. Új sor csak az alábbi listából adható hozzá:') ?>
        <code><?= h(implode(', ', POSTFIX_SAFE_TOKENS)) ?></code>
    </div>

    <?php foreach (postfix_restriction_directives() as $pf_dir):
        $pf_tokens = postfix_restriction_get($pf_dir);
    ?>
    <div style="padding:14px 20px;border-top:1px solid var(--border)">
        <strong style="font-size:.88rem"><?= h($pf_dir) ?></strong>
        <form method="post" action="?admin=1" style="margin-top:8px">
            <?= csrf_field() ?>
            <input type="hidden" name="admin_action" value="postfix_save_restriction">
            <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
            <input type="hidden" name="pf_dir" value="<?= h($pf_dir) ?>">
            <textarea name="pf_tokens" id="pf-ta-<?= h($pf_dir) ?>" rows="<?= max(3, count($pf_tokens)) ?>"
                      data-pf-preview="pf-preview-<?= h($pf_dir) ?>"
                      style="width:100%;font-family:monospace;font-size:.8rem;padding:8px;
                             border:1px solid var(--border);border-radius:var(--radius-sm)"
                      oninput="pfUpdatePreview(this)"><?= h(implode("\n", $pf_tokens)) ?></textarea>
            <div style="display:flex;gap:8px;align-items:center;margin-top:6px;flex-wrap:wrap">
                <select onchange="pfAppendToken(this)" data-pf-target="pf-ta-<?= h($pf_dir) ?>" style="padding:4px;font-size:.78rem">
                    <option value=""><?= h(t('+ elem hozzáadása…')) ?></option>
                    <?php foreach (POSTFIX_SAFE_TOKENS as $tok): ?>
                    <option value="<?= h($tok) ?>"><?= h($tok) ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn btn-sm btn-secondary"><?= t('Ment') ?></button>
            </div>
            <div id="pf-preview-<?= h($pf_dir) ?>" style="font-size:.75rem;color:var(--text-subtle);margin-top:6px;font-family:monospace">
                <?= h($pf_dir) ?> = <?= h(implode(', ', $pf_tokens)) ?>
            </div>
        </form>
    </div>
    <?php endforeach; ?>
</details>

<script>
function pfUpdatePreview(textarea) {
    var lines = textarea.value.split('\n').map(function (s) { return s.trim(); }).filter(function (s) { return s !== ''; });
    var preview = document.getElementById(textarea.dataset.pfPreview);
    if (preview) {
        var dirName = textarea.dataset.pfPreview.replace('pf-preview-', '');
        preview.textContent = dirName + ' = ' + lines.join(', ');
    }
}
function pfAppendToken(select) {
    if (!select.value) return;
    var ta = document.getElementById(select.dataset.pfTarget);
    if (ta) {
        ta.value = ta.value.replace(/\n+$/, '') + (ta.value.trim() === '' ? '' : '\n') + select.value;
        pfUpdatePreview(ta);
    }
    select.value = '';
}
</script>


<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- FTS Xapian indexek                                                         -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<?php
$total_fts_mb = array_sum(array_column($admin_fts, 'size_mb'));
$count_fts    = count($admin_fts);
$count_oversz = count(array_filter($admin_fts, fn($r) => $r['size_mb'] > 700));

$_fts_min = max(0, (int)($_GET['fmin'] ?? 0));
if ($_fts_min > 0) {
    $admin_fts = array_values(array_filter($admin_fts, fn($r) => $r['size_mb'] >= $_fts_min));
    $count_fts = count($admin_fts);
}

$_FTS_PP    = QA_PER_PAGE_FTS;
$_fts_pages = max(1, (int)ceil($count_fts / $_FTS_PP));
$_fts_page  = max(1, min($_fts_pages, (int)($_GET['fpage'] ?? 1)));
$_fts_rows  = array_slice($admin_fts, ($_fts_page - 1) * $_FTS_PP, $_FTS_PP);
$_fts_url   = fn(int $p) => '?sysconfig=1&fpage=' . $p . ($_fts_min ? '&fmin=' . $_fts_min : '') . '#fts';
?>
<details class="sys-sec results-card" id="fts" style="margin-bottom:20px">
    <summary class="results-header">
        <h2>FTS Xapian indexek</h2>
        <span class="sys-sec-desc"><?= h(t('A teljes szövegű kereséshez tartozó postafiók-indexek mérete.')) ?></span>
        <span class="meta">
            <?= $count_fts ?> <?= t('felhasználó &middot; összesen') ?> <?= number_format($total_fts_mb) ?> MB
            <?php if ($count_oversz): ?>
            &middot; <span style="color:var(--danger)"><?= $count_oversz ?> &gt; 700 MB</span>
            <?php endif; ?>
        </span>
    </summary>

    <?php $_fopt = admin_fts_optimize_status(); ?>
    <div class="filter-hint" style="margin:12px 20px 0">
        <strong><?= h(t('Mire való ez az index?')) ?></strong>
        <?= h(t('A Xapian index teszi lehetővé, hogy az Archívum keresése a levelek TÖRZSÉBEN is keressen anélkül, hogy minden levelet végig kellene olvasni. Az index a levelek érkezésekor, apránként bővül - ettől viszont töredezik: a törölt levelek helye bent marad, a fájl mérete jóval a valós tartalom fölé nő, a keresés pedig lassul. A tömörítés ezt írja újra tisztán.')) ?>
        <br><br>
        <strong><?= h(t('Miért heti ütemezéssel és memória-korláttal?')) ?></strong>
        <?= h(t('A tömörítés a régi indexet beolvasva ír újat, így a csúcs-memóriaigény az index méretével nő. A kézenfekvő "doveadm fts optimize -A" minden postafiókot egyszerre dolgoz fel, és egy levelezésre méretezett gépen ez megbízhatóan OOM-ot okoz - nem feltétlenül a doveadm-ot kilőve. Az ütemezett feladat ezért postafiókonként fut, ulimit -v korláttal, a korlát felénél nagyobb indexeket kihagyja, és a gép saját RAM-jából számolja a határokat futásidőben.')) ?>
    </div>

    <?php if (!empty($_fopt['available'])): ?>
    <div style="padding:12px 20px 0;display:flex;gap:10px;align-items:center;flex-wrap:wrap">
        <span style="font-size:.78rem;color:var(--text-subtle);font-weight:700;text-transform:uppercase;letter-spacing:.04em">
            <?= h(t('Heti tömörítés')) ?>
        </span>
        <span style="display:flex;align-items:center;gap:5px;font-size:.8rem;font-weight:600;
                     color:<?= !empty($_fopt['enabled']) ? '#27ae60' : 'var(--text-subtle)' ?>">
            <span style="width:8px;height:8px;border-radius:50%;flex-shrink:0;display:inline-block;
                         background:<?= !empty($_fopt['enabled']) ? '#27ae60' : 'var(--text-subtle)' ?>"></span>
            <?= !empty($_fopt['enabled']) ? h(t('bekapcsolva')) : h(t('kikapcsolva')) ?>
        </span>
        <form method="post" style="display:inline">
            <?= csrf_field() ?>
            <input type="hidden" name="admin_action" value="fts_optimize_toggle">
            <input type="hidden" name="fts_optimize" value="<?= !empty($_fopt['enabled']) ? '0' : '1' ?>">
            <button type="submit" class="btn btn-sm btn-secondary">
                <?= !empty($_fopt['enabled']) ? h(t('Kikapcsolás')) : h(t('Bekapcsolás')) ?>
            </button>
        </form>
        <span style="font-size:.75rem;color:var(--text-muted)">
            <?= h(t('Vasárnap 04:30. Az ütemezés kikapcsolva is megmarad, csak a feladat lép ki azonnal.')) ?>
            <?php if (!empty($_fopt['last_run'])): ?>
                <br><?= h(t('Utolsó futás')) ?>: <code style="font-size:.9em"><?= h((string)$_fopt['last_run']) ?></code>
            <?php else: ?>
                <br><?= h(t('Még nem futott le.')) ?>
            <?php endif; ?>
        </span>
    </div>
    <?php endif; ?>

    <div style="padding:12px 20px 0;display:flex;gap:8px;align-items:center;flex-wrap:wrap">
        <span style="font-size:.78rem;color:var(--text-subtle);font-weight:700;text-transform:uppercase;letter-spacing:.04em">
            <?= h(t('Méret szerint')) ?>
        </span>
        <?php foreach ([0 => t('Mind'), 100 => '≥ 100 MB', 300 => '≥ 300 MB', 700 => '≥ 700 MB'] as $_m => $_lbl): ?>
        <a href="?sysconfig=1<?= $_m ? '&fmin=' . $_m : '' ?>#fts"
           class="btn btn-sm <?= $_fts_min === $_m ? 'btn-primary' : 'btn-secondary' ?>"><?= h($_lbl) ?></a>
        <?php endforeach; ?>
        <?php if ($_fts_min): ?>
        <span style="font-size:.8rem;color:var(--text-muted)">
            <?= h(sprintf(t('%d index a szűrőnek megfelelően'), $count_fts)) ?>
        </span>
        <?php endif; ?>
    </div>

    <div class="filter-hint" style="margin:16px 20px 4px">
        A Dovecot <code>fts_xapian</code> <?= t('plugin keresési indexet épít minden felhasználó leveleiből. Az index mérete arányos a levelek számával és méretével - de a törölt levelek töredékei (') ?><em>tombstone</em><?= t('-ok) addig bent maradnak, amíg az') ?> <code>fts optimize</code> <?= t('tömörítés le nem fut. A') ?> <strong><?= t('Töröl') ?></strong> <?= t('gomb csak a keresési indexet törli - a levelek nem sérülnek. Az automatikus újraindexelés (') ?><code>fts_autoindex</code><?= t(') az IMAP-mappák megnyitásakor indul el. A heti') ?> <code>fts-optimize.sh</code> <?= t('automatikusan kihagyja a 700 MB-nál nagyobb indexeket (ezeket manuálisan érdemes törölni és újraépíteni).') ?>
    </div>

    <?php if (empty($admin_fts)): ?>
    <div class="empty-state"><p><?= t('Nincs FTS-index egy felhasználóhoz sem.') ?></p></div>
    <?php else:
        $max_mb = max(array_column($admin_fts, 'size_mb')) ?: 1;
    ?>
    <table class="msg-table sys-table" style="table-layout:fixed">
        <colgroup>
            <col style="width:38%"><col style="width:11%"><col style="width:35%"><col style="width:16%">
        </colgroup>
        <thead><tr><th scope="col"><?= t('Felhasználó') ?></th><th scope="col"><?= t('Méret') ?></th><th scope="col"></th><th scope="col"></th></tr></thead>
        <tbody>
        <?php foreach ($_fts_rows as $row):
            $pct       = (int)round($row['size_mb'] / $max_mb * 100);
            $bar_color = $row['size_mb'] > 700 ? 'var(--danger)' : ($row['size_mb'] > 300 ? 'var(--warning)' : 'var(--primary)');
        ?>
        <tr>
            <td style="font-family:monospace;font-size:.8rem"><?= h($row['user']) ?></td>
            <td style="font-variant-numeric:tabular-nums;white-space:nowrap;
                       <?= $row['size_mb'] > 700 ? 'color:var(--danger);font-weight:600' : '' ?>">
                <?= number_format($row['size_mb']) ?> MB
            </td>
            <td style="padding-right:12px">
                <div style="background:var(--border);border-radius:3px;height:8px;overflow:hidden">
                    <div style="background:<?= $bar_color ?>;height:100%;width:<?= $pct ?>%"></div>
                </div>
            </td>
            <td>
                <form method="post" action="?admin=1"
                      onsubmit="return confirm('<?= t('Törli') ?> <?= h(addslashes($row['user'])) ?> <?= t('FTS-indexét?') ?>\n\n<?= t('A levelek nem sérülnek. A keresési index az IMAP-hozzáféréskor automatikusan újraépül.') ?>')">
                    <?= csrf_field() ?>
                    <input type="hidden" name="admin_action" value="delete_fts">
                    <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                    <input type="hidden" name="fts_user"     value="<?= h($row['user']) ?>">
                    <button type="submit" class="btn btn-sm btn-danger"><?= t('Töröl') ?></button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

    <div class="results-footer"><?= render_pager($_fts_page, $_fts_pages, $_fts_url, number_format($count_fts) . ' ' . t('index')) ?></div>
    <?php endif; ?>
</details>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- Audit napló  (moved here from its own sidebar page)                        -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!--
  Always collapsed on load, deliberately with no exceptions -- not by
  ?audit= (still routes here via $is_sysconfig in index.php, it just no
  longer auto-opens the section too), not by a #hash deep link, and not by
  anything remembered from a previous visit. Every Rendszer section starts
  closed on every page visit; the admin opens what they want to see.

  The <details> markup is used rather than JS so the section still renders
  its content in the DOM when closed -- which is why views/audit.php's data
  is loaded up front in index.php regardless of open state.
-->
<details class="sys-sec results-card" id="audit" style="margin-bottom:20px">
    <summary class="results-header">
        <h2><?= t('Audit napló') ?></h2>
        <span class="sys-sec-desc"><?= h(t('Spam műveletek és admin belépések visszakereshető naplója.')) ?></span>
    </summary>
    <div style="padding:0 0 4px">
        <?php require __DIR__ . '/audit.php'; ?>
    </div>
</details>
