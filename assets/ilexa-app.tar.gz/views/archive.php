<!-- ── Archive view (central 30-day store) ── -->
<?php
$arc_msg = $_GET['msg'] ?? '';
$arc_notices = [
    'arc_learn_spam_learned' => ['ok',  arc_learn_message('spam', 'learned')],
    'arc_learn_spam_skipped' => ['ok',  arc_learn_message('spam', 'skipped')],
    'arc_learn_spam_failed'  => ['err', arc_learn_message('spam', 'failed')],
    'arc_learn_ham_learned'  => ['ok',  arc_learn_message('ham', 'learned')],
    'arc_learn_ham_skipped'  => ['ok',  arc_learn_message('ham', 'skipped')],
    'arc_learn_ham_failed'   => ['err', arc_learn_message('ham', 'failed')],
    'view_policy_denied' => ['err', t('A művelet le van tiltva az adatvédelmi beállítás miatt.')],
];
?>
<h1 class="page-title"><?= h(t('Archívum')) ?></h1>
<?php /* Page-level help text, previously always on screen under the title.
   Folded into the same <details class="sys-sec"> the Rendszer, Admin, IOC and
   Kampányok pages use: no `open` attribute, so it is closed on arrival, and
   the id lets the existing script in views/layout_foot.php reopen it across a
   save round-trip. Native fold -- no JavaScript and no CSS added. */ ?>
<details class="sys-sec results-card" id="archive-help" style="margin-bottom:20px">
    <summary class="results-header"><h2><?= t('Mi az Archívum?') ?></h2>
        <span class="sys-sec-desc"><?= h(t('Meddig őrzi a rendszer a másolatokat, és mit tehet egy archivált levéllel.')) ?></span></summary>
    <p class="filter-hint" style="margin-top:0;padding:14px 20px 18px">
        <?= t('Minden be- és kimenő levél központi másolata,') ?> <strong><?= t('30 napig') ?></strong> <?= t('megőrizve - a kézbesítést nem érinti. Megtekintheted a tartalmat, taníthatod spamként/hamként az rspamd-nek, vagy újraküldheted egy címzettnek.') ?>
    </p>
</details>
<?php if (isset($arc_notices[$arc_msg])):
    [$arc_cls, $arc_text] = $arc_notices[$arc_msg];
?>
<div class="notice notice-<?= h($arc_cls) ?>"><?= $arc_text ?></div>
<?php endif; ?>
<div class="filter-card">
    <h2><?= t('Archívum - szűrők') ?></h2>
    <form method="get" action="">
        <input type="hidden" name="arc" value="1">
        <div class="filter-row">
            <div class="filter-group">
                <label for="a_domain">Domain</label>
                <select name="adomain" id="a_domain">
                    <option value=""><?= t('- összes domain -') ?></option>
                    <?php foreach ($domains as $d): ?>
                    <option value="<?= h($d) ?>" <?= $af['domain'] === $d ? 'selected' : '' ?>><?= h($d) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="filter-group">
                <label for="a_from"><?= t('Feladó') ?></label>
                <input type="text" name="afrom" id="a_from" value="<?= h($af['from']) ?>" placeholder="<?= h(t('név vagy cím')) ?>">
            </div>
            <div class="filter-group">
                <label for="a_to"><?= t('Címzett') ?></label>
                <input type="text" name="ato" id="a_to" value="<?= h($af['to']) ?>" placeholder="<?= h(t('cím')) ?>">
            </div>
            <div class="filter-group">
                <label for="a_subject"><?= t('Tárgy') ?></label>
                <input type="text" name="asubject" id="a_subject" value="<?= h($af['subject']) ?>">
            </div>
            <div class="filter-group">
                <label for="a_status"><?= t('Állapot') ?></label>
                <select name="astatus" id="a_status">
                    <option value=""><?= t('- mind -') ?></option>
                    <option value="spam" <?= $af['status'] === 'spam' ? 'selected' : '' ?>>Spam</option>
                    <option value="ham"  <?= $af['status'] === 'ham'  ? 'selected' : '' ?>>Ham</option>
                </select>
            </div>
            <div class="filter-group">
                <label for="a_since"><?= t('Ettől') ?></label>
                <input type="date" name="asince" id="a_since" value="<?= h($af['since']) ?>">
            </div>
            <div class="filter-group">
                <label for="a_before"><?= t('Eddig') ?></label>
                <input type="date" name="abefore" id="a_before" value="<?= h($af['before']) ?>">
            </div>
            <div class="filter-group">
                <label>&nbsp;</label>
                <button type="submit" class="btn btn-primary"><?= t('Keresés') ?></button>
            </div>
            <div class="filter-group">
                <label>&nbsp;</label>
                <a class="btn" href="?arc=1"><?= t('Szűrők törlése') ?></a>
            </div>
        </div>
    </form>
</div>

<div class="results-card">
    <div class="results-header">
        <h2><?= t('Archívum') ?></h2>
        <div style="display:flex;align-items:center;gap:12px">
            <span class="meta">
                <?php if ($total > 0): ?>
                    <?= (($page - 1) * $per_page) + 1 ?>&ndash;<?= min($page * $per_page, $total) ?> / <?= $total ?> <?= t('tétel') ?>
                <?php else: ?><?= t('0 tétel') ?><?php endif; ?>
            </span>
            <?php $exp_url = '?' . http_build_query(array_filter([
                'export'=>'archive','adomain'=>$af['domain'],'afrom'=>$af['from'],'ato'=>$af['to'],
                'asubject'=>$af['subject'],'astatus'=>$af['status'],'asince'=>$af['since'],'abefore'=>$af['before'],
            ])); ?>
            <?php if (qa_view_allowed(true)): ?>
            <a class="btn btn-sm btn-secondary" href="<?= h($exp_url) ?>" title="<?= h(t('A jelenlegi szűrés exportálása CSV-be')) ?>"><svg class="icon"><use href="#icon-download"></use></svg> CSV</a>
            <?php endif; ?>
        </div>
    </div>

    <div class="legend">
        <span class="legend-label"><?= t('Jelmagyarázat:') ?></span>
        <span class="verdict verdict-ham"><span class="vi"><svg class="icon"><use href="#icon-check"></use></svg></span> Ham</span>
        <span class="legend-sep"><?= t('= jó levél') ?></span>
        <span class="verdict verdict-spam"><span class="vi"><svg class="icon"><use href="#icon-warning"></use></svg></span> Spam</span>
        <span class="legend-sep"><?= t('= a szűrő spamnek ítélte') ?></span>
    </div>

    <?php if (!qa_view_allowed(true)): ?>
    <p class="filter-hint" style="padding:12px 16px 8px">
        <svg class="icon"><use href="#icon-lock"></use></svg>
        <?= h(t('A levelek tartalma nem nyitható meg, és az exportálás nem érhető el: az adatvédelmi beállítás jelenleg letiltja. Adminisztrátor az Admin lapon módosíthatja.')) ?>
    </p>
    <?php endif; ?>

    <?php if ($archive_error): ?>
        <div class="empty-state"><div style="font-size:2em"><svg class="icon"><use href="#icon-warning"></use></svg></div><p><?= t('Az archívum-index nem elérhető.') ?></p></div>
    <?php elseif (!$archive_rows): ?>
        <div class="empty-state"><p><?= t('Nincs találat a megadott szűrőkre.') ?></p></div>
    <?php else:
        $cur_sort = in_array($_GET['asort'] ?? '', ['ts','from_addr','to_addr','subject','rspamd_score','is_spam','sender_cc'], true) ? $_GET['asort'] : 'ts';
        $cur_dir  = strtoupper($_GET['adir'] ?? '') === 'ASC' ? 'ASC' : 'DESC';
        $sortth = function (string $col, string $label) use ($af, $page, $cur_sort, $cur_dir) {
            $next = ($cur_sort === $col && $cur_dir === 'ASC') ? 'DESC' : 'ASC';
            $ind  = $cur_sort === $col ? ($cur_dir === 'ASC' ? ' <svg class="icon icon-rot-270"><use href="#icon-chevron"></use></svg>' : ' <svg class="icon icon-rot-90"><use href="#icon-chevron"></use></svg>') : '';
            $url  = '?' . http_build_query(array_filter([
                'arc'=>'1','adomain'=>$af['domain'],'afrom'=>$af['from'],'ato'=>$af['to'],
                'asubject'=>$af['subject'],'astatus'=>$af['status'],'asince'=>$af['since'],
                'abefore'=>$af['before'],'asort'=>$col,'adir'=>$next,'page'=>$page,
            ]));
            return '<a class="sort-th' . ($cur_sort === $col ? ' active' : '') . '" href="' . h($url) . '">' . $label . $ind . '</a>';
        };
        // Loaded once per page, not per row: the Enged./Tiltás buttons must
        // reflect a sender ALREADY on that list rather than offering an action
        // list_add() would reject anyway (see the logical-issue report this
        // fixes -- all four row buttons rendered active regardless of state).
        $arc_white_entries = can('action') ? list_load('white') : [];
        $arc_block_entries = can('action') ? list_load('block') : [];
    ?>
    <table class="archive-table">
        <thead><tr>
            <th scope="col"></th>
            <th scope="col"><?= $sortth('ts', t('Időpont')) ?></th>
            <th scope="col"><?= $sortth('from_addr', t('Feladó')) ?></th>
            <th scope="col"><?= $sortth('to_addr', t('Címzett')) ?></th>
            <th scope="col"><?= $sortth('subject', t('Tárgy')) ?> <small style="font-weight:normal;opacity:.7"><?= t('(kattintson a megtekintéshez)') ?></small></th>
            <th scope="col" title="<?= h(t('A küldő szerver országa a legfelső Received fejléc IP-címe alapján. Üres, ha a levélnek nincs nyilvános küldő IP-címe.')) ?>"><?= $sortth('sender_cc', t('Ország')) ?></th>
            <th scope="col"><?= $sortth('rspamd_score', t('Pont')) ?></th>
            <th scope="col"><?= t('Műveletek') ?></th>
        </tr></thead>
        <tbody>
        <?php $ri = 0; foreach ($archive_rows as $r): $ri++;
            // The badge shows the CURRENT verdict, which is the taught one when
            // an admin has corrected rspamd. It used to show is_spam alone, so a
            // message you had just taught as spam went on displaying "Ham" --
            // the star beside it was the only hint, and it reads as the console
            // ignoring the correction. rspamd's original verdict is not thrown
            // away: when the two disagree the badge is marked and the title
            // names both, which is what makes the disagreement useful for
            // tuning rather than merely invisible.
            $taught    = (string)($r['learned_as'] ?? '');
            $eff_spam  = $taught !== '' ? ($taught === 'spam') : (bool)$r['is_spam'];
            $corrected = $taught !== '' && (($taught === 'spam') !== (bool)$r['is_spam']);
            $badge_title = $corrected
                ? sprintf(t('rspamd ítélete: %s - tanítással felülírva: %s'),
                          $r['is_spam'] ? t('Spam') : t('Ham'), $eff_spam ? t('Spam') : t('Ham'))
                : '';
            $badge = '<span id="verdict-arc' . (int)$r['uid'] . '">'
                . '<span class="verdict verdict-' . ($eff_spam ? 'spam' : 'ham') . ($corrected ? ' verdict-corrected' : '') . '"'
                . ($badge_title !== '' ? ' title="' . h($badge_title) . '"' : '') . '>'
                . '<span class="vi"><svg class="icon"><use href="#icon-'
                . ($eff_spam ? 'warning' : 'check') . '"></use></svg></span> '
                . ($eff_spam ? 'Spam' : 'Ham')
                . ($corrected ? '<sup aria-hidden="true">*</sup>' : '')
                . '</span></span>';
            $learned = '<span id="learned-arc' . (int)$r['uid'] . '">';
            if (!empty($r['learned_as'])) {
                $learned_label = $r['learned_as'] === 'spam' ? t('spam') : t('ham');
                $learned_color = $r['learned_as'] === 'spam' ? 'var(--danger)' : 'var(--success)';
                $learned_when  = h(date('Y-m-d H:i', (int)$r['learned_at']));
                $learned .= '<span class="learned-mark" style="color:' . $learned_color . '"'
                    . ' data-ts="' . (int)$r['learned_at'] . '" data-learned-label="' . h($learned_label) . '"'
                    . ' title="' . h(sprintf(t('Megtanítva: %s (%s)'), $learned_label, $learned_when)) . '"><svg class="icon" style="width:1.4em;height:1.4em"><use href="#icon-star"></use></svg></span>';
            }
            $learned .= '</span>';
            $score = $r['rspamd_score'] === null ? '-' : h((string)round((float)$r['rspamd_score'], 2));
            // Empty for any row with no resolvable public sender IP -- see
            // qa_country_flag(). The sender IP rides in the same tooltip so the
            // flag can be sanity-checked against it without opening the message.
            $flag = qa_country_flag($r['sender_cc'] ?? null, $r['sender_ip'] ?? null);
            $to_hint = h(str_replace(["'", "\\"], ['', ''], (string)$r['to_addr']));
        ?>
            <tr class="data-row<?= $ri % 2 === 0 ? ' alt' : '' ?> <?= $r['is_spam'] ? 'f-spam' : 'f-ham' ?><?= !empty($r['learned_as']) ? ' learned' : '' ?>">
                <?php if (qa_view_allowed(true)): ?>
                <?php /* The title text alone goes through t(). This used to pass the
                         whole fragment -- `" title="..." onclick="toggleArc(this,` --
                         as the translation KEY, which only worked because no en.php
                         entry matched and it fell through to the Hungarian source
                         verbatim; adding one would have injected markup. Rendered
                         output is byte-identical to before. */ ?>
                <td><span class="arrow" id="arr-arc<?= (int)$r['uid'] ?>" title="<?= h(t('Kattintson a levél megtekintéséhez')) ?>" onclick="toggleArc(this, <?= (int)$r['uid'] ?>)"><svg class="icon"><use href="#icon-chevron"></use></svg></span></td>
                <?php else: ?>
                <td></td>
                <?php endif; ?>
                <td class="col-date local-ts" data-label="<?= h(t('Időpont')) ?>" data-ts="<?= (int)$r['ts'] ?>"><?= h(date('Y-m-d H:i', (int)$r['ts'])) ?></td>
                <td class="col-user" data-label="<?= h(t('Feladó')) ?>"><?= h($r['from_addr']) ?></td>
                <?php // Never render this cell blank. A BCC'd or bulk message can carry no
                      // To:/Cc: and no Received "for" clause at all, so the indexer has
                      // nothing to record -- 10 of 4,836 archived messages. Showing an
                      // explicit "unknown" says that, where an empty cell reads as a bug. ?>
                <td class="col-user" data-label="<?= h(t('Címzett')) ?>"><?php
                    if (trim((string)$r['to_addr']) !== ''): ?><?= h($r['to_addr']) ?><?php
                    else: ?><span style="color:var(--text-subtle);font-style:italic"
                        title="<?= h(t('A levél nem tartalmaz címzettet egyetlen fejlécében sem (rejtett másolat vagy tömeges küldés).')) ?>"><?= h(t('ismeretlen')) ?></span><?php
                    endif; ?></td>
                <?php if (qa_view_allowed(true)): ?>
                <td class="subject-link" data-label="<?= h(t('Tárgy')) ?>" title="<?= h(t('Kattintson a levél megtekintéséhez')) ?>"
                    onclick="toggleArc(document.getElementById('arr-arc<?= (int)$r['uid'] ?>'), <?= (int)$r['uid'] ?>)"><?= h($r['subject']) ?> <?= $badge ?> <?= $learned ?></td>
                <?php else: ?>
                <td data-label="<?= h(t('Tárgy')) ?>"><?= h($r['subject']) ?> <?= $badge ?> <?= $learned ?></td>
                <?php endif; ?>
                <td class="col-cc" data-label="<?= h(t('Ország')) ?>"><?= $flag ?></td>
                <td data-label="Pont" style="color:#666"><?= $score ?></td>
                <td class="col-actions" data-label="<?= h(t('Műveletek')) ?>" style="width:230px">
                    <?php if (can('action')):
                        // Already-done states: teaching the SAME verdict again,
                        // or listing a sender that is already on that list,
                        // is not a live choice -- list_add()/re-teach would
                        // just no-op or error. Grey the button out instead of
                        // leaving all four looking equally available.
                        $already_ham  = ($r['learned_as'] ?? '') === 'ham';
                        $already_spam = ($r['learned_as'] ?? '') === 'spam';
                        // from_addr is commonly "Display Name <addr>", not a
                        // bare address -- the list matcher's regexes are
                        // anchored and never match a trailing '>'.
                        $sender_email = qa_extract_email((string)$r['from_addr']);
                        $on_white = $sender_email !== '' && list_matches($arc_white_entries, $sender_email);
                        $on_block = $sender_email !== '' && list_matches($arc_block_entries, $sender_email);
                    ?>
                    <div class="action-btns">
                    <?= arc_action_form('arc_ham',  (string)$r['uid'], $af, $page, '<svg class="icon"><use href="#icon-check"></use></svg> Ham',  t('Hamként tanítja a levelet az rspamd-nek?'), 'btn-success',
                        $already_ham ? t('Ez a levél már ham-ként van tanítva.') : null) ?>
                    <?= arc_action_form('arc_spam', (string)$r['uid'], $af, $page, '<svg class="icon"><use href="#icon-block"></use></svg> ' . t('Spam'), t('Spamként tanítja a levelet az rspamd-nek?'), 'btn-danger',
                        $already_spam ? t('Ez a levél már spam-ként van tanítva.') : null) ?>
                    <?= sender_list_form('white', (string)$r['from_addr'], $af, $page, '<svg class="icon"><use href="#icon-check"></use></svg> ' . t('Enged.'), t('Fehérlistára teszed a feladót?'), 'btn-success',
                        $on_white ? t('A feladó már a fehérlistán van.') : null) ?>
                    <?= sender_list_form('block', (string)$r['from_addr'], $af, $page, '<svg class="icon"><use href="#icon-block"></use></svg> ' . t('Tiltás'), t('Blokklistára teszed a feladót? (a levelei ezután elutasításra kerülnek)'), 'btn-danger',
                        $on_block ? t('A feladó már a blokklistán van.') : null) ?>
                    <?php if (qa_view_allowed(true)): ?>
                    <button type="button" class="btn btn-sm btn-secondary action-btn-wide" onclick="arcResend(<?= (int)$r['uid'] ?>, '<?= $to_hint ?>')"><svg class="icon"><use href="#icon-mail"></use></svg> <?= t('Újraküld') ?></button>
                    <?php endif; ?>
                    <?php if (can('admin') && qa_view_allowed(true)): ?>
                    <button type="button" class="btn btn-sm btn-secondary action-btn-wide arc-ioc-btn" onclick="arcIocCheck(this, <?= (int)$r['uid'] ?>)"><svg class="icon"><use href="#icon-search"></use></svg> <?= t('IOC ellenőrzés') ?></button>
                    <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>

    <?php if ($total_pages > 1):
        $aurl = function (int $pp) use ($af) {
            return '?' . http_build_query(array_filter([
                'arc' => '1', 'adomain' => $af['domain'], 'afrom' => $af['from'], 'ato' => $af['to'], 'asubject' => $af['subject'],
                'astatus' => $af['status'], 'asince' => $af['since'], 'abefore' => $af['before'],
                'asort' => $_GET['asort'] ?? '', 'adir' => $_GET['adir'] ?? '', 'page' => $pp,
            ]));
        };
    ?>
    <div class="results-footer"><?= render_pager($page, $total_pages, $aurl, number_format($total) . ' ' . t('tétel')) ?></div>
    <?php endif; ?>

    <!-- hidden resend form, reused by arcResend() -->
    <?= arc_shared_form($af, $page) ?>

    <form id="arcResendForm" method="post" action="" style="display:none">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="arc_resend">
        <input type="hidden" name="msg_uid" id="arcResendUid">
        <input type="hidden" name="recipient" id="arcResendRcpt">
        <?= arc_hidden($af, $page) ?>
    </form>
</div>
