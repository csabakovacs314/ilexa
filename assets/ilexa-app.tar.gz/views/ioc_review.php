<?php
// Extracted-candidate review screen, populated by
// handle_ioc_action('ioc_extract') (src/ioc.php) into $_SESSION['ioc_review'].
// Included from views/ioc.php, before the add-form/list sections.

if (empty($_SESSION['ioc_review'])) return;
$ioc_candidates = $_SESSION['ioc_review']['candidates'];
?>
<div class="results-card" id="ioc-review" style="margin-bottom:20px">
    <div class="results-header">
        <h2><?= t('Kinyert indikátorok jóváhagyása') ?></h2>
        <span class="meta"><?= t('Semmi nem kerül mentésre a jóváhagyás előtt.') ?></span>
    </div>
    <?php if (empty($ioc_candidates)): ?>
    <div class="empty-state"><p><?= t('Ebből a levélből nem sikerült indikátort kinyerni.') ?></p></div>
    <?php else: ?>
    <form method="post" action="?ioc=1">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="ioc_confirm">
        <table class="msg-table" style="table-layout:fixed">
            <colgroup><col style="width:8%"><col style="width:15%"><col style="width:54%">
                      <col style="width:23%"></colgroup>
            <thead><tr>
                <th scope="col"></th><th scope="col"><?= t('Típus') ?></th><th scope="col"><?= t('Érték') ?></th>
                <th scope="col"><?= t('Megbízhatóság') ?></th>
            </tr></thead>
            <tbody>
            <?php foreach ($ioc_candidates as $i => $c): ?>
            <tr>
                <td><input type="checkbox" name="ioc_pick[]" value="<?= (int)$i ?>"></td>
                <td><?= h($c['type']) ?></td>
                <td style="font-family:monospace;word-break:break-all"><?= h($c['value']) ?></td>
                <td>
                    <select name="ioc_conf[<?= (int)$i ?>]">
                        <?php foreach (IOC_CONFIDENCE_LEVELS as $cf): ?>
                        <option value="<?= h($cf) ?>" <?= $cf === 'medium' ? 'selected' : '' ?>><?= h($cf) ?></option>
                        <?php endforeach; ?>
                    </select>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <div style="padding:12px 20px;display:flex;gap:8px">
            <button type="submit" class="btn btn-sm btn-primary"><?= t('Kijelöltek mentése') ?></button>
            <button type="submit" class="btn btn-sm btn-secondary" onclick="document.querySelectorAll('input[name=\'ioc_pick[]\']').forEach(cb=>cb.checked=false)"><?= t('Mégse') ?></button>
        </div>
    </form>
    <?php endif; ?>
</div>
