<script>
// Release puts a message the filter flagged back into a real mailbox, so the
// confirmation names the message rather than asking an anonymous "are you sure".
// Archive row actions share one hidden form; the button only supplies which
// action, and either a message uid or a sender address.
// Keyboard triage. Quarantine is a repetitive loop -- look, decide, next --
// so the whole cycle is reachable without the mouse. Deliberately inert while
// typing in a field, and the destructive keys still raise their confirmation.
(function () {
    var rows = function () { return Array.prototype.slice.call(document.querySelectorAll('tr.data-row')); };
    var cur = -1;
    function focusRow(i) {
        var r = rows();
        if (!r.length) return;
        cur = Math.max(0, Math.min(r.length - 1, i));
        r.forEach(function (x, n) { x.classList.toggle('kb-focus', n === cur); });
        r[cur].scrollIntoView({ block: 'nearest' });
    }
    function btn(sel) {
        var r = rows()[cur];
        return r ? r.querySelector(sel) : null;
    }
    document.addEventListener('keydown', function (e) {
        var t = e.target || {};
        var tag = (t.tagName || '').toLowerCase();
        if (tag === 'input' || tag === 'textarea' || tag === 'select' || t.isContentEditable) return;
        if (e.ctrlKey || e.altKey || e.metaKey) return;
        switch (e.key) {
            case 'j': focusRow(cur + 1); e.preventDefault(); break;
            case 'k': focusRow(cur - 1); e.preventDefault(); break;
            case 'o':
            case 'Enter': { var a = btn('.subject-cell, .subject-arrow'); if (a) { a.click(); e.preventDefault(); } break; }
            case 'r': { var b = btn('button[value=release]');  if (b) { b.click(); e.preventDefault(); } break; }
            case 'd': { var b2 = btn('button[value=delete]');  if (b2) { b2.click(); e.preventDefault(); } break; }
            case '/': { var f = document.querySelector('input[name=from], input[name=af_from]'); if (f) { f.focus(); e.preventDefault(); } break; }
            case '?': { var h = document.getElementById('kbHelp'); if (h) h.style.display = (h.style.display === 'none' ? '' : 'none'); break; }
        }
    });
})();

// Top-level (not inside the browser-local-timestamps IIFE below) so that
// applyArcLearnResult() can read it too when it runs a fresh in-place learn.
const LEARNED_TITLE_TPL = <?= json_encode(t('Megtanítva: %s (%s)')) ?>;

// ── rspamd module panel: load only when the section is opened ───────────────
// The panel is collapsed by default and its data costs a full `rspamadm
// configdump` server-side, so fetching it during page render meant every visit
// to Rendszer paid ~870ms for a table it usually never showed. Fetch on first
// expand instead.
const RMODS_TXT = {
  csrf:     <?= json_encode(csrf_token()) ?>,
  enabled:  <?= json_encode(t('bekapcsolva')) ?>,
  disabled: <?= json_encode(t('kikapcsolva')) ?>,
  byDefault:<?= json_encode(t('alapértelmezés szerint')) ?>,
  explicit: <?= json_encode(t('kifejezetten beállítva')) ?>,
  on:       <?= json_encode(t('Bekapcsolás')) ?>,
  off:      <?= json_encode(t('Kikapcsolás')) ?>,
  prot:     <?= json_encode(t('védett')) ?>,
  protTip:  <?= json_encode(t('Védett modul: a kikapcsolása csendes hibát okozna.')) ?>,
  colMod:   <?= json_encode(t('Modul')) ?>,
  colState: <?= json_encode(t('Állapot')) ?>,
  colSet:   <?= json_encode(t('Beállítás')) ?>,
  colAct:   <?= json_encode(t('Művelet')) ?>,
  failed:   <?= json_encode(t('A modullista betöltése sikertelen.')) ?>,
  meta:     <?= json_encode(t('%d / %d bekapcsolva')) ?>,
};
let rmodsLoaded = false;
function loadRspamdModules() {
    if (rmodsLoaded) return;
    rmodsLoaded = true;                       // one fetch per page, even if toggled repeatedly
    const body = document.getElementById('rmods-body');
    const meta = document.getElementById('rmods-meta');
    if (!body) return;
    fetch('?rmods=1', {credentials: 'same-origin', headers: {'X-Requested-With': 'XMLHttpRequest'}})
        .then(r => r.json())
        .then(d => {
            const mods = (d && d.modules) || [];
            if (!mods.length) { body.innerHTML = '<span style="color:var(--danger)">' + esc(RMODS_TXT.failed) + '</span>'; return; }
            const on = mods.filter(m => m.enabled).length;
            if (meta) meta.textContent = RMODS_TXT.meta.replace('%d', on).replace('%d', mods.length);
            let h = '<table class="msg-table"><thead><tr>' +
                    '<th scope="col">' + esc(RMODS_TXT.colMod)   + '</th>' +
                    '<th scope="col">' + esc(RMODS_TXT.colState) + '</th>' +
                    '<th scope="col">' + esc(RMODS_TXT.colSet)   + '</th>' +
                    '<th scope="col">' + esc(RMODS_TXT.colAct)   + '</th></tr></thead><tbody>';
            for (const m of mods) {
                const col = m.enabled ? '#27ae60' : 'var(--text-subtle)';
                h += '<tr class="data-row">' +
                     '<td data-label="' + esc(RMODS_TXT.colMod) + '"><code>' + esc(m.name) + '</code></td>' +
                     '<td data-label="' + esc(RMODS_TXT.colState) + '">' +
                       '<span style="display:flex;align-items:center;gap:5px;font-size:.8rem;font-weight:600;color:' + col + '">' +
                       '<span style="width:8px;height:8px;border-radius:50%;flex-shrink:0;display:inline-block;background:' + col + '"></span>' +
                       esc(m.enabled ? RMODS_TXT.enabled : RMODS_TXT.disabled) + '</span></td>' +
                     '<td data-label="' + esc(RMODS_TXT.colSet) + '" style="font-size:.78rem;color:var(--text-muted)">' +
                       esc(m.explicit ? RMODS_TXT.explicit : RMODS_TXT.byDefault) + '</td>' +
                     '<td data-label="' + esc(RMODS_TXT.colAct) + '">';
                if (m.protected) {
                    h += '<span style="font-size:.78rem;color:var(--text-subtle)" title="' + esc(RMODS_TXT.protTip) + '">&#128274; ' + esc(RMODS_TXT.prot) + '</span>';
                } else {
                    h += '<form method="post" style="display:inline">' +
                         '<input type="hidden" name="_csrf" value="' + esc(RMODS_TXT.csrf) + '">' +
                         '<input type="hidden" name="admin_action" value="rspamd_module_toggle">' +
                         '<input type="hidden" name="rspamd_module" value="' + esc(m.name) + '">' +
                         '<input type="hidden" name="rspamd_on" value="' + (m.enabled ? '0' : '1') + '">' +
                         '<button type="submit" class="btn btn-sm btn-secondary">' + esc(m.enabled ? RMODS_TXT.off : RMODS_TXT.on) + '</button></form>';
                }
                h += '</td></tr>';
            }
            body.innerHTML = h + '</tbody></table>';
        })
        .catch(() => { body.innerHTML = '<span style="color:var(--danger)">' + esc(RMODS_TXT.failed) + '</span>'; });
}
(function () {
    const d = document.getElementById('rspamdmods');
    if (!d) return;
    d.addEventListener('toggle', function () { if (d.open) loadRspamdModules(); });
    // Toggling a module POSTs and redirects back to #rspamdmods. Without this
    // the operator would land on a page where the section had closed again and
    // their change appeared to have done nothing.
    if (location.hash === '#rspamdmods') { d.open = true; loadRspamdModules(); }
})();
const VERDICT_CORRECTED_TPL = <?= json_encode(t('rspamd ítélete: %s - tanítással felülírva: %s')) ?>;
const SPAM_LBL = <?= json_encode(t('Spam')) ?>;
const HAM_LBL  = <?= json_encode(t('Ham')) ?>;

function arcSubmit(action, uid, sender, confirmMsg) {
    if (confirmMsg && !confirm(confirmMsg)) return false;
    var f = document.getElementById('arcActionForm');
    if (!f) return false;
    f.querySelector('#arcActX').value      = action;
    f.querySelector('#arcActUid').value    = (uid    === null ? '' : uid);
    f.querySelector('#arcActSender').value = (sender === null ? '' : sender);

    var ajaxActions = ['arc_spam', 'arc_ham', 'quick_block', 'quick_white'];
    if (ajaxActions.indexOf(action) === -1) {
        f.submit();
        return true;
    }

    var body = new URLSearchParams(new FormData(f));
    fetch(f.getAttribute('action') || '?', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'X-Requested-With': 'XMLHttpRequest' }, body: body,
    })
        .then(function (r) {
            var ct = r.headers.get('content-type') || '';
            if (!r.ok || ct.indexOf('application/json') === -1) throw new Error('unexpected-response');
            return r.json();
        })
        .then(function (d) {
            if (action === 'arc_spam' || action === 'arc_ham') {
                applyArcLearnResult(uid, d);
            } else {
                showLookupToast(d.message || (d.ok ? <?= json_encode(t('Kész.')) ?> : <?= json_encode(t('Hiba történt.')) ?>));
            }
        })
        .catch(function () {
            if (action === 'arc_spam' || action === 'arc_ham') {
                // The learn action may already have happened server-side even
                // though this response couldn't be trusted -- unlike
                // quick_block/quick_white (idempotent via list_add's own
                // duplicate check), blindly retrying via a real submit here
                // risks silently re-running rspamd_learn() a second time.
                // Surface the ambiguity instead of guessing.
                showLookupToast(<?= json_encode(t('Hálózati hiba történt - ellenőrizd, hogy a művelet lefutott-e, mielőtt újra megpróbálod.')) ?>);
            } else {
                // #arcActionForm is a single page-wide shared form (one for
                // all rows, not one per row) -- if the admin clicked another
                // row's button while this fetch was still in flight, the
                // form's fields now belong to that LATER click, not this
                // one. Re-populate from this call's own closed-over
                // action/uid/sender before falling back to a real submit, so
                // a failed quick_block on row A can never end up submitting
                // row B's action.
                f.querySelector('#arcActX').value      = action;
                f.querySelector('#arcActUid').value    = (uid    === null ? '' : uid);
                f.querySelector('#arcActSender').value = (sender === null ? '' : sender);
                f.submit();
            }
        });
    return true;
}

function applyArcLearnResult(uid, d) {
    if (d.learned_as) {
        var span = document.getElementById('learned-arc' + uid);
        if (span) {
            var color = d.learned_as === 'spam' ? 'var(--danger)' : 'var(--success)';
            var label = d.learned_as === 'spam' ? <?= json_encode(t('spam')) ?> : <?= json_encode(t('ham')) ?>;
            var title = LEARNED_TITLE_TPL.replace('%s', label).replace('%s', formatLocalDateTime(d.learned_at));
            span.innerHTML = '<span class="learned-mark" style="color:' + color + '"' +
                ' data-ts="' + d.learned_at + '" data-learned-label="' + esc(label) + '"' +
                ' title="' + esc(title) + '"><svg class="icon" style="width:1.4em;height:1.4em"><use href="#icon-star"></use></svg></span>';
            var row = span.closest('tr');
            if (row) row.classList.add('learned');

            // Flip the verdict badge too. Updating only the star left the row
            // still reading "Ham" straight after you taught it as spam, which
            // looks like the correction was ignored. d.was_spam is rspamd's
            // original verdict, kept so the badge can say the two disagree.
            var vb = document.getElementById('verdict-arc' + uid);
            if (vb) {
                var isSpam = d.learned_as === 'spam';
                var corrected = (typeof d.was_spam !== 'undefined') && (isSpam !== !!d.was_spam);
                var title = corrected
                    ? VERDICT_CORRECTED_TPL.replace('%s', (d.was_spam ? SPAM_LBL : HAM_LBL))
                                           .replace('%s', (isSpam ? SPAM_LBL : HAM_LBL))
                    : '';
                vb.innerHTML = '<span class="verdict verdict-' + (isSpam ? 'spam' : 'ham') +
                    (corrected ? ' verdict-corrected' : '') + '"' +
                    (title ? ' title="' + esc(title) + '"' : '') + '>' +
                    '<span class="vi"><svg class="icon"><use href="#icon-' +
                    (isSpam ? 'warning' : 'check') + '"></use></svg></span> ' +
                    (isSpam ? 'Spam' : 'Ham') +
                    (corrected ? '<sup aria-hidden="true">*</sup>' : '') + '</span>';
            }
        }
    }
    showLookupToast(d.message);
}

function confirmRelease(btn) {
    var to   = btn.getAttribute('data-rel-to')   || '';
    var from = btn.getAttribute('data-rel-from') || '';
    var subj = btn.getAttribute('data-rel-subj') || '';
    if (subj.length > 80) subj = subj.slice(0, 80) + '\u2026';
    return confirm(
        '<?= jsq(t('Felszabadítja ezt a levelet?')) ?>\n\n' +
        '<?= jsq(t('Feladó')) ?>: '  + from + '\n' +
        '<?= jsq(t('Címzett')) ?>: ' + to   + '\n' +
        '<?= jsq(t('Tárgy')) ?>: '   + subj + '\n\n' +
        '<?= jsq(t('A levél bekerül a címzett Beérkező levelek mappájába, és jó levélként tanítja az rspamd-et.')) ?>'
    );
}

const CSRF = <?= json_encode(csrf_token()) ?>;

// Generated from QA_VERDICT_ICON (src/ioc_lookup.php) rather than retyped, so
// the client badge markup can never disagree with the server-rendered markup
// for the same verdict. Must be defined before any handler that reads it.
var QA_VERDICT_ICON = <?= json_encode(QA_VERDICT_ICON) ?>;

const detailRows = {};

function esc(s) {
    return String(s || '')
        .replace(/&/g,'&amp;').replace(/</g,'&lt;')
        .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// Render a fetched message into `inner` (a .detail-inner). Shared by the quarantine
// (toggleDetail) and archive (toggleArc) viewers. HTML renders in a sandboxed iframe
// with a CSP that blocks remote content; "Load remote images" opts in per message.
function renderMessageBody(inner, d, src) {
    const textTrunc = d.truncated
        ? '<div class="truncated-note"><?= jsq(t('(A levél tartalma 8000 karakternél hosszabb - csak az első rész látható.)')) ?></div>'
        : '';

    let whyPanel = '';
    if (d.spamd_result) {
        const isSpam = /:\s*True/i.test(d.spamd_result)
                    || (d.spam_action && /reject|rewrite|add.?header|soft.?reject/i.test(d.spam_action));
        const score = (d.spam_score !== '' ? d.spam_score : '?');
        const thr   = (d.spam_threshold !== '' ? d.spam_threshold : '?');
        const syms  = (d.spam_symbols || []).map(s => '<span class="sym">' + esc(s) + '</span>').join('');
        whyPanel =
            '<div class="why ' + (isSpam ? 'why-spam' : 'why-ham') + '">' +
              '<div class="why-head"><strong><?= jsq(t('Miért? (rspamd)')) ?></strong> &middot; ' +
                '<?= jsq(t('Pontszám')) ?>: <b>' + esc(score) + '</b> / ' + esc(thr) +
                (d.spam_action ? ' &middot; <?= jsq(t('Művelet')) ?>: <b>' + esc(d.spam_action) + '</b>' : '') +
              '</div>' +
              (syms ? '<div class="why-syms">' + syms + '</div>' : '') +
            '</div>';
    }

    let toolbar = '';
    if (d.has_html) {
        toolbar =
            '<div class="detail-toolbar">' +
              '<div class="view-toggle">' +
                '<button type="button" class="vt-btn vt-html">HTML</button>' +
                '<button type="button" class="vt-btn vt-text"><?= jsq(t('Szöveg')) ?></button>' +
                '<button type="button" class="vt-btn vt-source"><?= jsq(t('Forrás')) ?></button>' +
              '</div>' +
              '<span class="remote-note" style="display:none">' +
                '<span class="rn-head"><svg class="icon"><use href="#icon-warning"></use></svg> <?= jsq(t('Távoli tartalom blokkolva')) ?></span>' +
                '<span class="rn-why"><?= jsq(t('A levél távoli képeket vagy tartalmat tölt be. Betöltésük elárulhatja az IP-címét, és visszaigazolja a feladónak, hogy megnyitotta a levelet.')) ?></span>' +
                '<button type="button" class="btn btn-sm btn-secondary vt-loadimg"><?= jsq(t('Képek betöltése')) ?></button>' +
              '</span>' +
            '</div>';
    }
    let senderActions = '';
    if (d.from) {
        senderActions =
            '<div class="sender-actions">' +
              '<span class="sa-label"><?= jsq(t('Feladó műveletek:')) ?></span>' +
              '<button type="button" class="btn btn-sm btn-secondary sa-block"><svg class="icon"><use href="#icon-block"></use></svg> <?= jsq(t('Feladó tiltása')) ?></button>' +
              '<button type="button" class="btn btn-sm btn-secondary sa-white"><svg class="icon"><use href="#icon-check"></use></svg> <?= jsq(t('Engedélyezés')) ?></button>' +
            '</div>';
    }
    inner.insertAdjacentHTML('afterbegin',
        whyPanel + toolbar + '<div class="detail-view-slot"></div>' + senderActions);

    const bBlock = inner.querySelector('.sa-block');
    const bWhite = inner.querySelector('.sa-white');
    if (bBlock) bBlock.addEventListener('click', () => submitSenderList('block', d.from, src));
    if (bWhite) bWhite.addEventListener('click', () => submitSenderList('white', d.from, src));

    const slot  = inner.querySelector('.detail-view-slot');
    const bHtml = inner.querySelector('.vt-html');
    const bText = inner.querySelector('.vt-text');
    const bSrc  = inner.querySelector('.vt-source');
    const bImg  = inner.querySelector('.vt-loadimg');
    const rnote = inner.querySelector('.remote-note');
    let remote = false;

    function setActive(mode) {
        if (bHtml) bHtml.classList.toggle('active', mode === 'html');
        if (bText) bText.classList.toggle('active', mode === 'text');
        if (bSrc)  bSrc.classList.toggle('active',  mode === 'source');
        if (rnote) rnote.style.display = (mode === 'html' && d.html_has_remote && !remote) ? '' : 'none';
    }
    function renderText() {
        slot.innerHTML = '<pre class="detail-body">' + esc(d.body || '<?= jsq(t('(üres tartalom)')) ?>') + '</pre>' + textTrunc;
        setActive('text');
    }
    // Raw RFC822 exactly as stored: full headers plus the undecoded body, which
    // is what you need to check routing, authentication results or an encoding.
    function renderSource() {
        var src = d.source || '';
        slot.innerHTML = '<pre class="detail-body detail-source">' +
            (src ? esc(src) : '<?= jsq(t('(üres tartalom)')) ?>') + '</pre>' +
            (d.source_truncated ? '<div class="truncated-note"><?= jsq(t('(A forrás rövidítve.)')) ?></div>' : '');
        setActive('source');
    }
    function renderHtml() {
        const csp = remote
            ? "default-src 'none'; img-src data: http: https:; style-src 'unsafe-inline' data:; font-src data: http: https:"
            : "default-src 'none'; img-src data:; style-src 'unsafe-inline' data:; font-src data:";
        const doc = '<!DOCTYPE html><html><head><meta charset="utf-8">' +
            '<meta http-equiv="Content-Security-Policy" content="' + csp + '">' +
            '<base target="_blank">' +
            '<style>html,body{margin:0}body{font-family:system-ui,-apple-system,sans-serif;' +
            'padding:10px;color:#111;word-break:break-word}img{max-width:100%;height:auto}</style>' +
            '</head><body>' + (d.html || '') + '</body></html>';
        const iframe = document.createElement('iframe');
        iframe.className = 'detail-html';
        iframe.setAttribute('sandbox', '');
        iframe.setAttribute('referrerpolicy', 'no-referrer');
        iframe.srcdoc = doc;
        slot.innerHTML = '';
        slot.appendChild(iframe);
        if (d.html_truncated) {
            slot.insertAdjacentHTML('beforeend', '<div class="truncated-note"><?= jsq(t('(A HTML-tartalom rövidítve.)')) ?></div>');
        }
        setActive('html');
    }
    if (bHtml) bHtml.addEventListener('click', renderHtml);
    if (bText) bText.addEventListener('click', renderText);
    if (bSrc)  bSrc.addEventListener('click', renderSource);
    if (bImg)  bImg.addEventListener('click', function () { remote = true; renderHtml(); });

    if (d.has_html) renderHtml(); else renderText();
}

function toggleDetail(subjectTd) {
    const user   = subjectTd.dataset.user;
    const folder = subjectTd.dataset.folder;
    const uid    = subjectTd.dataset.uid;
    const key    = user + '|' + folder + '|' + uid;
    const rowKey = (user + '__' + folder + '__' + uid).replace(/[^a-zA-Z0-9_\-@.]/g, '_');
    const arrow  = document.getElementById('arr-' + rowKey);
    const dataRow = subjectTd.closest('tr');

    if (detailRows[key]) {
        const dr = detailRows[key].row;
        const visible = dr.style.display !== 'none';
        dr.style.display = visible ? 'none' : '';
        if (arrow) arrow.classList.toggle('open', !visible);
        return;
    }

    const dr = document.createElement('tr');
    dr.className = 'detail-row';
    const td = document.createElement('td');
    td.colSpan = 7;
    td.innerHTML = '<div class="detail-inner"><div class="detail-loading"><?= jsq(t('Betölt&hellip;')) ?></div></div>';
    dr.appendChild(td);
    dataRow.insertAdjacentElement('afterend', dr);
    detailRows[key] = { row: dr, loaded: false };
    if (arrow) arrow.classList.add('open');

    const url = '?view=1'
        + '&user='   + encodeURIComponent(user)
        + '&folder=' + encodeURIComponent(folder)
        + '&uid='    + encodeURIComponent(uid);

    fetch(url, {credentials: 'same-origin'})
        .then(r => r.json())
        .then(d => {
            const inner = td.querySelector('.detail-inner');
            if (d.error) {
                inner.innerHTML = '<div class="detail-error"><svg class="icon"><use href="#icon-warning"></use></svg> ' + esc(d.error) + '</div>';
                return;
            }
            inner.innerHTML =
                '<div class="detail-actions">' +
                '<span class="detail-close-link" onclick="closeDetail(' + JSON.stringify(key) + ',' + JSON.stringify(rowKey) + ')"><svg class="icon icon-rot-270"><use href="#icon-chevron"></use></svg> <?= jsq(t('Bezár')) ?></span>' +
                '<button type="button" class="btn btn-danger btn-sm" id="delbtn-' + esc(rowKey) + '"><svg class="icon"><use href="#icon-x"></use></svg> <?= jsq(t('Törlés')) ?></button>' +
                '<button type="button" class="btn btn-success btn-sm" id="relbtn-' + esc(rowKey) + '"><svg class="icon"><use href="#icon-play"></use></svg> <?= jsq(t('Felszabadít')) ?></button>' +
                '</div>';
            renderMessageBody(inner, d, 'quar');

            document.getElementById('delbtn-' + rowKey).addEventListener('click', function() {
                detailDelete(user, folder, uid);
            });
            document.getElementById('relbtn-' + rowKey).addEventListener('click', function() {
                detailRelease(user, folder, uid);
            });
        })
        .catch(e => {
            td.querySelector('.detail-inner').innerHTML =
                '<div class="detail-error"><svg class="icon"><use href="#icon-warning"></use></svg> <?= jsq(t('Hálózati hiba')) ?>: ' + esc(e.message) + '</div>';
        });
}

function closeDetail(key, rowKey) {
    if (detailRows[key]) {
        detailRows[key].row.style.display = 'none';
    }
    const arrow = document.getElementById('arr-' + rowKey);
    if (arrow) arrow.classList.remove('open');
}

function detailRelease(user, folder, uid) {
    submitDetailAction('release', user, folder, uid);
}

function detailDelete(user, folder, uid) {
    if (!confirm('<?= jsq(t('Törli ezt a levelet?')) ?>')) return;
    submitDetailAction('delete', user, folder, uid);
}

function submitSenderList(which, sender, src) {
    const q = which === 'block' ? '<?= jsq(t('Blokklistára teszed a feladót?')) ?>' : '<?= jsq(t('Fehérlistára teszed a feladót?')) ?>';
    if (!confirm(q + '\n' + sender)) return;
    const g = n => (document.querySelector('[name=' + n + ']')?.value || '');
    const fields = { _csrf: CSRF, action: which === 'block' ? 'quick_block' : 'quick_white',
                     sender: sender, back: (src === 'arc' ? 'arc' : 'quar') };
    if (src === 'arc') {
        Object.assign(fields, { af_domain: g('adomain'), af_from: g('afrom'), af_to: g('ato'),
            af_subject: g('asubject'), af_status: g('astatus'), af_since: g('asince'),
            af_before: g('abefore'), af_page: '1' });
    } else {
        Object.assign(fields, { f_domain: g('domain'), f_user: g('user'), f_folder: g('folder'),
            f_since: g('since'), f_before: g('before'), f_from: g('from'), f_subject: g('subject') });
    }
    const f = document.createElement('form'); f.method = 'POST'; f.action = '';
    for (const [k, v] of Object.entries(fields)) {
        const i = document.createElement('input'); i.type = 'hidden'; i.name = k; i.value = v; f.appendChild(i);
    }
    document.body.appendChild(f); f.submit();
}

function submitDetailAction(action, user, folder, uid) {
    const f = document.createElement('form');
    f.method = 'POST'; f.action = '';
    const fields = {
        _csrf:      CSRF,
        action:     action,
        msg_user:   user,
        msg_folder: folder,
        msg_uid:    uid,
        f_domain:   document.querySelector('[name=domain]')?.value  || '',
        f_user:     document.querySelector('[name=user]')?.value    || '',
        f_folder:   document.querySelector('[name=folder]')?.value  || 'all',
        f_since:    document.querySelector('[name=since]')?.value   || '',
        f_before:   document.querySelector('[name=before]')?.value  || '',
        f_from:     document.querySelector('[name=from]')?.value    || '',
        f_subject:  document.querySelector('[name=subject]')?.value || '',
    };
    for (const [k, v] of Object.entries(fields)) {
        const i = document.createElement('input');
        i.type = 'hidden'; i.name = k; i.value = v;
        f.appendChild(i);
    }
    document.body.appendChild(f);
    f.submit();
}

// ── Archive view: expand content + re-send ──
const arcRows = {};
function toggleArc(arrow, uid) {
    const key = 'arc' + uid;
    const dataRow = arrow.closest('tr');
    if (arcRows[key]) {
        const dr = arcRows[key];
        const vis = dr.style.display !== 'none';
        dr.style.display = vis ? 'none' : '';
        arrow.classList.toggle('open', !vis);
        return;
    }
    const dr = document.createElement('tr');
    dr.className = 'detail-row';
    const td = document.createElement('td');
    td.colSpan = 7;
    td.innerHTML = '<div class="detail-inner"><div class="detail-loading"><?= jsq(t('Betölt&hellip;')) ?></div></div>';
    dr.appendChild(td);
    dataRow.insertAdjacentElement('afterend', dr);
    arcRows[key] = dr;
    arrow.classList.add('open');

    fetch('?view=1&archive=1&uid=' + encodeURIComponent(uid), {credentials: 'same-origin'})
        .then(r => r.json())
        .then(d => {
            const inner = td.querySelector('.detail-inner');
            if (d.error) { inner.innerHTML = '<div class="detail-error"><svg class="icon"><use href="#icon-warning"></use></svg> ' + esc(d.error) + '</div>'; return; }
            inner.innerHTML = '';
            renderMessageBody(inner, d, 'arc');
        })
        .catch(e => {
            td.querySelector('.detail-inner').innerHTML =
                '<div class="detail-error"><svg class="icon"><use href="#icon-warning"></use></svg> <?= jsq(t('Hálózati hiba')) ?>: ' + esc(e.message) + '</div>';
        });
}
function arcResend(uid, to) {
    const rcpt = prompt('Újraküldés - címzett e-mail címe:', to || '');
    if (!rcpt) return;
    var f = document.getElementById('arcResendForm');
    document.getElementById('arcResendUid').value = uid;
    document.getElementById('arcResendRcpt').value = rcpt;

    var body = new URLSearchParams(new FormData(f));
    fetch(f.getAttribute('action') || '?', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'X-Requested-With': 'XMLHttpRequest' }, body: body,
    })
        .then(function (r) {
            var ct = r.headers.get('content-type') || '';
            if (!r.ok || ct.indexOf('application/json') === -1) throw new Error('unexpected-response');
            return r.json();
        })
        .then(function (d) { showLookupToast(d.message); })
        .catch(function () {
            // Never blindly retry via a real submit here -- the message may
            // already have been resent server-side even though this response
            // couldn't be trusted, and retrying risks sending a second real
            // email to a real recipient.
            showLookupToast(<?= json_encode(t('Hálózati hiba történt - ellenőrizd, hogy a levél elment-e, mielőtt újra megpróbálod.')) ?>);
        });
}

// ── Browser-local timestamps ─────────────────────────────────────
function padTs(n) { return String(n).padStart(2, '0'); }
function formatLocalDateTime(ts) {
    const d = new Date(ts * 1000);
    return d.getFullYear() + '-' + padTs(d.getMonth() + 1) + '-' + padTs(d.getDate())
         + ' ' + padTs(d.getHours()) + ':' + padTs(d.getMinutes());
}
(function () {
    document.querySelectorAll('.local-ts[data-ts]').forEach(function (el) {
        const ts = parseInt(el.dataset.ts, 10);
        if (ts > 0) el.textContent = formatLocalDateTime(ts);
    });
    document.querySelectorAll('.local-ts-title[data-ts]').forEach(function (el) {
        const ts = parseInt(el.dataset.ts, 10);
        if (ts > 0) el.title = formatLocalDateTime(ts);
    });
    document.querySelectorAll('.learned-mark[data-ts]').forEach(function (el) {
        const ts = parseInt(el.dataset.ts, 10);
        const label = el.dataset.learnedLabel || '';
        if (ts > 0) el.title = LEARNED_TITLE_TPL.replace('%s', label).replace('%s', formatLocalDateTime(ts));
    });
})();

// ── Loading overlay on search + remember-last-filters ──
(function () {
    const VIEW_FLAGS = ['quar', 'arc', 'audit', 'block', 'white'];
    function viewKey() {
        const p = new URLSearchParams(location.search);
        for (const k of VIEW_FLAGS) if (p.has(k)) return 'qadmin_filt_' + k;
        return 'qadmin_filt_dash';
    }
    const form = document.querySelector('.filter-card form:not(.lists-search-form)');
    if (form) {
        form.addEventListener('submit', function () {
            document.getElementById('loadingOverlay')?.classList.add('show');
            try {
                const data = {};
                form.querySelectorAll('input[type=text], input[type=date], select').forEach(el => {
                    if (el.name) data[el.name] = el.value;
                });
                localStorage.setItem(viewKey(), JSON.stringify(data));
            } catch (e) {}
        });
        const p = new URLSearchParams(location.search);
        const bare = [...p.keys()].every(k => VIEW_FLAGS.includes(k));
        if (bare) {
            let saved; try { saved = JSON.parse(localStorage.getItem(viewKey()) || '{}'); } catch (e) { saved = {}; }
            for (const [k, v] of Object.entries(saved || {})) {
                const el = form.querySelector('[name="' + k + '"]');
                if (el && !el.value && v) el.value = v;
            }
        }
    }
})();

// IOC lookup: intercept the per-row "Ellenőrzés" form so checking an
// indicator updates that row in place instead of reloading the page --
// event delegation on the table body means this works for every row,
// including ones added by future re-renders, with one listener.
document.addEventListener('submit', function (e) {
    var form = e.target;
    if (!form.classList || !form.classList.contains('ioc-lookup-form')) return;
    e.preventDefault();

    var iocId = form.querySelector('[name="ioc_id"]').value;
    var csrf  = form.querySelector('[name="_csrf"]').value;
    var body = new URLSearchParams({ action: 'ioc_lookup', ioc_id: iocId, _csrf: csrf });

    fetch('?ioc=1', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'X-Requested-With': 'XMLHttpRequest' },
        body: body,
    })
        .then(function (r) { return r.json(); })
        .then(function (d) { applyIocLookupResult(iocId, d); })
        .catch(function () { form.submit(); }); // AJAX failed -- fall back to a normal submit
});

function applyIocLookupResult(iocId, d) {
    for (var svc in d.results) {
        var td = document.getElementById('ioc-rep-' + iocId + '-' + svc);
        if (!td) continue;
        var r = d.results[svc];
        // Tooltip carries the verdict word since it's no longer visible as
        // text on the icon-only badge -- mirrors the PHP-side title format
        // in views/ioc.php exactly (verdict — [detail —] date).
        var detailPrefix = r.detail ? esc(r.detail) + ' — ' : '';
        var icon = QA_VERDICT_ICON[r.verdict] || 'icon-info';
        td.innerHTML = '<span class="verdict verdict-' + esc(r.verdict) + '" ' +
            'title="' + esc(r.verdict) + ' — ' + detailPrefix + esc(formatLocalDateTime(r.checked_at)) + '" ' +
            'aria-label="' + esc(r.verdict) + '">' +
            '<svg class="icon"><use href="#' + icon + '"></use></svg></span>';
    }
    var confTd = document.getElementById('ioc-conf-' + iocId);
    if (confTd) {
        confTd.innerHTML = d.confidence
            ? '<span class="conf-' + esc(d.confidence.tier) + '">' + parseInt(d.confidence.pct, 10) + '%</span>'
            : '';
    }
    showLookupToast(buildIocLookupMessage(d));
}

function buildIocLookupMessage(d) {
    var parts = [];
    for (var svc in d.results) {
        var r = d.results[svc];
        parts.push(svc + ': ' + r.verdict + (r.detail ? ' (' + r.detail + ')' : ''));
    }
    if (parts.length) return parts.join(' · ');
    if (d.errors && d.errors._) return d.errors._;
    return d.ok
        ? '<?= jsq(t('Ellenőrzés lefutott.')) ?>'
        : '<?= jsq(t('Az ellenőrzés sikertelen volt minden szolgáltatásnál.')) ?>';
}

var lookupToastTimer = null;
function showLookupToast(message) {
    var box = document.getElementById('lookup-toast');
    if (!box) {
        box = document.createElement('div');
        box.id = 'lookup-toast';
        document.body.appendChild(box);
    }
    box.textContent = message;
    box.classList.add('show');
    if (lookupToastTimer) clearTimeout(lookupToastTimer);
    lookupToastTimer = setTimeout(function () { box.classList.remove('show'); }, 4000);
}

// Block/whitelist duplicate check: live, no-reload feedback on the
// add-entry form's pattern field, using the same fetch()-without-page-
// reload pattern the IOC-lookup feature already established.
(function () {
    var patternEl = document.getElementById('b_pattern');
    var typeEl = document.getElementById('b_type');
    var msgEl = document.getElementById('lcheck-msg');
    if (!patternEl || !typeEl || !msgEl) return;
    var which = <?= json_encode($is_white ? 'white' : 'block') ?>;

    function runCheck() {
        var pattern = patternEl.value.trim();
        if (!pattern) { msgEl.textContent = ''; return; }
        var url = '?lcheck=1&which=' + encodeURIComponent(which)
            + '&type=' + encodeURIComponent(typeEl.value)
            + '&pattern=' + encodeURIComponent(pattern);
        fetch(url, { credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(function (d) {
                if (d.error) { msgEl.textContent = ''; return; }
                if (d.exact_same) {
                    msgEl.style.color = 'var(--danger)';
                    msgEl.textContent = <?= json_encode(t('Ez a minta már szerepel ezen a listán.')) ?>;
                } else if (d.exact_other) {
                    msgEl.style.color = 'var(--danger)';
                    msgEl.textContent = <?= json_encode(t('Ez a minta már szerepel a másik listán.')) ?>;
                } else if (d.covered_by) {
                    msgEl.style.color = 'var(--warning)';
                    msgEl.textContent = <?= json_encode(t('Figyelem: ezt már lefedi egy meglévő tétel:')) ?> + ' ' + esc(d.covered_by.pattern);
                } else {
                    msgEl.textContent = '';
                }
                if (d.ioc_match) {
                    msgEl.textContent += (msgEl.textContent ? ' ' : '') +
                        <?= json_encode(t('Ez a minta már szerepel az IOC-tárban.')) ?>;
                }
            })
            .catch(function () { msgEl.textContent = ''; });
    }

    patternEl.addEventListener('blur', runCheck);
    typeEl.addEventListener('change', runCheck);
})();

// Block/whitelist reputation check: parallel to the IOC page's own
// .ioc-lookup-form handler (not shared, to avoid any risk to that
// already-shipped feature) -- same POST+AJAX+toast contract, applied to
// list entries instead of IOC rows.
document.addEventListener('submit', function (e) {
    var form = e.target;
    if (!form.classList || !form.classList.contains('list-lookup-form')) return;
    e.preventDefault();

    var rowId = form.getAttribute('data-row-id');
    var csrf  = form.querySelector('[name="_csrf"]').value;
    var which = form.querySelector('[name="which"]').value;
    var lType = form.querySelector('[name="l_type"]').value;
    var lPattern = form.querySelector('[name="l_pattern"]').value;
    var body = new URLSearchParams({
        action: 'list_lookup', which: which, l_type: lType, l_pattern: lPattern, _csrf: csrf,
    });

    fetch(form.getAttribute('action'), {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'X-Requested-With': 'XMLHttpRequest' },
        body: body,
    })
        .then(function (r) { return r.json(); })
        .then(function (d) { applyListLookupResult(rowId, d); })
        .catch(function () { form.submit(); });
});

function applyListLookupResult(rowId, d) {
    var td = document.getElementById('list-rep-' + rowId);
    if (td) {
        var html = '';
        for (var svc in d.results) {
            var r = d.results[svc];
            // Mirrors the PHP render exactly (views/lists.php): icon-only badge,
            // service name carried in the tooltip because this cell holds every
            // service's icon and no column header names them.
            var detailPrefix = r.detail ? esc(r.detail) + ' — ' : '';
            var icon = QA_VERDICT_ICON[r.verdict] || 'icon-info';
            html += '<span class="verdict verdict-' + esc(r.verdict) + '" ' +
                'title="' + esc(svc) + ' — ' + esc(r.verdict) + ' — ' + detailPrefix + esc(formatLocalDateTime(r.checked_at)) + '" ' +
                'aria-label="' + esc(svc) + ': ' + esc(r.verdict) + '">' +
                '<svg class="icon"><use href="#' + icon + '"></use></svg></span> ';
        }
        // The lookup form lives inside this cell; preserve and re-append it, or
        // the "Ellenőrzés" button disappears until the next page load.
        var form = td.querySelector('.list-lookup-form');
        td.innerHTML = html;
        if (form) td.appendChild(form);
    }
    var confTd = document.getElementById('list-conf-' + rowId);
    if (confTd) {
        confTd.innerHTML = d.confidence
            ? '<span class="conf-' + esc(d.confidence.tier) + '">' + parseInt(d.confidence.pct, 10) + '%</span>'
            : '';
    }
    showLookupToast(buildListLookupMessage(d));
}

function buildListLookupMessage(d) {
    var parts = [];
    for (var svc in d.results) {
        var r = d.results[svc];
        parts.push(svc + ': ' + r.verdict + (r.detail ? ' (' + r.detail + ')' : ''));
    }
    if (parts.length) return parts.join(' · ');
    if (d.errors && d.errors._) return d.errors._;
    return d.ok
        ? '<?= jsq(t('Ellenőrzés lefutott.')) ?>'
        : '<?= jsq(t('Az ellenőrzés sikertelen volt minden szolgáltatásnál.')) ?>';
}

// Quarantine-row reputation lookup ("Jelentett" tab): parallel to the
// .list-lookup-form handler above, but deliberately NOT a <form> submit --
// the row lives inside the page's outer <form method="post"> (bulk
// release/delete, carrying name="action"), and HTML drops nested <form>s.
// A nested form here would silently leave this button submitting the OUTER
// form instead, wiring a reputation check to bulk release/delete. Delegated
// click listener + a body built from CSRF, same as #presubmit-lookup-btn
// below.
document.addEventListener('click', function (e) {
    var btn = e.target.closest('.quar-lookup-btn');
    if (!btn) return;

    // Double-click guard: read-then-set happens synchronously, before any
    // async work, so a second click event dispatched while the first fetch
    // is still in flight can never slip through and fire a second lookup.
    if (btn.dataset.quarLoading === '1') return;
    btn.dataset.quarLoading = '1';

    var rowId  = btn.getAttribute('data-row-id');
    var user   = btn.getAttribute('data-user');
    var folder = btn.getAttribute('data-folder');
    var uid    = btn.getAttribute('data-uid');

    // Cold worst case is ~5 services x 15s timeout, per indicator, with up
    // to two indicators (domain + IP) -- an unresponsive-looking button for
    // over a minute is a real usability problem, so disable it and spin its
    // icon for the duration.
    var origHtml = btn.innerHTML;
    btn.disabled = true;
    btn.setAttribute('aria-busy', 'true');
    btn.innerHTML = '<svg class="icon" style="animation:spin .8s linear infinite">'
        + '<use href="#icon-search"></use></svg> ' + esc(<?= json_encode(t('Ellenőrzés')) ?>);

    var body = new URLSearchParams({
        action: 'quar_lookup', msg_user: user, msg_folder: folder, msg_uid: uid, _csrf: CSRF,
    });

    fetch('?', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'X-Requested-With': 'XMLHttpRequest' }, body: body,
    })
        .then(function (r) {
            // content-type only, never r.ok: a permission failure comes
            // back as JSON 403 with a real message in errors._
            // (src/quar_lookup.php's $deny()) that must reach the admin,
            // not be collapsed into the same bucket as a session-expired
            // login page (HTML, non-JSON) or a real network failure.
            var ct = r.headers.get('content-type') || '';
            if (ct.indexOf('application/json') === -1) throw new Error('unexpected-response');
            return r.json();
        })
        .then(function (d) { applyQuarLookupResult(rowId, d); })
        .catch(function (e) {
            // Non-JSON response (session expiry returning an HTML login
            // page) or fetch() itself rejecting. This is a read-only,
            // idempotent check -- unlike arc_spam/quick_block there is no
            // "did it already happen" ambiguity to resolve, so just say so.
            showLookupToast(<?= json_encode(t('Hálózati hiba')) ?> + ': ' + esc(e.message));
        })
        .finally(function () {
            btn.disabled = false;
            btn.removeAttribute('aria-busy');
            btn.innerHTML = origHtml;
            // removeAttribute, not dataset.quarLoading = '' -- the latter
            // would leave a stray data-quar-loading="" attribute on the
            // button forever, a permanent (if harmless) drift from the
            // server-rendered markup this button started as.
            btn.removeAttribute('data-quar-loading');
        });
});

// Mirrors views/quarantine.php's $q_conf_title sprintf() exactly -- MUST use
// the positional %1$s/%2$s specifiers, never plain concatenation order, so a
// language whose translation reorders "Domain: ... IP: ..." still lines up
// the right value with the right label.
var QUAR_CONF_TITLE_TPL = <?= json_encode(t('Domain: %1$s · IP: %2$s')) ?>;
function quarPctStr(c) { return c ? c.pct + '%' : '—'; }

function applyQuarLookupResult(rowId, d) {
    var repTd = document.getElementById('quar-rep-' + rowId);
    // lookup_run_value() degrades to the last-good cached value per service
    // on a live failure, so `results` is usually complete even when some
    // services errored -- EXCEPT for a service that has never been checked
    // before (no prior cache) and fails on this attempt, which is the
    // common shape of a first-ever click hitting a rate limit or timeout
    // (VT is ~4/min and nothing in this app enforces a throttle). When that
    // happens for every service on both indicators, `results` comes back
    // completely empty with `ok: true` -- repainting from that would wipe
    // any previously-cached icons for a data-free "success", exactly what
    // requirement 5 forbids. Gate the repaint on at least one real result.
    var hasAnyResult = d.indicators && (
        (d.indicators.domain && Object.keys(d.indicators.domain.results || {}).length > 0) ||
        (d.indicators.ip && Object.keys(d.indicators.ip.results || {}).length > 0)
    );
    if (repTd && d.ok && d.indicators && hasAnyResult) {
        // Preserve and re-append the button around the innerHTML clobber
        // below -- same trap applyListLookupResult() documents above --
        // or "Ellenőrzés" vanishes from the row until the next page load.
        var savedBtn = repTd.querySelector('.quar-lookup-btn');
        // Trailing space after every tag/icon span, matching
        // applyListLookupResult()'s icon-span convention above: neither
        // .verdict nor .quar-tag carries a CSS margin, so the visual gap
        // between adjacent badges (and before the button) comes only from
        // the literal whitespace PHP's template emits between them --
        // without it here, the AJAX-painted row would render with badges
        // touching, unlike a page reload of the same data.
        //
        // Wrapped in the same .quar-rep-badges container views/quarantine.php
        // emits (see that file's comment): on mobile, tr.data-row td is a
        // nowrap flex container, and without this wrapper 3+ verdict badges
        // push the button off-screen -- painting bare spans straight into
        // repTd here would reintroduce that overflow immediately after the
        // very click that triggered this repaint, which is worse than the
        // pre-click state. The button is appended INTO this div below, not
        // into repTd directly, so it wraps onto its own line with the badges
        // instead of staying a lone nowrap sibling.
        var html = '<div class="quar-rep-badges">';
        // One row per indicator, then the button on its own centred row --
        // the exact shape views/quarantine.php renders. If this diverged, a
        // row would silently change layout the moment it was checked.
        if (d.indicators.domain) {
            html += '<div class="quar-rep-label">' + esc(<?= json_encode(t('Domain')) ?>) + '</div>';
            html += '<div class="quar-rep-syms">';
            for (var dsvc in d.indicators.domain.results) {
                var dr = d.indicators.domain.results[dsvc];
                var dPrefix = dr.detail ? esc(dr.detail) + ' — ' : '';
                var dIcon = QA_VERDICT_ICON[dr.verdict] || 'icon-info';
                html += '<span class="verdict verdict-' + esc(dr.verdict) + '" ' +
                    'title="' + esc(<?= json_encode(t('Domain')) ?>) + ' — ' + esc(dsvc) + ' — ' + esc(dr.verdict) + ' — ' + dPrefix + esc(formatLocalDateTime(dr.checked_at)) + '" ' +
                    'aria-label="' + esc(dsvc + ': ' + dr.verdict) + '">' +
                    '<svg class="icon"><use href="#' + dIcon + '"></use></svg></span> ';
            }
            html += '</div>';
        }
        if (d.indicators.ip) {
            html += '<div class="quar-rep-label">' + esc(<?= json_encode(t('IP-cím')) ?>) + '</div>';
            html += '<div class="quar-rep-syms">';
            for (var isvc in d.indicators.ip.results) {
                var ir = d.indicators.ip.results[isvc];
                var iPrefix = ir.detail ? esc(ir.detail) + ' — ' : '';
                var iIcon = QA_VERDICT_ICON[ir.verdict] || 'icon-info';
                // NB: no t('IP') wrapper on this prefix -- mirrors the PHP
                // render exactly, which uses the literal 'IP' here (unlike
                // the domain branch's t('Domain')).
                html += '<span class="verdict verdict-' + esc(ir.verdict) + '" ' +
                    'title="IP — ' + esc(isvc) + ' — ' + esc(ir.verdict) + ' — ' + iPrefix + esc(formatLocalDateTime(ir.checked_at)) + '" ' +
                    'aria-label="' + esc(isvc + ': ' + ir.verdict) + '">' +
                    '<svg class="icon"><use href="#' + iIcon + '"></use></svg></span> ';
            }
            html += '</div>';
        }
        // Act row goes INSIDE the badge group, before it closes: it is the
        // last row of the column, not a sibling of it.
        html += '<div class="quar-rep-act"></div>';
        html += '</div>';
        repTd.innerHTML = html;
        // The button goes into its own row, not straight into the group:
        // appending it to .quar-rep-badges would make it a third flex ITEM of
        // the column, which loses the row's own margin and alignment.
        var actRow = repTd.querySelector('.quar-rep-act');
        if (savedBtn && actRow) actRow.appendChild(savedBtn);

        var confTd = document.getElementById('quar-conf-' + rowId);
        if (confTd) {
            if (d.confidence) {
                var domConf = d.indicators.domain ? d.indicators.domain.confidence : null;
                var ipConf  = d.indicators.ip ? d.indicators.ip.confidence : null;
                var title = QUAR_CONF_TITLE_TPL.replace('%1$s', quarPctStr(domConf)).replace('%2$s', quarPctStr(ipConf));
                confTd.innerHTML = '<span class="conf-' + esc(d.confidence.tier) + '" title="' + esc(title) + '">' + parseInt(d.confidence.pct, 10) + '%</span>';
            } else {
                confTd.innerHTML = '';
            }
        }
    }
    // On any failure (bad params, message gone, permission denied) the cell
    // is deliberately left untouched above -- repainting from a null
    // `indicators` would blank out real cached results the admin can still
    // see and act on. The toast is the only signal for this state, so it
    // must never be empty (buildQuarLookupMessage() below always falls back
    // to a concrete string).
    showLookupToast(buildQuarLookupMessage(d));
}

function buildQuarLookupMessage(d) {
    var parts = [];
    var errParts = [];
    // Label every part with its indicator (Domain/IP): unlike the flat
    // list/IOC lookups this mirrors, a single service can appear TWICE
    // here with different verdicts (e.g. domain clean, IP malicious --
    // src/quar_lookup.php calls this "the most actionable pattern on this
    // page" and it must stay visible, not read as a self-contradiction).
    // Whether any indicator that's actually present had at least one
    // service *configured* to run against it (a result or an error) --
    // distinct from anyIndicatorPresent below, which only says the domain/
    // IP itself was checkable. If every reputation service applicable to
    // the present indicator(s) is disabled (Admin tab), lookup_run_value()
    // legitimately returns empty results AND empty errors -- nothing was
    // ever attempted, which must not read the same as "ran and found
    // nothing to report".
    var anyIndicatorPresent = false;
    var anyServiceConfigured = false;
    ['domain', 'ip'].forEach(function (type) {
        var ind = d.indicators && d.indicators[type];
        if (!ind) return;
        anyIndicatorPresent = true;
        var label = type === 'domain' ? <?= json_encode(t('Domain')) ?> : 'IP';
        for (var svc in ind.results) {
            anyServiceConfigured = true;
            var r = ind.results[svc];
            parts.push(label + ' ' + svc + ': ' + r.verdict + (r.detail ? ' (' + r.detail + ')' : ''));
        }
        // Per-service failures (e.g. a rate-limited VirusTotal on a
        // never-before-checked indicator, where lookup_run_value() has no
        // prior cached value to degrade to) never surface as an icon --
        // fold them into the toast instead, or a fully-failed check would
        // read as silent success ("Ellenőrzés lefutott.") with an
        // unchanged, icon-less cell.
        for (var esvc in ind.errors) {
            anyServiceConfigured = true;
            errParts.push(label + ' ' + esvc + ': ' + ind.errors[esvc]);
        }
    });
    if (parts.length || errParts.length) {
        return parts.concat(errParts).join(' · ');
    }
    if (d.errors && d.errors._) return d.errors._;
    // ok:true, but neither present indicator produced a result or an error:
    // not "ran and found nothing" -- every reputation service applicable to
    // the checked domain/IP is currently disabled, so nothing was actually
    // attempted. Falling through to the generic success string here would
    // be the same "looks like a completed, clean check" failure mode as the
    // all-services-errored case above, just triggered by config instead of
    // a live failure.
    if (d.ok && anyIndicatorPresent && !anyServiceConfigured) {
        return <?= json_encode(t('Nincs engedélyezett hírnév-szolgáltatás az ellenőrizhető adatokhoz.')) ?>;
    }
    return d.ok
        ? <?= json_encode(t('Ellenőrzés lefutott.')) ?>
        : <?= json_encode(t('Az ellenőrzés sikertelen volt minden szolgáltatásnál.')) ?>;
}

// Pre-submit reputation check: a plain button (not a form submit), since
// the pattern isn't saved as a list entry yet.
(function () {
    var btn = document.getElementById('presubmit-lookup-btn');
    var resultEl = document.getElementById('presubmit-lookup-result');
    var patternEl = document.getElementById('b_pattern');
    var typeEl = document.getElementById('b_type');
    if (!btn || !resultEl || !patternEl || !typeEl) return;

    btn.addEventListener('click', function () {
        var pattern = patternEl.value.trim();
        if (!pattern) return;
        var body = new URLSearchParams({
            action: 'list_lookup', which: <?= json_encode($is_white ? 'white' : 'block') ?>,
            l_type: typeEl.value, l_pattern: pattern, _csrf: CSRF,
        });
        fetch('?', {
            method: 'POST', credentials: 'same-origin',
            headers: { 'X-Requested-With': 'XMLHttpRequest' }, body: body,
        })
            .then(function (r) { return r.json(); })
            .then(function (d) {
                var parts = [];
                for (var svc in d.results) {
                    var r = d.results[svc];
                    parts.push(esc(svc) + ': ' + esc(r.verdict) + (r.detail ? ' (' + esc(r.detail) + ')' : ''));
                }
                resultEl.textContent = parts.length ? parts.join(' · ')
                    : (d.errors && d.errors._ ? d.errors._ : '');
            })
            .catch(function () { resultEl.textContent = ''; });
    });
})();

// Archívum "IOC ellenőrzés" popup: immediate, automatic reputation check of
// every indicator src/arc_lookup.php extracts from one archived message.
// A purpose-built modal, not a reuse of applyQuarLookupResult()'s inline-cell
// repaint above -- this surface has a variable number of candidates
// (ip/domain/url/hash), not that button's two fixed indicators.
function arcIocModalOpen() {
    var ov = document.getElementById('arcIocOverlay');
    if (ov) ov.classList.add('show');
}
function arcIocModalClose() {
    var ov = document.getElementById('arcIocOverlay');
    if (ov) ov.classList.remove('show');
}
// Delegated listener, not addEventListener() on the elements directly: the
// modal markup below is the LAST thing in <body>, after this <script> block
// -- looking the nodes up here at script-run time (the original shipped
// version did exactly that in an IIFE) finds nothing, because they have not
// been parsed into the DOM yet, so every listener silently failed to attach
// and the popup could not be closed. Delegating on `document` sidesteps the
// ordering question entirely (matches this file's existing quar-lookup-btn/
// list-lookup-form pattern above) and also lets the two footer buttons,
// which do not exist until a check has actually rendered results, work
// without a second binding step.
document.addEventListener('click', function (e) {
    if (e.target.closest('#arcIocModalClose') || e.target.closest('#arcIocCancelBtn')) {
        arcIocModalClose();
        return;
    }
    if (e.target.id === 'arcIocOverlay') {
        arcIocModalClose();
        return;
    }
    var fireBtn = e.target.closest('#arcIocAddFireBtn');
    if (fireBtn) { arcIocAddFire(fireBtn); return; }
});
document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') arcIocModalClose();
});

function arcIocCandidateHtml(c, idx) {
    var head = '<div class="arc-ioc-cand-head">'
        + '<label class="arc-ioc-cand-pick">'
        + '<input type="checkbox" class="arc-ioc-pick" data-idx="' + idx + '">'
        + '</label>'
        + '<span class="arc-ioc-cand-type">' + esc(c.type) + '</span>'
        + '<span class="arc-ioc-cand-value">' + esc(c.value) + '</span>';
    if (c.confidence) {
        head += ' <span class="conf-' + esc(c.confidence.tier) + '">' + parseInt(c.confidence.pct, 10) + '%</span>';
    }
    head += '</div>';

    var syms = '<div class="arc-ioc-cand-syms">';
    var any = false;
    for (var svc in c.results) {
        any = true;
        var r = c.results[svc];
        var prefix = r.detail ? esc(r.detail) + ' — ' : '';
        var icon = QA_VERDICT_ICON[r.verdict] || 'icon-info';
        syms += '<span class="verdict verdict-' + esc(r.verdict) + '" '
            + 'title="' + esc(svc) + ' — ' + esc(r.verdict) + ' — ' + prefix + esc(formatLocalDateTime(r.checked_at)) + '" '
            + 'aria-label="' + esc(svc + ': ' + r.verdict) + '">'
            + '<svg class="icon"><use href="#' + icon + '"></use></svg></span> ';
    }
    if (!any) {
        var errMsg = (c.errors && c.errors._) || <?= json_encode(t('Nincs elérhető hírnév-adat.')) ?>;
        syms += '<span style="color:var(--text-subtle)">' + esc(errMsg) + '</span>';
    }
    syms += '</div>';

    return '<div class="arc-ioc-cand">' + head + syms + '</div>';
}

function arcIocSetFootVisible(visible) {
    var foot = document.getElementById('arcIocModalFoot');
    if (foot) foot.style.display = visible ? 'flex' : 'none';
}

function arcIocRenderResult(d) {
    var body = document.getElementById('arcIocModalBody');
    if (!body) return;
    if (!d.ok) {
        var msg = (d.errors && d.errors._) || <?= json_encode(t('Az ellenőrzés sikertelen volt minden szolgáltatásnál.')) ?>;
        body.innerHTML = '<p style="color:var(--danger)">' + esc(msg) + '</p>';
        arcIocSetFootVisible(false);
        return;
    }
    if (!d.candidates || !d.candidates.length) {
        body.innerHTML = '<p>' + esc(<?= json_encode(t('Ehhez a levélhez nincs ellenőrizhető adat.')) ?>) + '</p>';
        arcIocSetFootVisible(false);
        return;
    }
    var html = '';
    d.candidates.forEach(function (c, idx) { html += arcIocCandidateHtml(c, idx); });
    body.innerHTML = html;
    arcIocSetFootVisible(true);
    var addBtn = document.getElementById('arcIocAddFireBtn');
    if (addBtn) { addBtn.disabled = false; addBtn.innerHTML = esc(<?= json_encode(t('Hozzáadás és élesítés')) ?>); }
}

// "Hozzáadás és élesítés": adds every checked candidate to the permanent
// IOC store and immediately activates it (live block) -- src/arc_lookup.php's
// handle_arc_lookup_add_action(). The check itself never picks anything on
// its own; this only runs on an explicit click against explicitly checked
// rows, because unlike the read-only reputation check, this creates a real,
// immediately-enforced mail rejection.
function arcIocAddFire(btn) {
    if (btn.dataset.arcAdding === '1') return;

    var overlay = document.getElementById('arcIocOverlay');
    var uid = overlay ? overlay.dataset.uid : '';
    var checked = document.querySelectorAll('.arc-ioc-pick:checked');
    if (!uid || !checked.length) {
        showLookupToast(<?= json_encode(t('Nincs kijelölt indikátor.')) ?>);
        return;
    }

    btn.dataset.arcAdding = '1';
    var origHtml = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = esc(<?= json_encode(t('Feldolgozás…')) ?>);
    var cancelBtn = document.getElementById('arcIocCancelBtn');
    if (cancelBtn) cancelBtn.disabled = true;

    var params = new URLSearchParams();
    params.set('action', 'arc_ioc_add');
    params.set('msg_uid', uid);
    params.set('_csrf', CSRF);
    checked.forEach(function (cb) { params.append('ioc_pick[]', cb.getAttribute('data-idx')); });

    fetch('?', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'X-Requested-With': 'XMLHttpRequest' }, body: params,
    })
        .then(function (r) {
            var ct = r.headers.get('content-type') || '';
            if (ct.indexOf('application/json') === -1) throw new Error('unexpected-response');
            return r.json();
        })
        .then(function (d) {
            var body = document.getElementById('arcIocModalBody');
            if (!body) return;
            if (d.ok) {
                var msg = <?= json_encode(t('%1$d indikátor hozzáadva, %2$d élesítve.')) ?>
                    .replace('%1$d', d.added).replace('%2$d', d.promoted);
                var errHtml = (d.errors && d.errors.length)
                    ? '<ul>' + d.errors.map(function (er) { return '<li>' + esc(er) + '</li>'; }).join('') + '</ul>'
                    : '';
                body.innerHTML = '<p style="color:var(--success-dark)">' + esc(msg) + '</p>' + errHtml;
            } else if (d.errors && d.errors.length) {
                // Every pick was attempted but none succeeded (e.g. every
                // one already existed with a live block, or ioc_promote()
                // failed for all of them) -- this is the same list shape the
                // success branch above renders, not the single named
                // `errors._` a permission/session denial uses below.
                body.innerHTML = '<ul>' + d.errors.map(function (er) { return '<li>' + esc(er) + '</li>'; }).join('') + '</ul>';
            } else {
                var errMsg = (d.errors && d.errors._) || <?= json_encode(t('Nem sikerült hozzáadni az indikátorokat.')) ?>;
                body.innerHTML = '<p style="color:var(--danger)">' + esc(errMsg) + '</p>';
            }
            arcIocSetFootVisible(false);
        })
        .catch(function (e) {
            var body = document.getElementById('arcIocModalBody');
            if (body) {
                body.innerHTML = '<p style="color:var(--danger)">'
                    + esc(<?= json_encode(t('Hálózati hiba')) ?>) + ': ' + esc(e.message) + '</p>';
            }
        })
        .finally(function () {
            btn.disabled = false;
            btn.innerHTML = origHtml;
            btn.removeAttribute('data-arc-adding');
            if (cancelBtn) cancelBtn.disabled = false;
        });
}

function arcIocCheck(btn, uid) {
    // Double-click guard, same read-then-set-before-any-await shape as the
    // quar-lookup-btn handler above -- a second click while the first fetch
    // is in flight can never slip through.
    if (btn.dataset.arcLoading === '1') return;
    btn.dataset.arcLoading = '1';

    var origHtml = btn.innerHTML;
    btn.disabled = true;
    btn.setAttribute('aria-busy', 'true');
    btn.innerHTML = '<svg class="icon" style="animation:spin .8s linear infinite">'
        + '<use href="#icon-search"></use></svg> ' + esc(<?= json_encode(t('Ellenőrzés')) ?>);

    // Open the popup immediately with a loading state -- "immediate,
    // automatic" per the feature request, rather than waiting for the
    // response before showing anything.
    var body = document.getElementById('arcIocModalBody');
    if (body) {
        body.innerHTML = '<div class="arc-ioc-loading"><div class="spinner"></div><p>'
            + esc(<?= json_encode(t('Ellenőrzés folyamatban…')) ?>) + '</p></div>';
    }
    arcIocSetFootVisible(false);
    // Remembered here so arcIocAddFire() (fired later by a separate click on
    // the footer button) knows which message its picks belong to, and so
    // the server can reject a pick made against a stale/cross-message
    // session -- see handle_arc_lookup_add_action()'s uid check.
    var overlayEl = document.getElementById('arcIocOverlay');
    if (overlayEl) overlayEl.dataset.uid = String(uid);
    arcIocModalOpen();

    var reqBody = new URLSearchParams({ action: 'arc_ioc_check', msg_uid: String(uid), _csrf: CSRF });

    fetch('?', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'X-Requested-With': 'XMLHttpRequest' }, body: reqBody,
    })
        .then(function (r) {
            // content-type only, never r.ok -- a permission/policy failure
            // comes back as JSON with a real message in errors._
            // (src/arc_lookup.php's $deny()), not HTML.
            var ct = r.headers.get('content-type') || '';
            if (ct.indexOf('application/json') === -1) throw new Error('unexpected-response');
            return r.json();
        })
        .then(arcIocRenderResult)
        .catch(function (e) {
            var body2 = document.getElementById('arcIocModalBody');
            if (body2) {
                body2.innerHTML = '<p style="color:var(--danger)">'
                    + esc(<?= json_encode(t('Hálózati hiba')) ?>) + ': ' + esc(e.message) + '</p>';
            }
        })
        .finally(function () {
            btn.disabled = false;
            btn.removeAttribute('aria-busy');
            btn.innerHTML = origHtml;
            btn.removeAttribute('data-arc-loading');
        });
}

// Admin > Adatvédelem: GDPR notice popup before enabling message-content
// viewing. Replaces a plain browser confirm() (easy to blast through with
// Enter, no room for real guidance) with the same modal-chrome pattern as
// the Archívum IOC popup above -- delegated click listener, not
// getElementById+addEventListener at script-load time, since this modal's
// own markup (like that one's) is emitted AFTER this <script> block closes
// and would otherwise bind to nothing (see the Archívum popup's own
// close-button fix, same root cause).
var qaGdprPendingForm = null;

function qaGdprGate(form) {
    // Turning viewing OFF never needs the warning -- it only ever narrows
    // access, so submit immediately.
    if (form.view_policy.value === 'none') return true;
    qaGdprPendingForm = form;
    var ov = document.getElementById('qaGdprOverlay');
    if (ov) ov.classList.add('show');
    return false; // always block the native submit; the modal's own button re-submits
}

document.addEventListener('click', function (e) {
    if (e.target.closest('#qaGdprModalClose') || e.target.closest('#qaGdprCancelBtn')) {
        var ov = document.getElementById('qaGdprOverlay');
        if (ov) ov.classList.remove('show');
        qaGdprPendingForm = null;
        return;
    }
    if (e.target.id === 'qaGdprOverlay') {
        e.target.classList.remove('show');
        qaGdprPendingForm = null;
        return;
    }
    if (e.target.closest('#qaGdprAcceptBtn')) {
        var ov2 = document.getElementById('qaGdprOverlay');
        if (ov2) ov2.classList.remove('show');
        // .submit() (unlike a real click or .requestSubmit()) never re-fires
        // the form's own submit event / onsubmit handler, so this cannot
        // loop back into qaGdprGate().
        if (qaGdprPendingForm) qaGdprPendingForm.submit();
        qaGdprPendingForm = null;
    }
});
document.addEventListener('keydown', function (e) {
    if (e.key !== 'Escape') return;
    var ov = document.getElementById('qaGdprOverlay');
    if (ov && ov.classList.contains('show')) {
        ov.classList.remove('show');
        qaGdprPendingForm = null;
    }
});
</script>
<div class="loading-overlay" id="loadingOverlay"><div class="spinner"></div></div>
<div class="arc-ioc-overlay" id="arcIocOverlay">
  <div class="arc-ioc-modal" role="dialog" aria-modal="true" aria-labelledby="arcIocModalTitle">
    <div class="arc-ioc-modal-head">
      <h3 id="arcIocModalTitle"><?= h(t('IOC ellenőrzés')) ?></h3>
      <button type="button" class="arc-ioc-modal-close" id="arcIocModalClose" aria-label="<?= h(t('Bezár')) ?>"><svg class="icon"><use href="#icon-x"></use></svg></button>
    </div>
    <div class="arc-ioc-modal-body" id="arcIocModalBody"></div>
    <div class="arc-ioc-modal-foot" id="arcIocModalFoot" style="display:none">
      <button type="button" class="btn btn-sm btn-secondary" id="arcIocCancelBtn"><?= h(t('Mégse')) ?></button>
      <button type="button" class="btn btn-sm btn-danger" id="arcIocAddFireBtn"><?= h(t('Hozzáadás és élesítés')) ?></button>
    </div>
  </div>
</div>
<div class="arc-ioc-overlay" id="qaGdprOverlay">
  <div class="arc-ioc-modal" role="dialog" aria-modal="true" aria-labelledby="qaGdprModalTitle">
    <div class="arc-ioc-modal-head">
      <h3 id="qaGdprModalTitle"><svg class="icon" style="color:var(--danger)"><use href="#icon-warning"></use></svg> <?= h(t('Adatvédelmi figyelmeztetés')) ?></h3>
      <button type="button" class="arc-ioc-modal-close" id="qaGdprModalClose" aria-label="<?= h(t('Bezár')) ?>"><svg class="icon"><use href="#icon-x"></use></svg></button>
    </div>
    <div class="arc-ioc-modal-body">
      <p><?= h(t('Ezzel engedélyezi, hogy az adminisztrátorok elolvassák a felhasználók leveleinek tartalmát. Ez a beállítás személyes adatok kezelésének minősül.')) ?></p>
      <ul style="margin:10px 0 14px 20px;padding:0;line-height:1.6">
        <li><?= h(t('Győződjön meg róla, hogy a hozzáféréshez van jogalapja (pl. jogos érdek, munkajogi szabályzat).')) ?></li>
        <li><?= h(t('A felhasználók legyenek tájékoztatva arról, hogy leveleik tartalma adminisztrátori betekintés alá eshet.')) ?></li>
        <li><?= h(t('"Minden levél" esetén ez kiterjed az archívumra is: minden felhasználó teljes levelezésének 30 napos másolatára.')) ?></li>
        <li><?= h(t('A módosítás - ki, mikor, mire változtatta - naplózásra kerül.')) ?></li>
      </ul>
      <p style="color:var(--text-subtle);font-size:.9em"><?= h(t('A beállítás bármikor visszaállítható "Letiltva" értékre.')) ?></p>
    </div>
    <div class="arc-ioc-modal-foot">
      <button type="button" class="btn btn-sm btn-secondary" id="qaGdprCancelBtn"><?= h(t('Mégse')) ?></button>
      <button type="button" class="btn btn-sm btn-danger" id="qaGdprAcceptBtn"><?= h(t('Elfogadom és mentem')) ?></button>
    </div>
  </div>
</div>
</body>
</html>
