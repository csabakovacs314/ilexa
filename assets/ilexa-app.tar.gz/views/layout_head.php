<!DOCTYPE html>
<html lang="<?= h(qa_lang()) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= h(t(SITE_TITLE)) ?> - <?= h(SITE_SUBTITLE) ?></title>
<link rel="icon" href="<?= h(COOKIE_PATH) ?>assets/favicon.ico" sizes="any">
<link rel="icon" type="image/png" sizes="32x32" href="<?= h(COOKIE_PATH) ?>assets/favicon-32.png">
<link rel="apple-touch-icon" href="<?= h(COOKIE_PATH) ?>assets/apple-touch-icon.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root {
    --bg:              #f1f5f9;
    --surface:         #ffffff;
    --border:          #e2e8f0;
    --border-focus:    #c04c06;
    --text:            #0f172a;
    --text-muted:      #475569;
    --text-subtle:     #64748b;
    --ink:             #091828;
    --ink-light:       #2d3c4a;
    --primary:         #c04c06;
    --primary-dark:    #9c3d05;
    --primary-light:   #f3ded2;
    --primary-surface: #fbf4f0;
    --success:         #059669;
    --success-dark:    #047857;
    --success-light:   #d1fae5;
    --success-medium:  #6ee7b7;
    --success-surface: #ecfdf5;
    --danger:          #dc2626;
    --danger-dark:     #b91c1c;
    --danger-light:    #fee2e2;
    --danger-medium:   #fca5a5;
    --danger-surface:  #fef2f2;
    --warning:         #a16207;
    --warning-light:   #eee2d2;
    --neutral:         #475569;
    --neutral-light:   #f8fafc;
    --radius:          8px;
    --radius-sm:       5px;
    --shadow-sm:       0 1px 2px 0 rgb(0 0 0 / .05);
    --shadow:          0 1px 3px 0 rgb(0 0 0 / .1), 0 1px 2px -1px rgb(0 0 0 / .1);
    --t:               150ms cubic-bezier(.4,0,.2,1);
}
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
.icon { width: 1em; height: 1em; display: inline-block; vertical-align: -0.15em; flex-shrink: 0; }
.icon-rot-90  { transform: rotate(90deg); }
.icon-rot-180 { transform: rotate(180deg); }
.icon-rot-270 { transform: rotate(270deg); }
body {
    font-family: 'Inter', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    font-size: 16px;
    line-height: 1.6;
    background: var(--bg);
    color: var(--text);
    -webkit-font-smoothing: antialiased;
    text-rendering: optimizeLegibility;
}
.page-title { font-size: 1.4rem; font-weight: 700; margin: 0 0 18px; color: var(--text); }

/* ── Layout shell: sidebar + content ───────────────────────────────── */
body { display: flex; min-height: 100vh; }
.wrap { flex: 1 1 auto; min-width: 0; }

/* ── Collapsible sections (Rendszer) ─────────────────────────────────── */
/* <details> keeps this working with no JavaScript: the fold is native, and the
   script below only adds remembering. Sections that report health ship open,
   configuration ships collapsed -- see views/admin_system.php. */
.sys-sec > summary.results-header {
    cursor: pointer;
    list-style: none;                 /* hide the default disclosure triangle */
    display: flex;
    align-items: center;
    /* .results-header sets space-between, which pushed the chevron to the left
       edge and the title away from it. Sections must read as a left-aligned
       list, so start-align here and let the warning badge claim the right with
       its own margin-left:auto. */
    justify-content: flex-start;
    flex-wrap: wrap;
    gap: 2px 10px;
    user-select: none;
}
/* One-line summary of what the section is for, so a COLLAPSED section still
   says what it does. flex-basis:100% puts it on its own row; the left margin
   lines it up under the title rather than under the chevron. */
.sys-sec-desc {
    flex: 1 0 100%;
    margin-left: 17px;
    font-size: .8rem;
    font-weight: 400;
    color: var(--text-muted);
    line-height: 1.45;
}
.sys-sec > summary.results-header::-webkit-details-marker { display: none; }
/* Our own chevron, so it sits with the heading instead of before the box. */
.sys-sec > summary.results-header::before {
    content: "";
    flex: 0 0 auto;
    width: 7px; height: 7px;
    margin-right: 2px;
    border-right: 2px solid var(--text-muted);
    border-bottom: 2px solid var(--text-muted);
    transform: rotate(-45deg);        /* points right when closed */
    transition: transform var(--t);
}
.sys-sec[open] > summary.results-header::before { transform: rotate(45deg); }
.sys-sec > summary.results-header:hover::before { border-color: var(--primary); }
.sys-sec > summary.results-header:hover h2 { color: var(--primary); }
/* Keyboard focus must be visible: summary is a real focus target. */
.sys-sec > summary.results-header:focus-visible {
    outline: 2px solid var(--border-focus);
    outline-offset: -2px;
}
/* Badge for a collapsed section that needs attention, so folding never buries
   a fault. Shown only while closed -- once open, the section says it itself. */
.sys-sec-flag {
    margin-left: auto;
    font-size: .74rem;
    font-weight: 700;
    padding: 2px 9px;
    border-radius: 999px;
    background: var(--warning-light);
    color: var(--warning);
    white-space: nowrap;
}
.sys-sec[open] .sys-sec-flag { display: none; }

/* ── Sidebar ────────────────────────────────────────────────────────── */
.sidebar {
    flex: 0 0 220px;
    width: 220px;
    height: 100vh;
    position: sticky;
    top: 0;
    display: flex;
    flex-direction: column;
    background: var(--ink);
    color: #fff;
    overflow-y: auto;
    z-index: 100;
}
.sidebar-brand {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px 16px;
    border-bottom: 1px solid rgb(255 255 255 / .1);
}
.sidebar-brand img {
    max-width: 100%;
    height: auto;
    background: #fff;
    border-radius: var(--radius);
    padding: 8px;
}
.snav { flex: 1; padding: 12px 10px; display: flex; flex-direction: column; gap: 2px; }
.snav-item {
    display: block;
    color: rgba(255,255,255,.78);
    text-decoration: none;
    padding: 9px 12px;
    border-radius: 6px;
    font-size: .92em;
    font-weight: 500;
    transition: background var(--t), color var(--t);
}
.snav-item:hover  { background: rgb(255 255 255 / .1); color: #fff; }
.snav-item.active { background: var(--primary); color: #fff; font-weight: 700; }
.snav-bottom { margin-top: auto; }
.snav-group { margin-top: 14px; }
.snav-group-label {
    font-size: .7rem;
    font-weight: 700;
    letter-spacing: .06em;
    text-transform: uppercase;
    color: rgba(255,255,255,.45);
    padding: 4px 12px 4px;
}
.sidebar-foot {
    padding: 12px 14px 16px;
    border-top: 1px solid rgb(255 255 255 / .1);
    display: flex;
    flex-direction: column;
    gap: 8px;
}
.sidebar-user {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: .8rem;
    color: rgba(255,255,255,.7);
}
.sidebar-user .icon { width: .95em; height: .95em; }
.role-chip {
    background: var(--primary-light);
    color: var(--primary-dark);
    padding: 1px 6px;
    border-radius: 3px;
    font-size: .7rem;
    font-weight: 600;
}
.learn-badge {
    padding: 4px 10px;
    border-radius: 999px;
    font-size: .74em;
    font-weight: 600;
    letter-spacing: .01em;
    text-align: center;
}
.learn-log  { background: rgb(255 255 255 / .12); color: rgba(255,255,255,.75); }
.learn-live { background: var(--success); color: #fff; box-shadow: 0 0 0 2px #6ee7b7; }

/* Mobile nav toggle + backdrop - hidden entirely on desktop */
.nav-toggle {
    display: none;
    position: fixed;
    top: 12px;
    left: 12px;
    z-index: 210;
    background: var(--ink);
    border: 1px solid rgb(255 255 255 / .2);
    color: #fff;
    border-radius: var(--radius-sm);
    padding: 8px 10px;
    cursor: pointer;
}
.nav-toggle .icon { width: 1.1em; height: 1.1em; }
.nav-backdrop {
    display: none;
    position: fixed;
    inset: 0;
    background: rgb(0 0 0 / .4);
    z-index: 150;
}

/* ClamAV stat blocks (dashboard tile + admin section) */
.cv-stat {
    flex: 1 1 150px;
    min-width: 140px;
    display: flex;
    flex-direction: column;
    gap: 2px;
    padding: 10px 12px;
    background: var(--neutral-light);
    border: 1px solid var(--border);
    border-radius: var(--radius-sm);
}
.cv-stat-k { font-size: .72rem; text-transform: uppercase; letter-spacing: .04em;
             color: var(--text-subtle); font-weight: 700; }
.cv-stat-v { font-size: 1.05rem; font-weight: 700; color: var(--text); }
.cv-stat-s { font-size: .72rem; color: var(--text-muted); }

/* Audit sub-tabs */
.tabbar {
    display: flex;
    gap: 0;
    padding: 0 16px;
    background: var(--surface);
    border-bottom: 2px solid var(--border);
}
.tab {
    padding: 10px 18px;
    text-decoration: none;
    color: var(--text-muted);
    font-size: .87em;
    font-weight: 500;
    border: none;
    background: transparent;
    position: relative;
    transition: color var(--t);
}
.tab::after {
    content: '';
    position: absolute;
    bottom: -2px; left: 0; right: 0;
    height: 2px;
    background: var(--primary);
    transform: scaleX(0);
    transition: transform var(--t);
    border-radius: 2px 2px 0 0;
}
.tab:hover { color: var(--primary); }
.tab.active { color: var(--primary); font-weight: 600; }
.tab.active::after { transform: scaleX(1); }

/* Status badges */
.op-tag {
    display: inline-flex;
    align-items: center;
    padding: 2px 9px;
    border-radius: 999px;
    font-size: .82em;
    font-weight: 700;
    white-space: nowrap;
    letter-spacing: .01em;
}
.op-release { background: var(--success-light); color: var(--success-dark); }
.op-delete  { background: var(--danger-light);  color: var(--danger-dark); }

/* Ham/Spam verdict badges (Archívum) */
.verdict {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 3px 10px 3px 8px;
    border-radius: 6px;
    font-size: .82em;
    font-weight: 800;
    letter-spacing: .03em;
    text-transform: uppercase;
    white-space: nowrap;
    vertical-align: middle;
}
.verdict-ham  { background: #dcfce7; color: #15803d; border: 1px solid #86efac; }
/* Verdict corrected by an admin's teaching: the badge shows what it was taught
   as, and this marks that it disagrees with what rspamd originally decided.
   Dashed border rather than a different colour, so the spam/ham colour still
   reads at a glance and the correction is a modifier on top of it. */
.verdict-corrected { border-style: dashed; border-width: 2px; }
.verdict-corrected sup { font-weight: 700; margin-left: 1px; }
.verdict-spam { background: #fee2e2; color: #b91c1c; border: 1px solid #fca5a5; }
.verdict .vi { font-size: 1.05em; line-height: 1; }

/* IOC lookup verdict badges (IOC tab) */
.verdict-malicious  { background: var(--danger-light);  color: var(--danger-dark); }
.verdict-suspicious { background: var(--warning-light); color: var(--warning); }
.verdict-clean      { background: var(--success-light); color: var(--success-dark); }
.verdict-unknown    { background: var(--neutral-light); color: var(--neutral); }
.conf-high   { background: var(--danger-light);  color: var(--danger-dark); }
.conf-medium { background: var(--warning-light); color: var(--warning); }
.conf-low    { background: var(--neutral-light); color: var(--neutral); }
/* Login-risk scoring's 4th tier (src/signin.php): a profile with too little
   history to trust a verdict from yet. Deliberately styled distinct from
   conf-low (a real "safe" verdict) -- this one means "no verdict", not
   "checked and clean", and showing it in the same color as a real low-risk
   result would misrepresent a brand-new profile's raw score as meaningful. */
.conf-learning { background: var(--neutral-light); color: var(--text-subtle); font-style: italic; }

/* IOC table's 5 per-service verdict columns render an icon instead of a
   word (see docs/superpowers/notes/2026-08-13-ioc-table-fit-fix.md) -- the
   shared .verdict pill (padding, icon at 1em) is used as-is, no compact
   override needed here now that there's no long verdict word to fit. */

/* ── Wrapper ─────────────────────────────────────────────────────── */
.wrap { max-width: 1340px; margin: 0 auto; padding: 24px 20px; }

/* Inline notices */
.notice { padding: 11px 16px; border-radius: var(--radius-sm); margin-bottom: 16px;
          font-size: .92em; font-weight: 600; border: 1px solid transparent; }
.notice-ok  { background: var(--success-surface); color: var(--success-dark); border-color: var(--success-light); }
.notice-err { background: var(--danger-surface);  color: var(--danger-dark);  border-color: var(--danger-light); }

/* ── Filter card ─────────────────────────────────────────────────── */
.filter-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    box-shadow: var(--shadow-sm);
    padding: 20px 24px;
    margin-bottom: 16px;
}
.filter-card h2 {
    font-size: .79em;
    font-weight: 700;
    color: var(--text-subtle);
    margin-bottom: 16px;
    text-transform: uppercase;
    letter-spacing: .07em;
}
.filter-row { display: flex; flex-wrap: nowrap; gap: 10px; align-items: flex-end; overflow-x: auto; }
.filter-group { display: flex; flex-direction: column; gap: 4px; flex: 1 1 auto; min-width: 0; }
.filter-group:has(> .btn),
.filter-group:has(> a.btn) { flex: 0 0 auto; }
.filter-group label {
    font-size: .82em;
    color: var(--text-muted);
    font-weight: 600;
    letter-spacing: .01em;
    white-space: nowrap;
}
.filter-group select,
.filter-group input[type=date],
.filter-group input[type=text] {
    border: 1px solid var(--border);
    border-radius: var(--radius-sm);
    padding: 6px 8px;
    font-size: .9em;
    font-family: inherit;
    background: var(--surface);
    color: var(--text);
    min-width: 0;
    width: 100%;
    transition: border-color var(--t), box-shadow var(--t);
}
.filter-group select:focus,
.filter-group input:focus {
    outline: none;
    border-color: var(--border-focus);
    box-shadow: 0 0 0 3px rgb(192 76 6 / .15);
}
.filter-hint { margin-top: 14px; font-size: .79em; color: var(--text-muted); line-height: 1.65; }
mark { background: #fef08a; color: inherit; padding: 0 1px; border-radius: 2px; }

/* ── Buttons ─────────────────────────────────────────────────────── */
.btn {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 7px 16px;
    border: 1px solid transparent;
    border-radius: var(--radius-sm);
    font-family: inherit;
    font-size: .88em;
    font-weight: 600;
    cursor: pointer;
    text-decoration: none;
    white-space: nowrap;
    transition: background var(--t), box-shadow var(--t), transform var(--t), border-color var(--t);
    line-height: 1.25;
}
.btn:active { transform: translateY(1px); }
.btn-primary   { background: var(--primary);  color: #fff; border-color: var(--primary); }
.btn-primary:hover { background: var(--primary-dark); border-color: var(--primary-dark); box-shadow: var(--shadow); }
.btn-success   { background: var(--success);  color: #fff; border-color: var(--success); }
.btn-success:hover { background: var(--success-dark); border-color: var(--success-dark); box-shadow: var(--shadow); }
.btn-danger    { background: var(--danger);   color: #fff; border-color: var(--danger); }
.btn-danger:hover  { background: var(--danger-dark);  border-color: var(--danger-dark);  box-shadow: var(--shadow); }
.btn-secondary { background: var(--surface);  color: var(--neutral); border-color: var(--border); }
.btn-secondary:hover { background: var(--neutral-light); border-color: #cbd5e1; box-shadow: var(--shadow-sm); }
.btn-sm { padding: 4px 10px; font-size: .84em; }

/* ── Active-filter chips ─────────────────────────────────────────── */
.active-filters {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 6px;
    padding: 10px 16px;
    border-bottom: 1px solid var(--border);
    background: var(--neutral-light);
}
.af-label {
    font-size: .8em;
    color: var(--text-subtle);
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: .05em;
}
.chip {
    display: inline-flex;
    align-items: center;
    padding: 3px 10px;
    border-radius: 999px;
    font-size: .83em;
    font-weight: 500;
    background: var(--primary-light);
    color: var(--primary-dark);
    border: 1px solid #e3c8b4;
}
.chip-clear {
    background: var(--danger-surface);
    color: var(--danger);
    border-color: #fecaca;
    text-decoration: none;
    cursor: pointer;
    font-weight: 600;
}
.chip-clear:hover { background: var(--danger-light); }

/* ── Results card ────────────────────────────────────────────────── */
.results-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    box-shadow: var(--shadow-sm);
    overflow: clip;
}
.results-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 14px 20px;
    border-bottom: 1px solid var(--border);
}
.results-header h2 { font-size: 1.02em; font-weight: 700; color: var(--text); }
.results-header .meta { font-size: .82em; color: var(--text-muted); }
/* Info-affordance glyph next to a card title carrying extra detail in its
   title attribute -- cursor:help signals "hover for more" on pointer
   devices. Touch devices don't get a hover state at all; that's a known,
   accepted gap here, not something this glyph tries to solve. */
.info-hint { cursor: help; color: var(--text-subtle); font-size: .85em; }

/* Ham/Spam legend bar (Archívum) */
.legend {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 8px;
    padding: 10px 16px;
    background: var(--neutral-light);
    border-bottom: 1px solid var(--border);
}
.legend-label { font-size: .78em; font-weight: 700; text-transform: uppercase;
                letter-spacing: .05em; color: var(--text-subtle); }
.legend-sep { font-size: .84em; color: var(--text-muted); margin-right: 8px; }

/* Dashboard (Áttekintés) */
/* First row, four tracks: logo | 2-card Archívum stack (7-day / 30-day) |
   2-card rspamd/Bayes stack (scanned / trained) | single System card
   (disk/memory/swap/CPU as compact rows) -- not five same-size boxes in a
   row. align-items:stretch (explicit, not relied on as the default) makes
   the row height follow the tallest .dash-col stack, and stretches the
   logo card's box to match it; height: 100% on brand-card and dash-col
   makes both fill that stretched box fully rather than only their own
   content height. */
/* Per-range total above the bars. Lives INSIDE the range panel so it switches
   with the tab automatically and cannot drift from the chart it describes --
   it is summed from the same rows. Not a fourth .stat-card in the grid above:
   those use flex:1, so a third card in one column would shrink its two
   neighbours to 1/3 height while the other columns kept halves. */
.range-summary { padding: 2px 4px 10px; font-size: .86rem; color: var(--text-muted); }
.range-summary strong { color: var(--text); font-weight: 600; }
.range-summary .dot-spam { margin-left: 10px; margin-right: 4px; }
.dash-grid { display: grid; grid-template-columns: minmax(220px, 1.3fr) repeat(3, minmax(150px, 1fr)); gap: 14px; align-items: stretch; }
.dash-col { display: flex; flex-direction: column; gap: 14px; height: 100%; }
/* Without this, .dash-col's own box stretched to match the logo card (via
   align-items:stretch above) but its two stat-cards stayed their natural,
   shorter height inside it -- the wrapper grew, the two *visible* bordered
   boxes did not, so they still visibly didn't match the logo. flex:1
   makes the two cards themselves split the stretched height evenly. */
.dash-col .stat-card { flex: 1; }
/* Compact System-info rows inside the third .dash-col (disk/memory/swap/CPU as one
   thin bar + percentage per line, full detail in a title tooltip) -- shares the
   existing .stat-card container, no new column-level class. */
.sys-row { display: flex; align-items: center; gap: 8px; font-size: .78rem; }
.sys-row + .sys-row { margin-top: 8px; }
.sys-row-label { flex: 0 0 78px; color: var(--text-muted); font-weight: 600;
                  white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.sys-row-bar { flex: 1; background: var(--border); border-radius: 4px; height: 8px; overflow: hidden; }
.sys-row-bar > span { display: block; height: 100%; }
.sys-row-pct { flex: 0 0 34px; text-align: right; font-variant-numeric: tabular-nums;
                font-weight: 600; color: var(--text); }
/* Wraps rather than ellipsising. This line now carries the FQDN (postfix
   myhostname) instead of the short kernel hostname, and measured in Chrome
   "mail.linuxforum.hu" needs 179.7px against a 112px box at .dash-grid's
   150px column floor -- it clipped to "mail.linuxforu..." at every column
   width below ~240px, leaving the name readable only on hover. An FQDN the
   operator cannot read defeats the point of showing it.
   `overflow-wrap: anywhere` is required, not just `white-space: normal`:
   browsers do not break at dots, so the FQDN is one unbreakable token
   (same finding as the IOC page's Hírnév column). */
.sys-host { font-size: 1.05em; font-weight: 800; color: var(--text); margin-bottom: 2px;
            white-space: normal; overflow-wrap: anywhere; }
.sys-meta { font-size: .8em; color: var(--text-muted); margin-bottom: 8px; line-height: 1.4; }
/* Blokklista-források tiles. Base = the previous inline auto-fill behaviour,
   which is what narrow viewports still need and what every width below the
   breakpoint keeps -- floor respected, nothing ever clips. Above the
   breakpoint, six equal columns per row so the 11 tiles land as a balanced
   6+5. Six is chosen because it halves 11 most evenly -- the tile count is
   data-driven ($_dash_feeds), so a 12th tile gives 6+6 and removing one
   gives 6+4, never a stretched or broken row. A CSS Grid with six 1fr
   columns was tried first, but grid's justify-content only redistributes
   free space around the whole track set -- with 1fr tracks that space is
   always zero, so an incomplete last row (5 of 6 columns) stays pinned to
   the left edge instead of centring. flex-wrap centres each wrapped line
   independently, which is what an incomplete last row needs; flex-basis
   reproduces exactly six equal-width tiles per row (6 tiles + 5 gaps of
   10px = 100%), and row 1 above the breakpoint is pixel-identical to the
   grid version.
   Breakpoint: six fixed columns drop the 150px tile-width floor, so it must
   only apply where six tiles actually fit at that floor. This page's layout
   shell is sidebar (220px, in-flow once the sidebar stops being an
   off-canvas drawer at >720px) + .wrap (max-width 1340px, 20px side
   padding) + this grid's own 14px/20px padding + 5 gaps of 10px: six 150px
   tiles need a viewport of ~1250px before there's room. Measured live in
   Chromium (forcing this rule at every width and reading real tile
   getBoundingClientRect().width): the 150px floor is first met at exactly
   1252px. 1260px is used below for headroom against sub-pixel/engine
   rounding -- at no width does auto-fill (the rule below) ever clip a
   label, so erring a few px later here costs nothing. */
.feed-grid {
    padding: 14px 20px;
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
    gap: 10px;
}
@media (min-width: 1260px) {
    .feed-grid {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
    }
    .feed-grid > div {
        flex: 0 0 calc((100% - 5 * 10px) / 6);
        min-width: 0;
    }
}
@media (max-width: 780px) {
    .dash-grid { grid-template-columns: 1fr; }
    .dash-col { flex-direction: row; }
}
.stat-card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius);
             box-shadow: var(--shadow-sm); padding: 16px 18px; }
.stat-label { font-size: .77em; font-weight: 700; text-transform: uppercase; letter-spacing: .05em; color: var(--text-subtle); }
.stat-value { font-size: 1.9em; font-weight: 800; color: var(--text); line-height: 1.1; margin: 6px 0 3px; }
.stat-sub { font-size: .84em; color: var(--text-muted); display: flex; align-items: center; gap: 6px; }
.dot-spam { width: 9px; height: 9px; border-radius: 50%; background: var(--danger); display: inline-block; }
/* Remote-content warning in the viewer: an explicit privacy explanation, not
   just an icon, since loading images confirms the address is live. */
.remote-note {
    display: flex !important;
    flex-direction: column;
    gap: 6px;
    align-items: flex-start;
    max-width: 460px;
    padding: 10px 12px;
    background: var(--warning-light);
    border: 1px solid var(--warning);
    border-radius: var(--radius-sm);
}
.remote-note[style*="none"] { display: none !important; }
.rn-head { font-weight: 700; font-size: .84rem; color: #92400e; }
.rn-why  { font-size: .78rem; color: #78350f; line-height: 1.45; }

/* Inline code. Was entirely unstyled, so it inherited the browser's smaller
   default monospace size -- most visible inside small text, where it rendered
   noticeably shrunken and off-baseline against its surroundings. */
code {
    font-family: ui-monospace, 'JetBrains Mono', 'Fira Code', 'Courier New', monospace;
    font-size: .92em;
    background: var(--neutral-light);
    border: 1px solid var(--border);
    border-radius: 4px;
    padding: 1px 5px;
    color: var(--text);
    white-space: nowrap;
}

/* About page */
.about-hero { padding: 28px 30px; }
/* Same logo-lockup.png as the Áttekintés brand tile (wordmark + tagline
   are already baked into the image). Here the hero is wide, not a narrow
   tile, so the logo sits as a left-hand anchor with everything else --
   hostname, lead paragraph, credits -- in one column beside it, not
   stacked underneath. object-fit:contain guarantees the full image is
   always shown, never cropped, at any box size. */
.about-title { display: flex; align-items: center; gap: 28px; }
.about-mark { width: 100%; max-width: 190px; height: auto; flex: 0 0 auto; object-fit: contain; }
.about-title-text { display: flex; flex-direction: column; gap: 10px; min-width: 0; }
.about-sub { margin: 0; color: var(--text-muted); font-size: 1.05rem; font-weight: 600; }
.about-lead { margin: 0; color: var(--text-subtle); font-size: .85rem; max-width: 60ch; }
.about-credits {
    display: flex; flex-wrap: wrap; gap: 6px 22px; margin: 0;
    padding-top: 10px; border-top: 1px solid var(--border);
    font-size: .82rem; color: var(--text-muted);
}
@media (max-width: 640px) {
    .about-title { flex-direction: column; align-items: flex-start; text-align: left; }
    .about-mark { max-width: 150px; }
}
.about-body { padding: 16px 24px 22px; font-size: .9rem; line-height: 1.7; color: var(--text-muted); }
.about-body p { margin: 12px 0 0; }
.about-flow {
    font-family: ui-monospace, 'JetBrains Mono', monospace; font-size: .78rem; line-height: 1.6;
    background: var(--neutral-light); border: 1px solid var(--border); border-radius: var(--radius-sm);
    padding: 14px 16px; overflow-x: auto; color: var(--text); margin: 0;
}
.about-dl { margin: 0; }
.about-dl dt { font-weight: 700; color: var(--text); margin-top: 14px; }
.about-dl dt:first-child { margin-top: 0; }
.about-dl dd { margin: 3px 0 0; }
.about-ul { margin: 0; padding-left: 18px; }
.about-ul li { margin-bottom: 10px; }
.about-body kbd {
    font-family: ui-monospace, monospace; font-size: .78em; font-weight: 700;
    background: var(--surface); border: 1px solid var(--border); border-bottom-width: 2px;
    border-radius: 4px; padding: 1px 6px; color: var(--text);
}

/* Keyboard-focused row + the shortcut cheatsheet */
tr.data-row.kb-focus > td { background: var(--primary-surface) !important; }
tr.data-row.kb-focus > td:first-child { box-shadow: inset 3px 0 0 var(--primary); }
.kb-help {
    display: flex; flex-wrap: wrap; gap: 6px 14px; align-items: center;
    margin: 0 0 12px; padding: 8px 12px;
    background: var(--neutral-light); border: 1px solid var(--border);
    border-radius: var(--radius-sm); font-size: .78rem; color: var(--text-muted);
}
.kb-help kbd {
    font-family: ui-monospace, monospace; font-size: .74rem; font-weight: 700;
    background: var(--surface); border: 1px solid var(--border);
    border-bottom-width: 2px; border-radius: 4px; padding: 1px 6px; color: var(--text);
}

/* Breach names link to their XposedOrNot detail page */
.breach-link { color: var(--primary); text-decoration: none; border-bottom: 1px dotted currentColor; }
.breach-link:hover { color: var(--primary-dark); border-bottom-style: solid; }

/* Brand tile - first block of the dashboard's top row. The logo's white
   matte matches the card, so it needs no plate here (unlike the header).
   height:100% + the logo centered within it (justify-content:center) is
   what makes this card match the height of the two-stat-card stack next
   to it in .dash-grid, instead of only being as tall as the logo image. */
.brand-card { display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center; height: 100%; }
/* The mark alone is unreadable at tile size, so the tile carries the full
   lockup, which already states the product name and tagline. */
.brand-lockup { width: 100%; max-width: 260px; height: auto; object-fit: contain; }
.barchart-scroll { overflow-x: auto; }
.barchart { display: flex; align-items: flex-end; gap: 10px; padding: 16px 18px; height: 220px; }
/* flex-shrink:0 on a 28px basis keeps bars from being squeezed unreadable when
   the 30-day view has more columns than fit the card; barchart-scroll takes
   over instead. flex-grow:1 still spreads the (usual) 7-day view to full width. */
.bar-col { flex: 1 0 28px; display: flex; flex-direction: column; align-items: center; height: 100%; }
[data-range-panel="30"] .bar-col { flex: 1 1 16px; min-width: 16px; }
.bar-count { font-size: .78em; color: var(--text-muted); margin-bottom: 4px; }
.bar { flex: 1; width: 60%; max-width: 46px; min-width: 16px; display: flex; flex-direction: column-reverse;
       background: var(--neutral-light); border-radius: 4px 4px 0 0; overflow: hidden; }
.bar-ham  { background: #86efac; }
.bar-spam { background: #f87171; }
.bar-lbl { font-size: .74em; color: var(--text-subtle); margin-top: 6px; white-space: nowrap; }

.range-toggle { display: inline-flex; border: 1px solid var(--border); border-radius: var(--radius-sm); overflow: hidden; }
.range-btn {
    padding: 3px 10px;
    font-size: .78em;
    font-weight: 600;
    font-family: inherit;
    border: none;
    background: var(--surface);
    color: var(--text-muted);
    cursor: pointer;
}
.range-btn + .range-btn { border-left: 1px solid var(--border); }
.range-btn.active { background: var(--primary); color: #fff; }
.hidden { display: none !important; }

/* Loading overlay */
.loading-overlay { position: fixed; inset: 0; background: rgba(15,23,42,.35); z-index: 200;
    display: none; align-items: center; justify-content: center; }
.loading-overlay.show { display: flex; }
#lookup-toast {
    position: fixed; right: 20px; bottom: 20px; max-width: 360px;
    background: var(--text); color: #fff; padding: 10px 16px; border-radius: var(--radius-sm);
    font-size: .85em; box-shadow: 0 4px 16px rgba(0,0,0,.25); z-index: 300;
    opacity: 0; transform: translateY(8px); transition: opacity .2s ease, transform .2s ease;
    pointer-events: none;
}
#lookup-toast.show { opacity: 1; transform: translateY(0); }
.spinner { width: 44px; height: 44px; border: 4px solid rgba(255,255,255,.45); border-top-color: #fff;
    border-radius: 50%; animation: spin .8s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }
/* Update-card status dot while an update apply is running (views/partials/update_card.php) */
@keyframes qa-pulse { 0%, 100% { opacity: 1; } 50% { opacity: .35; } }

/* Archívum "IOC ellenőrzés" popup -- this generic modal-chrome block
   (.arc-ioc-overlay/-modal/-modal-head/-modal-body/-modal-foot/-modal-close)
   is also reused as-is by the Admin > Adatvédelem GDPR notice popup
   (views/layout_foot.php's #qaGdprOverlay); only .arc-ioc-cand-* below is
   specific to the Archívum feature. */
.arc-ioc-overlay { position: fixed; inset: 0; background: rgba(15,23,42,.45); z-index: 220;
    display: none; align-items: center; justify-content: center; padding: 20px; }
.arc-ioc-overlay.show { display: flex; }
.arc-ioc-modal { background: var(--surface); border-radius: var(--radius); box-shadow: var(--shadow);
    max-width: 640px; width: 100%; max-height: 85vh; display: flex; flex-direction: column; }
.arc-ioc-modal-head { display: flex; align-items: center; justify-content: space-between;
    padding: 14px 18px; border-bottom: 1px solid var(--border); flex: 0 0 auto; }
.arc-ioc-modal-head h3 { margin: 0; font-size: 1.05em; }
.arc-ioc-modal-close { background: none; border: none; cursor: pointer; color: var(--text-subtle);
    padding: 4px; line-height: 0; }
.arc-ioc-modal-close:hover { color: var(--text); }
.arc-ioc-modal-close .icon { width: 1.2em; height: 1.2em; }
.arc-ioc-modal-body { padding: 16px 18px; overflow-y: auto; }
.arc-ioc-modal-foot { display: flex; justify-content: flex-end; gap: 8px;
    padding: 12px 18px; border-top: 1px solid var(--border); flex: 0 0 auto; }
.arc-ioc-cand { padding: 10px 0; border-bottom: 1px solid var(--border); }
.arc-ioc-cand:last-child { border-bottom: none; }
.arc-ioc-cand-head { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; margin-bottom: 6px; }
.arc-ioc-cand-pick { display: inline-flex; align-items: center; }
.arc-ioc-cand-type { font-size: .72rem; text-transform: uppercase; letter-spacing: .04em;
    color: var(--text-subtle); font-weight: 700; }
.arc-ioc-cand-value { font-family: monospace; word-break: break-all; font-size: .9em; }
.arc-ioc-loading { display: flex; flex-direction: column; align-items: center; gap: 12px; padding: 30px 0; }
.arc-ioc-loading .spinner { border-color: rgba(15,23,42,.15); border-top-color: var(--primary); }

.bulk-bar {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px 16px;
    background: var(--primary-surface);
    border-bottom: 1px solid var(--primary-light);
}
.bulk-bar label { font-size: .84em; color: var(--text-muted); font-weight: 500; }

/* ── Tables ──────────────────────────────────────────────────────── */
table { width: 100%; border-collapse: collapse; }
thead th {
    background: var(--neutral-light);
    color: var(--text-muted);
    padding: 10px 14px;
    text-align: left;
    font-size: .8em;
    font-weight: 700;
    white-space: nowrap;
    text-transform: uppercase;
    letter-spacing: .04em;
    border-bottom: 2px solid var(--border);
    position: sticky;
    top: 0;
    z-index: 5;
}
thead th:first-child { width: 36px; text-align: center; }
.sort-th { color: inherit; text-decoration: none; display: inline-flex; align-items: center; gap: 2px;
           cursor: pointer; white-space: nowrap; }
.sort-th:hover, .sort-th.active { color: var(--primary); }
tbody tr.data-row { background: var(--surface); transition: background var(--t); }
tbody tr.data-row.alt { background: var(--neutral-light); }
tbody tr.data-row:hover,
tbody tr.data-row.alt:hover { background: var(--primary-surface); }

tr.data-row td:first-child { border-left: 4px solid transparent; }
tr.data-row.f-Spam       td:first-child { border-left-color: #e11d48; }
tr.data-row.f-Junk       td:first-child { border-left-color: var(--warning); }
tr.data-row.f-Quarantine td:first-child { border-left-color: var(--danger); }
tr.data-row.f-spam       td:first-child { border-left-color: var(--danger);  border-left-width: 5px; }
tr.data-row.f-ham        td:first-child { border-left-color: var(--success); border-left-width: 5px; }

/* Spam/ham rows both use the same tint as their own verdict badge
   (--danger-light / --success-light) rather than a near-invisible custom
   color, so a row reads as spam/ham at a glance, not just via the small
   badge text. */
tr.data-row.f-spam, tr.data-row.f-spam.alt { background: var(--danger-light); }
tr.data-row.f-ham,  tr.data-row.f-ham.alt  { background: var(--success-light); }
tr.data-row.f-spam:hover, tr.data-row.f-spam.alt:hover {
    background: linear-gradient(rgba(0,0,0,.04), rgba(0,0,0,.04)), var(--danger-light);
}
tr.data-row.f-ham:hover, tr.data-row.f-ham.alt:hover {
    background: linear-gradient(rgba(0,0,0,.04), rgba(0,0,0,.04)), var(--success-light);
}
/* A learned row gets a visibly darker shade than an ordinary spam/ham row, so
   "this one was already acted on" reads at a glance, not just via the icon. */
tr.data-row.f-spam.learned, tr.data-row.f-spam.learned.alt { background: var(--danger-medium); }
tr.data-row.f-ham.learned,  tr.data-row.f-ham.learned.alt  { background: var(--success-medium); }
tr.data-row.f-spam.learned:hover, tr.data-row.f-spam.learned.alt:hover {
    background: linear-gradient(rgba(0,0,0,.04), rgba(0,0,0,.04)), var(--danger-medium);
}
tr.data-row.f-ham.learned:hover, tr.data-row.f-ham.learned.alt:hover {
    background: linear-gradient(rgba(0,0,0,.04), rgba(0,0,0,.04)), var(--success-medium);
}
td {
    padding: 12px 14px;
    border-bottom: 1px solid var(--border);
    vertical-align: middle;
    font-size: .95em;
    line-height: 1.5;
}
td:first-child { text-align: center; }
/* Archívum: denser rows so more messages fit on screen without scrolling. */
.archive-table td { padding: 7px 14px; }
/* IOC page: denser rows so more indicators fit on screen without scrolling. */
.ioc-table td { padding: 8px 8px; }
/* Blokklista / Fehérlista and Rendszer status tables (+ the dashboard's
   Blokkolt levelek and Adatvédelmi incidensek cards): same dense-row family
   as the IOC table, but at 7 columns .list-table does not need that table's
   12-column horizontal squeeze, and neither class inherits the IOC-specific
   th rule below. Rendszer/dashboard deliberately use .sys-table rather than
   .list-table -- that class also carries the Minta-column
   `code { white-space: normal }' fix below, which has no meaning outside
   Blokklista/Fehérlista. */
.list-table td, .sys-table td { padding: 8px 14px; }
/* Pattern column: the global `code { white-space: nowrap }' rule above
   (~line 496) silently defeats the pattern cell's own inline
   overflow-wrap:anywhere -- nowrap suppresses ALL line breaks regardless of
   overflow-wrap, so long unbroken patterns (e.g. message-id-style local
   parts) overflowed the cell instead of wrapping. Scoped here rather than
   changed globally so every other `code' use on the site keeps its
   single-line look. If that global rule is ever removed or changed, revisit
   whether this override is still needed. */
.list-table code { white-space: normal; }
/* Blokklista / Fehérlista: the new "Összesített %" header (13 chars,
   uppercased by the shared thead th rule with letter-spacing) needs
   ~93.9px and only had a 62-81px content box -- broke mid-word in hu at
   every width and in es at 1280/1400 (the overflow-wrap:anywhere inline
   style on that one th converts "doesn't fit" into "breaks mid-word"
   instead of overflowing, which is why no automated overflow check ever
   caught it). Unlike .ioc-table thead th above, this is NOT the 12-column
   horizontal squeeze -- it is only the typography (uppercase +
   letter-spacing + 14px padding) that doesn't fit, so pull in just that,
   not the .ioc-table rule itself. Also brings this table's header
   case in line with .ioc-table's (was the last uppercase/uncompacted
   holdout), which increases parity rather than reducing it.
   .quar-table (Jelentett spam, Task 6 of the reputation-lookup work) shares
   this rule for the exact same reason -- it grew the same "Összesített %"
   header onto a table that was never given the auto-layout squeeze the IOC
   table has, so only the typography needs pulling in, not a colgroup. */
.list-table thead th, .quar-table thead th, .sys-table thead th { padding: 6px 8px; font-size: .72em; letter-spacing: 0; text-transform: none; }
/* Deliberately NOT adding `.list-table th, .list-table td { overflow-wrap:
   anywhere }` here. It was tried, to contain small Típus/Hozzáadta overflow
   in the 720-1280px band, and it backfired: overflow-wrap fires on
   CONTENT-box overflow, so it also triggers on tokens that overflow by less
   than the 14px cell padding -- previously invisible (the padding gutter
   absorbed them), visibly split mid-word with the rule on. Measured: new
   mid-word breaks on "Domain"/"Dirección"/"mailscanner-import" at 1152px in
   all three languages and at 1280px in Spanish, where the rendering had been
   clean. It was a real win only at 1024px. Net worse, so reverted.
   Note for anyone re-attempting this: `scrollWidth > clientWidth` does NOT
   detect the original overflow on a `table-layout:fixed` td -- a token can
   bleed 16px past the border box with scrollWidth == clientWidth. Measure
   with Range.getBoundingClientRect() against the cell box instead. */
/* IOC table: 12 columns means the shared thead th style (14px horizontal
   padding, uppercase, letter-spacing) is itself the widest thing in several
   narrow columns -- e.g. "MEGBÍZHATÓSÁG" alone needs ~147px unmodified vs.
   ~122px compacted (measured floor: 112px broke mid-word, 122px didn't --
   see docs/superpowers/notes/2026-08-13-ioc-table-fit-fix.md for the German
   "Vertrauenswürdigkeit" case, which needs ~142px even compacted). Scoped to
   .ioc-table only, other tables' headers (Archívum, Block/Whitelist) keep
   the shared style untouched. */
.ioc-table thead th {
    padding: 6px 8px;
    font-size: .72em;
    letter-spacing: 0;
    text-transform: none;
}
/* Hyphenate ONLY the long single-word headers ("Megbízhatóság",
   "Összesített %"), which otherwise break at an arbitrary character
   ("Megbízha|tóság"); <html lang> is always set so the browser breaks at real
   syllable boundaries instead. Deliberately NOT on `.ioc-table thead th`
   generally: applied there it also hyphenates the SERVICE headers, and giving
   "VirusTotal" extra break points pushed it from 2 lines to "Vi-|rus-|Total"
   -- a 3-line header, the one case this table's column budget forbids
   (docs/superpowers/notes/2026-08-13-ioc-table-fit-fix.md). Verified in
   Chromium both ways. Cosmetic only; overflow-wrap remains the no-overflow
   guarantee. */
.ioc-th-hyphen { hyphens: auto; }
/* Megbízhatóság as an icon (QA_IOC_CONFIDENCE_ICON): one shield at three
   strengths, so the level reads as an intensity rather than three glyphs the
   operator has to learn. Colour is the ONLY difference, which is why the
   tooltip + .sr-only label + the legend under the table all carry the word --
   colour alone must never be the sole carrier of meaning. */
.ioc-conf .icon { width: 17px; height: 17px; vertical-align: middle; }
/* Típus / Forrás icon cells (QA_IOC_TYPE_ICON, QA_IOC_SOURCE_ICON). Muted
   rather than coloured: these are neutral facts about the row (what kind of
   indicator, where it came from), not a severity, and colouring them would
   compete with the Megbízhatóság and per-service verdict columns that DO
   carry meaning in colour. */
.ioc-gi .icon { width: 17px; height: 17px; vertical-align: middle; color: var(--text-muted); }
.ioc-conf-high   { color: var(--danger); }
.ioc-conf-medium { color: var(--warning); }
.ioc-conf-low    { color: var(--text-subtle); opacity: .75; }
/* Every control in the IOC Művelet column the same width, so the stacked
   Ellenőrzés / Élesítés / Élesítve / Visszavonás / Lejáratás controls form one
   tidy block instead of a ragged edge. width:100% (not a fixed px) keeps them
   matched at any column width and in any language -- the column is already
   sized by the colgroup. box-sizing so the border does not push them past it.
   The .verdict badge is included because "Élesítve" sits in the same stack and
   would otherwise be the one odd-width element. */
.ioc-table td form { margin: 0; }
.ioc-table td .btn,
.ioc-table td .verdict {
    display: flex; width: 100%; box-sizing: border-box;
    align-items: center; justify-content: center; gap: 4px;
}
/* Visible only to screen readers: keeps the icon-only cells announced. */
.sr-only {
    position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px;
    overflow: hidden; clip: rect(0, 0, 0, 0); white-space: nowrap; border: 0;
}
/* max-width + overflow-wrap: a long email address has no spaces to wrap
   at, so without both of these one long From/To address forces the whole
   table wider than its container -- table-layout:auto happily grows a
   column to fit an unbreakable string if there's room, and overflow-wrap
   alone only helps once a column can't grow any further. This is what was
   actually pushing the Archívum table past its card and clipping the last
   column, not the action buttons (already fixed separately). */
.col-user    { min-width: 175px; max-width: 220px; font-size: .88em; color: var(--text-muted); overflow-wrap: anywhere; }
.col-folder  { width: 90px; }
.col-from    { min-width: 180px; }
.col-subject { font-weight: 600; color: var(--text); }
.col-date    { width: 148px; font-size: .87em; color: var(--text-muted); white-space: nowrap; }
/* Country flag cell: narrow and centred, and never a wrap/stretch target --
   one small image, so the column should cost as little width as possible
   next to Subject, which wants all it can get. */
.col-cc      { width: 46px; text-align: center; white-space: nowrap; line-height: 1; }
/* The 20x15 render is half the 40x30 source, so it stays sharp on HiDPI.
   The hairline border keeps predominantly-white flags (JP, PL, FI) from
   dissolving into a light row background. */
.cc-flag     { width: 20px; height: 15px; vertical-align: middle; border-radius: 2px;
               box-shadow: 0 0 0 1px rgba(0,0,0,.18); object-fit: cover; }
.col-actions { width: 150px; white-space: nowrap; }
/* Jelentett spam (Task 6): the two reputation-lookup cells. Auto layout, like
   every other column on this table (deliberately NOT table-layout:fixed --
   see the .quar-table comment on the thead th rule above), so this is only a
   TD sizing hint (the %/value is always short and never wraps) -- it is
   deliberately NOT put on the <th> too. thead th is nowrap by default
   (:640), and "Összesített %" under nowrap doesn't break, it just forces the
   column (and so the whole table) wider -- measured via real Chromium: up to
   +260px table width and a squeezed col-from/col-subject at 768/1024px,
   the exact regression this task's Layout section warned about. The view
   gives that one <th> the same inline white-space:normal;overflow-wrap:
   anywhere override views/lists.php:112 and views/ioc.php already use for
   this identical header, instead of a shared class rule here. No min-width
   on col-quar-rep either, for the same reason: reserving space for the
   *populated* (post-lookup) state on every render, including rows nobody
   has checked yet, was the other half of that same width regression --
   auto-layout already sizes the column from whatever's actually in it.
   min-width, not width: under auto layout a wrap-capable header has almost
   no min-content, so a plain `width` is only a hint the table-layout
   algorithm freely overrides (measured: it still shrank to ~52px and
   3-line-wrapped) -- min-width is treated as a hard floor instead. 110px
   matches .list-table's own colgroup allowance for this exact header
   (:711-722's comment) so it wraps to 2 clean lines, not 3 ugly ones. */
/* 130px is not a guess: measured in a real browser, the longest unbreakable
   word in this header ("Összesített") is 102px in the header's own font, plus
   28px of cell padding. Below that the th carries overflow-wrap:anywhere, so
   it does not wrap at the space -- it splits the WORD, rendering
   "ÖSSZESÍTE / TT %". The previous 110px was already under that threshold;
   narrowing it further to give the Hírnév column room simply made the break
   visible. Widening slightly is the honest fix, and the Hírnév column gets its
   room from its own min-width instead. */
.col-quar-conf { min-width: 130px; }

/* ── Hírnév cell: one row per indicator, then the button ──────────────────
   Reads top-to-bottom as "D <verdicts>" / "IP <verdicts>" / [Ellenőrzés]
   instead of one long line that had to wrap arbitrarily. Stacking makes the
   column's intrinsic width SMALLER (measured 257px -> 184px at 1440), so the
   min-width below is what actually widens it -- and it is safe here in a way
   it was not for the old flat layout, because the stacked content no longer
   grows sideways with the number of verdicts. */
td.col-quar-rep .quar-rep-badges {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    gap: 4px;
}
/* Label on its own row, its verdict icons on the next. Putting the label
   inline with the icons meant the icons had only the leftover width and wrapped
   raggedly under it; giving each a full row keeps the icons on one line in a
   narrow column and makes the D/IP grouping obvious at a glance. */
.quar-rep-label {
    font-size: .68rem;
    font-weight: 700;
    letter-spacing: .04em;
    text-transform: uppercase;
    color: var(--text-subtle);
    line-height: 1.2;
}
.quar-rep-syms {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 3px;
    margin-bottom: 2px;
}
/* The button gets its own row, left-aligned with the labels and icons above
   it -- the whole cell reads as one left edge. */
.quar-rep-act { align-self: flex-start; margin-top: 2px; }
/* 193px, measured: five 30px verdict icons plus four 3px gaps plus the cell's
   28px padding. Five is reachable in practice -- virustotal, urlhaus, otx, hrbl
   and url.vet can all answer for a domain -- and below this the fifth icon
   wrapped onto a second line, which is exactly the ragged look the row-per-
   indicator layout exists to avoid. */
.col-quar-rep { min-width: 193px; }
/* Short indicator tag (D / IP) grouping the icons that follow it in the
   Hírnév cell -- same pill language as .folder-tag, just smaller, since this
   is a label for a group of badges rather than a value on its own. */
.quar-tag {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 1.4em;
    padding: 1px 5px;
    margin-right: 3px;
    border-radius: 999px;
    background: var(--neutral-light);
    color: var(--neutral);
    font-size: .72em;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: .02em;
}
.quar-tag:not(:first-child) { margin-left: 6px; }

.subject-link {
    cursor: pointer;
    color: var(--primary);
    user-select: none;
    overflow-wrap: anywhere;
}
.subject-link:hover { text-decoration: underline; }
.subject-arrow, .arrow {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 1.6em;
    height: 1.6em;
    font-size: 1.1em;
    margin-right: 5px;
    border-radius: 50%;
    transition: transform 0.18s, color var(--t), background var(--t);
    color: var(--primary-dark);
    cursor: pointer;
}
.subject-arrow:hover, .arrow:hover { color: var(--primary-dark); background: var(--primary-surface); }
.subject-arrow.open, .arrow.open { transform: rotate(90deg); color: var(--primary-dark); }

/* ── Inline detail row ───────────────────────────────────────────── */
.detail-row > td {
    padding: 0;
    border-bottom: 2px solid var(--primary);
    border-top: none;
}
.detail-inner {
    padding: 12px 16px 12px;
    background: var(--primary-surface);
    border-left: 4px solid var(--primary);
    animation: slideDown 0.18s ease;
}
@keyframes slideDown {
    from { opacity: 0; max-height: 0; }
    to   { opacity: 1; max-height: 9999px; }
}
.detail-meta {
    margin-bottom: 14px;
    padding-bottom: 12px;
    border-bottom: 1px solid var(--primary-light);
}
.meta-tbl { width: 100%; border-collapse: collapse; }
.meta-tbl th {
    width: 72px;
    padding: 4px 10px 4px 0;
    font-size: .8em;
    color: var(--text-muted);
    text-align: left;
    vertical-align: top;
    white-space: nowrap;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: .04em;
}
.meta-tbl td { padding: 4px 0; font-size: .92em; word-break: break-word; }
/* The expanded detail row is a table cell, and `td:first-child` centres first
   cells for the checkbox column -- which the text and source views inherited.
   Message content is always read left-aligned. */
tr.detail-row > td { text-align: left; }
.detail-body {
    text-align: left;
    white-space: pre-wrap;
    word-break: break-word;
    font-family: ui-monospace, 'JetBrains Mono', 'Fira Code', 'Courier New', monospace;
    font-size: .9em;
    line-height: 1.65;
    max-height: 380px;
    overflow-y: auto;
    background: var(--surface);
    padding: 14px 16px;
    border: 1px solid var(--primary-light);
    border-radius: 6px;
    margin: 0 0 8px;
    color: var(--text);
}
/* Raw source. white-space:pre + overflow-x:auto was the previous form, but
   this <pre> lives inside a colspan cell of the AUTO-layout .archive-table:
   an auto table sizes cells by intrinsic content width, so overflow never
   engaged -- a long source line (a 148-char DKIM fold is enough) inflated
   the cell, the whole table grew past the card and the page layout broke,
   and STAYED broken after closing the row. Reported live from the Archive
   source view. Wrapping is the containment that works inside auto tables
   (same lesson as the Hírnév column: overflow-wrap:anywhere, not scroll);
   RFC 5322 folding keeps wrapped headers readable, and base64 was never
   line-by-line meaningful anyway. */
.detail-source {
    white-space: pre-wrap;
    overflow-wrap: anywhere;
    word-break: normal;
    max-height: 460px;
    overflow-y: auto;
    font-size: .82em;
    line-height: 1.5;
}
.detail-actions {
    display: flex;
    gap: 8px;
    margin-top: 12px;
    justify-content: flex-end;
    align-items: center;
}
.detail-close-link {
    font-size: .82em;
    color: var(--text-muted);
    cursor: pointer;
    margin-right: auto;
    text-decoration: underline;
}
.detail-close-link:hover { color: var(--text); }
.detail-loading { text-align: center; padding: 36px; color: var(--text-muted); font-size: .9em; }
.detail-error   { color: var(--danger); padding: 12px 0; font-size: .9em; }
.truncated-note { font-size: .79em; color: var(--text-muted); margin-top: 6px; font-style: italic; }

.why { border-radius: 6px; padding: 10px 12px; margin-bottom: 12px; border: 1px solid; font-size: .86em; }
.why-spam { background: #fef5f5; border-color: #fca5a5; }
.why-ham  { background: #f5fbf7; border-color: #86efac; }
.why-head { color: var(--text); }
.why-syms { margin-top: 8px; display: flex; flex-wrap: wrap; gap: 5px; }
.why .sym { font-family: ui-monospace, monospace; font-size: .92em; background: rgba(0,0,0,.05);
            border: 1px solid rgba(0,0,0,.08); border-radius: 4px; padding: 1px 6px; color: var(--neutral); }

.sender-actions { display: flex; flex-wrap: wrap; align-items: center; gap: 8px; margin-top: 12px;
                  padding-top: 10px; border-top: 1px dashed var(--border); }
.sa-label { font-size: .82em; font-weight: 700; color: var(--text-subtle); }

.detail-toolbar {
    display: flex;
    align-items: center;
    gap: 12px;
    flex-wrap: wrap;
    margin-bottom: 10px;
}
.view-toggle {
    display: inline-flex;
    border: 1px solid var(--border);
    border-radius: var(--radius-sm);
    overflow: hidden;
    background: var(--surface);
}
.vt-btn {
    padding: 5px 13px;
    border: none;
    background: var(--surface);
    color: var(--text-muted);
    font-family: inherit;
    font-size: .84em;
    font-weight: 600;
    cursor: pointer;
    transition: background var(--t), color var(--t);
}
.vt-btn + .vt-btn { border-left: 1px solid var(--border); }
.vt-btn:hover { background: var(--neutral-light); }
.vt-btn.active { background: var(--primary); color: #fff; }
.remote-note {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    font-size: .82em;
    color: var(--warning);
    font-weight: 600;
}
.detail-html {
    width: 100%;
    height: 420px;
    border: 1px solid var(--primary-light);
    border-radius: 6px;
    background: #fff;
    display: block;
}

/* Folder / status pills */
.folder-tag {
    display: inline-flex;
    align-items: center;
    padding: 2px 9px;
    border-radius: 999px;
    font-size: .8em;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: .02em;
}
.folder-Junk       { background: var(--warning-light); color: var(--warning); }
.folder-Quarantine { background: var(--danger-light);  color: var(--danger-dark); }
.folder-Spam       { background: #ffe4e6;              color: #9f1239; }
/* Mail-auth-failure source badges (Audit > Bejelentkezések) -- protocol,
   not severity, so a neutral palette rather than the warning/danger tones
   above. */
.folder-IMAP       { background: var(--neutral-light); color: var(--neutral); }
.folder-POP3       { background: var(--neutral-light); color: var(--neutral); }
.folder-WEBMAIL    { background: var(--primary-light); color: var(--primary-dark); }

.from-name  { font-weight: 600; color: var(--text); font-size: .95em; }
.from-email { font-size: .83em; color: var(--text-muted); margin-top: 1px; }

.empty-state { text-align: center; padding: 56px 20px; color: var(--text-muted); }
.empty-state p { margin-top: 10px; font-size: .9em; }

.action-btns { display: flex; gap: 5px; flex-wrap: wrap; }
/* Archívum: two equal-width columns (Ham/Spam, then Tiltás/Enged.), with
   Újraküld as its own full-width row last -- explicit grid placement
   rather than relying on flex-wrap's natural flow, so the pairing is
   guaranteed regardless of container width. minmax(0,1fr) lets a column
   shrink below its content's natural width instead of forcing the row
   (and the table) wider than the card. Scoped to Archívum only --
   quarantine.php's action-btns (2 longer Hungarian labels in a narrower
   column) keeps the plain flex behavior above. */
.archive-table .action-btns {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 6px;
}
.archive-table .action-btns .btn { justify-content: center; }
.archive-table .action-btns .action-btn-wide { grid-column: 1 / -1; }

/* Pagination */
.results-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    padding: 13px 20px;
    border-top: 1px solid var(--border);
    background: var(--neutral-light);
}
.pager { display: flex; align-items: center; gap: 10px; }
.pager-info { font-size: .84em; color: var(--text-muted); }
.pager-disabled { background: var(--neutral-light); color: var(--text-subtle); border-color: var(--border); cursor: default; box-shadow: none; }
/* A control that is present but not currently permitted. Shown rather than
   hidden so the option is discoverable and its precondition can be stated in
   the tooltip -- a button that simply is not there teaches nobody why. */
.btn:disabled, .btn[disabled] {
    background: var(--neutral-light); color: var(--text-subtle);
    border-color: var(--border); cursor: not-allowed; box-shadow: none; opacity: .75;
}
.btn:disabled:hover, .btn[disabled]:hover { background: var(--neutral-light); box-shadow: none; }
input:disabled { background: var(--neutral-light); color: var(--text-subtle); cursor: not-allowed; }

input[type=checkbox] { width: 15px; height: 15px; cursor: pointer; accent-color: var(--primary); }

/* ── Mobile ──────────────────────────────────────────────────────── */
@media (max-width: 720px) {
    .wrap { padding: 12px 8px; }
    .page-title { margin-top: 44px; }
    .nav-toggle { display: flex; align-items: center; justify-content: center; }
    .sidebar {
        position: fixed;
        left: 0;
        top: 0;
        width: 260px;
        z-index: 160;
        transform: translateX(-100%);
        transition: transform var(--t);
    }
    .sidebar.nav-open { transform: translateX(0); }
    .sidebar.nav-open ~ .nav-backdrop,
    #navBackdrop:has(~ .sidebar.nav-open) { display: block; }
    .nav-open ~ #navBackdrop { display: block; }
    .filter-card, .results-card { border-radius: 0; margin-left: -8px; margin-right: -8px; }
    .filter-row { flex-direction: column; align-items: stretch; gap: 10px; overflow-x: visible; }
    .filter-group { flex: none; width: 100%; }
    .filter-group:has(> .btn),
    .filter-group:has(> a.btn) { flex: none; }
    .filter-group select,
    .filter-group input[type=date],
    .filter-group input[type=text] { width: 100%; padding: 10px; }
    .filter-card .btn { width: 100%; justify-content: center; padding: 11px 16px; }
    .filter-group label[for] { font-size: .9em; }
    .results-header { flex-direction: column; align-items: flex-start; gap: 4px; }
    .bulk-bar { flex-wrap: wrap; }
    .bulk-bar .btn { flex: 1 1 auto; justify-content: center; padding: 9px 12px; }
    .tabbar { overflow-x: auto; padding: 0 8px; }
    table, tbody, tr.data-row, tr.data-row td { display: block; width: 100%; }
    thead { display: none; }
    tr.data-row {
        border: 1px solid var(--border);
        border-left: 4px solid var(--border);
        border-radius: var(--radius);
        margin: 10px;
        padding: 4px 12px;
        background: var(--surface) !important;
        box-shadow: var(--shadow-sm);
    }
    tr.data-row td:first-child { border-left: none; }
    tr.data-row.f-Spam       { border-left-color: #e11d48; }
    tr.data-row.f-Junk       { border-left-color: var(--warning); }
    tr.data-row.f-Quarantine { border-left-color: var(--danger); }
    tr.data-row.f-spam       { border-left-color: var(--danger); }
    tr.data-row.f-ham        { border-left-color: var(--success); }
    tr.data-row td {
        display: flex;
        gap: 10px;
        align-items: baseline;
        padding: 7px 0;
        border: none;
        border-bottom: 1px solid var(--bg);
        text-align: left;
        white-space: normal;
        width: auto;
    }
    tr.data-row td:last-child { border-bottom: none; }
    tr.data-row td::before {
        content: attr(data-label);
        flex: 0 0 84px;
        font-weight: 700;
        color: var(--text-subtle);
        font-size: .76em;
        text-transform: uppercase;
        letter-spacing: .04em;
    }
    tr.data-row td.col-check { justify-content: flex-start; }
    td.col-actions .action-btns { flex: 1; flex-wrap: wrap; }
    td.col-actions .action-btns .btn { flex: 1 1 auto; justify-content: center; padding: 10px; }
    /* Jelentett Hírnév cell (Task 6): same problem/fix as .action-btns just
       above. tr.data-row td is a nowrap flex container at this breakpoint;
       .quar-rep-badges' .quar-tag/.verdict/.quar-lookup-btn children were
       bare flex items with no wrap, so 3+ cached verdicts (trivially reached
       with e.g. virustotal+otx+hrbl on one indicator) pushed the button off
       the visible edge of the row card -- measured 41-134px overflow.
       Deliberately no base (non-media) rule for .quar-rep-badges: on desktop
       the <td> isn't flex at all, so the wrapper div only needs to stay
       display:block (its default) for its inline children to flow exactly
       as they did before this div existed -- giving it display:flex there
       too would swap the badges' natural inline-whitespace gaps for a CSS
       gap and could nudge the measured desktop column width. flex:1 (grow
       into the row's remaining width, alongside the ::before label) is what
       makes the group wrap within the available space instead of shrinking
       to its own overflowing intrinsic width first. */
    td.col-quar-rep .quar-rep-badges {
        /* Keep the stacked column here too -- this rule predates the stacking
           and would otherwise flip the cell back to one wrapping row at the
           720px breakpoint. flex:1 still lets it grow into the row card's
           remaining width alongside the ::before label. */
        display: flex; flex-direction: column; align-items: flex-start; gap: 4px; flex: 1;
    }
    tr.detail-row, tr.detail-row td { display: block; width: 100%; }
    tr.detail-row td { padding: 0; }
    tr.detail-row td::before { content: none; }
    .detail-inner { padding: 12px; }
    .detail-html { height: 320px; }
    .detail-toolbar { gap: 8px; }
    .meta-tbl th { width: 60px; }
    /* Raw source. white-space:pre + overflow-x:auto was the previous form, but
   this <pre> lives inside a colspan cell of the AUTO-layout .archive-table:
   an auto table sizes cells by intrinsic content width, so overflow never
   engaged -- a long source line (a 148-char DKIM fold is enough) inflated
   the cell, the whole table grew past the card and the page layout broke,
   and STAYED broken after closing the row. Reported live from the Archive
   source view. Wrapping is the containment that works inside auto tables
   (same lesson as the Hírnév column: overflow-wrap:anywhere, not scroll);
   RFC 5322 folding keeps wrapped headers readable, and base64 was never
   line-by-line meaningful anyway. */
.detail-source {
    white-space: pre-wrap;
    overflow-wrap: anywhere;
    word-break: normal;
    max-height: 460px;
    overflow-y: auto;
    font-size: .82em;
    line-height: 1.5;
}
.detail-actions { flex-wrap: wrap; }
    .detail-actions .btn { flex: 1 1 auto; justify-content: center; }
    .results-footer { flex-direction: column-reverse; gap: 10px; align-items: stretch; }
    .results-footer .btn { justify-content: center; }
    .pager { justify-content: space-between; }

    /* Admin management tables (settings / users / FTS) */
    table.msg-table tr {
        display: block;
        border: 1px solid var(--border);
        border-radius: var(--radius);
        margin: 8px 10px;
        padding: 10px 12px;
        background: var(--surface);
        box-shadow: var(--shadow-sm);
    }
    table.msg-table td {
        display: block;
        padding: 6px 0;
        border: none;
        border-bottom: 1px solid var(--bg);
        white-space: normal;
        width: auto;
    }
    table.msg-table td:last-child { border-bottom: none; }
    table.msg-table td form { flex-wrap: wrap; }

    /* Add-user form: stack fields full-width */
    .admin-add-user-row { flex-direction: column; align-items: stretch; }
    .admin-add-user-row > div { width: 100%; }
    .admin-add-user-row > div > input,
    .admin-add-user-row > div > select { width: 100% !important; box-sizing: border-box; }
    .admin-add-user-row > div > button.btn { width: 100%; justify-content: center; }
}
</style>
</head>
<body>
<?php require __DIR__ . '/icons.php'; ?>
