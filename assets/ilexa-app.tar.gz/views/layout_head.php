<!DOCTYPE html>
<html lang="<?= h(qa_lang()) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php
// Page name first, so browser tabs, history and screen readers tell the
// console's pages apart (they all read "ilexa - ..." before).
$_qa_page_name = t('Áttekintés');
if (!empty($is_quar))             $_qa_page_name = t('Jelentett spam');
elseif (!empty($is_archive))      $_qa_page_name = t('Archívum');
elseif (!empty($is_block))        $_qa_page_name = t('Blokklista');
elseif (!empty($is_white))        $_qa_page_name = t('Fehérlista');
elseif (!empty($is_ioc))          $_qa_page_name = 'IOC';
elseif (!empty($is_campaigns))    $_qa_page_name = t('Kampányok');
elseif (!empty($is_settings))     $_qa_page_name = t('Beállítások');
elseif (!empty($is_audit))        $_qa_page_name = t('Audit napló');
elseif (!empty($is_pfa))          $_qa_page_name = 'PostfixAdmin';
elseif (!empty($is_about))        $_qa_page_name = t('Névjegy');
?>
<title><?= h($_qa_page_name) ?> · <?= h(t(SITE_TITLE)) ?> - <?= h(SITE_SUBTITLE) ?></title>
<link rel="icon" href="<?= h(COOKIE_PATH) ?>assets/favicon.ico" sizes="any">
<link rel="icon" type="image/png" sizes="32x32" href="<?= h(COOKIE_PATH) ?>assets/favicon-32.png">
<link rel="apple-touch-icon" href="<?= h(COOKIE_PATH) ?>assets/apple-touch-icon.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root {
    --bg:              #f1f5f9;
    --surface:         #ffffff;
    --border:          #e2e8f0;
    --border-focus:    #c04c06;
    --text:            #0f172a;
    --text-muted:      #475569;
    --text-subtle:     #5c6b80;   /* 4.95:1 on --bg; #64748b was 4.34 (WCAG AA is 4.5) */
    --ink:             #091828;
    --ink-light:       #2d3c4a;
    --primary:         #c04c06;
    --primary-dark:    #9c3d05;
    --primary-light:   #f3ded2;
    --primary-surface: #fbf4f0;
    --success:         #047857;   /* white text 5.48:1; #059669 was 3.77 */
    --success-dark:    #065f46;
    --success-light:   #d1fae5;
    --success-medium:  #6ee7b7;
    --success-surface: #ecfdf5;
    --danger:          #dc2626;
    --danger-dark:     #b91c1c;
    --danger-light:    #fee2e2;
    --danger-medium:   #fca5a5;
    --danger-surface:  #fef2f2;
    --warning:         #854d0e;   /* 5.36:1 on --warning-light; #a16207 was 3.86 */
    --warning-light:   #eee2d2;
    --neutral:         #475569;
    --neutral-light:   #f8fafc;
    --radius:          8px;
    --radius-sm:       5px;
    --shadow-sm:       0 1px 2px 0 rgb(0 0 0 / .05);
    --shadow:          0 1px 3px 0 rgb(0 0 0 / .1), 0 1px 2px -1px rgb(0 0 0 / .1);
    --t:               150ms cubic-bezier(.4,0,.2,1);
}
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
.icon { width: 1em; height: 1em; display: inline-block; vertical-align: -0.15em; flex-shrink: 0; }
.icon-rot-90  { transform: rotate(90deg); }
.icon-rot-180 { transform: rotate(180deg); }
.icon-rot-270 { transform: rotate(270deg); }
body {
    font-family: 'Inter', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    font-size: 16px;
    line-height: 1.6;
    background: var(--bg);
    color: var(--text);
    -webkit-font-smoothing: antialiased;
    text-rendering: optimizeLegibility;
}
.page-title { font-size: 1.375rem; font-weight: 600; margin: 0 0 18px; color: var(--text); }
/* Hierarchy comes from size and colour; inline emphasis stays one step up. */
b, strong { font-weight: 600; }

/* ── Layout shell: sidebar + content ───────────────────────────────── */
body { display: flex; min-height: 100vh; }
.wrap { flex: 1 1 auto; min-width: 0; }

/* ── Collapsible sections (Rendszer) ─────────────────────────────────── */
/* <details> keeps this working with no JavaScript: the fold is native, and the
   script below only adds remembering. Sections that report health ship open,
   configuration ships collapsed -- see views/admin_system.php. */
.sys-sec > summary.results-header {
    cursor: pointer;
    list-style: none;                 /* hide the default disclosure triangle */
    display: flex;
    align-items: center;
    /* .results-header sets space-between, which pushed the chevron to the left
       edge and the title away from it. Sections must read as a left-aligned
       list, so start-align here and let the warning badge claim the right with
       its own margin-left:auto. */
    justify-content: flex-start;
    flex-wrap: wrap;
    gap: 2px 10px;
    user-select: none;
}
/* One-line summary of what the section is for, so a COLLAPSED section still
   says what it does. flex-basis:100% puts it on its own row; the left margin
   lines it up under the title rather than under the chevron. */
.sys-sec-desc {
    flex: 1 0 100%;
    margin-left: 17px;
    font-size: .8125rem;
    font-weight: 400;
    color: var(--text-muted);
    line-height: 1.45;
}
.sys-sec > summary.results-header::-webkit-details-marker { display: none; }
/* Our own chevron, so it sits with the heading instead of before the box. */
.sys-sec > summary.results-header::before {
    content: "";
    flex: 0 0 auto;
    width: 7px; height: 7px;
    margin-right: 2px;
    border-right: 2px solid var(--text-muted);
    border-bottom: 2px solid var(--text-muted);
    transform: rotate(-45deg);        /* points right when closed */
    transition: transform var(--t);
}
.sys-sec[open] > summary.results-header::before { transform: rotate(45deg); }
.sys-sec > summary.results-header:hover::before { border-color: var(--primary); }
.sys-sec > summary.results-header:hover h2 { color: var(--primary); }
/* Keyboard focus must be visible: summary is a real focus target. */
.sys-sec > summary.results-header:focus-visible {
    outline: 2px solid var(--border-focus);
    outline-offset: -2px;
}
/* Badge for a collapsed section that needs attention, so folding never buries
   a fault. Shown only while closed -- once open, the section says it itself. */
.sys-sec-flag {
    margin-left: auto;
    font-size: .75rem;
    font-weight: 600;
    padding: 2px 9px;
    border-radius: 999px;
    background: var(--warning-light);
    color: var(--warning);
    white-space: nowrap;
}
.sys-sec[open] .sys-sec-flag { display: none; }

/* ── Sidebar ────────────────────────────────────────────────────────── */
.sidebar {
    flex: 0 0 220px;
    width: 220px;
    height: 100vh;
    position: sticky;
    top: 0;
    display: flex;
    flex-direction: column;
    background: var(--ink);
    color: #fff;
    overflow-y: auto;
    z-index: 100;
}
.sidebar-brand {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px 16px;
    border-bottom: 1px solid rgb(255 255 255 / .1);
}
.sidebar-brand img {
    max-width: 100%;
    height: auto;
    background: #fff;
    border-radius: var(--radius);
    padding: 8px;
}
.snav { flex: 1; padding: 12px 10px; display: flex; flex-direction: column; gap: 2px; }
.snav-item {
    display: block;
    color: rgba(255,255,255,.78);
    text-decoration: none;
    padding: 9px 12px;
    border-radius: 6px;
    font-size: .9375em;
    font-weight: 500;
    transition: background var(--t), color var(--t);
}
.snav-item:hover  { background: rgb(255 255 255 / .1); color: #fff; }
/* Active = a surface step plus a short accent bar, not a filled orange block:
   the accent marks the selection without being the loudest thing on screen. */
.snav-item.active { background: rgb(255 255 255 / .1); color: #fff; box-shadow: inset 3px 0 0 var(--primary); }
.snav-bottom { margin-top: auto; }
.snav-group { margin-top: 14px; }
.snav-group-label {
    font-size: .75rem;
    font-weight: 500;
    letter-spacing: 0;
    color: rgba(255,255,255,.62);   /* .45 was 3.9:1 on the sidebar ink */
    padding: 4px 12px 4px;
}
.sidebar-foot {
    padding: 12px 14px 16px;
    border-top: 1px solid rgb(255 255 255 / .1);
    display: flex;
    flex-direction: column;
    gap: 8px;
}
.sidebar-user {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: .8125rem;
    color: rgba(255,255,255,.7);
}
.sidebar-user .icon { width: .95em; height: .95em; }
.role-chip {
    background: var(--primary-light);
    color: var(--primary-dark);
    padding: 1px 6px;
    border-radius: 3px;
    font-size: .6875rem;
    font-weight: 600;
}
.learn-badge {
    padding: 4px 10px;
    border-radius: 999px;
    font-size: .75em;
    font-weight: 600;
    letter-spacing: .01em;
    text-align: center;
}
/* The mode reads from a status dot (the console's live-state marker), not
   from a saturated pill with a bright ring. */
.learn-log, .learn-live { background: rgb(255 255 255 / .08); color: rgba(255,255,255,.85);
                          display: inline-flex; align-items: center; justify-content: center; gap: 8px; }
.learn-log::before, .learn-live::before { content: ""; width: 8px; height: 8px; border-radius: 50%; flex: 0 0 auto; }
.learn-log::before  { background: rgba(255,255,255,.45); }
.learn-live::before { background: #34d399; }

/* Mobile nav toggle + backdrop - hidden entirely on desktop */
.nav-toggle {
    display: none;
    position: fixed;
    top: 12px;
    left: 12px;
    z-index: 210;
    background: var(--ink);
    border: 1px solid rgb(255 255 255 / .2);
    color: #fff;
    border-radius: var(--radius-sm);
    padding: 8px 10px;
    cursor: pointer;
}
.nav-toggle .icon { width: 1.1em; height: 1.1em; }
.nav-backdrop {
    display: none;
    position: fixed;
    inset: 0;
    background: rgb(0 0 0 / .4);
    z-index: 150;
}

/* ClamAV stat blocks (dashboard tile + admin section) */
.cv-stat {
    flex: 1 1 150px;
    min-width: 140px;
    display: flex;
    flex-direction: column;
    gap: 2px;
    padding: 10px 12px;
    background: var(--neutral-light);
    border: 1px solid var(--border);
    border-radius: var(--radius-sm);
}
.cv-stat-k { font-size: .75rem; letter-spacing: 0;
             color: var(--text-subtle); font-weight: 500; }
.cv-stat-v { font-size: 1rem; font-weight: 600; color: var(--text); }
.cv-stat-s { font-size: .75rem; color: var(--text-muted); }

/* Audit sub-tabs */
.tabbar {
    display: flex;
    gap: 0;
    padding: 0 16px;
    background: var(--surface);
    border-bottom: 2px solid var(--border);
}
.tab {
    padding: 10px 18px;
    text-decoration: none;
    color: var(--text-muted);
    font-size: .875em;
    font-weight: 500;
    border: none;
    background: transparent;
    position: relative;
    transition: color var(--t);
}
.tab::after {
    content: '';
    position: absolute;
    bottom: -2px; left: 0; right: 0;
    height: 2px;
    background: var(--primary);
    transform: scaleX(0);
    transition: transform var(--t);
    border-radius: 2px 2px 0 0;
}
.tab:hover { color: var(--primary); }
.tab.active { color: var(--primary); font-weight: 600; }
.tab.active::after { transform: scaleX(1); }

/* Status badges */
.op-tag {
    display: inline-flex;
    align-items: center;
    padding: 2px 9px;
    border-radius: 999px;
    font-size: .8125em;
    font-weight: 600;
    white-space: nowrap;
    letter-spacing: .01em;
}
.op-release { background: var(--success-light); color: var(--success-dark); }
.op-delete  { background: var(--danger-light);  color: var(--danger-dark); }

/* Ham/Spam verdict badges (Archívum) */
.verdict {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 3px 10px 3px 8px;
    border-radius: 6px;
    font-size: .8125em;
    font-weight: 500;
    letter-spacing: 0;
    white-space: nowrap;
    vertical-align: middle;
}
.verdict-ham  { background: #dcfce7; color: #15803d; border: 1px solid #86efac; }
/* Verdict corrected by an admin's teaching: the badge shows what it was taught
   as, and this marks that it disagrees with what rspamd originally decided.
   Dashed border rather than a different colour, so the spam/ham colour still
   reads at a glance and the correction is a modifier on top of it. */
.verdict-corrected { border-style: dashed; border-width: 2px; }
.verdict-corrected sup { font-weight: 600; margin-left: 1px; }
.verdict-spam { background: #fee2e2; color: #b91c1c; border: 1px solid #fca5a5; }
.verdict .vi { font-size: 1em; line-height: 1; }

/* IOC lookup verdict badges (IOC tab) */
.verdict-malicious  { background: var(--danger-light);  color: var(--danger-dark); }
.verdict-suspicious { background: var(--warning-light); color: var(--warning); }
.verdict-clean      { background: var(--success-light); color: var(--success-dark); }
.verdict-unknown    { background: var(--neutral-light); color: var(--neutral); }
.conf-high   { background: var(--danger-light);  color: var(--danger-dark); }
.conf-medium { background: var(--warning-light); color: var(--warning); }
.conf-low    { background: var(--neutral-light); color: var(--neutral); }
/* Login-risk scoring's 4th tier (src/signin.php): a profile with too little
   history to trust a verdict from yet. Deliberately styled distinct from
   conf-low (a real "safe" verdict) -- this one means "no verdict", not
   "checked and clean", and showing it in the same color as a real low-risk
   result would misrepresent a brand-new profile's raw score as meaningful. */
.conf-learning { background: var(--neutral-light); color: var(--text-subtle); font-style: italic; }

/* IOC table's 5 per-service verdict columns render an icon instead of a
   word (see docs/superpowers/notes/2026-08-13-ioc-table-fit-fix.md) -- the
   shared .verdict pill (padding, icon at 1em) is used as-is, no compact
   override needed here now that there's no long verdict word to fit. */

/* ── Wrapper ─────────────────────────────────────────────────────── */
.wrap { max-width: 1340px; margin: 0 auto; padding: 24px 20px; }

/* Inline notices */
.notice { padding: 11px 16px; border-radius: var(--radius-sm); margin-bottom: 16px;
          font-size: .9375em; font-weight: 600; border: 1px solid transparent; }
.notice-ok  { background: var(--success-surface); color: var(--success-dark); border-color: var(--success-light); }
.notice-err { background: var(--danger-surface);  color: var(--danger-dark);  border-color: var(--danger-light); }

/* ── Filter card ─────────────────────────────────────────────────── */
.filter-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    box-shadow: var(--shadow-sm);
    padding: 20px 24px;
    margin-bottom: 16px;
}
.filter-card h2 {
    font-size: .8125em;
    font-weight: 500;
    color: var(--text-subtle);
    margin-bottom: 16px;
    letter-spacing: 0;
}
.filter-row { display: flex; flex-wrap: wrap; gap: 10px; align-items: flex-end; }
/* Wrap rather than squeeze: with nowrap the selects truncated their own
   values ("- össz", "-") at laptop widths. 120px keeps every field usable. */
.filter-group { display: flex; flex-direction: column; gap: 4px; flex: 1 1 120px; min-width: 120px; max-width: 280px; }
.filter-group:has(> .btn),
.filter-group:has(> a.btn) { flex: 0 0 auto; }
.filter-group label {
    font-size: .8125em;
    color: var(--text-muted);
    font-weight: 600;
    letter-spacing: .01em;
    white-space: nowrap;
}
.filter-group select,
.filter-group input[type=date],
.filter-group input[type=text] {
    border: 1px solid var(--border);
    border-radius: var(--radius-sm);
    padding: 6px 8px;
    font-size: .875em;
    font-family: inherit;
    background: var(--surface);
    color: var(--text);
    min-width: 0;
    width: 100%;
    transition: border-color var(--t), box-shadow var(--t);
}
.filter-group select:focus,
.filter-group input:focus {
    outline: none;
    border-color: var(--border-focus);
    box-shadow: 0 0 0 3px rgb(192 76 6 / .15);
}
.filter-hint { margin-top: 14px; font-size: .75em; color: var(--text-muted); line-height: 1.65; }
mark { background: #fef08a; color: inherit; padding: 0 1px; border-radius: 2px; }

/* ── Buttons ─────────────────────────────────────────────────────── */
.btn {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 7px 16px;
    border: 1px solid transparent;
    border-radius: var(--radius-sm);
    font-family: inherit;
    font-size: .875em;
    font-weight: 600;
    cursor: pointer;
    text-decoration: none;
    white-space: nowrap;
    transition: background var(--t), box-shadow var(--t), transform var(--t), border-color var(--t);
    line-height: 1.25;
}
.btn:active { transform: translateY(1px); }
.btn-primary   { background: var(--primary);  color: #fff; border-color: var(--primary); }
.btn-primary:hover { background: var(--primary-dark); border-color: var(--primary-dark); box-shadow: var(--shadow); }
.btn-success   { background: var(--success);  color: #fff; border-color: var(--success); }
.btn-success:hover { background: var(--success-dark); border-color: var(--success-dark); box-shadow: var(--shadow); }
.btn-danger    { background: var(--danger);   color: #fff; border-color: var(--danger); }
.btn-danger:hover  { background: var(--danger-dark);  border-color: var(--danger-dark);  box-shadow: var(--shadow); }
.btn-secondary { background: var(--surface);  color: var(--neutral); border-color: var(--border); }
.btn-secondary:hover { background: var(--neutral-light); border-color: #cbd5e1; box-shadow: var(--shadow-sm); }
.btn-sm { padding: 4px 10px; font-size: .8125em; }

/* ── Active-filter chips ─────────────────────────────────────────── */
.active-filters {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 6px;
    padding: 10px 16px;
    border-bottom: 1px solid var(--border);
    background: var(--neutral-light);
}
.af-label {
    font-size: .8125em;
    color: var(--text-subtle);
    font-weight: 500;
    letter-spacing: 0;
}
.chip {
    display: inline-flex;
    align-items: center;
    padding: 3px 10px;
    border-radius: 999px;
    font-size: .8125em;
    font-weight: 500;
    background: var(--primary-light);
    color: var(--primary-dark);
    border: 1px solid #e3c8b4;
}
.chip-clear {
    background: var(--danger-surface);
    color: var(--danger);
    border-color: #fecaca;
    text-decoration: none;
    cursor: pointer;
    font-weight: 600;
}
.chip-clear:hover { background: var(--danger-light); }

/* ── Results card ────────────────────────────────────────────────── */
.results-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    box-shadow: var(--shadow-sm);
    overflow: clip;
}
.results-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 14px 20px;
    border-bottom: 1px solid var(--border);
}
.results-header h2 { font-size: 1em; font-weight: 600; color: var(--text); }
.results-header .meta { font-size: .8125em; color: var(--text-muted); }
/* Info-affordance glyph next to a card title carrying extra detail in its
   title attribute -- cursor:help signals "hover for more" on pointer
   devices. Touch devices don't get a hover state at all; that's a known,
   accepted gap here, not something this glyph tries to solve. */
.info-hint { cursor: help; color: var(--text-subtle); font-size: .875em; }

/* Ham/Spam legend bar (Archívum) */
.legend {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 8px;
    padding: 10px 16px;
    background: var(--neutral-light);
    border-bottom: 1px solid var(--border);
}
.legend-label { font-size: .75em; font-weight: 500;
                letter-spacing: 0; color: var(--text-subtle); }
.legend-sep { font-size: .8125em; color: var(--text-muted); margin-right: 8px; }

/* Dashboard (Áttekintés) */
/* First row, four tracks: logo | 2-card Archívum stack (7-day / 30-day) |
   2-card rspamd/Bayes stack (scanned / trained) | single System card
   (disk/memory/swap/CPU as compact rows) -- not five same-size boxes in a
   row. align-items:stretch (explicit, not relied on as the default) makes
   the row height follow the tallest .dash-col stack, and stretches the
   logo card's box to match it; height: 100% on brand-card and dash-col
   makes both fill that stretched box fully rather than only their own
   content height. */
/* Per-range total above the bars. Lives INSIDE the range panel so it switches
   with the tab automatically and cannot drift from the chart it describes --
   it is summed from the same rows. Not a fourth .stat-card in the grid above:
   those use flex:1, so a third card in one column would shrink its two
   neighbours to 1/3 height while the other columns kept halves. */
.range-summary { padding: 2px 4px 10px; font-size: .875rem; color: var(--text-muted); }
.range-summary strong { color: var(--text); font-weight: 600; }
.range-summary .dot-spam { margin-left: 10px; margin-right: 4px; }
.dash-grid { display: grid; grid-template-columns: minmax(220px, 1.3fr) repeat(3, minmax(150px, 1fr)); gap: 14px; align-items: stretch; }
.dash-col { display: flex; flex-direction: column; gap: 14px; height: 100%; }
/* Without this, .dash-col's own box stretched to match the logo card (via
   align-items:stretch above) but its two stat-cards stayed their natural,
   shorter height inside it -- the wrapper grew, the two *visible* bordered
   boxes did not, so they still visibly didn't match the logo. flex:1
   makes the two cards themselves split the stretched height evenly. */
.dash-col .stat-card { flex: 1; }
/* Compact System-info rows inside the third .dash-col (disk/memory/swap/CPU as one
   thin bar + percentage per line, full detail in a title tooltip) -- shares the
   existing .stat-card container, no new column-level class. */
.sys-row { display: flex; align-items: center; gap: 8px; font-size: .75rem; }
.sys-row + .sys-row { margin-top: 8px; }
.sys-row-label { flex: 0 0 88px; color: var(--text-muted); font-weight: 500;
                  white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.sys-row-bar { flex: 1; background: var(--border); border-radius: 4px; height: 8px; overflow: hidden; }
.sys-row-bar > span { display: block; height: 100%; }
.sys-row-pct { flex: 0 0 34px; text-align: right; font-variant-numeric: tabular-nums;
                font-weight: 600; color: var(--text); }
/* Value cell for rows that carry TEXT rather than a progress bar (the ilexa
   version row). Not .sys-row-bar: that is an 8px-tall overflow-hidden track
   and crops text to an 8-pixel strip -- see the Várólista row's own note. */
.sys-row-val { flex: 1; font-size: .75rem; font-variant-numeric: tabular-nums;
               overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
/* The ilexa version row is also the control that replaced the old standalone
   update card: a real <button> so it is keyboard-focusable and announced as a
   control, reset to sit flush in the row grid. width:100% keeps the flex
   children on the same track as the non-clickable rows above it, so the
   label/value/marker columns still line up. */
.sys-row-btn { width: 100%; background: none; border: 0; padding: 2px 0; margin: 0;
               font: inherit; color: inherit; cursor: pointer; text-align: left;
               border-radius: 4px; }
.sys-row-btn:hover { background: var(--hover, rgba(127,127,127,.10)); }
.sys-row-btn:focus-visible { outline: 2px solid var(--primary); outline-offset: 1px; }
/* Wraps rather than ellipsising. This line now carries the FQDN (postfix
   myhostname) instead of the short kernel hostname, and measured in Chrome
   "mail.linuxforum.hu" needs 179.7px against a 112px box at .dash-grid's
   150px column floor -- it clipped to "mail.linuxforu..." at every column
   width below ~240px, leaving the name readable only on hover. An FQDN the
   operator cannot read defeats the point of showing it.
   `overflow-wrap: anywhere` is required, not just `white-space: normal`:
   browsers do not break at dots, so the FQDN is one unbreakable token
   (same finding as the IOC page's Hírnév column). */
.sys-host { font-size: 1em; font-weight: 600; color: var(--text); margin-bottom: 2px;
            white-space: normal; overflow-wrap: anywhere; }
.sys-meta { font-size: .8125em; color: var(--text-muted); margin-bottom: 8px; line-height: 1.4; }
/* Blokklista-források tiles: one auto-fill grid at every width, so tiles
   always sit in aligned columns and an incomplete last row starts at the left
   edge like every other list in the console. (Above 1260px this used to be a
   centred flex row tuned for 11 tiles; with 13 it left one tile alone in the
   middle of its own row.) The 150px floor keeps every label unclipped. */
.feed-grid {
    padding: 14px 20px;
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
    gap: 10px;
}
@media (max-width: 780px) {
    .dash-grid { grid-template-columns: 1fr; }
    .dash-col { flex-direction: row; }
}
.stat-card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius);
             box-shadow: var(--shadow-sm); padding: 16px 18px; }
.stat-label { font-size: .8125em; font-weight: 500; letter-spacing: 0; color: var(--text-subtle); }
.stat-value { font-size: 1.875em; font-weight: 600; color: var(--text); line-height: 1.1; margin: 6px 0 3px; }
.stat-sub { font-size: .8125em; color: var(--text-muted); display: flex; align-items: center; gap: 6px; }
.dot-spam { width: 9px; height: 9px; border-radius: 50%; background: var(--danger); display: inline-block; }
/* Remote-content warning in the viewer: an explicit privacy explanation, not
   just an icon, since loading images confirms the address is live. */
.remote-note {
    display: flex !important;
    flex-direction: column;
    gap: 6px;
    align-items: flex-start;
    max-width: 460px;
    padding: 10px 12px;
    background: var(--warning-light);
    border: 1px solid var(--warning);
    border-radius: var(--radius-sm);
}
.remote-note[style*="none"] { display: none !important; }
.rn-head { font-weight: 600; font-size: .8125rem; color: #92400e; }
.rn-why  { font-size: .75rem; color: #78350f; line-height: 1.45; }

/* Inline code. Was entirely unstyled, so it inherited the browser's smaller
   default monospace size -- most visible inside small text, where it rendered
   noticeably shrunken and off-baseline against its surroundings. */
code {
    font-family: ui-monospace, 'JetBrains Mono', 'Fira Code', 'Courier New', monospace;
    font-size: .9375em;
    background: var(--neutral-light);
    border: 1px solid var(--border);
    border-radius: 4px;
    padding: 1px 5px;
    color: var(--text);
    white-space: nowrap;
}

/* About page */
.about-hero { padding: 28px 30px; }
/* Same logo-lockup.png as the Áttekintés brand tile (wordmark + tagline
   are already baked into the image). Here the hero is wide, not a narrow
   tile, so the logo sits as a left-hand anchor with everything else --
   hostname, lead paragraph, credits -- in one column beside it, not
   stacked underneath. object-fit:contain guarantees the full image is
   always shown, never cropped, at any box size. */
.about-title { display: flex; align-items: center; gap: 28px; }
.about-mark { width: 100%; max-width: 190px; height: auto; flex: 0 0 auto; object-fit: contain; }
.about-title-text { display: flex; flex-direction: column; gap: 10px; min-width: 0; }
.about-sub { margin: 0; color: var(--text-muted); font-size: 1rem; font-weight: 600; }
.about-lead { margin: 0; color: var(--text-subtle); font-size: .875rem; max-width: 60ch; }
.about-credits {
    display: flex; flex-wrap: wrap; gap: 6px 22px; margin: 0;
    padding-top: 10px; border-top: 1px solid var(--border);
    font-size: .8125rem; color: var(--text-muted);
}
@media (max-width: 640px) {
    .about-title { flex-direction: column; align-items: flex-start; text-align: left; }
    .about-mark { max-width: 150px; }
}
.about-body { padding: 16px 24px 22px; font-size: .875rem; line-height: 1.7; color: var(--text-muted); }
.about-body p { margin: 12px 0 0; }
.about-flow {
    font-family: ui-monospace, 'JetBrains Mono', monospace; font-size: .75rem; line-height: 1.6;
    background: var(--neutral-light); border: 1px solid var(--border); border-radius: var(--radius-sm);
    padding: 14px 16px; overflow-x: auto; color: var(--text); margin: 0;
}
.about-dl { margin: 0; }
.about-dl dt { font-weight: 600; color: var(--text); margin-top: 14px; }
.about-dl dt:first-child { margin-top: 0; }
.about-dl dd { margin: 3px 0 0; }
.about-ul { margin: 0; padding-left: 18px; }
.about-ul li { margin-bottom: 10px; }
.about-body kbd {
    font-family: ui-monospace, monospace; font-size: .75em; font-weight: 600;
    background: var(--surface); border: 1px solid var(--border); border-bottom-width: 2px;
    border-radius: 4px; padding: 1px 6px; color: var(--text);
}

/* Keyboard-focused row + the shortcut cheatsheet */
tr.data-row.kb-focus > td { background: var(--primary-surface) !important; }
tr.data-row.kb-focus > td:first-child { box-shadow: inset 3px 0 0 var(--primary); }
.kb-help {
    display: flex; flex-wrap: wrap; gap: 6px 14px; align-items: center;
    margin: 0 0 12px; padding: 8px 12px;
    background: var(--neutral-light); border: 1px solid var(--border);
    border-radius: var(--radius-sm); font-size: .75rem; color: var(--text-muted);
}
.kb-help kbd {
    font-family: ui-monospace, monospace; font-size: .75rem; font-weight: 600;
    background: var(--surface); border: 1px solid var(--border);
    border-bottom-width: 2px; border-radius: 4px; padding: 1px 6px; color: var(--text);
}

/* Breach names link to their XposedOrNot detail page */
.breach-link { color: var(--primary); text-decoration: none; border-bottom: 1px dotted currentColor; }
.breach-link:hover { color: var(--primary-dark); border-bottom-style: solid; }
/* An UNLINKED finding (its only source has no per-incident page) must not wear
   link styling: rendered as a span it used to be the same blue with the same
   dotted underline, which reads as a clickable link that does nothing -- and
   was reported as exactly that, a dead link. Muted, and cursor:help says the
   tooltip is the interaction on offer. */
span.breach-link { color: inherit; border-bottom-color: var(--text-subtle); cursor: help; }
span.breach-link:hover { color: inherit; border-bottom-style: dotted; }
/* Expanding a breach row EXTENDS the list: the div holds only the remaining
   items, and the "+N tovabbi" marker disappears while open so the first four
   don't read as repeated. display:inline keeps the continuation on the same
   flowing line as the summary. */
details.breach-expand { display: inline; }
details.breach-expand[open] .breach-more { display: none; }
details.breach-expand[open] summary { display: inline; }
details.breach-expand > span { display: inline; }

/* Brand tile - first block of the dashboard's top row. The logo's white
   matte matches the card, so it needs no plate here (unlike the header).
   height:100% + the logo centered within it (justify-content:center) is
   what makes this card match the height of the two-stat-card stack next
   to it in .dash-grid, instead of only being as tall as the logo image. */
.brand-card { display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center; height: 100%; }
/* The mark alone is unreadable at tile size, so the tile carries the full
   lockup, which already states the product name and tagline. */
.brand-lockup { width: 100%; max-width: 260px; height: auto; object-fit: contain; }
.barchart-scroll { overflow-x: auto; }
.barchart { display: flex; align-items: flex-end; gap: 10px; padding: 16px 18px; height: 220px; }
/* flex-shrink:0 on a 28px basis keeps bars from being squeezed unreadable when
   the 30-day view has more columns than fit the card; barchart-scroll takes
   over instead. flex-grow:1 still spreads the (usual) 7-day view to full width. */
.bar-col { flex: 1 0 28px; display: flex; flex-direction: column; align-items: center; height: 100%; }
[data-range-panel="30"] .bar-col { flex: 1 1 16px; min-width: 16px; }
.bar-count { font-size: .75em; color: var(--text-muted); margin-bottom: 4px; }
.bar { flex: 1; width: 60%; max-width: 46px; min-width: 16px; display: flex; flex-direction: column-reverse;
       background: var(--neutral-light); border-radius: 4px 4px 0 0; overflow: hidden; }
/* One series leads: spam is what the chart is read for, so it keeps the
   danger colour and ham sits in a neutral step of the ramp. */
.bar-ham  { background: #cbd5e1; }
.bar-spam { background: var(--danger); }
.bar-lbl { font-size: .75em; color: var(--text-subtle); margin-top: 6px; white-space: nowrap; }

.range-toggle { display: inline-flex; border: 1px solid var(--border); border-radius: var(--radius-sm); overflow: hidden; }
.range-btn {
    padding: 3px 10px;
    font-size: .75em;
    font-weight: 600;
    font-family: inherit;
    border: none;
    background: var(--surface);
    color: var(--text-muted);
    cursor: pointer;
}
.range-btn + .range-btn { border-left: 1px solid var(--border); }
.range-btn.active { background: var(--primary); color: #fff; }
.hidden { display: none !important; }

/* Loading overlay */
.loading-overlay { position: fixed; inset: 0; background: rgba(15,23,42,.35); z-index: 200;
    display: none; align-items: center; justify-content: center; }
.loading-overlay.show { display: flex; }
#lookup-toast {
    position: fixed; right: 20px; bottom: 20px; max-width: 360px;
    background: var(--text); color: #fff; padding: 10px 16px; border-radius: var(--radius-sm);
    font-size: .875em; box-shadow: 0 4px 16px rgba(0,0,0,.25); z-index: 300;
    opacity: 0; transform: translateY(8px); transition: opacity .2s ease, transform .2s ease;
    pointer-events: none;
}
#lookup-toast.show { opacity: 1; transform: translateY(0); }
.spinner { width: 44px; height: 44px; border: 4px solid rgba(255,255,255,.45); border-top-color: #fff;
    border-radius: 50%; animation: spin .8s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }
/* Kept although nothing currently animates with it: the update row that
   replaced views/partials/update_card.php shows its running state as a
   static marker. Two rules' worth of dead CSS is cheaper than deleting a
   keyframe a future in-progress indicator would just re-add. */
@keyframes qa-pulse { 0%, 100% { opacity: 1; } 50% { opacity: .35; } }

/* Archívum "IOC ellenőrzés" popup -- this generic modal-chrome block
   (.arc-ioc-overlay/-modal/-modal-head/-modal-body/-modal-foot/-modal-close)
   is also reused as-is by the Admin > Adatvédelem GDPR notice popup
   (views/layout_foot.php's #qaGdprOverlay); only .arc-ioc-cand-* below is
   specific to the Archívum feature. */
.arc-ioc-overlay { position: fixed; inset: 0; background: rgba(15,23,42,.45); z-index: 220;
    display: none; align-items: center; justify-content: center; padding: 20px; }
.arc-ioc-overlay.show { display: flex; }
.arc-ioc-modal { background: var(--surface); border-radius: var(--radius); box-shadow: var(--shadow);
    max-width: 640px; width: 100%; max-height: 85vh; display: flex; flex-direction: column; }
.arc-ioc-modal-head { display: flex; align-items: center; justify-content: space-between;
    padding: 14px 18px; border-bottom: 1px solid var(--border); flex: 0 0 auto; }
.arc-ioc-modal-head h3 { margin: 0; font-size: 1em; }
.arc-ioc-modal-close { background: none; border: none; cursor: pointer; color: var(--text-subtle);
    padding: 4px; line-height: 0; }
.arc-ioc-modal-close:hover { color: var(--text); }
.arc-ioc-modal-close .icon { width: 1.2em; height: 1.2em; }
.arc-ioc-modal-body { padding: 16px 18px; overflow-y: auto; }
.arc-ioc-modal-foot { display: flex; justify-content: flex-end; gap: 8px;
    padding: 12px 18px; border-top: 1px solid var(--border); flex: 0 0 auto; }
.arc-ioc-cand { padding: 10px 0; border-bottom: 1px solid var(--border); }
.arc-ioc-cand:last-child { border-bottom: none; }
.arc-ioc-cand-head { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; margin-bottom: 6px; }
.arc-ioc-cand-pick { display: inline-flex; align-items: center; }
.arc-ioc-cand-type { font-size: .75rem; letter-spacing: 0;
    color: var(--text-subtle); font-weight: 500; }
.arc-ioc-cand-value { font-family: monospace; word-break: break-all; font-size: .875em; }
.arc-ioc-loading { display: flex; flex-direction: column; align-items: center; gap: 12px; padding: 30px 0; }
.arc-ioc-loading .spinner { border-color: rgba(15,23,42,.15); border-top-color: var(--primary); }

.bulk-bar {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px 16px;
    background: var(--primary-surface);
    border-bottom: 1px solid var(--primary-light);
}
.bulk-bar label { font-size: .8125em; color: var(--text-muted); font-weight: 500; }

/* ── Tables ──────────────────────────────────────────────────────── */
table { width: 100%; border-collapse: collapse; }
thead th {
    background: var(--neutral-light);
    color: var(--text-muted);
    padding: 10px 14px;
    text-align: left;
    font-size: .8125em;
    font-weight: 500;
    white-space: nowrap;
    letter-spacing: 0;
    border-bottom: 2px solid var(--border);
    position: sticky;
    top: 0;
    z-index: 5;
}
/* Only where the first column is a control (checkbox / open-row arrow): on
   tables whose first column is data (Minta, Domain) this centred a header
   over left-aligned values. */
table.ctl-first thead th:first-child { width: 36px; text-align: center; }
.sort-th { color: inherit; text-decoration: none; display: inline-flex; align-items: center; gap: 2px;
           cursor: pointer; white-space: nowrap; }
.sort-th:hover, .sort-th.active { color: var(--primary); }
tbody tr.data-row { background: var(--surface); transition: background var(--t); }
tbody tr.data-row.alt { background: var(--neutral-light); }
tbody tr.data-row:hover,
tbody tr.data-row.alt:hover { background: var(--primary-surface); }

tr.data-row td:first-child { border-left: 4px solid transparent; }
tr.data-row.f-Spam       td:first-child { border-left-color: #e11d48; }
tr.data-row.f-Junk       td:first-child { border-left-color: var(--warning); }
tr.data-row.f-Quarantine td:first-child { border-left-color: var(--danger); }
tr.data-row.f-spam       td:first-child { border-left-color: var(--danger);  border-left-width: 5px; }
tr.data-row.f-ham        td:first-child { border-left-color: var(--success); border-left-width: 5px; }

/* Spam/ham rows (Archívum) carry their verdict in the left stripe above, the
   HAM/SPAM badge and, once taught, the star -- not in a full-row fill. The
   old saturated --danger/--success-light (and -medium for learned rows)
   fills made the page a red/green wall that colour-blind readers could not
   use, and dropped the orange subject link to 2.6-3.2:1. These near-white
   tints keep it at 4.6:1 or better. */
tr.data-row.f-spam, tr.data-row.f-spam.alt { background: #fff7f7; }
tr.data-row.f-ham,  tr.data-row.f-ham.alt  { background: var(--success-surface); }
tr.data-row.f-spam:hover, tr.data-row.f-spam.alt:hover,
tr.data-row.f-ham:hover,  tr.data-row.f-ham.alt:hover { background: var(--primary-surface); }
/* A learned row: the stripe doubles in width, so "already acted on" still
   reads at a glance without the darker fill. */
tr.data-row.f-spam.learned td:first-child,
tr.data-row.f-ham.learned  td:first-child { border-left-width: 9px; }
td {
    padding: 12px 14px;
    border-bottom: 1px solid var(--border);
    vertical-align: middle;
    font-size: .9375em;
    line-height: 1.5;
}
td:first-child { text-align: center; }
/* Archívum: denser rows so more messages fit on screen without scrolling. */
.archive-table td { padding: 7px 10px; }
.archive-table thead th { padding: 9px 10px; letter-spacing: .02em; }
/* The "(click to view)" hint under Tárgy wraps on its own line: as nowrap
   header text it set the Subject column's minimum width. */
table.ctl-first thead th small { display: block; white-space: normal; text-transform: none; letter-spacing: 0; }
/* IOC page: denser rows so more indicators fit on screen without scrolling. */
.ioc-table td { padding: 8px 8px; }
/* Blokklista / Fehérlista and Rendszer status tables (+ the dashboard's
   Blokkolt levelek and Adatvédelmi incidensek cards): same dense-row family
   as the IOC table, but at 7 columns .list-table does not need that table's
   12-column horizontal squeeze, and neither class inherits the IOC-specific
   th rule below. Rendszer/dashboard deliberately use .sys-table rather than
   .list-table -- that class also carries the Minta-column
   `code { white-space: normal }' fix below, which has no meaning outside
   Blokklista/Fehérlista. */
.list-table td, .sys-table td { padding: 8px 14px; }
/* Pattern column: the global `code { white-space: nowrap }' rule above
   (~line 496) silently defeats the pattern cell's own inline
   overflow-wrap:anywhere -- nowrap suppresses ALL line breaks regardless of
   overflow-wrap, so long unbroken patterns (e.g. message-id-style local
   parts) overflowed the cell instead of wrapping. Scoped here rather than
   changed globally so every other `code' use on the site keeps its
   single-line look. If that global rule is ever removed or changed, revisit
   whether this override is still needed. */
.list-table code { white-space: normal; }
/* Blokklista / Fehérlista: the new "Összesített %" header (13 chars,
   uppercased by the shared thead th rule with letter-spacing) needs
   ~93.9px and only had a 62-81px content box -- broke mid-word in hu at
   every width and in es at 1280/1400 (the overflow-wrap:anywhere inline
   style on that one th converts "doesn't fit" into "breaks mid-word"
   instead of overflowing, which is why no automated overflow check ever
   caught it). Unlike .ioc-table thead th above, this is NOT the 12-column
   horizontal squeeze -- it is only the typography (uppercase +
   letter-spacing + 14px padding) that doesn't fit, so pull in just that,
   not the .ioc-table rule itself. Also brings this table's header
   case in line with .ioc-table's (was the last uppercase/uncompacted
   holdout), which increases parity rather than reducing it.
   .quar-table (Jelentett spam, Task 6 of the reputation-lookup work) shares
   this rule for the exact same reason -- it grew the same "Összesített %"
   header onto a table that was never given the auto-layout squeeze the IOC
   table has, so only the typography needs pulling in, not a colgroup. */
.list-table thead th, .quar-table thead th, .sys-table thead th { padding: 6px 8px; font-size: .75em; letter-spacing: 0; text-transform: none; }
/* Deliberately NOT adding `.list-table th, .list-table td { overflow-wrap:
   anywhere }` here. It was tried, to contain small Típus/Hozzáadta overflow
   in the 720-1280px band, and it backfired: overflow-wrap fires on
   CONTENT-box overflow, so it also triggers on tokens that overflow by less
   than the 14px cell padding -- previously invisible (the padding gutter
   absorbed them), visibly split mid-word with the rule on. Measured: new
   mid-word breaks on "Domain"/"Dirección"/"mailscanner-import" at 1152px in
   all three languages and at 1280px in Spanish, where the rendering had been
   clean. It was a real win only at 1024px. Net worse, so reverted.
   Note for anyone re-attempting this: `scrollWidth > clientWidth` does NOT
   detect the original overflow on a `table-layout:fixed` td -- a token can
   bleed 16px past the border box with scrollWidth == clientWidth. Measure
   with Range.getBoundingClientRect() against the cell box instead. */
/* IOC table: 12 columns means the shared thead th style (14px horizontal
   padding, uppercase, letter-spacing) is itself the widest thing in several
   narrow columns -- e.g. "MEGBÍZHATÓSÁG" alone needs ~147px unmodified vs.
   ~122px compacted (measured floor: 112px broke mid-word, 122px didn't --
   see docs/superpowers/notes/2026-08-13-ioc-table-fit-fix.md for the German
   "Vertrauenswürdigkeit" case, which needs ~142px even compacted). Scoped to
   .ioc-table only, other tables' headers (Archívum, Block/Whitelist) keep
   the shared style untouched. */
.ioc-table thead th {
    padding: 6px 8px;
    font-size: .75em;
    letter-spacing: 0;
    text-transform: none;
}
/* Hyphenate ONLY the long single-word headers ("Megbízhatóság",
   "Összesített %"), which otherwise break at an arbitrary character
   ("Megbízha|tóság"); <html lang> is always set so the browser breaks at real
   syllable boundaries instead. Deliberately NOT on `.ioc-table thead th`
   generally: applied there it also hyphenates the SERVICE headers, and giving
   "VirusTotal" extra break points pushed it from 2 lines to "Vi-|rus-|Total"
   -- a 3-line header, the one case this table's column budget forbids
   (docs/superpowers/notes/2026-08-13-ioc-table-fit-fix.md). Verified in
   Chromium both ways. Cosmetic only; overflow-wrap remains the no-overflow
   guarantee. */
.ioc-th-hyphen { hyphens: auto; }
/* Megbízhatóság as an icon (QA_IOC_CONFIDENCE_ICON): one shield at three
   strengths, so the level reads as an intensity rather than three glyphs the
   operator has to learn. Colour is the ONLY difference, which is why the
   tooltip + .sr-only label + the legend under the table all carry the word --
   colour alone must never be the sole carrier of meaning. */
.ioc-conf .icon { width: 17px; height: 17px; vertical-align: middle; }
/* Típus / Forrás icon cells (QA_IOC_TYPE_ICON, QA_IOC_SOURCE_ICON). Muted
   rather than coloured: these are neutral facts about the row (what kind of
   indicator, where it came from), not a severity, and colouring them would
   compete with the Megbízhatóság and per-service verdict columns that DO
   carry meaning in colour. */
.ioc-gi .icon { width: 17px; height: 17px; vertical-align: middle; color: var(--text-muted); }
.ioc-conf-high   { color: var(--danger); }
.ioc-conf-medium { color: var(--warning); }
.ioc-conf-low    { color: var(--text-subtle); opacity: .75; }
/* Every control in the IOC Művelet column the same width, so the stacked
   Ellenőrzés / Élesítés / Élesítve / Visszavonás / Lejáratás controls form one
   tidy block instead of a ragged edge. width:100% (not a fixed px) keeps them
   matched at any column width and in any language -- the column is already
   sized by the colgroup. box-sizing so the border does not push them past it.
   The .verdict badge is included because "Élesítve" sits in the same stack and
   would otherwise be the one odd-width element. */
.ioc-table td form { margin: 0; }
.ioc-table td .btn,
.ioc-table td .verdict {
    display: flex; width: 100%; box-sizing: border-box;
    align-items: center; justify-content: center; gap: 4px;
}
/* Visible only to screen readers: keeps the icon-only cells announced. */
.sr-only {
    position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px;
    overflow: hidden; clip: rect(0, 0, 0, 0); white-space: nowrap; border: 0;
}
/* max-width + overflow-wrap: a long email address has no spaces to wrap
   at, so without both of these one long From/To address forces the whole
   table wider than its container -- table-layout:auto happily grows a
   column to fit an unbreakable string if there's room, and overflow-wrap
   alone only helps once a column can't grow any further. This is what was
   actually pushing the Archívum table past its card and clipping the last
   column, not the action buttons (already fixed separately). */
.col-user    { min-width: 175px; max-width: 220px; font-size: .875em; color: var(--text-muted); overflow-wrap: anywhere; }
.col-folder  { width: 90px; }
.col-from    { min-width: 180px; }
.col-subject { font-weight: 600; color: var(--text); }
.col-date    { width: 148px; font-size: .875em; color: var(--text-muted); white-space: nowrap; }
/* Country flag cell: narrow and centred, and never a wrap/stretch target --
   one small image, so the column should cost as little width as possible
   next to Subject, which wants all it can get. */
.col-cc      { width: 46px; text-align: center; white-space: nowrap; line-height: 1; }
/* The 20x15 render is half the 40x30 source, so it stays sharp on HiDPI.
   The hairline border keeps predominantly-white flags (JP, PL, FI) from
   dissolving into a light row background. */
.cc-flag     { width: 20px; height: 15px; vertical-align: middle; border-radius: 2px;
               box-shadow: 0 0 0 1px rgba(0,0,0,.18); object-fit: cover; }
.col-actions { width: 150px; white-space: nowrap; }
/* Jelentett spam (Task 6): the two reputation-lookup cells. Auto layout, like
   every other column on this table (deliberately NOT table-layout:fixed --
   see the .quar-table comment on the thead th rule above), so this is only a
   TD sizing hint (the %/value is always short and never wraps) -- it is
   deliberately NOT put on the <th> too. thead th is nowrap by default
   (:640), and "Összesített %" under nowrap doesn't break, it just forces the
   column (and so the whole table) wider -- measured via real Chromium: up to
   +260px table width and a squeezed col-from/col-subject at 768/1024px,
   the exact regression this task's Layout section warned about. The view
   gives that one <th> the same inline white-space:normal;overflow-wrap:
   anywhere override views/lists.php:112 and views/ioc.php already use for
   this identical header, instead of a shared class rule here. No min-width
   on col-quar-rep either, for the same reason: reserving space for the
   *populated* (post-lookup) state on every render, including rows nobody
   has checked yet, was the other half of that same width regression --
   auto-layout already sizes the column from whatever's actually in it.
   min-width, not width: under auto layout a wrap-capable header has almost
   no min-content, so a plain `width` is only a hint the table-layout
   algorithm freely overrides (measured: it still shrank to ~52px and
   3-line-wrapped) -- min-width is treated as a hard floor instead. 110px
   matches .list-table's own colgroup allowance for this exact header
   (:711-722's comment) so it wraps to 2 clean lines, not 3 ugly ones. */
/* 130px is not a guess: measured in a real browser, the longest unbreakable
   word in this header ("Összesített") is 102px in the header's own font, plus
   28px of cell padding. Below that the th carries overflow-wrap:anywhere, so
   it does not wrap at the space -- it splits the WORD, rendering
   "ÖSSZESÍTE / TT %". The previous 110px was already under that threshold;
   narrowing it further to give the Hírnév column room simply made the break
   visible. Widening slightly is the honest fix, and the Hírnév column gets its
   room from its own min-width instead. */
.col-quar-conf { min-width: 130px; }

/* ── Hírnév cell: one row per indicator, then the button ──────────────────
   Reads top-to-bottom as "D <verdicts>" / "IP <verdicts>" / [Ellenőrzés]
   instead of one long line that had to wrap arbitrarily. Stacking makes the
   column's intrinsic width SMALLER (measured 257px -> 184px at 1440), so the
   min-width below is what actually widens it -- and it is safe here in a way
   it was not for the old flat layout, because the stacked content no longer
   grows sideways with the number of verdicts. */
td.col-quar-rep .quar-rep-badges {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    gap: 4px;
}
/* Label on its own row, its verdict icons on the next. Putting the label
   inline with the icons meant the icons had only the leftover width and wrapped
   raggedly under it; giving each a full row keeps the icons on one line in a
   narrow column and makes the D/IP grouping obvious at a glance. */
.quar-rep-label {
    font-size: .6875rem;
    font-weight: 500;
    letter-spacing: 0;
    color: var(--text-subtle);
    line-height: 1.2;
}
.quar-rep-syms {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 3px;
    margin-bottom: 2px;
}
/* The button gets its own row, left-aligned with the labels and icons above
   it -- the whole cell reads as one left edge. */
.quar-rep-act { align-self: flex-start; margin-top: 2px; }
/* 193px, measured: five 30px verdict icons plus four 3px gaps plus the cell's
   28px padding. Five is reachable in practice -- virustotal, urlhaus, otx, hrbl
   and url.vet can all answer for a domain -- and below this the fifth icon
   wrapped onto a second line, which is exactly the ragged look the row-per-
   indicator layout exists to avoid. */
.col-quar-rep { min-width: 193px; }
/* Short indicator tag (D / IP) grouping the icons that follow it in the
   Hírnév cell -- same pill language as .folder-tag, just smaller, since this
   is a label for a group of badges rather than a value on its own. */
.quar-tag {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 1.4em;
    padding: 1px 5px;
    margin-right: 3px;
    border-radius: 999px;
    background: var(--neutral-light);
    color: var(--neutral);
    font-size: .75em;
    font-weight: 500;
    letter-spacing: 0;
}
.quar-tag:not(:first-child) { margin-left: 6px; }

.subject-link {
    cursor: pointer;
    color: var(--primary);
    user-select: none;
    overflow-wrap: anywhere;
}
.subject-link:hover { text-decoration: underline; }
.subject-arrow, .arrow {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 1.6em;
    height: 1.6em;
    font-size: 1.125em;
    margin-right: 5px;
    border-radius: 50%;
    transition: transform 0.18s, color var(--t), background var(--t);
    color: var(--primary-dark);
    cursor: pointer;
}
.subject-arrow:hover, .arrow:hover { color: var(--primary-dark); background: var(--primary-surface); }
.subject-arrow.open, .arrow.open { transform: rotate(90deg); color: var(--primary-dark); }

/* ── Inline detail row ───────────────────────────────────────────── */
.detail-row > td {
    padding: 0;
    border-bottom: 2px solid var(--primary);
    border-top: none;
}
.detail-inner {
    padding: 12px 16px 12px;
    background: var(--primary-surface);
    border-left: 4px solid var(--primary);
    animation: slideDown 0.18s ease;
}
@keyframes slideDown {
    from { opacity: 0; max-height: 0; }
    to   { opacity: 1; max-height: 9999px; }
}
.detail-meta {
    margin-bottom: 14px;
    padding-bottom: 12px;
    border-bottom: 1px solid var(--primary-light);
}
.meta-tbl { width: 100%; border-collapse: collapse; }
.meta-tbl th {
    width: 72px;
    padding: 4px 10px 4px 0;
    font-size: .8125em;
    color: var(--text-muted);
    text-align: left;
    vertical-align: top;
    white-space: nowrap;
    font-weight: 500;
    letter-spacing: 0;
}
.meta-tbl td { padding: 4px 0; font-size: .9375em; word-break: break-word; }
/* The expanded detail row is a table cell, and `td:first-child` centres first
   cells for the checkbox column -- which the text and source views inherited.
   Message content is always read left-aligned. */
tr.detail-row > td { text-align: left; }
.detail-body {
    text-align: left;
    white-space: pre-wrap;
    word-break: break-word;
    font-family: ui-monospace, 'JetBrains Mono', 'Fira Code', 'Courier New', monospace;
    font-size: .875em;
    line-height: 1.65;
    max-height: 380px;
    overflow-y: auto;
    background: var(--surface);
    padding: 14px 16px;
    border: 1px solid var(--primary-light);
    border-radius: 6px;
    margin: 0 0 8px;
    color: var(--text);
}
/* Raw source. white-space:pre + overflow-x:auto was the previous form, but
   this <pre> lives inside a colspan cell of the AUTO-layout .archive-table:
   an auto table sizes cells by intrinsic content width, so overflow never
   engaged -- a long source line (a 148-char DKIM fold is enough) inflated
   the cell, the whole table grew past the card and the page layout broke,
   and STAYED broken after closing the row. Reported live from the Archive
   source view. Wrapping is the containment that works inside auto tables
   (same lesson as the Hírnév column: overflow-wrap:anywhere, not scroll);
   RFC 5322 folding keeps wrapped headers readable, and base64 was never
   line-by-line meaningful anyway. */
.detail-source {
    white-space: pre-wrap;
    overflow-wrap: anywhere;
    word-break: normal;
    max-height: 460px;
    overflow-y: auto;
    font-size: .8125em;
    line-height: 1.5;
}
.detail-actions {
    display: flex;
    gap: 8px;
    margin-top: 12px;
    justify-content: flex-end;
    align-items: center;
}
.detail-close-link {
    font-size: .8125em;
    color: var(--text-muted);
    cursor: pointer;
    margin-right: auto;
    text-decoration: underline;
}
.detail-close-link:hover { color: var(--text); }
.detail-loading { text-align: center; padding: 36px; color: var(--text-muted); font-size: .875em; }
.detail-error   { color: var(--danger); padding: 12px 0; font-size: .875em; }
.truncated-note { font-size: .75em; color: var(--text-muted); margin-top: 6px; font-style: italic; }

.why { border-radius: 6px; padding: 10px 12px; margin-bottom: 12px; border: 1px solid; font-size: .875em; }
.why-spam { background: #fef5f5; border-color: #fca5a5; }
.why-ham  { background: #f5fbf7; border-color: #86efac; }
.why-head { color: var(--text); }
.why-syms { margin-top: 8px; display: flex; flex-wrap: wrap; gap: 5px; }
.why .sym { font-family: ui-monospace, monospace; font-size: .9375em; background: rgba(0,0,0,.05);
            border: 1px solid rgba(0,0,0,.08); border-radius: 4px; padding: 1px 6px; color: var(--neutral); }

.sender-actions { display: flex; flex-wrap: wrap; align-items: center; gap: 8px; margin-top: 12px;
                  padding-top: 10px; border-top: 1px dashed var(--border); }
.sa-label { font-size: .8125em; font-weight: 600; color: var(--text-subtle); }

.detail-toolbar {
    display: flex;
    align-items: center;
    gap: 12px;
    flex-wrap: wrap;
    margin-bottom: 10px;
}
.view-toggle {
    display: inline-flex;
    border: 1px solid var(--border);
    border-radius: var(--radius-sm);
    overflow: hidden;
    background: var(--surface);
}
.vt-btn {
    padding: 5px 13px;
    border: none;
    background: var(--surface);
    color: var(--text-muted);
    font-family: inherit;
    font-size: .8125em;
    font-weight: 600;
    cursor: pointer;
    transition: background var(--t), color var(--t);
}
.vt-btn + .vt-btn { border-left: 1px solid var(--border); }
.vt-btn:hover { background: var(--neutral-light); }
.vt-btn.active { background: var(--primary); color: #fff; }
.remote-note {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    font-size: .8125em;
    color: var(--warning);
    font-weight: 600;
}
.detail-html {
    width: 100%;
    height: 420px;
    border: 1px solid var(--primary-light);
    border-radius: 6px;
    background: #fff;
    display: block;
}

/* Folder / status pills */
.folder-tag {
    display: inline-flex;
    align-items: center;
    padding: 2px 9px;
    border-radius: 999px;
    font-size: .8125em;
    font-weight: 500;
    letter-spacing: 0;
}
.folder-Junk       { background: var(--warning-light); color: var(--warning); }
.folder-Quarantine { background: var(--danger-light);  color: var(--danger-dark); }
.folder-Spam       { background: #ffe4e6;              color: #9f1239; }
/* Mail-auth-failure source badges (Audit > Bejelentkezések) -- protocol,
   not severity, so a neutral palette rather than the warning/danger tones
   above. */
.folder-IMAP       { background: var(--neutral-light); color: var(--neutral); }
.folder-POP3       { background: var(--neutral-light); color: var(--neutral); }
.folder-WEBMAIL    { background: var(--primary-light); color: var(--primary-dark); }

.from-name  { font-weight: 600; color: var(--text); font-size: .9375em; }
.from-email { font-size: .8125em; color: var(--text-muted); margin-top: 1px; }

.empty-state { text-align: center; padding: 56px 20px; color: var(--text-muted); }
.empty-state p { margin-top: 10px; font-size: .875em; }

.action-btns { display: flex; gap: 5px; flex-wrap: wrap; }
/* Archívum: two equal-width columns (Ham/Spam, then Tiltás/Enged.), with
   Újraküld as its own full-width row last -- explicit grid placement
   rather than relying on flex-wrap's natural flow, so the pairing is
   guaranteed regardless of container width. minmax(0,1fr) lets a column
   shrink below its content's natural width instead of forcing the row
   (and the table) wider than the card. Scoped to Archívum only --
   quarantine.php's action-btns (2 longer Hungarian labels in a narrower
   column) keeps the plain flex behavior above. */
.archive-table .action-btns {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 6px;
}
.archive-table .action-btns .btn { justify-content: center; }
.archive-table .action-btns .action-btn-wide { grid-column: 1 / -1; }

/* Pagination */
.results-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    padding: 13px 20px;
    border-top: 1px solid var(--border);
    background: var(--neutral-light);
}
.pager { display: flex; align-items: center; gap: 10px; }
.pager-info { font-size: .8125em; color: var(--text-muted); }
.pager-disabled { background: var(--neutral-light); color: var(--text-subtle); border-color: var(--border); cursor: default; box-shadow: none; }
/* A control that is present but not currently permitted. Shown rather than
   hidden so the option is discoverable and its precondition can be stated in
   the tooltip -- a button that simply is not there teaches nobody why. */
.btn:disabled, .btn[disabled] {
    background: var(--neutral-light); color: var(--text-subtle);
    border-color: var(--border); cursor: not-allowed; box-shadow: none; opacity: .75;
}
.btn:disabled:hover, .btn[disabled]:hover { background: var(--neutral-light); box-shadow: none; }
input:disabled { background: var(--neutral-light); color: var(--text-subtle); cursor: not-allowed; }

input[type=checkbox] { width: 15px; height: 15px; cursor: pointer; accent-color: var(--primary); }

/* ── Usability pass (2026-10-14) ─────────────────────────────────── */
/* `hidden` must win over any class that sets display (details.sys-sec, the
   settings tabs and the shortcut strip all toggle it). */
[hidden] { display: none !important; }
/* Keyboard focus is always visible, on every focusable thing -- most controls
   here had no focus style of their own. :where() keeps the specificity at
   zero, so the few components with their own ring keep it. */
:where(a, button, summary, input, select, textarea, [tabindex]):focus-visible {
    outline: 2px solid var(--border-focus);
    outline-offset: 2px;
}
.skip-link {
    position: absolute; left: 8px; top: -60px; z-index: 400;
    background: var(--surface); color: var(--primary-dark); font-weight: 600;
    padding: 8px 14px; border-radius: var(--radius-sm); box-shadow: var(--shadow);
}
.skip-link:focus { top: 8px; }
.notice-info { background: var(--neutral-light); color: var(--text); border-color: var(--border); }

/* Jelentett spam: quick-range row and the shortcut strip sit inside the
   results card, so they need the card's own side padding. */
.quick-range { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; padding: 14px 20px 0; margin: 0 0 12px; }
.quick-range-label { font-size: .8125rem; color: var(--text-subtle); font-weight: 500; letter-spacing: 0; }
.quick-range-counts { margin-left: auto; display: flex; gap: 10px; font-size: .8125rem; color: var(--text-muted); }
.results-card > .kb-help { margin: 12px 20px; }
.kb-keys { display: inline-flex; flex-wrap: wrap; gap: 6px 14px; align-items: center; }
.kb-off-note { font-style: italic; }
.kb-toggle { margin-left: auto; }
.bulk-count { font-size: .8125em; color: var(--text-muted); font-weight: 600; }

/* Open-row arrows and the detail "Bezár" are real buttons now (keyboard). */
button.subject-arrow, button.arrow { border: 0; background: transparent; padding: 0; font: inherit; }
button.detail-close-link { border: 0; background: transparent; padding: 0; font-family: inherit; }

/* Reported spam: three labelled row actions, stacked. */
td.col-actions:not(.col-arc-actions) .action-btns { flex-direction: column; align-items: stretch; }
td.col-actions:not(.col-arc-actions) .action-btns .btn { justify-content: flex-start; }
.ctl-first .col-actions:not(.col-arc-actions) { width: 120px; }
/* The aggregate % heads the Hírnév cell (it used to be its own column). */
.quar-rep-conf, .ioc-rep-conf { font-size: .8125rem; font-weight: 600; margin-bottom: 2px; }
.quar-rep-conf:empty, .ioc-rep-conf:empty { display: none; }

/* Archívum row actions: Ham/Spam inline, the rest in a "Továbbiak" menu. */
.col-arc-actions { width: 150px; white-space: normal; }
.archive-table .action-btns .row-more { grid-column: 1 / -1; }
.archive-table .action-btns .row-more > summary { width: 100%; justify-content: center; }
/* The two list tables (Jelentett spam, Archívum) at laptop widths: the
   date wraps at its space onto two lines, and the address columns give way
   to Subject -- at 1200px these minimums used to add up to more than the
   card, clipping Pontszám and Műveletek off its edge. */
.ctl-first .col-date { width: 112px; min-width: 112px; white-space: normal; }   /* "YYYY-MM-DD" must fit, or it breaks at a hyphen */
.ctl-first .col-user { min-width: 150px; max-width: 190px; }
.archive-table.ctl-first .col-user { min-width: 120px; max-width: 170px; }   /* two address columns here */
.ctl-first .col-from { min-width: 150px; max-width: 200px; overflow-wrap: anywhere; }
.ctl-first .col-quar-rep { min-width: 150px; }
.table-scroll { overflow-x: auto; }
.campaign-actions { display: flex; flex-wrap: wrap; gap: 4px; align-items: center; }
td.campaign-actions { display: table-cell; }
.campaign-actions form { display: inline-block; margin: 0 4px 4px 0; }
.col-score { color: var(--text-muted); font-variant-numeric: tabular-nums; }
.btn-danger-outline { background: var(--surface); color: var(--danger-dark); border-color: var(--danger-medium); }
.btn-danger-outline:hover { background: var(--danger-surface); border-color: var(--danger); box-shadow: var(--shadow-sm); }
.row-more { position: relative; display: inline-block; }
.row-more > summary { list-style: none; }
.row-more > summary::-webkit-details-marker { display: none; }
.row-more-menu {
    position: absolute; right: 0; top: calc(100% + 4px); z-index: 30;
    min-width: 200px; display: flex; flex-direction: column; gap: 4px; padding: 6px;
    background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius-sm);
    box-shadow: 0 6px 18px rgb(15 23 42 / .14);
}
.row-more-menu .btn { justify-content: flex-start; width: 100%; }

/* Message viewer: attachment list -- metadata only, never a link. */
.att-strip { margin: 0 0 12px; padding: 10px 12px; border: 1px solid var(--border); border-radius: var(--radius-sm); background: var(--neutral-light); font-size: .8125rem; }
.att-head { margin-bottom: 6px; color: var(--text); }
.att-note { color: var(--text-muted); font-size: .875em; }
.att-list { list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 4px; }
.att-item { display: flex; flex-wrap: wrap; align-items: center; gap: 4px 10px; padding: 5px 8px; background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius-sm); }
.att-item.att-danger { border-color: var(--danger); background: var(--danger-surface); }
.att-name { font-weight: 600; overflow-wrap: anywhere; }
.att-meta { color: var(--text-muted); font-size: .9375em; }
.att-flag { display: inline-flex; align-items: center; gap: 4px; padding: 1px 8px; border-radius: 999px; font-size: .8125em; font-weight: 600; background: var(--warning-light); color: var(--warning); }
.att-flag-danger { background: var(--danger-light); color: var(--danger-dark); }
.att-hash { margin-left: auto; font-size: .75em; }

/* The result toast: results fade, errors stay (red) until dismissed. */
#lookup-toast { display: flex; align-items: flex-start; gap: 10px; }
#lookup-toast.show { pointer-events: auto; }
#lookup-toast.toast-err { background: var(--danger-dark); }
#lookup-toast .toast-msg:empty { display: none; }
#lookup-toast .toast-close { margin-left: auto; padding: 2px; border: 0; background: transparent; color: inherit; cursor: pointer; opacity: .85; }
#lookup-toast .toast-close:hover { opacity: 1; }

/* Dialog form fields (Archívum resend). */
.field-label { display: block; font-size: .8125rem; font-weight: 600; margin: 10px 0 4px; }
.field-input { width: 100%; box-sizing: border-box; padding: 8px 10px; font: inherit; border: 1px solid var(--border); border-radius: var(--radius-sm); }
.field-error { color: var(--danger-dark); font-size: .8125rem; margin: 6px 0 0; min-height: 1em; }

/* IOC table: type in words, one Hírnév cell of labelled chips, an Állapot column. */
.ioc-type-cell { white-space: nowrap; }
.ioc-type-cell .ioc-gi { width: 15px; height: 15px; vertical-align: -3px; color: var(--text-muted); margin-right: 3px; }
.ioc-type-word { font-size: .875em; }
.ioc-value { font-family: ui-monospace, 'JetBrains Mono', monospace; font-size: .875em; word-break: break-all; }
.ioc-rep-chips { display: flex; flex-wrap: wrap; gap: 3px; }
.ioc-table td .ioc-rep-chips .verdict { display: inline-flex; width: auto; justify-content: flex-start; padding: 1px 6px; font-size: .75rem; }
.ioc-rep-none { color: var(--text-subtle); font-size: .8125em; }
.ioc-state { display: inline-flex; align-items: center; gap: 4px; font-size: .8125em; color: var(--text-muted); }
.ioc-state-armed { color: var(--danger-dark); font-weight: 600; }

/* Settings page: group tabs + search. */
.settings-bar { display: flex; align-items: flex-end; gap: 12px; flex-wrap: wrap; margin-bottom: 16px; border-bottom: 2px solid var(--border); }
.settings-tabs.tabbar { border-bottom: 0; padding: 0; background: transparent; flex-wrap: wrap; }
.settings-tabs .tab { font-size: .9375em; }
.settings-tabs .tab.active, .settings-tabs .tab:hover { color: var(--primary-dark); }   /* on --bg, --primary is just under 4.5:1 */
.tab-count { display: inline-block; min-width: 1.4em; margin-left: 6px; padding: 0 5px; border-radius: 999px; background: var(--primary-light); color: var(--primary-dark); font-size: .75em; font-weight: 600; text-align: center; }
.tab.tab-dim { opacity: .55; }
.settings-find { margin: 0 0 6px auto; position: relative; display: flex; align-items: center; }
.settings-find .icon { position: absolute; left: 9px; color: var(--text-subtle); pointer-events: none; }
.settings-find input { width: 250px; max-width: 100%; padding: 7px 10px 7px 30px; font: inherit; font-size: .875em; background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius-sm); }
.settings-find-empty { margin: 0 0 16px; color: var(--text-muted); font-size: .875em; }
.sec-group-chip { display: none; order: 3; margin-left: auto; padding: 1px 8px; border-radius: 999px; background: var(--primary-light); color: var(--primary-dark); font-size: .75rem; font-weight: 600; }
body.settings-searching .sec-group-chip { display: inline-block; }

/* Dashboard "Teendők" card (replaced the logo tile). */
.attn-card h2.stat-label { margin: 0 0 8px; }
.attn-list { list-style: none; margin: 0 0 10px; padding: 0; display: flex; flex-direction: column; gap: 6px; font-size: .875rem; }
.attn-list li { display: flex; gap: 6px; align-items: flex-start; line-height: 1.35; }
.attn-list li .icon { flex: 0 0 auto; margin-top: 2px; }
.attn-list a { color: inherit; font-weight: 600; text-decoration: none; border-bottom: 1px dotted currentColor; }
.attn-list a:hover { border-bottom-style: solid; }
.attn-danger  { color: var(--danger-dark); }
.attn-warning { color: var(--warning); }
.attn-info    { color: var(--text); }
.attn-ok { margin: 0 0 10px; color: var(--success-dark); font-weight: 600; font-size: .875rem; display: flex; gap: 6px; align-items: center; }
.attn-task { display: inline-flex; align-items: center; gap: 4px; font-size: .8125rem; font-weight: 600; color: var(--primary-dark); text-decoration: none; }
.attn-task:hover { text-decoration: underline; }
/* The card is stretched to its row's height; keep the list at the top and the
   standing task at the bottom so the height reads as composed, not empty. */
.attn-card { display: flex; flex-direction: column; }
.attn-card .attn-task { margin-top: auto; align-self: flex-start; }
.feed-state { font-size: .6875rem; font-weight: 600; margin-left: auto; }

.fold-explain { margin: 0; padding: 12px 20px 0; }
/* Dashboard explanation icons: a click/keyboard disclosure, not hover-only. */
.info-hint[role=button] { cursor: pointer; position: relative; }
.info-pop {
    position: absolute; z-index: 40; top: calc(100% + 6px); left: -8px; width: min(340px, 80vw);
    padding: 10px 12px; background: var(--surface); color: var(--text); border: 1px solid var(--border);
    border-radius: var(--radius-sm); box-shadow: 0 6px 18px rgb(15 23 42 / .14);
    font-size: .8125rem; font-weight: 400; line-height: 1.5; text-transform: none; letter-spacing: 0; white-space: normal;
}

/* ── Mobile ──────────────────────────────────────────────────────── */
@media (max-width: 720px) {
    .wrap { padding: 12px 8px; }
    .page-title { margin-top: 44px; }
    .nav-toggle { display: flex; align-items: center; justify-content: center; }
    .sidebar {
        position: fixed;
        left: 0;
        top: 0;
        width: 260px;
        z-index: 160;
        transform: translateX(-100%);
        visibility: hidden;   /* off-screen links must not be tabbable */
        transition: transform var(--t), visibility var(--t);
    }
    .sidebar.nav-open { transform: translateX(0); visibility: visible; }
    .sidebar.nav-open ~ .nav-backdrop,
    #navBackdrop:has(~ .sidebar.nav-open) { display: block; }
    .nav-open ~ #navBackdrop { display: block; }
    .filter-card, .results-card { border-radius: 0; margin-left: -8px; margin-right: -8px; }
    .filter-row { flex-direction: column; align-items: stretch; gap: 10px; overflow-x: visible; }
    .filter-group { flex: none; width: 100%; max-width: none; }
    .kb-help { display: none; }   /* single-key shortcuts mean nothing on a touch screen */
    .ctl-first .col-from, .ctl-first .col-user { max-width: none; }
    .ctl-first .col-date { width: auto; min-width: 0; }
    .from-block { min-width: 0; overflow-wrap: anywhere; }
    .filter-group:has(> .btn),
    .filter-group:has(> a.btn) { flex: none; }
    .filter-group select,
    .filter-group input[type=date],
    .filter-group input[type=text] { width: 100%; padding: 10px; }
    .filter-card .btn { width: 100%; justify-content: center; padding: 11px 16px; }
    .filter-group label[for] { font-size: .875em; }
    .results-header { flex-direction: column; align-items: flex-start; gap: 4px; }
    .bulk-bar { flex-wrap: wrap; }
    .bulk-bar .btn { flex: 1 1 auto; justify-content: center; padding: 9px 12px; }
    .tabbar { overflow-x: auto; padding: 0 8px; }
    table, tbody, tr.data-row, tr.data-row td { display: block; width: 100%; }
    thead { display: none; }
    tr.data-row {
        width: auto;   /* block + width:100% + 10px margins stuck out 9px past the table */
        border: 1px solid var(--border);
        border-left: 4px solid var(--border);
        border-radius: var(--radius);
        margin: 10px;
        padding: 4px 12px;
        background: var(--surface) !important;
        box-shadow: var(--shadow-sm);
    }
    tr.data-row td:first-child { border-left: none; }
    tr.data-row.f-Spam       { border-left-color: #e11d48; }
    tr.data-row.f-Junk       { border-left-color: var(--warning); }
    tr.data-row.f-Quarantine { border-left-color: var(--danger); }
    tr.data-row.f-spam       { border-left-color: var(--danger); }
    tr.data-row.f-ham        { border-left-color: var(--success); }
    tr.data-row td {
        display: flex;
        gap: 10px;
        align-items: baseline;
        padding: 7px 0;
        border: none;
        border-bottom: 1px solid var(--bg);
        text-align: left;
        white-space: normal;
        width: auto;
    }
    tr.data-row td:last-child { border-bottom: none; }
    tr.data-row td::before {
        content: attr(data-label);
        flex: 0 0 84px;
        font-weight: 500;
        color: var(--text-subtle);
        font-size: .75em;
        letter-spacing: 0;
    }
    tr.data-row td.col-check { justify-content: flex-start; }
    td.col-actions .action-btns { flex: 1; flex-wrap: wrap; }
    td.col-actions .action-btns .btn { flex: 1 1 auto; justify-content: center; padding: 10px; }
    /* Jelentett Hírnév cell (Task 6): same problem/fix as .action-btns just
       above. tr.data-row td is a nowrap flex container at this breakpoint;
       .quar-rep-badges' .quar-tag/.verdict/.quar-lookup-btn children were
       bare flex items with no wrap, so 3+ cached verdicts (trivially reached
       with e.g. virustotal+otx+hrbl on one indicator) pushed the button off
       the visible edge of the row card -- measured 41-134px overflow.
       Deliberately no base (non-media) rule for .quar-rep-badges: on desktop
       the <td> isn't flex at all, so the wrapper div only needs to stay
       display:block (its default) for its inline children to flow exactly
       as they did before this div existed -- giving it display:flex there
       too would swap the badges' natural inline-whitespace gaps for a CSS
       gap and could nudge the measured desktop column width. flex:1 (grow
       into the row's remaining width, alongside the ::before label) is what
       makes the group wrap within the available space instead of shrinking
       to its own overflowing intrinsic width first. */
    td.col-quar-rep .quar-rep-badges {
        /* Keep the stacked column here too -- this rule predates the stacking
           and would otherwise flip the cell back to one wrapping row at the
           720px breakpoint. flex:1 still lets it grow into the row card's
           remaining width alongside the ::before label. */
        display: flex; flex-direction: column; align-items: flex-start; gap: 4px; flex: 1;
    }
    tr.detail-row, tr.detail-row td { display: block; width: 100%; }
    tr.detail-row td { padding: 0; }
    tr.detail-row td::before { content: none; }
    .detail-inner { padding: 12px; }
    .detail-html { height: 320px; }
    .detail-toolbar { gap: 8px; }
    .meta-tbl th { width: 60px; }
    /* Raw source. white-space:pre + overflow-x:auto was the previous form, but
   this <pre> lives inside a colspan cell of the AUTO-layout .archive-table:
   an auto table sizes cells by intrinsic content width, so overflow never
   engaged -- a long source line (a 148-char DKIM fold is enough) inflated
   the cell, the whole table grew past the card and the page layout broke,
   and STAYED broken after closing the row. Reported live from the Archive
   source view. Wrapping is the containment that works inside auto tables
   (same lesson as the Hírnév column: overflow-wrap:anywhere, not scroll);
   RFC 5322 folding keeps wrapped headers readable, and base64 was never
   line-by-line meaningful anyway. */
.detail-source {
    white-space: pre-wrap;
    overflow-wrap: anywhere;
    word-break: normal;
    max-height: 460px;
    overflow-y: auto;
    font-size: .8125em;
    line-height: 1.5;
}
.detail-actions { flex-wrap: wrap; }
    .detail-actions .btn { flex: 1 1 auto; justify-content: center; }
    .results-footer { flex-direction: column-reverse; gap: 10px; align-items: stretch; }
    .results-footer .btn { justify-content: center; }
    .pager { justify-content: space-between; }

    /* Admin management tables (settings / users / FTS) */
    table.msg-table tr {
        display: block;
        border: 1px solid var(--border);
        border-radius: var(--radius);
        margin: 8px 10px;
        padding: 10px 12px;
        background: var(--surface);
        box-shadow: var(--shadow-sm);
    }
    table.msg-table td {
        display: block;
        padding: 6px 0;
        border: none;
        border-bottom: 1px solid var(--bg);
        white-space: normal;
        width: auto;
    }
    table.msg-table td:last-child { border-bottom: none; }
    table.msg-table td form { flex-wrap: wrap; }

    /* Add-user form: stack fields full-width */
    .admin-add-user-row { flex-direction: column; align-items: stretch; }
    .admin-add-user-row > div { width: 100%; }
    .admin-add-user-row > div > input,
    .admin-add-user-row > div > select { width: 100% !important; box-sizing: border-box; }
    .admin-add-user-row > div > button.btn { width: 100%; justify-content: center; }
}
</style>
</head>
<body>
<?php require __DIR__ . '/icons.php'; ?>
