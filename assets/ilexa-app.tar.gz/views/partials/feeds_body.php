<?php
// Feeds card BODY, served by the ?feedsbody=1 endpoint when the operator
// expands the card (views/admin_system.php keeps only the summary).
//
// WHY IT IS A PARTIAL: the rows were 52KB of markup and, more to the point,
// the only thing on the page that needed admin_feeds_status() -- a sudo
// helper call -- plus the per-source key/status widgets. The summary's
// "N active / M sources" is computed from the cheap config read and the two
// cached reachability probes, so the operator still sees at a glance whether
// the feeds are on without paying for the table.
//
// Expects the same variables the card used inline; they are gathered by
// feeds_body_vars() so the endpoint and the page cannot drift apart.
if (!isset($feed_sources)) return;
?>
    <div class="filter-hint" style="margin:16px 20px 4px">
        <?= t('Az alábbi forrásokat a rendszer automatikusan frissíti (cron). Az') ?> <strong><?= t('Azonnali frissítés') ?></strong>
        <?= t('gomb háttérben indítja el a letöltő szkriptet - az eredmény néhány perc múlva látható. Az') ?> <em><?= t('Állapot') ?></em> <?= t('a legutóbbi frissítés korát mutatja a várt frissítési ütemhez képest. Egy forrás csak akkor kapcsolható be, ha van hozzá API-kulcs - a kulcs nélküli forrás minden futáskor eredmény nélkül lépne ki. A mentett kulcsot a felület soha nem jeleníti meg.') ?>
    </div>
    <?php if (empty($admin_feeds) && empty($feed_sources)): ?>
    <div class="empty-state"><p><?= t('A forrásállapot nem elérhető (ellenőrizze a sudo-konfigurációt).') ?></p></div>
    <?php else: ?>
    <table class="msg-table sys-table" style="table-layout:fixed">
        <colgroup>
            <col style="width:20%">
            <col style="width:9%">
            <col style="width:7%">
            <col style="width:16%">
            <col style="width:10%">
            <col style="width:11%">
            <col style="width:27%">
        </colgroup>
        <thead>
            <tr>
                <th scope="col"><?= t('Forrás') ?></th>
                <th scope="col"><?= t('Bejegyzés') ?></th>
                <th scope="col"><?= t('Egység') ?></th>
                <th scope="col"><?= t('Frissítve') ?></th>
                <th scope="col"><?= t('Állapot') ?></th>
                <th scope="col"><?= t('API-kulcs') ?></th>
                <th scope="col"><?= t('Kezelés') ?></th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($_feeds_meta as $fk => $fm):
            $fd  = $admin_feeds[$fk] ?? [];
            // Called unconditionally: feed_health() handles a missing status on
            // its own -- with an empty $status there is no 'count' key, so its
            // $hasCount guard is false and the collapse branch is unreachable;
            // the verdict falls back to 'unknown' from age alone. What the
            // cells actually print is still decided by the $fd ? ... : '-'
            // ternaries below.
            $fh  = feed_health($fk, $fd, $fm['cadence']);
            $st  = $fh['state'];
            $sc  = $_fst_colors[$st] ?? 'var(--text-subtle)';
            // Trend arrow for the Bejegyzés cell: only meaningful once a
            // baseline exists (same FEED_BASELINE_MIN_DAYS gate feed_health()
            // itself uses for collapse). +-5% of baseline reads as flat.
            $_trend = '';
            if ($fd && $fh['baseline'] !== null && $fh['pct'] !== null) {
                if ($fh['pct'] > 105)     $_trend = '↑';
                elseif ($fh['pct'] < 95)  $_trend = '↓';
                else                      $_trend = '→';
            }
            // feed_health() already fetched and daily-bucketed these rows --
            // one point per 24h, so at most 14 numbers, not one per hourly
            // sample. Still gated on $fd: a feed with no status gets no tooltip.
            $_hist       = $fd ? $fh['history'] : [];
            $_hist_title = $_hist
                ? t('Előzmény (14 nap): ') . implode(' → ', array_map(
                      static fn($c) => number_format($c), $_hist))
                : '';
            // Alapszint below is the median of these same daily points, so the
            // two tooltips reconcile against one series.
            $_st_title = '';
            if ($fh['baseline'] !== null) {
                $_st_title = $fh['pct'] !== null
                    ? sprintf(t('Alapszint: %s, jelenleg: %d%%'), number_format($fh['baseline']), $fh['pct'])
                    : sprintf(t('Alapszint: %s'), number_format($fh['baseline']));
            }
            $fv  = $feed_sources[$fk] ?? null;
            // A source's enabled flag lives in $feed_sources, not $admin_feeds
            // (status only) -- default true so a source absent from $feed_sources
            // (e.g. otx_dnsbl, which isn't independently toggleable) isn't wrongly
            // greyed out.
            $en    = $fv !== null ? !empty($fv['enabled']) : true;
            $needs = $fv !== null && !empty($fv['needs_key']);
            $has   = $fv !== null && !empty($fv['has_key']);
        ?>
        <tr class="data-row">
            <td data-label="<?= h(t('Forrás')) ?>">
                <strong><?= h($_fs_label[$fk] ?? $fm['label']) ?></strong>
                <div style="font-size:.75rem;color:var(--text-subtle);margin-top:2px"><?= h($fm['note']) ?></div>
            </td>
            <td data-label="<?= h(t('Bejegyzés')) ?>" style="font-variant-numeric:tabular-nums;font-weight:600"
                <?= $_hist_title !== '' ? 'title="' . h($_hist_title) . '"' : '' ?>>
                <?= $fd ? number_format((int)($fd['count'] ?? 0)) : '-' ?>
                <?php if ($_trend !== ''): ?><span style="font-weight:400;color:var(--text-subtle)"><?= h($_trend) ?></span><?php endif; ?>
            </td>
            <td data-label="<?= h(t('Egység')) ?>" style="font-size:.8rem;color:var(--text-muted)"><?= h($fm['unit']) ?></td>
            <td data-label="<?= h(t('Frissítve')) ?>" style="font-size:.8rem">
                <?= $fd ? h($fd['updated'] ?? '-') : '-' ?>
                <?php if ($fk === 'otx_dnsbl' && isset($fd['svc'])): ?>
                <span style="display:block;font-size:.7rem;color:var(--text-subtle)">
                    rbldnsd: <?= h($fd['svc']) ?>
                </span>
                <?php endif; ?>
            </td>
            <td data-label="<?= h(t('Állapot')) ?>">
                <span style="display:flex;flex-wrap:wrap;align-items:center;gap:5px;font-size:.8rem;
                             color:<?= $sc ?>;font-weight:600;max-width:100%"
                      <?= $_st_title !== '' ? 'title="' . h($_st_title) . '"' : '' ?>>
                    <span style="width:8px;height:8px;border-radius:50%;background:<?= $sc ?>;
                                 flex-shrink:0;display:inline-block"></span>
                    <span style="overflow-wrap:anywhere;min-width:0"><?= h($_fst_labels[$st] ?? '?') ?></span>
                </span>
            </td>
            <td data-label="<?= h(t('API-kulcs')) ?>" style="font-size:.8rem">
                <?php if ($fv === null): ?>
                <span style="color:var(--text-subtle)"><?= h(t('nem szükséges')) ?></span>
                <?php elseif (!$needs): ?><span style="color:var(--text-subtle)"><?= h(t('nem szükséges')) ?></span>
                <?php elseif ($has): ?><span style="color:#27ae60"><svg class="icon"><use href="#icon-check"></use></svg> <?= h(t('megadva')) ?></span>
                <?php else: ?><span style="color:var(--warning);font-weight:600"><?= h(t('hiányzik')) ?></span><?php endif; ?>
            </td>
            <td data-label="<?= h(t('Kezelés')) ?>">
                <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">
                    <?php if ($fv !== null): ?>
                    <form method="post" action="?admin=1" style="display:inline">
                        <?= csrf_field() ?>
                        <input type="hidden" name="admin_action" value="feed_toggle">
                        <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                        <input type="hidden" name="feed_src" value="<?= h($fk) ?>">
                        <input type="hidden" name="feed_on" value="<?= $en ? '0' : '1' ?>">
                        <button type="submit" class="btn btn-sm <?= $en ? 'btn-secondary' : 'btn-primary' ?>"
                            <?= (!$en && $needs && !$has) ? 'disabled title="' . h(t('Előbb adjon meg API-kulcsot.')) . '"' : '' ?>>
                            <?= $en ? h(t('Kikapcsol')) : h(t('Bekapcsol')) ?>
                        </button>
                    </form>
                    <?php if ($needs): ?>
                    <form method="post" action="?admin=1" style="display:flex;gap:6px;align-items:center">
                        <?= csrf_field() ?>
                        <input type="hidden" name="admin_action" value="feed_key">
                        <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                        <input type="hidden" name="feed_src" value="<?= h($fk) ?>">
                        <input type="password" name="feed_key" autocomplete="new-password"
                               aria-label="<?= h(t('API-kulcs')) ?>"
                               placeholder="<?= $has ? h(t('új kulcs (üres = törlés)')) : h(t('API-kulcs')) ?>"
                               style="padding:5px;font-size:.78rem;width:150px">
                        <button type="submit" class="btn btn-sm btn-secondary"><?= h(t('Ment')) ?></button>
                    </form>
                    <?php endif; ?>
                    <?php if ($fk === 'geoblock'): ?>
                    <form method="post" action="?admin=1" style="display:flex;gap:6px;align-items:center">
                        <?= csrf_field() ?>
                        <input type="hidden" name="admin_action" value="geoblock_set_countries">
                        <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                        <input type="text" name="geoblock_countries"
                               value="<?= h($geoblock_countries) ?>"
                               aria-label="<?= h(t('Blokkolt országkódok')) ?>"
                               placeholder="ru cn br kr"
                               <?= !$en ? 'disabled' : '' ?>
                               style="padding:5px;font-size:.78rem;width:150px">
                        <button type="submit" class="btn btn-sm btn-secondary" <?= !$en ? 'disabled' : '' ?>><?= h(t('Ment')) ?></button>
                    </form>
                    <?php endif; ?>
                    <?php endif; ?>
                    <?php if ($fm['refreshable'] && $en): ?>
                    <form method="post" action="?admin=1"
                          onsubmit="return confirm('<?= jsq(t('Elindítja a(z)')) ?> <?= jsq($fm['label']) ?> <?= jsq(t('azonnali frissítését?')) ?>\n\n<?= jsq(t('A folyamat a háttérben fut, néhány percig tarthat.')) ?>')">
                        <?= csrf_field() ?>
                        <input type="hidden" name="admin_action" value="feed_refresh">
                        <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                        <input type="hidden" name="feed_name"    value="<?= h($fk) ?>">
                        <button type="submit" class="btn btn-sm btn-secondary"><svg class="icon"><use href="#icon-refresh"></use></svg> <?= t('Frissít') ?></button>
                    </form>
                    <?php elseif ($fm['refreshable']): ?>
                    <span style="font-size:.75rem;color:var(--text-subtle)" title="<?= h(t('A forrás ki van kapcsolva')) ?>"><?= t('kikapcsolva') ?></span>
                    <?php else: ?>
                    <span style="font-size:.75rem;color:var(--text-subtle)">auto</span>
                    <?php endif; ?>
                </div>
            </td>
        </tr>
        <?php endforeach; ?>
        <tr class="data-row">
            <td data-label="<?= h(t('Forrás')) ?>">
                <strong>Spamhaus DQS</strong>
                <div style="font-size:.75rem;color:var(--text-subtle);margin-top:2px"><?= h(t('rspamd RBL (ZEN, DBL) + ZRD - fiókkulcsos, élő lekérdezés')) ?></div>
            </td>
            <td data-label="<?= h(t('Bejegyzés')) ?>">-</td>
            <td data-label="<?= h(t('Egység')) ?>" style="font-size:.8rem;color:var(--text-muted)">-</td>
            <td data-label="<?= h(t('Frissítve')) ?>" style="font-size:.8rem">
                <span style="color:var(--text-subtle)"><?= h(t('nincs értelmezve (élő DNS-lekérdezés minden levélnél)')) ?></span>
            </td>
            <td data-label="<?= h(t('Állapot')) ?>">
                <span style="display:flex;align-items:center;gap:5px;font-size:.8rem;font-weight:600;
                             color:<?= $_shdqs_dot ?>">
                    <span style="width:8px;height:8px;border-radius:50%;flex-shrink:0;display:inline-block;
                                 background:<?= $_shdqs_dot ?>"></span>
                    <?= h($_shdqs_label) ?>
                </span>
                <?php if ($_shdqs_hint !== ''): ?>
                    <div style="font-size:.72rem;color:var(--text-muted);margin-top:2px;max-width:22ch;overflow-wrap:anywhere">
                        <?= h($_shdqs_hint) ?></div>
                <?php endif; ?>
            </td>
            <td data-label="<?= h(t('API-kulcs')) ?>" style="font-size:.8rem">
                <?php if ($_shdqs_has): ?><span style="color:#27ae60"><svg class="icon"><use href="#icon-check"></use></svg> <?= h(t('megadva')) ?></span>
                <?php else: ?><span style="color:var(--text-subtle)"><?= h(t('nincs megadva')) ?></span><?php endif; ?>
            </td>
            <td data-label="<?= h(t('Kezelés')) ?>">
                <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">
                    <form method="post" action="?admin=1" style="display:flex;gap:6px;align-items:center">
                        <?= csrf_field() ?>
                        <input type="hidden" name="admin_action" value="spamhaus_key">
                        <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                        <input type="password" name="spamhaus_key" autocomplete="new-password"
                               aria-label="<?= h(t('Spamhaus DQS fiókkulcs')) ?>"
                               placeholder="<?= $_shdqs_has ? h(t('új kulcs (üres = törlés)')) : h(t('DQS fiókkulcs')) ?>"
                               style="padding:5px;font-size:.78rem;width:150px">
                        <button type="submit" class="btn btn-sm btn-secondary"><?= h(t('Ment')) ?></button>
                    </form>
                    <?php if ($_shdqs_has): ?>
                    <form method="post" action="?admin=1">
                        <?= csrf_field() ?>
                        <input type="hidden" name="admin_action" value="spamhaus_test">
                        <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                        <button type="submit" class="btn btn-sm btn-secondary"><?= h(t('Teszt')) ?></button>
                    </form>
                    <?php endif; ?>
                </div>
            </td>
        </tr>
        <tr class="data-row">
            <td data-label="<?= h(t('Forrás')) ?>" style="font-weight:600">Abusix Mail Intelligence</td>
            <td data-label="<?= h(t('Bejegyzés')) ?>" style="font-size:.8rem;color:var(--text-muted)">-</td>
            <td data-label="<?= h(t('Egység')) ?>" style="font-size:.8rem;color:var(--text-muted)">-</td>
            <td data-label="<?= h(t('Frissítve')) ?>" style="font-size:.8rem">
                <span style="color:var(--text-subtle)"><?= h(t('nincs értelmezve (élő DNS-lekérdezés minden levélnél)')) ?></span>
            </td>
            <td data-label="<?= h(t('Állapot')) ?>">
                <span style="display:flex;align-items:center;gap:5px;font-size:.8rem;font-weight:600;
                             color:<?= $_abusix_dot ?>">
                    <span style="width:8px;height:8px;border-radius:50%;flex-shrink:0;display:inline-block;
                                 background:<?= $_abusix_dot ?>"></span>
                    <?= h($_abusix_label) ?>
                </span>
                <?php if ($_abusix_hint !== ''): ?>
                    <div style="font-size:.72rem;color:var(--text-muted);margin-top:2px;max-width:22ch;overflow-wrap:anywhere">
                        <?= h($_abusix_hint) ?></div>
                <?php endif; ?>
            </td>
            <td data-label="<?= h(t('API-kulcs')) ?>" style="font-size:.8rem">
                <?php if ($_abusix_has): ?><span style="color:#27ae60"><svg class="icon"><use href="#icon-check"></use></svg> <?= h(t('megadva')) ?></span>
                <?php else: ?><span style="color:var(--text-subtle)"><?= h(t('nincs megadva')) ?></span><?php endif; ?>
            </td>
            <td data-label="<?= h(t('Kezelés')) ?>">
                <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">
                    <form method="post" action="?admin=1" style="display:flex;gap:6px;align-items:center">
                        <?= csrf_field() ?>
                        <input type="hidden" name="admin_action" value="abusix_key">
                        <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                        <input type="password" name="abusix_key" autocomplete="new-password"
                               aria-label="<?= h(t('Abusix datafeed kulcs')) ?>"
                               placeholder="<?= $_abusix_has ? h(t('új kulcs (üres = törlés)')) : h(t('datafeed kulcs')) ?>"
                               style="padding:5px;font-size:.78rem;width:150px">
                        <button type="submit" class="btn btn-sm btn-secondary"><?= h(t('Ment')) ?></button>
                    </form>
                    <?php if ($_abusix_has): ?>
                    <form method="post" action="?admin=1">
                        <?= csrf_field() ?>
                        <input type="hidden" name="admin_action" value="abusix_test">
                        <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                        <button type="submit" class="btn btn-sm btn-secondary"><?= h(t('Teszt')) ?></button>
                    </form>
                    <?php endif; ?>
                </div>
            </td>
        </tr>
        </tbody>
    </table>
    <div class="filter-hint" style="margin:4px 20px 16px">
        <?= h(t('A Spamhaus DQS nem letöltött lista, hanem élő DNS-lekérdezés minden levélnél (ezért nincs Bejegyzés/Frissítve értéke és nincs Azonnali frissítés gombja) - fiókkulcsos hozzáférés a nyilvános Spamhaus-zónákhoz (ZEN) és a ZRD (frissen regisztrált domain) jelzéshez. A kulcs beszerzéséről lásd a Névjegy oldalt.')) ?>
    </div>
    <div class="filter-hint" style="margin:4px 20px 16px">
        <strong><?= h(t('Abusix: a kulcs önmagában elég, IP-engedélyezés nem kell.')) ?></strong>
        <?= h(t('A lekérdezést maga a kulcs hitelesíti: mérve, hogy olyan szerverről is válaszol, amelynek IP-címe soha nem került be az Abusix portálba. IP-engedélyezésre tehát nincs szükség. (A panel korábbi szövege azt állította, hogy kötelező - ez téves volt.) Ami viszont csendben elnémítja a forrást: el nem fogadott kulcs (elgépelt, visszavont, lejárt előfizetés), vagy olyan DNS-feloldó, amelyik nem éri el az Abusix névszervereit. Mindkettő üres választ ad, ezért az Állapot oszlop élő lekérdezéssel ellenőrzi, hogy a forrás tényleg válaszol-e, és nem csak azt mutatja, hogy van beállított kulcs.')) ?>
    </div>
    <?php endif; ?>
