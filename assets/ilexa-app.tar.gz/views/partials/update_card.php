<?php
// ilexa version/update status card. Included from dashboard.php just above
// the "Blokklista-források" feed-grid -- reuses that exact status-tile
// idiom (small identity card with a colour dot) rather than the heavier,
// uncached System-identity card, because this one is fed by a cache file a
// cron job writes, never by a live shell-out on this render.
//
// $update_status (from update_status(), src/update.php) is populated
// unconditionally for every dashboard viewer, same as $admin_feeds --
// status is not sensitive. Only the action buttons below are admin-gated.
$us = $update_status ?? ['known' => false, 'check_disabled' => false, 'reason' => 'never_checked'];
$run = update_run_state();

$installedVersion  = trim((string)@file_get_contents(dirname(__DIR__, 2) . '/VERSION')) ?: 'dev';
$installedCodename = trim((string)@file_get_contents(dirname(__DIR__, 2) . '/CODENAME')) ?: '';

$runActive = $run && ($run['state'] ?? '') === 'running';

if ($runActive) {
    $dot = '#e67e22'; $pulsing = true;
    $label = sprintf(t('Frissítés folyamatban: %s'), h($run['phase'] ?? '?'));
} elseif ($run && ($run['state'] ?? '') === 'needs_attention') {
    $dot = '#e74c3c'; $pulsing = false;
    $label = t('A frissítés meghiúsult és a visszaállítás sem sikerült — beavatkozás szükséges');
} elseif (!$us['known']) {
    $dot = '#95a5a6'; $pulsing = false;
    $label = $us['check_disabled']
        ? t('Ismeretlen — automatikus ellenőrzés kikapcsolva')
        : (($us['reason'] ?? '') === 'last_check_failed' ? t('Az ellenőrzés nem sikerült') : t('Még nincs ellenőrizve'));
} elseif (empty($us['update_available'])) {
    $dot = '#27ae60'; $pulsing = false;
    $label = t('Naprakész');
} elseif (($us['latest']['severity'] ?? '') === 'security') {
    $dot = '#e74c3c'; $pulsing = false;
    $label = sprintf(t('Biztonsági frissítés elérhető: %1$s · %2$s'), h($us['latest']['version']), h($us['latest']['codename']));
} else {
    $dot = '#e67e22'; $pulsing = false;
    $label = sprintf(t('Elérhető: %1$s · %2$s'), h($us['latest']['version']), h($us['latest']['codename']));
}
?>
<div class="results-card" style="margin-top:16px">
    <div class="results-header">
        <h2><?= h(t('ilexa verzió')) ?></h2>
        <span class="meta"><?= h($installedVersion) ?><?= $installedCodename !== '' ? ' · ' . h($installedCodename) : '' ?></span>
    </div>
    <div style="padding:12px 20px;display:flex;align-items:center;gap:16px;flex-wrap:wrap">
        <div style="display:flex;align-items:center;gap:8px">
            <span style="width:10px;height:10px;border-radius:50%;background:<?= $dot ?>;flex-shrink:0;display:inline-block<?= $pulsing ? ';animation:qa-pulse 1.4s ease-in-out infinite' : '' ?>"></span>
            <span style="font-size:.875rem"><?= $label ?></span>
        </div>

        <?php if (!$runActive): ?>
        <form method="post" action="?admin=1" style="margin:0">
            <?= csrf_field() ?>
            <input type="hidden" name="admin_action" value="update_check_now">
            <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB ?? '') ?>">
            <button type="submit" class="btn btn-sm btn-secondary">
                <svg class="icon"><use href="#icon-refresh"></use></svg> <?= t('Ellenőrzés most') ?>
            </button>
        </form>

        <?php if (can('admin') && $us['known'] && !empty($us['update_available'])): ?>
            <?php if (!empty($us['latest']['requires_installer'])): ?>
            <button type="button" class="btn btn-sm" disabled title="<?= h(t('Ez a kiadás a telepítőt igényli — nem telepíthető egy kattintással.')) ?>">
                <?= sprintf(t('Frissítés telepítése (%s)'), h($us['latest']['version'])) ?>
            </button>
            <?php else: ?>
            <form method="post" action="?admin=1" style="margin:0"
                  onsubmit="return confirm(<?= h(json_encode(sprintf(
                      t('Telepíti a(z) %1$s (%2$s) frissítést? A konzol rövid időre nem lesz elérhető a telepítés alatt.'),
                      $us['latest']['version'], $us['latest']['codename']
                  ))) ?>)">
                <?= csrf_field() ?>
                <input type="hidden" name="admin_action" value="update_apply">
                <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB ?? '') ?>">
                <input type="hidden" name="update_target_version" value="<?= h($us['latest']['version']) ?>">
                <button type="submit" class="btn btn-sm btn-primary">
                    <?= sprintf(t('Frissítés telepítése (%1$s · %2$s)'), h($us['latest']['version']), h($us['latest']['codename'])) ?>
                </button>
            </form>
            <?php endif; ?>
        <?php endif; ?>
        <?php endif; ?>
    </div>
    <?php if ($us['known'] && !empty($us['update_available']) && !empty($us['latest']['notes_hu'])): ?>
    <div style="padding:0 20px 12px;font-size:.8125rem;color:var(--text-muted)">
        <?= h(qa_lang() === 'hu' ? $us['latest']['notes_hu'] : $us['latest']['notes_en']) ?>
    </div>
    <?php endif; ?>
</div>
