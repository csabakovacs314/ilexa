<?php
// Settings page chrome: the former Admin and Rendszer pages are one page now,
// split into five groups shown as tabs. index.php renders views/admin.php
// (the General group) and views/admin_system.php (the other four) after this
// partial, every section in full; sections outside the active group carry
// `hidden`. The tabs therefore work without a reload, and the search box
// below finds a setting in ANY group (views/layout_foot.php).
//
// Variables from index.php: $settings_group (one of QA_SETTINGS_GROUPS).
$settings_group = in_array($settings_group ?? '', QA_SETTINGS_GROUPS, true) ? $settings_group : 'general';
$settings_tabs = [
    'general'     => ['?admin=1',                   t('Általános')],
    'filtering'   => ['?sysconfig=1&g=filtering',   t('Levélszűrés')],
    'feeds'       => ['?sysconfig=1&g=feeds',       t('Fenyegetési források')],
    'postfix'     => ['?sysconfig=1&g=postfix',     'Postfix'],
    'maintenance' => ['?sysconfig=1&g=maintenance', t('Karbantartás')],
];
// Per-section attributes. Called inside each section's <details> tag; it
// also points $ADMIN_TAB -- the admin_return_to every form in that section
// posts -- at the section's own group, so a save lands back on the tab it was
// made from (all of these values are in QA_ADMIN_TABS).
$sg = function (string $group) use ($settings_group, $settings_tabs, &$ADMIN_TAB): string {
    $ADMIN_TAB = $group === 'general' ? 'admin=1' : 'sysconfig=1&g=' . $group;
    return ' data-group="' . h($group) . '" data-group-label="' . h($settings_tabs[$group][1] ?? $group) . '"'
         . ($group === $settings_group ? '' : ' hidden');
};
?>
<h1 class="page-title"><?= h(t('Beállítások')) ?></h1>
<div class="settings-bar">
    <nav class="tabbar settings-tabs" id="settingsTabs" aria-label="<?= h(t('Beállítás-csoportok')) ?>">
        <?php foreach ($settings_tabs as $_g => [$_href, $_label]): ?>
        <a href="<?= h($_href) ?>" class="tab<?= $_g === $settings_group ? ' active' : '' ?>" data-group="<?= h($_g) ?>"<?= $_g === $settings_group ? ' aria-current="page"' : '' ?>><?= h($_label) ?><span class="tab-count" hidden></span></a>
        <?php endforeach; ?>
    </nav>
    <div class="settings-find">
        <label for="settingsFind" class="sr-only"><?= h(t('Beállítás keresése')) ?></label>
        <svg class="icon" aria-hidden="true"><use href="#icon-search"></use></svg>
        <input type="search" id="settingsFind" placeholder="<?= h(t('Beállítás keresése…')) ?>" autocomplete="off">
    </div>
</div>
<p class="settings-find-empty" id="settingsFindEmpty" role="status" hidden><?= h(t('Egyik beállítás címe vagy leírása sem tartalmazza ezt a szöveget.')) ?></p>
