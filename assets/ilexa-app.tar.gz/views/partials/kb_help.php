<?php
// Keyboard-shortcut strip, shared by Jelentett spam and Archívum. The
// shortcuts in views/layout_foot.php only run on a page that renders this
// strip, so every key that works is also listed here, and the switch below
// turns them all off (WCAG 2.1.4: single-key shortcuts must be switchable).
// The on/off state is a per-browser convenience in localStorage.
$_kb_quar = !empty($is_quar);
?>
<div class="kb-help" id="kbHelp">
    <strong style="color:var(--text)"><?= h(t('Billentyűk')) ?></strong>
    <span class="kb-keys">
        <span><kbd>j</kbd>/<kbd>k</kbd> <?= h(t('sor')) ?></span>
        <span><kbd>o</kbd> <?= h(t('megnyitás')) ?></span>
        <?php if ($_kb_quar): ?>
        <span><kbd>r</kbd> <?= h(t('felszabadítás')) ?></span>
        <span><kbd>d</kbd> <?= h(t('törlés')) ?></span>
        <?php endif; ?>
        <span><kbd>/</kbd> <?= h(t('keresés')) ?></span>
    </span>
    <span class="kb-off-note" hidden><?= h(t('A billentyűparancsok ki vannak kapcsolva.')) ?></span>
    <button type="button" class="btn btn-sm btn-secondary kb-toggle" id="kbToggle" aria-pressed="true"
            data-on="<?= h(t('Kikapcsolás')) ?>" data-off="<?= h(t('Bekapcsolás')) ?>"><?= h(t('Kikapcsolás')) ?></button>
</div>
