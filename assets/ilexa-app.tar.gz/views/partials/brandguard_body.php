<?php
// Brand-guard card BODY, rendered both inline (never, today) and by the
// ?bgbody=1 endpoint that the card fetches when the operator expands it.
//
// WHY IT IS A PARTIAL: with 46 brands this markup was 294KB -- 45% of the
// whole Rendszer page -- for a card that is collapsed on arrival and that
// most page loads never display. Returning server-rendered HTML (rather than
// JSON rebuilt in JS, which is how the rspamd-modules panel does it) keeps
// the markup, the translations and the CSRF fields in exactly one place.
//
// Expects: $brandcfg (admin_brandguard_list()), $ADMIN_TAB.
if (!isset($brandcfg) || $brandcfg === null) return;
$lures = admin_brandguard_lures();
?>
    <div class="filter-hint" style="margin:16px 20px 4px">
        <?= h(t('Ha a feladó megjelenített neve egy védett márkára hasonlít (ékezet-, kis/nagybetű- és homoglif-eltérésekkel együtt), de a feladó domainje nem a márka valódi domainje, a levél BRAND_DN_SPOOF pontot kap. A tárgysorban vagy a feladó címében szereplő márkanév szintén pontoz (BRAND_SUBJ_SPOOF / BRAND_ADDR_SPOOF), az álcázott tárgysorbeli említés — pl. "0TP" — erősebben (BRAND_SUBJ_OBFUS). Ha a levél emellett klasszikus adathalász fordulatokat is használ (magyarul vagy angolul), BRAND_LURE többletpontot kap; önmagában, márkajelzés nélkül ez sosem pontoz. A "=" előtagú névváltozat csak a teljes megjelenített névre illeszkedik (köznévi márkanevekhez, pl. "=wise"), tárgysorban nem vesz részt. A márkák és a csalinyelvi fordulatok az rspamd local.d/brand_definitions.json és brand_lures.json fájljaiban élnek. Minden mentés újraindítja az rspamd-t (néhány másodperc).')) ?>
    </div>
    <div style="padding:8px 20px 0">
        <form method="post" action="?admin=1" style="display:inline">
            <?= csrf_field() ?>
            <input type="hidden" name="admin_action" value="brand_toggle">
            <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
            <input type="hidden" name="brand_on" value="<?= ($brandcfg['enabled'] ?? true) ? '0' : '1' ?>">
            <button type="submit" class="btn btn-sm <?= ($brandcfg['enabled'] ?? true) ? 'btn-secondary' : 'btn-primary' ?>">
                <?= h(($brandcfg['enabled'] ?? true) ? t('Kikapcsolás') : t('Bekapcsolás')) ?>
            </button>
        </form>
    </div>
    <table class="msg-table sys-table" style="table-layout:fixed">
        <colgroup><col style="width:18%"><col style="width:34%"><col style="width:34%"><col style="width:14%"></colgroup>
        <thead><tr>
            <th scope="col"><?= h(t('Márka')) ?></th>
            <th scope="col"><?= h(t('Névváltozatok')) ?></th>
            <th scope="col"><?= h(t('Valódi domainek')) ?></th>
            <th scope="col"><?= h(t('Művelet')) ?></th>
        </tr></thead>
        <tbody>
        <?php foreach ($brandcfg['brands'] as $bb): $bid = (string)($bb['id'] ?? ''); ?>
        <tr class="data-row">
            <td data-label="<?= h(t('Márka')) ?>">
                <?= h((string)($bb['name'] ?? $bid)) ?><br><code style="font-size:.72rem"><?= h($bid) ?></code>
            </td>
            <?php foreach (['variant' => t('Névváltozatok'), 'domain' => t('Valódi domainek')] as $kind => $klabel):
                  $items = (array)($bb[$kind === 'variant' ? 'variants' : 'domains'] ?? []); ?>
            <td data-label="<?= h($klabel) ?>">
                <div style="display:flex;flex-wrap:wrap;gap:4px;align-items:center">
        
                    <?php // ONE form per cell, not one per chip. Each chip was a full
                          // <form> with a CSRF field and four hidden inputs; across 46
                          // brands that made this card 365KB of the page's 713KB and 373
                          // of its 484 forms -- the single biggest reason the Rendszer
                          // page felt slow to open. A submit button carries its own
                          // name/value, so the shared hidden fields are written once and
                          // each chip costs a button instead of a form.
                          //
                          // No per-chip confirm: removing one variant or domain is
                          // trivially re-addable from the field alongside it. The
                          // destructive action (removing a whole brand with everything
                          // under it) keeps its confirm. ?>
                    <?php if ($items): ?>
                    <form method="post" action="?admin=1" style="display:inline-flex;flex-wrap:wrap;gap:4px;align-items:center">
                        <?= csrf_field() ?>
                        <input type="hidden" name="admin_action" value="brand_<?= $kind ?>_remove">
                        <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                        <input type="hidden" name="brand_id" value="<?= h($bid) ?>">
                        <?php foreach ($items as $it): ?>
                        <span style="display:inline-flex;align-items:center;gap:2px"><code><?= h((string)$it) ?></code><button
                            type="submit" name="brand_value" value="<?= h((string)$it) ?>"
                            class="btn btn-sm btn-secondary" style="padding:0 5px"
                            aria-label="<?= h(sprintf(t('%s törlése'), $it)) ?>">&times;</button></span>
                        <?php endforeach; ?>
                    </form>
                    <?php endif; ?>
                    <form method="post" action="?admin=1" style="display:inline-flex;gap:2px">
                        <?= csrf_field() ?>
                        <input type="hidden" name="admin_action" value="brand_<?= $kind ?>_add">
                        <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                        <input type="hidden" name="brand_id" value="<?= h($bid) ?>">
                        <input type="text" name="brand_value" required style="padding:3px;width:110px;font-size:.78rem"
                               placeholder="<?= h($kind === 'variant' ? t('új változat') : t('új domain')) ?>"
                               aria-label="<?= h($kind === 'variant' ? sprintf(t('Új névváltozat: %s'), $bid) : sprintf(t('Új domain: %s'), $bid)) ?>">
                        <button type="submit" class="btn btn-sm btn-secondary" style="padding:0 7px">+</button>
                    </form>
                </div>
            </td>
            <?php endforeach; ?>
            <td data-label="<?= h(t('Művelet')) ?>">
                <form method="post" action="?admin=1" style="display:inline"
                      onsubmit="return confirm(<?= h(json_encode(sprintf(t('Eltávolítod a(z) %s márkát minden változatával és domainjével együtt?'), $bb['name'] ?? $bid))) ?>)">
                    <?= csrf_field() ?>
                    <input type="hidden" name="admin_action" value="brand_remove">
                    <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                    <input type="hidden" name="brand_id" value="<?= h($bid) ?>">
                    <button type="submit" class="btn btn-sm btn-danger"><?= h(t('Eltávolít')) ?></button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <div style="padding:12px 20px 16px">
        <form method="post" action="?admin=1" style="display:flex;gap:6px;align-items:flex-end;flex-wrap:wrap">
            <?= csrf_field() ?>
            <input type="hidden" name="admin_action" value="brand_add">
            <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
            <label style="display:flex;flex-direction:column;font-size:.78rem;gap:2px"><?= h(t('Új márka azonosítója')) ?>
                <input type="text" name="brand_id" placeholder="pl. dhl" required
                       pattern="[a-z0-9][a-z0-9_-]*" style="padding:5px;width:130px"></label>
            <label style="display:flex;flex-direction:column;font-size:.78rem;gap:2px"><?= h(t('Megjelenő név')) ?>
                <input type="text" name="brand_name" placeholder="pl. DHL" required maxlength="64"
                       style="padding:5px;width:210px"></label>
            <button type="submit" class="btn btn-sm btn-primary"><?= h(t('Hozzáadás')) ?></button>
        </form>
        <div class="filter-hint" style="margin-top:6px">
            <?= h(t('Új márka felvétele után add meg a névváltozatait és a valódi domainjeit — változat nélkül a márka nem szűr semmit.')) ?>
        </div>
    </div>

    <?php if ($lures !== null): $lureOn = ($lures['enabled'] ?? true); ?>
    <div class="results-header" style="border-top:1px solid var(--border);margin-top:8px">
        <h2 style="font-size:1rem"><?= h(t('Adathalász fordulatok')) ?></h2>
        <span class="sys-sec-desc"><?= h(t('Nyelvenkénti csalinyelvi kifejezések; csak márkajelzés mellett pontoznak (BRAND_LURE).')) ?></span>
        <span class="meta"><?= h(sprintf(t('%1$d nyelv / %2$d kifejezés / %3$s'),
            count($lures['phrases']),
            array_sum(array_map(fn($l) => is_array($l) ? count($l) : 0, $lures['phrases'])),
            $lureOn ? t('bekapcsolva') : t('kikapcsolva'))) ?></span>
    </div>
    <div class="filter-hint" style="margin:10px 20px 4px">
        <?= h(t('Egy fordulat önmagában sosem pontoz — a valódi jelszó-visszaállító levelek ugyanezt írják. Csak akkor ad plusz pontot, ha a levél emellett márkát is megszemélyesít. Az ékezetek és a kis/nagybetűk nem számítanak. Új nyelv felvételéhez add meg a kétbetűs kódját (pl. de, sk, ro).')) ?>
    </div>
    <div style="padding:4px 20px 0">
        <form method="post" action="?admin=1" style="display:inline">
            <?= csrf_field() ?>
            <input type="hidden" name="admin_action" value="brand_lure_toggle">
            <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
            <input type="hidden" name="brand_on" value="<?= $lureOn ? '0' : '1' ?>">
            <button type="submit" class="btn btn-sm <?= $lureOn ? 'btn-secondary' : 'btn-primary' ?>">
                <?= h($lureOn ? t('Fordulatok kikapcsolása') : t('Fordulatok bekapcsolása')) ?>
            </button>
        </form>
    </div>
    <table class="msg-table sys-table" style="table-layout:fixed">
        <colgroup><col style="width:14%"><col style="width:86%"></colgroup>
        <thead><tr>
            <th scope="col"><?= h(t('Nyelv')) ?></th>
            <th scope="col"><?= h(t('Kifejezések')) ?></th>
        </tr></thead>
        <tbody>
        <?php foreach ($lures['phrases'] as $lang => $plist): $lang = (string)$lang; ?>
        <tr class="data-row">
            <td data-label="<?= h(t('Nyelv')) ?>"><code><?= h($lang) ?></code></td>
            <td data-label="<?= h(t('Kifejezések')) ?>">
                <div style="display:flex;flex-wrap:wrap;gap:4px;align-items:center">
                    <?php if ($plist): ?>
                    <form method="post" action="?admin=1" style="display:inline-flex;flex-wrap:wrap;gap:4px;align-items:center">
                        <?= csrf_field() ?>
                        <input type="hidden" name="admin_action" value="brand_lure_remove">
                        <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                        <input type="hidden" name="brand_lang" value="<?= h($lang) ?>">
                        <?php foreach ((array)$plist as $p): ?>
                        <span style="display:inline-flex;align-items:center;gap:2px"><code><?= h((string)$p) ?></code><button
                            type="submit" name="brand_value" value="<?= h((string)$p) ?>"
                            class="btn btn-sm btn-secondary" style="padding:0 5px"
                            aria-label="<?= h(sprintf(t('%s törlése'), $p)) ?>">&times;</button></span>
                        <?php endforeach; ?>
                    </form>
                    <?php endif; ?>
                    <form method="post" action="?admin=1" style="display:inline-flex;gap:2px">
                        <?= csrf_field() ?>
                        <input type="hidden" name="admin_action" value="brand_lure_add">
                        <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
                        <input type="hidden" name="brand_lang" value="<?= h($lang) ?>">
                        <input type="text" name="brand_value" required minlength="8" maxlength="64"
                               style="padding:3px;width:180px;font-size:.78rem"
                               placeholder="<?= h(t('új kifejezés')) ?>"
                               aria-label="<?= h(sprintf(t('Új kifejezés (%s)'), $lang)) ?>">
                        <button type="submit" class="btn btn-sm btn-secondary" style="padding:0 7px">+</button>
                    </form>
                </div>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <div style="padding:12px 20px 16px">
        <form method="post" action="?admin=1" style="display:flex;gap:6px;align-items:flex-end;flex-wrap:wrap">
            <?= csrf_field() ?>
            <input type="hidden" name="admin_action" value="brand_lure_add">
            <input type="hidden" name="admin_return_to" value="<?= h($ADMIN_TAB) ?>">
            <label style="display:flex;flex-direction:column;font-size:.78rem;gap:2px"><?= h(t('Új nyelv kódja')) ?>
                <input type="text" name="brand_lang" placeholder="de" required pattern="[a-z]{2,8}"
                       style="padding:5px;width:80px"></label>
            <label style="display:flex;flex-direction:column;font-size:.78rem;gap:2px"><?= h(t('Első kifejezés')) ?>
                <input type="text" name="brand_value" required minlength="8" maxlength="64"
                       placeholder="<?= h(t('pl. ihr konto wurde gesperrt')) ?>" style="padding:5px;width:260px"></label>
            <button type="submit" class="btn btn-sm btn-primary"><?= h(t('Hozzáadás')) ?></button>
        </form>
    </div>
    <?php endif; ?>
