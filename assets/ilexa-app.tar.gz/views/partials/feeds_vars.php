<?php
// Shared feeds state: the source catalogue, the status label/colour maps, the
// DQS + Abusix probes, and the "N active / M sources" counters.
//
// Extracted so the SUMMARY (rendered inline by admin_system.php) and the BODY
// (served by ?feedsbody=1 when the card is expanded) compute them from one
// place. The header total disagreeing with the rows it summarises is a bug
// this card has already had twice -- see the comments below -- and splitting
// it across two requests would have been a third chance to reintroduce it.
//
// Expects $feed_sources / $admin_feeds / $geoblock_countries to be loaded.

$_feeds_meta = [
    'otx'      => ['label' => 'AlienVault OTX (IP)',      'unit' => 'IP',   'cadence' => 21600,  'refreshable' => true,  'note' => t('firewalld ipset + rbldnsd DNSBL')],
    'otx_dnsbl'=> ['label' => 'OTX DNSBL (rbldnsd)',     'unit' => 'IP',   'cadence' => 21600,  'refreshable' => false, 'note' => t('OTX-ből automatikusan frissül')],
    'otx_uri'  => ['label' => 'OTX URI (SpamAssassin)',   'unit' => 'host', 'cadence' => 86400,  'refreshable' => true,  'note' => t('URI pontozás, nem blokk (FP-biztos)')],
    'urlhaus'  => ['label' => 'URLhaus (rspamd multimap)','unit' => 'host', 'cadence' => 86400,  'refreshable' => true,  'note' => t('aktív malware terjesztők')],
    'spamhaus' => ['label' => 'Spamhaus DROP',             'unit' => 'CIDR', 'cadence' => 86400,  'refreshable' => true,  'note' => t('spam IP-prefixek, firewalld')],
    'c2'       => ['label' => 'Abuse.ch C2',              'unit' => 'IP',   'cadence' => 86400,  'refreshable' => true,  'note' => t('ThreatFox + Feodo, firewalld')],
    'geoblock' => ['label' => 'Geoblock',                 'unit' => 'CIDR', 'cadence' => 604800, 'refreshable' => true,  'note' => t('ország-szintű blokk, firewalld')],
    'firehol'  => ['label' => 'FireHOL Level 1',          'unit' => 'CIDR', 'cadence' => 86400,  'refreshable' => true,  'note' => t('rspamd IP-reputáció - csak pontoz, nem blokkol')],
    'abuseipdb'=> ['label' => 'AbuseIPDB',                'unit' => 'IP',   'cadence' => 86400,  'refreshable' => true,  'note' => t('rspamd IP-reputáció - csak pontoz, nem blokkol')],
    'et'       => ['label' => 'Emerging Threats',         'unit' => 'IP',   'cadence' => 86400,  'refreshable' => true,  'note' => t('rspamd IP-reputáció - csak pontoz, nem blokkol')],
    'dshield'  => ['label' => 'DShield/SANS ISC',         'unit' => 'CIDR', 'cadence' => 86400,  'refreshable' => true,  'note' => t('rspamd IP-reputáció - csak pontoz, nem blokkol')],
    'rspamd_rules' => ['label' => 'Community Rspamd Rules', 'unit' => t('kategória'), 'cadence' => 86400, 'refreshable' => true, 'note' => t('martinschaible/rspamd-rules - kéretlen/adathalász minta-egyezés (en/de), csak pontoz')],
    'yara_forge' => ['label' => 'YARA Forge (ClamAV)', 'unit' => t('szabály'), 'cadence' => 86400, 'refreshable' => true, 'note' => t('yarahq.github.io "core" csomag a ClamAV-nak - kb. 4200 szabály. FIGYELEM: kb. 100 MB többlet memória a clamd-ben, és újratöltéskor átmenetileg duplán. Alapértelmezetten kikapcsolva.')],
];
$_fs_label = [
    'otx' => 'AlienVault OTX', 'otx_uri' => 'OTX URI', 'urlhaus' => 'URLhaus',
    'c2' => 'Abuse.ch C2 (ThreatFox + Feodo)', 'abuseipdb' => 'AbuseIPDB',
    'spamhaus' => 'Spamhaus DROP', 'firehol' => 'FireHOL Level 1',
    'et' => 'Emerging Threats', 'dshield' => 'DShield/SANS ISC', 'geoblock' => 'Geoblock',
    'rspamd_rules' => 'Community Rspamd Rules',
    'yara_forge' => 'YARA Forge (ClamAV)',
];
// Health verdict now comes from feed_health() (src/feed_health.php) so one
// function decides ok/stale/old/collapsed/unknown for the whole product,
// instead of this view re-deriving staleness from age alone.
$_fst_labels = ['ok' => 'OK', 'stale' => t('Elavult'), 'old' => t('Régi'), 'unknown' => '?', 'collapsed' => t('Összeomlott')];
$_fst_colors = ['ok' => '#27ae60', 'stale' => 'var(--warning)', 'old' => 'var(--danger)', 'unknown' => 'var(--text-subtle)', 'collapsed' => 'var(--danger)'];
// Spamhaus DQS isn't in $_feeds_meta / $feed_sources -- it has no cron
// cadence or qa-feeds-config.sh entry, so it gets its own row appended after
// the loop below rather than threaded through the shared rendering (that row
// has no count/updated/toggle/refresh, and reusing the loop for one source
// with a different shape was how the yaraify and ClamAV status bugs
// happened). It IS counted in this header's numerator/denominator explicitly
// so "N aktív / M forrás" stays honest instead of undercounting by one.
$_shdqs      = admin_spamhaus_status();
$_abusix     = admin_abusix_status();
$_abusix_has = !empty($_abusix['has_key']);

// Green means "answering", not "configured". A key Abusix does not accept, or a
// resolver that cannot reach them, leaves the feed silently inert -- and this
// row used to show that as green "aktív" purely because the config file was on
// disk, which is the one thing that is never in doubt.
$_abusix_state = (string)($_abusix['state'] ?? 'unknown');
$_abusix_hint  = '';
if (!$_abusix_has) {
    $_abusix_dot   = 'var(--text-subtle)';
    $_abusix_label = t('nincs beállítva');
} elseif (!empty($_abusix['reachable'])) {
    $_abusix_dot   = '#27ae60';
    $_abusix_label = t('aktív');
} else {
    $_abusix_dot   = '#c0392b';
    $_abusix_label = t('nem válaszol');
    $_abusix_hint  = $_abusix_state === 'rejected'
        ? t('az Abusix nem fogadja el a kulcsot')
        : ($_abusix_state === 'unreachable'
            ? t('a DNS-feloldó nem éri el az Abusix névszervereit')
            : t('a kulcs nem olvasható ki a beállításból'));
}
// Spamhaus DQS gets the same treatment as Abusix directly below it, for the
// same reason -- and because two adjacent dots drawn the same way must not mean
// different things. Its helper runs the identical probe.
$_shdqs_has   = !empty($_shdqs['has_key']);
$_shdqs_state = (string)($_shdqs['state'] ?? 'unknown');
$_shdqs_hint  = '';
if (!$_shdqs_has) {
    $_shdqs_dot   = 'var(--text-subtle)';
    $_shdqs_label = t('nincs beállítva');
} elseif (!empty($_shdqs['reachable'])) {
    $_shdqs_dot   = '#27ae60';
    $_shdqs_label = t('aktív');
} else {
    $_shdqs_dot   = '#c0392b';
    $_shdqs_label = t('nem válaszol');
    $_shdqs_hint  = $_shdqs_state === 'rejected'
        ? t('a Spamhaus nem szolgálja ki ezt a kulcsot')
        : ($_shdqs_state === 'unreachable'
            ? t('a DNS-feloldó nem éri el a Spamhaus névszervereit')
            : t('a kulcs nem olvasható ki a beállításból'));
}
// Pre-existing bug, surfaced (not introduced) by adding the DQS row: a plain
// count(array_filter($feed_sources, ...)) undercounts because otx_dnsbl has
// no qa-feeds-config.sh entry (not independently toggleable -- it's derived
// from OTX) and so is absent from $feed_sources entirely, even though its
// row below always renders "aktív". Same "$fv !== null ? enabled : true"
// expression as the row loop's $en (line ~262), evaluated here up front so
// the header total agrees with what the rows actually display -- if that
// per-source default ever changes, change it in both places.
$_feeds_active = 0;
foreach ($_feeds_meta as $_fk => $_fm) {
    $_fv = $feed_sources[$_fk] ?? null;
    if ($_fv !== null ? !empty($_fv['enabled']) : true) $_feeds_active++;
}
// DQS and Abusix are the two rows rendered outside $_feeds_meta, so they are
// added by hand -- both to the count and to the total. The total said "+ 1"
// while two such rows were being drawn, which understated it by one from the
// moment the Abusix row was added.
//
// They count as active only when the probe actually answered. "Active" here
// has to mean the same thing the dot beside the row means, or the header
// contradicts the table it summarises.
if (!empty($_shdqs['reachable']))  $_feeds_active++;
if (!empty($_abusix['reachable'])) $_feeds_active++;
$_feeds_total = count($_feeds_meta) + 2;
?>
