<?php
// About / documentation. Deliberately inline rather than a link to a file:
// the person who needs it is already looking at the console.
$_v = trim((string)@file_get_contents(dirname(__DIR__) . '/VERSION')) ?: 'dev';
?>
<h1 class="page-title"><?= h(t('Névjegy')) ?></h1>
<div class="results-card about-hero">
    <div class="about-title">
        <img src="<?= h(COOKIE_PATH) ?>assets/logo-lockup.png" alt="<?= h(t(SITE_TITLE)) ?>" class="about-mark">
        <div class="about-title-text">
            <div class="about-sub"><?= h(SITE_SUBTITLE) ?></div>
            <p class="about-lead">
                <?= h(t('Levélbiztonsági konzol: karantén-kezelés, archívum, blokk- és fehérlisták, vírusvédelem, hírnevességi források és auditnapló egy helyen.')) ?>
            </p>
            <div class="about-credits">
                <span><strong><?= h(t('Ötletgazda')) ?>:</strong> <?= h(CREDIT_IDEA) ?></span>
                <span><strong><?= h(t('Fejlesztő')) ?>:</strong> <?= h(CREDIT_CODE) ?></span>
            </div>
        </div>
    </div>
</div>

<div class="results-card" style="margin-top:16px">
    <div class="results-header"><h2><?= h(t('Hogyan halad át egy levél a rendszeren')) ?></h2></div>
    <div class="about-body">
        <pre class="about-flow">
 <?= h(t('Beérkező kapcsolat')) ?>
        │
        ├─ postscreen ──────── <?= h(t('DNSBL, protokollsértés → elutasítás a levél megérkezése előtt')) ?>

        │
        ├─ rspamd (milter) ─── <?= h(t('pontozás; blokklista/vírus → elutasítás')) ?>

        │                      <?= h(t('spam-tag: {Spam?} a tárgyban, a levél kézbesítve')) ?>

        │
        ├─ <?= h(t('kézbesítés a postafiókba')) ?>

        │
        └─ always_bcc ──────── <?= h(t('másolat az archívumba (30 nap)')) ?>
</pre>
        <p><?= h(t('Fontos: a rendszer nem tart vissza levelet. A spamnek ítélt levél megjelölve kézbesítésre kerül, a biztosan rossz levél pedig már SMTP-szinten elutasításra kerül - így nincs kiadandó karantén. Amit a "Jelentett spam" lapon látsz, azt a felhasználók jelölték meg.')) ?></p>
    </div>
</div>

<div class="results-card" style="margin-top:16px">
    <div class="results-header"><h2><?= h(t('Menüpontok')) ?></h2></div>
    <div class="about-body">
        <dl class="about-dl">
            <dt><?= h(t('Áttekintés')) ?></dt>
            <dd><?= h(t('Forgalmi és spam-statisztika, napi bontás, rendszerállapot (lemez, memória), ClamAV, blokkolt levelek rétegenként, adatvédelmi incidensek és a hírnevességi források állapota.')) ?></dd>

            <dt><?= h(t('Archívum')) ?></dt>
            <dd><?= h(t('Minden be- és kimenő levél központi másolata 30 napig, kereshetően. Innen megtekinthető a levél tartalma és forrása, taníthatod spamként vagy hamként, újraküldheted egy címzettnek, illetve a feladót blokk- vagy fehérlistára teheted.')) ?></dd>

            <dt><?= h(t('Jelentett spam')) ?></dt>
            <dd><?= h(t('A felhasználók Spam/Junk mappáiba került levelek. A Felszabadít visszateszi a Beérkező levelek közé és hamként tanítja, a Töröl véglegesen törli és spamként tanítja.')) ?></dd>

            <dt><?= h(t('Blokkolás és Fehérlista')) ?></dt>
            <dd><?= h(t('Feladók, tartományok, minták és IP-címek. A blokkolt feladó levele SMTP-szinten elutasításra kerül; a fehérlistás feladó erősen negatív pontszámot kap, de a vírus- és csatolmány-tiltás rá is érvényes.')) ?></dd>

            <dt><?= h(t('IOC')) ?></dt>
            <dd><?= h(t('Indikátor-tár (IP, domain, URL, e-mail, hash) archivált levelekből kinyerve, kampányokból, a Rendszer lapon tömeges hash-importból, vagy kézzel felvéve. Kérésre futó hírnév-ellenőrzés öt szolgáltatás ellen (VirusTotal, URLhaus, AlienVault OTX, HRBL, Mailspike), melyekből súlyozott "Megbízhatóság" számítódik; ezeken felül az url.vet a domain szerkezetét elemzi (külön oszlop, a súlyozásba nem számít bele). A szolgáltatások a Rendszer lapon kapcsolhatók. Az "Élesítés" élő blokkolást hoz létre.')) ?></dd>

            <dt><?= h(t('Kampányok')) ?></dt>
            <dd><?= h(t('Automatikusan felismert tömeges küldések (azonos domain, hasonló tárgy, 48 órán belül legalább 5 levél). Egy kattintással hozzáadható a kampány domainje az IOC-listához.')) ?></dd>

            <dt><?= h(t('Audit')) ?></dt>
            <dd><?= h(t('Minden adminisztrátori művelet (felszabadítás, törlés, listaváltozás) és a bejelentkezések nyilvántartása.')) ?></dd>

            <dt><?= h(t('Admin')) ?></dt>
            <dd><?= h(t('Kezelőfelület nyelve, futtatókörnyezet-beállítások, valamint a felhasználók és szerepkörök kezelése.')) ?></dd>

            <dt><?= h(t('Rendszer')) ?></dt>
            <dd><?= h(t('rspamd Bayes-tanulás, hírnevességi és blokklista-források (be/kikapcsolás, API-kulcsok, azonnali frissítés), ClamAV aláírás-források, Postfix hálózati, TLS- és korlátozási beállításai, közösségi IP-források, valamint a keresési (FTS/Xapian) indexek karbantartása.')) ?></dd>
        </dl>
    </div>
</div>

<div class="results-card" style="margin-top:16px">
    <div class="results-header"><h2><?= h(t('Amit tudni érdemes')) ?></h2></div>
    <div class="about-body">
        <ul class="about-ul">
            <li><strong><?= h(t('Tanulás')) ?>:</strong> <?= h(t('a felszabadítás ham-példaként, a törlés spam-példaként kerül az rspamd Bayes-szűrőjébe. Napló-módban csak naplózás történik, tényleges tanulás nem.')) ?></li>
            <li><strong><?= h(t('Blokkolt levelek')) ?>:</strong> <?= h(t('az elutasított levelek soha nem jutnak postafiókba, ezért az archívumban sem szerepelnek - számlálásuk a Postfix naplójából történik. A tűzfal által csomagszinten eldobott forgalomról nem készül napló, az sehol nem jelenik meg.')) ?></li>
            <li><strong><?= h(t('Adatvédelmi incidensek')) ?>:</strong> <?= h(t('a postafiók-címeket a XposedOrNot adatbázisában ellenőrzi egy éjszakai feladat. Az API napi 100 kérést enged, ezért egy teljes körbeérés több éjszakát vesz igénybe.')) ?></li>
            <li><strong><?= h(t('Billentyűparancsok')) ?>:</strong> <kbd>j</kbd>/<kbd>k</kbd> <?= h(t('sor')) ?>, <kbd>o</kbd> <?= h(t('megnyitás')) ?>, <kbd>r</kbd> <?= h(t('felszabadítás')) ?>, <kbd>d</kbd> <?= h(t('törlés')) ?>, <kbd>/</kbd> <?= h(t('keresés')) ?>.</li>
            <li><strong><?= h(t('Heti összefoglaló')) ?>:</strong> <?= h(t('hétfőnként e-mailben érkezik a heti forgalom, a leggyakoribb spam-feladók és a források állapota.')) ?></li>
        </ul>
    </div>
</div>

<div class="results-card" style="margin-top:16px">
    <div class="results-header"><h2><?= h(t('Rendszerelemek')) ?></h2></div>
    <div class="about-body">
        <table class="msg-table">
            <thead><tr><th scope="col"><?= h(t('Elem')) ?></th><th scope="col"><?= h(t('Szerep')) ?></th></tr></thead>
            <tbody>
            <?php foreach ([
                ['Postfix',   t('levéltovábbítás, postscreen szűrés, SMTP-szintű elutasítás')],
                ['rspamd',    t('spam-pontozás, Bayes-tanulás, blokk-/fehérlista, vírus-hívás')],
                ['ClamAV',    t('vírusellenőrzés hivatalos és nem hivatalos aláírásokkal')],
                ['Dovecot',   t('postafiókok, IMAP/POP3, keresési index')],
                ['MariaDB',   t('archívum-index és auditadatok')],
            ] as [$c, $r]): ?>
                <tr class="data-row">
                    <td data-label="<?= h(t('Elem')) ?>"><strong><?= h($c) ?></strong></td>
                    <td data-label="<?= h(t('Szerep')) ?>"><?= h($r) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <p style="font-size:.8rem;color:var(--text-subtle);margin-top:12px">
            <?= h(t('Verzió')) ?>: <code><?= h($_v) ?></code>
        </p>
    </div>
</div>

<div class="results-card" style="margin-top:16px">
    <div class="results-header"><h2><?= h(t('API-kulcsok beszerzése')) ?></h2></div>
    <div class="about-body">
        <p><?= h(t('Néhány hírnevességi/blokklista-forrás ingyenes regisztrációhoz kötött API-kulcsot igényel a szolgáltatótól. A kulcs nélkül a forrás telepítve marad, de kikapcsolt állapotban - bármikor pótolható.')) ?></p>
        <table class="msg-table">
            <thead>
                <tr>
                    <th scope="col"><?= h(t('Szolgáltatás')) ?></th>
                    <th scope="col"><?= h(t('Mihez használja a rendszer')) ?></th>
                    <th scope="col"><?= h(t('Regisztráció')) ?></th>
                    <th scope="col"><?= h(t('Hova írd be')) ?></th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ([
                ['AlienVault OTX (LevelBlue)',
                    t('Fenyegetés-intelligencia feed: OTX IP-blokklista, OTX URI-lista, OTX DNSBL zóna'),
                    'https://otx.alienvault.com/', t('Ingyenes fiók regisztrálása után az API-kulcs a fiókbeállítások között található (a szolgáltató időközben LevelBlue néven fut tovább)'),
                    t('Rendszer → Hírnevességi és blokklista-források')],
                ['abuse.ch',
                    t('Feed: URLhaus + ThreatFox/Feodo C2. Kérésre futó IOC-keresés: URLhaus, YARAify, ThreatFox (ugyanaz a kulcs)'),
                    'https://auth.abuse.ch/', t('Ingyenes fiók → Auth-Key generálása'),
                    t('Rendszer → Hírnevességi és blokklista-források')],
                ['AbuseIPDB',
                    t('Feed: IP-hírnév (csak pontoz, nem blokkol)'),
                    'https://www.abuseipdb.com/account/api', t('Ingyenes fiók → Account → API'),
                    t('Rendszer → Hírnevességi és blokklista-források')],
                ['VirusTotal',
                    t('Kérésre futó IOC-keresés (IP, domain, URL, hash)'),
                    'https://www.virustotal.com/gui/my-apikey', t('Ingyenes fiók → bejelentkezve a fenti címen közvetlenül az API-kulcs'),
                    t('Rendszer → IOC-keresési szolgáltatások')],
                ['Abusix Mail Intelligence',
                    t('IP- és domain-blokklisták, valamint fehérlista (combined, dblack, white zóna) - élő DNS-lekérdezéssel, minden levélnél'),
                    'https://app.abusix.com/', t('Ingyenes fiókkal alacsony forgalomra → a 32 karakteres datafeed-kulcs a portálon. A kulcs önmagában hitelesíti a lekérdezést - IP-engedélyezés nem szükséges.'),
                    t('Rendszer → Hírnevességi és blokklista-források')],
                ['Spamhaus DQS',
                    t('Spamhaus RBL a nyilvános zónák helyett, valamint Spamhaus ZRD (frissen regisztrált domain, adathalász-jelzés)'),
                    'https://www.spamhaus.com/data-access/free-data-query-service/', t('Alacsony forgalomra ingyenes fiók → a kulcs a portálon, az "1.0 Datafeed Query Service" szakasznál'),
                    t('Rendszer → Hírnevességi és blokklista-források')],
            ] as [$svc, $use, $url, $reg, $where]): ?>
                <tr class="data-row">
                    <td data-label="<?= h(t('Szolgáltatás')) ?>"><strong><?= h($svc) ?></strong></td>
                    <td data-label="<?= h(t('Mihez használja a rendszer')) ?>"><?= h($use) ?></td>
                    <td data-label="<?= h(t('Regisztráció')) ?>">
                        <a href="<?= h($url) ?>" target="_blank" rel="noopener noreferrer"><?= h($url) ?></a><br>
                        <span style="color:var(--text-subtle);font-size:.85em"><?= h($reg) ?></span>
                    </td>
                    <td data-label="<?= h(t('Hova írd be')) ?>"><?= h($where) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <p style="margin-top:14px">
            <strong><?= h(t('Nem igényelnek kulcsot')) ?>:</strong>
            <?= h(t('HRBL, Mailspike, url.vet, FireHOL Level 1, Emerging Threats, Spamhaus DROP, Blocklist.de (beépített DNSBL-ként), XposedOrNot, YARA Forge, Community Rspamd Rules.')) ?>
        </p>
    </div>
</div>
