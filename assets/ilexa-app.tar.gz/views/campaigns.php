<?php
// Campaign detection tab: lists open (non-dismissed) clusters of related
// spam messages detected by qa-campaign-detect.php. Reached only when
// can('admin').

$campaign_msg = $_GET['msg'] ?? '';
$campaign_notices = [
    'campaign_dismissed' => ['ok',  t('Kampány elvetve.')],
    'campaign_ioc_added' => ['ok',  t('Domain hozzáadva az IOC-listához.')],
    'campaign_ioc_err'   => ['err', t('Művelet sikertelen.')],
    'campaign_err'       => ['err', t('Művelet sikertelen.')],
];
?>
<h1 class="page-title"><?= h(t('Kampányok')) ?></h1>
<?php if (isset($campaign_notices[$campaign_msg])):
    [$campaign_cls, $campaign_text] = $campaign_notices[$campaign_msg];
?>
<div class="notice notice-<?= h($campaign_cls) ?>"><?= $campaign_text ?></div>
<?php endif; ?>

<?php
$campaigns = campaign_list();
$campaign_ioc_domains = campaign_existing_ioc_domains();
?>
<?php /* The explanation used to sit inside the card, above the table, always
   on screen. Folded into the same <details class="sys-sec"> the Rendszer,
   Admin and IOC pages use: no `open` attribute, so it is closed on arrival,
   and the id lets the script in views/layout_foot.php reopen it across a
   save round-trip. Native fold -- no JavaScript and no CSS added. The card
   below keeps the table it always had. */ ?>
<details class="sys-sec results-card" id="campaigns-help" style="margin-bottom:20px">
    <summary class="results-header"><h2><?= t('Mi az a kampány?') ?></h2>
        <span class="sys-sec-desc"><?= h(t('Hogyan ismeri fel a rendszer a kampányokat, és mit csinál a Hozzáadás IOC-ként és az Elvetés.')) ?></span></summary>
    <div class="filter-hint" style="margin-top:0;padding:14px 20px 18px">
        <?= h(t('Egy kampány 5 vagy több, ugyanabból a küldő domainből érkező, egymáshoz hasonló tárgyú spam üzenetet jelent az elmúlt 48 órában - a rendszer naponta egyszer, automatikusan keresi ezeket. A "Hozzáadás IOC-ként" gomb egyetlen kattintással közepes megbízhatóságú indikátorként rögzíti a domaint. Az "Elvetés" leállítja a kampány követését - később sem jelenik meg újra, még ha a minta folytatódik is.')) ?>
    </div>
</details>

<div class="results-card">
    <?php if (empty($campaigns)): ?>
    <div class="empty-state"><p><?= t('Nincs nyitott kampány.') ?></p></div>
    <?php else: ?>
    <table class="msg-table" style="table-layout:fixed">
        <colgroup><col style="width:20%"><col style="width:30%"><col style="width:10%">
                  <col style="width:14%"><col style="width:14%"><col style="width:12%"></colgroup>
        <thead><tr>
            <th scope="col"><?= t('Domain') ?></th><th scope="col"><?= t('Tárgy minta') ?></th>
            <th scope="col"><?= t('Üzenetek') ?></th>
            <th scope="col"><?= t('Először látva') ?></th><th scope="col"><?= t('Utoljára látva') ?></th>
            <th scope="col"><?= t('Művelet') ?></th>
        </tr></thead>
        <tbody>
        <?php foreach ($campaigns as $c): ?>
        <tr class="data-row">
            <td style="font-family:monospace;word-break:break-all"><?= h($c['from_domain']) ?></td>
            <?php /* subject_sample is raw sender-controlled text in a
                     table-layout:fixed 30% column. Without a wrap rule a
                     subject containing no whitespace bleeds straight out of
                     the cell: measured 557.6px past the cell box at 1024px
                     (Range.getBoundingClientRect, since scrollWidth cannot
                     see this under table-layout:fixed) and it took the whole
                     page into horizontal overflow. overflow-wrap:anywhere,
                     NOT the blanket .list-table rule that was tried and
                     reverted (see layout_head.php) -- scoped to this one
                     prose cell, and measured NOT to change rendering of
                     ordinary or hyphenated subjects at 1024/1280/1400px. */ ?>
            <td style="overflow-wrap:anywhere"><?= h($c['subject_sample']) ?></td>
            <td><?= (int) $c['message_count'] ?></td>
            <td class="local-ts" data-ts="<?= (int) $c['first_seen_at'] ?>"><?= h(date('Y-m-d H:i', (int) $c['first_seen_at'])) ?></td>
            <td class="local-ts" data-ts="<?= (int) $c['last_seen_at'] ?>"><?= h(date('Y-m-d H:i', (int) $c['last_seen_at'])) ?></td>
            <td>
                <?php if (in_array($c['from_domain'], $campaign_ioc_domains, true)): ?>
                <span style="color:#27ae60;font-weight:600"><svg class="icon"><use href="#icon-check"></use></svg> <?= h(t('IOC hozzáadva')) ?></span>
                <?php else: ?>
                <form method="post" action="?campaigns=1" style="display:inline">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="campaign_add_ioc">
                    <input type="hidden" name="campaign_id" value="<?= (int) $c['id'] ?>">
                    <button type="submit" class="btn btn-sm btn-secondary"><?= t('Hozzáadás IOC-ként') ?></button>
                </form>
                <?php endif; ?>
                <form method="post" action="?campaigns=1" style="display:inline"
                      onsubmit="return confirm('<?= h(t('Elveti ezt a kampányt?')) ?>')">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="campaign_dismiss">
                    <input type="hidden" name="campaign_id" value="<?= (int) $c['id'] ?>">
                    <button type="submit" class="btn btn-sm btn-secondary"><?= t('Elvetés') ?></button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>
