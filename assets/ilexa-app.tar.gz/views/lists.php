<!-- ── Block/white-list view ── -->
<?php
    $which     = $is_white ? 'white' : 'block';
    $L_entries = list_load($which);
    $L_icon    = $is_white ? '<svg class="icon"><use href="#icon-check"></use></svg>' : '<svg class="icon"><use href="#icon-block"></use></svg>';
    $L_title   = $is_white ? t('Feladó engedélyezése (fehérlista)') : t('Feladó blokkolása');
    $L_added   = $is_white ? t('a fehérlistához') : t('a blokklistához');
    $L_listh   = $is_white ? t('Fehérlista') : t('Blokklista');
    $L_empty   = $is_white ? t('A fehérlista üres.') : t('A blokklista üres.');
    $L_placeholder = $is_white
        ? t('pl. sajatceg.hu · partner@sajatceg.hu · *@sajatceg.hu · 203.0.113.7')
        : t('pl. spamdomain.hu · rossz@spamdomain.hu · *@spamdomain.hu · 203.0.113.7');
    $back      = $is_white ? '?white=1' : '?block=1';

    // Search (pattern-only, case-insensitive substring) + pagination.
    $L_q = trim((string) ($_GET['lq'] ?? ''));
    if ($L_q !== '') {
        $L_entries = array_values(array_filter(
            $L_entries,
            fn($e) => mb_stripos((string) ($e['pattern'] ?? ''), $L_q) !== false
        ));
    }
    $L_total    = count($L_entries);
    $L_pages    = max(1, (int) ceil($L_total / QA_PER_PAGE_LISTS));
    $L_page     = max(1, min($L_pages, (int) ($_GET['lp'] ?? 1)));
    $L_rows     = array_slice($L_entries, ($L_page - 1) * QA_PER_PAGE_LISTS, QA_PER_PAGE_LISTS);
    $L_qs_key   = $is_white ? 'white' : 'block';
    $L_url      = fn(int $p): string => '?' . http_build_query(array_filter([
        $L_qs_key => 1, 'lq' => $L_q, 'lp' => $p,
    ]));
?>
<h1 class="page-title"><?= h($L_title) ?></h1>
<?php if (can('lists')): ?>
<p class="filter-hint" style="margin-bottom:16px">
<?php if ($is_white): ?>
    <?= t('A fehérlistás feladó/IP') ?> <strong><?= t('erősen negatív pontszámot') ?></strong> <?= t('kap (soha nem lesz spamként jelölve/elutasítva) - de a vírus-, tiltott csatolmány- és blokklista-tiltás továbbra is érvényes. Egyezés a') ?> <strong><?= t('boríték- és From-feladóra') ?></strong> <?= t('és az') ?>
    <strong><?= t('IP-re') ?></strong><?= t(' is.') ?>
<?php else: ?>
    <?= t('A blokkolt feladó/IP levele') ?> <strong><?= t('SMTP-szinten elutasításra kerül') ?></strong> <?= t('(5xx; a feladó bounce-t kap) - az egyezést a') ?> <strong><?= t('boríték-feladóra, a látható From: fejlécre és az IP-re') ?></strong> <?= t('is vizsgáljuk.') ?>
<?php endif; ?>
    <strong>Domain</strong> <?= t('= a domain és aldomainjei;') ?> <strong><?= t('Cím') ?></strong> = <?= t('pontos e-mail;') ?>
    <strong><?= t('Minta') ?></strong> = <code>*</code> <?= t('tetszőleges részt jelöl;') ?> <strong>IP</strong> <?= t('= cím vagy CIDR (pl.') ?> <code>203.0.113.0/24</code>).
</p>
<?php endif; ?>
<div class="filter-card" style="margin-bottom:12px">
    <form method="get" action="<?= $back ?>" class="lists-search-form">
        <input type="hidden" name="<?= h($which) ?>" value="1">
        <div class="filter-row">
            <div class="filter-group" style="flex:2 1 260px">
                <label for="lq"><?= t('Keresés a mintában') ?></label>
                <input type="text" name="lq" id="lq" value="<?= h($L_q) ?>" placeholder="<?= h($is_white ? t('pl. sajatceg.hu') : t('pl. spamdomain.hu')) ?>">
            </div>
            <div class="filter-group">
                <label>&nbsp;</label>
                <button type="submit" class="btn btn-secondary"><?= t('Keresés') ?></button>
            </div>
        </div>
    </form>
</div>
<?php if (can('lists')): ?>
<div class="filter-card">
    <?php if (isset($_GET['ok'])): ?>
        <p class="filter-hint" style="color:#137333"><svg class="icon"><use href="#icon-check"></use></svg> <?= t('A minta hozzáadva') ?> <?= h($L_added) ?>.</p>
    <?php elseif (isset($_GET['err'])): ?>
        <p class="filter-hint" style="color:#b00020"><svg class="icon"><use href="#icon-warning"></use></svg> <?= h((string) $_GET['err']) ?></p>
    <?php endif; ?>
    <form method="post" action="<?= $back ?>">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="list_add">
        <input type="hidden" name="which" value="<?= $which ?>">
        <div class="filter-row">
            <div class="filter-group">
                <label for="b_type"><?= t('Típus') ?></label>
                <select name="b_type" id="b_type">
                    <option value="domain"><?= t('Domain (aldomainekkel)') ?></option>
                    <option value="address"><?= t('E-mail cím (pontos)') ?></option>
                    <option value="wildcard"><?= t('Minta (* helyettesítő)') ?></option>
                    <option value="ip"><?= t('IP-cím / tartomány') ?></option>
                </select>
            </div>
            <div class="filter-group" style="flex:2 1 320px">
                <label for="b_pattern"><?= t('Minta') ?></label>
                <input type="text" name="b_pattern" id="b_pattern" required
                       placeholder="<?= h($L_placeholder) ?>">
                <div id="lcheck-msg" style="font-size:.78rem;margin-top:4px"></div>
            </div>
            <div class="filter-group">
                <label>&nbsp;</label>
                <button type="button" id="presubmit-lookup-btn" class="btn btn-sm btn-secondary"><svg class="icon"><use href="#icon-search"></use></svg> <?= t('Hírnév ellenőrzése') ?></button>
                <div id="presubmit-lookup-result" style="font-size:.78rem;margin-top:4px"></div>
            </div>
            <div class="filter-group">
                <label>&nbsp;</label>
                <button type="submit" class="btn btn-primary"><?= $L_icon ?> <?= t('Hozzáadás') ?></button>
            </div>
        </div>
    </form>
</div>
<?php endif; ?>

<div class="results-card">
    <div class="results-header">
        <h2><?= h($L_listh) ?></h2>
        <span class="meta"><?= number_format($L_total) ?> <?= t('tétel') ?></span>
    </div>
    <?php if (!$L_rows): ?>
        <div class="empty-state"><p><?= h($L_q !== '' ? t('Nincs találat a megadott szűrőkre.') : $L_empty) ?></p></div>
    <?php else: ?>
    <table class="msg-table list-table" style="table-layout:fixed">
        <colgroup>
            <col style="width:28%"><col style="width:9%"><col style="width:16%">
            <col style="width:17%"><col style="width:110px"><col style="width:90px"><col style="width:120px">
        </colgroup>
        <thead><tr><th scope="col"><?= t('Minta') ?></th><th scope="col"><?= t('Típus') ?></th><th scope="col"><?= t('Hozzáadta') ?></th><th scope="col"><?= t('Mikor') ?></th><th scope="col"></th><th scope="col" style="white-space:normal;overflow-wrap:anywhere"><?= t('Összesített %') ?></th><th scope="col"><?= t('Hírnév') ?></th></tr></thead>
        <tbody>
        <?php
        // Same four sprite symbols the IOC page uses, so both pages read as one
        // family. All are fill="none" stroke="currentColor", so they inherit the
        // .verdict box's colour.
        ?>
        <?php foreach ($L_rows as $i => $e): $key = $e['regex'] ?? ($e['ip'] ?? '');
            $eff = list_lookup_effective_value((string)($e['type'] ?? ''), (string)($e['pattern'] ?? ''));
            // Filtered at the assignment (not just at ioc_lookup_confidence()
            // below) so the icon list and the percentage always agree -- the
            // AJAX path (list_lookup_run(), via ioc_lookup_services_for())
            // is already enablement-filtered; the server render was not,
            // so a since-disabled service's stale icon/score would show
            // here and vanish on the next Ellenőrzés click. Mirrors
            // views/ioc.php:180's array_intersect_key() pattern.
            // The 'lists' surface is REQUIRED here, not decorative: without it
            // this defaults to 'ioc', and a service scoped away from the list
            // pages (url.vet) would survive the intersect and render an icon
            // plus a weighted score that the AJAX path then drops -- the exact
            // failure this filter exists to prevent. Reachable because
            // quar_lookup writes into the same list_lookups table, so a domain
            // both reported as spam and present on a list carries a cached row.
            $L_cached = $eff ? array_intersect_key(list_lookup_cached($eff[0], $eff[1]),
                                   array_flip(ioc_lookup_services_for($eff[0], 'lists'))) : [];
            $L_conf   = ioc_lookup_confidence($L_cached);
            $L_iocRow = list_ioc_cross_reference((string)($e['type'] ?? ''), (string)($e['pattern'] ?? ''));
            $rowId = h($which) . '-' . $i;
        ?>
            <tr class="data-row">
                <td data-label="<?= h(t('Minta')) ?>" style="text-align:left">
                    <code style="overflow-wrap:anywhere"><?= h((string) ($e['pattern'] ?? '')) ?></code>
                    <?php if (can('lists') && $L_iocRow): ?>
                    <span class="verdict verdict-suspicious" style="display:inline-block;margin-left:4px"><?= t('Ismert IOC') ?></span>
                    <?php endif; ?>
                </td>
                <td data-label="<?= h(t('Típus')) ?>"><?= h(['domain' => 'Domain', 'address' => t('Cím'), 'wildcard' => t('Minta'), 'ip' => 'IP'][$e['type'] ?? ''] ?? (string) ($e['type'] ?? '')) ?></td>
                <td data-label="<?= h(t('Hozzáadta')) ?>"><?= h((string) ($e['by'] ?? '')) ?></td>
                <td class="local-ts" data-label="Mikor" data-ts="<?= isset($e['at']) ? (int)$e['at'] : 0 ?>"><?= isset($e['at']) ? h(date('Y-m-d H:i', (int) $e['at'])) : '' ?></td>
                <td data-label="">
                    <?php if (can('lists')): ?>
                    <form method="post" action="<?= $back ?>" onsubmit="return confirm('<?= t('Törlöd ezt a tételt?') ?>');" style="margin:0">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="list_remove">
                        <input type="hidden" name="which" value="<?= $which ?>">
                        <input type="hidden" name="b_key" value="<?= h((string) $key) ?>">
                        <button type="submit" class="btn btn-sm btn-secondary"><svg class="icon"><use href="#icon-trash"></use></svg> <?= t('Törlés') ?></button>
                    </form>
                    <?php endif; ?>
                </td>
                <td data-label="<?= t('Összesített %') ?>" id="list-conf-<?= h($rowId) ?>">
                    <?php if (can('lists') && $L_conf !== null): ?>
                    <span class="conf-<?= h($L_conf['tier']) ?>" title="<?= h($L_conf['title'] ?? '') ?>"><?= (int)$L_conf['pct'] ?>%</span>
                    <?php endif; ?>
                </td>
                <td data-label="<?= t('Hírnév') ?>" id="list-rep-<?= h($rowId) ?>">
                    <?php if (can('lists')): foreach ($L_cached as $svc => $lk):
                        // Every service's icon shares this one cell, so unlike the IOC
                        // page (where the column header names the service) the tooltip
                        // must carry it. No local-ts-title/data-ts here: that class's
                        // page-load JS would overwrite the whole title with just a date.
                        $L_detail_prefix = $lk['detail'] !== '' ? $lk['detail'] . ' — ' : '';
                        $L_title = $svc . ' — ' . $lk['verdict'] . ' — ' . $L_detail_prefix . date('Y-m-d H:i', (int)$lk['checked_at']);
                        $L_icon  = QA_VERDICT_ICON[$lk['verdict']] ?? 'icon-info';
                    ?>
                    <span class="verdict verdict-<?= h($lk['verdict']) ?>" title="<?= h($L_title) ?>" aria-label="<?= h($svc . ': ' . $lk['verdict']) ?>"><svg class="icon"><use href="#<?= h($L_icon) ?>"></use></svg></span>
                    <?php endforeach; endif; ?>
                    <?php if (can('lists') && $eff): ?>
                    <form method="post" action="<?= $back ?>" class="list-lookup-form" data-row-id="<?= h($rowId) ?>" style="margin:0">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="list_lookup">
                        <input type="hidden" name="which" value="<?= $which ?>">
                        <input type="hidden" name="l_type" value="<?= h((string)($e['type'] ?? '')) ?>">
                        <input type="hidden" name="l_pattern" value="<?= h((string)($e['pattern'] ?? '')) ?>">
                        <button type="submit" class="btn btn-sm btn-secondary"><svg class="icon"><use href="#icon-search"></use></svg> <?= t('Ellenőrzés') ?></button>
                    </form>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php if (can('lists')): ?>
    <div class="filter-hint" style="margin:12px 20px 4px">
<?php
        $L_legend_labels = ['malicious' => t('kártékony'), 'suspicious' => t('gyanús'), 'clean' => t('tiszta'), 'unknown' => t('ismeretlen')];
        $L_legend_i = 0; $L_legend_n = count(QA_VERDICT_ICON);
        foreach (QA_VERDICT_ICON as $L_legend_v => $L_legend_ic) {
            $L_legend_i++;
            // ?? $L_legend_v: a verdict added to QA_VERDICT_ICON without a
            // matching entry here labels itself instead of emitting
            // "Undefined array key" and rendering blank -- see the
            // co-dependency note on QA_VERDICT_ICON (src/ioc_lookup.php).
            echo '        <span class="verdict verdict-' . $L_legend_v . '" style="font-size:1.3em"><svg class="icon"><use href="#' . $L_legend_ic . '"></use></svg></span> ' . ($L_legend_labels[$L_legend_v] ?? $L_legend_v);
            // The leading spaces and trailing \n below are byte-significant:
            // PHP's closing tag above swallows one newline, so this literal
            // reproduces the pre-refactor template's exact output bytes.
            // Do not "tidy" this string without re-checking that fact.
            if ($L_legend_i < $L_legend_n) echo "        &nbsp;·&nbsp;\n";
        }
?>
        <br><?= t('Üres Hírnév oszlop = még nincs ellenőrizve. Vigye az egeret egy ikon fölé a szolgáltatás nevéért és a részletekért.') ?>
    </div>
    <?php endif; ?>
    <?php if ($L_pages > 1): ?>
    <div class="results-footer"><?= render_pager($L_page, $L_pages, $L_url, number_format($L_total) . ' ' . t('tétel')) ?></div>
    <?php endif; ?>
    <?php endif; ?>
</div>
