<?php
// Audit napló -- its own page: ?audit=ops | ?audit=config | ?audit=logins.
// Reached only when can('admin') (index.php gates it).
//
// From index.php: $audit_tab, $audit_page_data (audit_ops_page()'s result,
// ops/config tabs only), $audit_action, and for the logins tab the same
// variables as always ($admin_logins, $admin_login_failures,
// $mail_auth_failures, $mail_auth_successes, $audit_rows, $audit_error,
// $al_/af_/mf_/ms_/ul_ page/total/total_pages, $ms_anom).
//
// Everything below is markup. Field values come from the audit log, which
// carries operator input and mail-derived data (sender patterns, mailbox
// names, brand phrases): every one is h()-escaped, and audit_normalise_row()
// has already bounded each to ~200 characters.

$audit_tab = in_array($audit_tab ?? '', ['ops', 'config', 'logins'], true) ? $audit_tab : 'ops';
$apd = (isset($audit_page_data) && is_array($audit_page_data) ? $audit_page_data : []) + [
    'rows' => [], 'total' => 0, 'actions' => [], 'action' => (string) ($audit_action ?? ''),
    'page' => 1, 'pages' => 1, 'per_page' => (int) ($per_page ?? 25), 'unreadable' => false,
];
$audit_tabs = [
    'ops'    => ['mail',   t('Spam műveletek')],
    'config' => ['server', t('Konfiguráció')],
    'logins' => ['user',   t('Bejelentkezések')],
];
?>
<h1 class="page-title"><?= h(t('Audit napló')) ?></h1>

<?php if ($audit_tab !== 'logins' && $apd['unreadable']): ?>
<div class="notice notice-err" role="alert"><?= h(t('Az audit-napló nem olvasható.')) ?> <?= h(t('Ellenőrizze a naplófájl tulajdonosát és jogosultságait.')) ?></div>
<?php endif; ?>

<div class="results-card">
    <nav class="tabbar" aria-label="<?= h(t('Audit napló')) ?>">
        <?php foreach ($audit_tabs as $tab_key => [$tab_icon, $tab_label]): $tab_on = $audit_tab === $tab_key; ?>
        <a href="<?= h(audit_url($tab_key, 1)) ?>" class="tab<?= $tab_on ? ' active' : '' ?>"<?= $tab_on ? ' aria-current="page"' : '' ?>><svg class="icon" aria-hidden="true"><use href="#icon-<?= $tab_icon ?>"></use></svg> <?= h($tab_label) ?></a>
        <?php endforeach; ?>
    </nav>

    <?php if ($audit_tab === 'logins'):
        // Preserves the OTHER sections' current page while changing just the
        // one being paged -- without this, clicking "next" on one list would
        // silently reset the others back to page 1. The fragment names the
        // section being paged: it reopens that <details> after the reload
        // (layout_foot.php opens the section a #hash names), which the old
        // #audit anchor used to do for the whole fold on the Rendszer page.
        $login_url = function (string $which, int $p) use ($al_page, $af_page, $mf_page, $ms_page, $ul_page, $ms_anom): string {
            $params = ['audit' => 'logins',
                       'al_page' => $al_page, 'af_page' => $af_page,
                       'mf_page' => $mf_page, 'ms_page' => $ms_page, 'ul_page' => $ul_page];
            if ($ms_anom) $params['ms_anom'] = '1';
            $params[$which] = $p;
            return '?' . http_build_query($params) . '#' . substr($which, 0, 2) . '-section';
        };
        $ip_flag = function (string $ip): string {
            return $ip !== '' ? qa_country_flag(qa_ip_country($ip), $ip) . ' ' : '';
        };
        // Hint text + a CSV link exporting the WHOLE list, independent of
        // this section's own 10-per-page display pagination -- same
        // relationship the Archívum/Spam-műveletek CSV buttons already have
        // to their own paginated tables.
        $hint_csv = function (string $hint, string $exportType): void {
            echo '<div style="display:flex;align-items:center;justify-content:space-between;gap:12px;padding:6px 16px 0;flex-wrap:wrap">'
               . '<p class="filter-hint" style="margin:0">' . $hint . '</p>'
               . '<a class="btn btn-sm btn-secondary" href="?export=' . h($exportType) . '"'
               . ' title="' . h(t('A teljes lista, ezen oldalszámozástól függetlenül, CSV-be')) . '">'
               . '<svg class="icon"><use href="#icon-download"></use></svg> CSV</a></div>';
        };
    ?>
        <details class="sys-sec" id="af-section" style="margin:16px 16px 0">
            <summary class="results-header" style="padding:8px 12px">
                <h2 style="margin:0;font-size:1em;color:#b91c1c"><svg class="icon"><use href="#icon-warning"></use></svg> <?= h(t('Sikertelen admin belépési kísérletek')) ?> - <?= h(SITE_TITLE) ?></h2>
                <?php if ($af_total > 0): ?><span class="sys-sec-flag"><?= sprintf(t('%d kísérlet'), $af_total) ?></span><?php endif; ?>
            </summary>
            <?php $hint_csv(t('Hibás jelszóval vagy ismeretlen felhasználónévvel tett kísérletek, a webszerver hibanaplójából. A legutóbbi 8 nap.'), 'admin_login_failures'); ?>
            <?php if (!$admin_login_failures): ?>
            <div class="empty-state"><p><?= t('Nincs rögzített sikertelen admin belépési kísérlet.') ?></p></div>
            <?php else: ?>
            <div class="table-scroll">
            <table>
                <thead><tr><th scope="col"><?= t('Időpont') ?></th><th scope="col"><?= t('Megadott felhasználó') ?></th><th scope="col"><?= t('Forrás IP') ?></th><th scope="col"><?= t('Ok') ?></th><th scope="col"><?= t('Mikor') ?></th></tr></thead>
                <tbody>
                <?php foreach ($admin_login_failures as $f): ?>
                    <tr class="data-row">
                        <td class="col-date local-ts" data-label="<?= h(t('Időpont')) ?>" data-ts="<?= (int)$f['ts'] ?>"><?= h(date('Y-m-d H:i:s', $f['ts'])) ?></td>
                        <td class="col-user" data-label="<?= h(t('Megadott felhasználó')) ?>"><?= h($f['user']) ?></td>
                        <td data-label="<?= h(t('Forrás IP')) ?>"><?= $ip_flag($f['ip']) ?><?= h($f['ip']) ?></td>
                        <td data-label="<?= h(t('Ok')) ?>" style="color:#b91c1c"><?= h($f['reason']) ?></td>
                        <td data-label="<?= h(t('Mikor')) ?>" style="color:#888"><?= h(rel_time($f['ts'])) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
            <?php if ($af_total_pages > 1): ?>
            <div class="results-footer"><?= render_pager($af_page, $af_total_pages, fn($p) => $login_url('af_page', $p), number_format($af_total) . ' ' . t('tétel')) ?></div>
            <?php endif; ?>
            <?php endif; ?>
        </details>

        <details class="sys-sec" id="mf-section" style="margin:16px 16px 0">
            <summary class="results-header" style="padding:8px 12px">
                <h2 style="margin:0;font-size:1em;color:#b91c1c"><svg class="icon"><use href="#icon-warning"></use></svg> <?= t('Sikertelen POP3/IMAP/Webmail bejelentkezések') ?></h2>
                <?php if ($mf_total > 0): ?><span class="sys-sec-flag"><?= sprintf(t('%d kísérlet'), $mf_total) ?></span><?php endif; ?>
            </summary>
            <?php $hint_csv(t('Hibás jelszóval tett kísérletek levelesláda-fiókok ellen, a levelezőszerver naplójából. A Webmail forrás a valódi böngésző-oldali IP-t mutatja, nem a webmail szerver saját (loopback) IP-jét. A legutóbbi 8 nap.'), 'mail_auth_failures'); ?>
            <?php if (!$mail_auth_failures): ?>
            <div class="empty-state"><p><?= t('Nincs rögzített sikertelen bejelentkezés.') ?></p></div>
            <?php else: ?>
            <div class="table-scroll">
            <table>
                <thead><tr><th scope="col"><?= t('Időpont') ?></th><th scope="col"><?= t('Felhasználó') ?></th><th scope="col"><?= t('Forrás IP') ?></th><th scope="col"><?= t('Forrás') ?></th><th scope="col"><?= t('Mikor') ?></th></tr></thead>
                <tbody>
                <?php foreach ($mail_auth_failures as $f): ?>
                    <tr class="data-row">
                        <td class="col-date local-ts" data-label="<?= h(t('Időpont')) ?>" data-ts="<?= (int)$f['ts'] ?>"><?= h(date('Y-m-d H:i:s', $f['ts'])) ?></td>
                        <td class="col-user" data-label="<?= h(t('Felhasználó')) ?>"><?= h($f['user']) ?></td>
                        <td data-label="<?= h(t('Forrás IP')) ?>"><?= $ip_flag($f['ip']) ?><?= h($f['ip']) ?></td>
                        <td data-label="<?= h(t('Forrás')) ?>"><span class="folder-tag folder-<?= h($f['source']) ?>"><?= h($f['source']) ?></span></td>
                        <td data-label="<?= h(t('Mikor')) ?>" style="color:#888"><?= h(rel_time($f['ts'])) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
            <?php if ($mf_total_pages > 1): ?>
            <div class="results-footer"><?= render_pager($mf_page, $mf_total_pages, fn($p) => $login_url('mf_page', $p), number_format($mf_total) . ' ' . t('tétel')) ?></div>
            <?php endif; ?>
            <?php endif; ?>
        </details>

        <details class="sys-sec" id="ms-section" style="margin:16px 16px 0">
            <summary class="results-header" style="padding:8px 12px">
                <h2 style="margin:0;font-size:1em;color:#1a3a5c"><svg class="icon"><use href="#icon-key"></use></svg> <?= t('Sikeres POP3/IMAP/Webmail bejelentkezések') ?></h2>
                <?php if ($ms_total > 0): ?><span class="sys-sec-flag"><?= sprintf(t('%d belépés'), $ms_total) ?></span><?php endif; ?>
            </summary>
            <?php $hint_csv(t('Sikeres bejelentkezések levelesláda-fiókokba, a levelezőszerver naplójából. A Webmail forrás a valódi böngésző-oldali IP-t mutatja, nem a webmail szerver saját (loopback) IP-jét. A legutóbbi 8 nap.'), 'mail_auth_successes'); ?>
            <div style="display:flex;align-items:center;gap:12px;padding:6px 16px 0">
                <?php $ms_anom_params = ['audit' => 'logins',
                                          'al_page' => $al_page, 'af_page' => $af_page,
                                          'mf_page' => $mf_page, 'ul_page' => $ul_page]; ?>
                <?php if ($ms_anom): ?>
                <a class="btn btn-sm btn-secondary" href="?<?= h(http_build_query($ms_anom_params)) ?>#ms-section"><?= t('Összes mutatása') ?></a>
                <?php else: ?>
                <?php $ms_anom_params['ms_anom'] = '1'; ?>
                <a class="btn btn-sm btn-secondary" href="?<?= h(http_build_query($ms_anom_params)) ?>#ms-section"><?= t('Csak a gyanús bejelentkezések') ?></a>
                <?php endif; ?>
            </div>
            <?php if (!$mail_auth_successes): ?>
            <div class="empty-state"><p><?= $ms_anom ? t('Nincs gyanús bejelentkezés a jelenlegi beállítások mellett.') : t('Nincs rögzített sikeres bejelentkezés.') ?></p></div>
            <?php else: ?>
            <div class="table-scroll">
            <table>
                <thead><tr><th scope="col"><?= t('Időpont') ?></th><th scope="col"><?= t('Felhasználó') ?></th><th scope="col"><?= t('Forrás IP') ?></th><th scope="col"><?= t('Forrás') ?></th><th scope="col"><?= t('Kockázat') ?></th><th scope="col"><?= t('Mikor') ?></th></tr></thead>
                <tbody>
                <?php foreach ($mail_auth_successes as $s): ?>
                    <tr class="data-row">
                        <td class="col-date local-ts" data-label="<?= h(t('Időpont')) ?>" data-ts="<?= (int)$s['ts'] ?>"><?= h(date('Y-m-d H:i:s', $s['ts'])) ?></td>
                        <td class="col-user" data-label="<?= h(t('Felhasználó')) ?>"><?= h($s['user']) ?></td>
                        <td data-label="<?= h(t('Forrás IP')) ?>"><?= $ip_flag($s['ip']) ?><?= h($s['ip']) ?></td>
                        <td data-label="<?= h(t('Forrás')) ?>"><span class="folder-tag folder-<?= h($s['source']) ?>"><?= h($s['source']) ?></span></td>
                        <td data-label="<?= h(t('Kockázat')) ?>">
                            <?php if ($s['tier'] === null): ?>
                            <span style="color:var(--text-subtle)">&ndash;</span>
                            <?php else:
                                $ms_reason_title = implode('; ', array_map(fn($r) => t($r['label']) . ' (' . ($r['weight'] > 0 ? '+' : '') . $r['weight'] . ')', $s['reasons']));
                                $ms_tier_label = $s['tier'] === 'learning' ? t('tanulás') : $s['score'] . '%';
                            ?>
                            <span class="conf-<?= h($s['tier']) ?>" title="<?= h($ms_reason_title) ?>"><?= h($ms_tier_label) ?></span>
                            <?php endif; ?>
                        </td>
                        <td data-label="<?= h(t('Mikor')) ?>" style="color:#888"><?= h(rel_time($s['ts'])) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
            <?php if ($ms_total_pages > 1): ?>
            <div class="results-footer"><?= render_pager($ms_page, $ms_total_pages, fn($p) => $login_url('ms_page', $p), number_format($ms_total) . ' ' . t('tétel')) ?></div>
            <?php endif; ?>
            <?php endif; ?>
        </details>

        <details class="sys-sec" id="al-section" style="margin:16px 16px 0">
            <summary class="results-header" style="padding:8px 12px">
                <h2 style="margin:0;font-size:1em;color:#1a3a5c"><svg class="icon"><use href="#icon-key"></use></svg> <?= h(t('Admin belépések')) ?> - <?= h(SITE_TITLE) ?></h2>
                <?php if ($al_total > 0): ?><span class="sys-sec-flag"><?= sprintf(t('%d belépés'), $al_total) ?></span><?php endif; ?>
            </summary>
            <?php $hint_csv(h(t('Sikeres')) . ' <strong>' . t('rendszergazdai belépések') . '</strong> '
                . t('ehhez a felülethez, a webszerver hozzáférési naplójából származtatva, ~30 perces munkamenetekre bontva (nem minden kérés külön).'),
                'admin_logins'); ?>
            <?php if (!$admin_logins): ?>
            <div class="empty-state"><p><?= t('Nincs rögzített admin belépés a naplóban.') ?></p></div>
            <?php else: ?>
            <div class="table-scroll">
            <table>
                <thead><tr><th scope="col"><?= t('Belépés') ?></th><th scope="col"><?= t('Admin') ?></th><th scope="col"><?= t('Forrás IP') ?></th><th scope="col"><?= t('Kérések') ?></th><th scope="col"><?= t('Mikor') ?></th></tr></thead>
                <tbody>
                <?php foreach ($admin_logins as $s): ?>
                    <tr class="data-row">
                        <td class="col-date local-ts" data-label="<?= h(t('Belépés')) ?>" data-ts="<?= (int)$s['start'] ?>"><?= h(date('Y-m-d H:i:s', $s['start'])) ?></td>
                        <td class="col-user" data-label="<?= h(t('Admin')) ?>"><?= h($s['user']) ?></td>
                        <td data-label="<?= h(t('Forrás IP')) ?>"><?= $ip_flag($s['ip']) ?><?= h($s['ip']) ?></td>
                        <td data-label="<?= h(t('Kérések')) ?>" style="color:#666"><?= (int)$s['hits'] ?></td>
                        <td data-label="<?= h(t('Mikor')) ?>" style="color:#888"><?= h(rel_time($s['start'])) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
            <?php if ($al_total_pages > 1): ?>
            <div class="results-footer"><?= render_pager($al_page, $al_total_pages, fn($p) => $login_url('al_page', $p), number_format($al_total) . ' ' . t('tétel')) ?></div>
            <?php endif; ?>
            <?php endif; ?>
        </details>

        <details class="sys-sec" id="ul-section" style="margin:16px 16px 0">
            <summary class="results-header" style="padding:8px 12px">
                <h2 style="margin:0;font-size:1em;color:#1a3a5c"><svg class="icon"><use href="#icon-user"></use></svg> <?= t('Felhasználók utolsó belépése') ?></h2>
                <?php if ($ul_total > 0): ?><span class="sys-sec-flag"><?= sprintf(t('%d felhasználó'), $ul_total) ?></span><?php endif; ?>
            </summary>
            <?php if ($audit_error): ?>
            <div class="empty-state"><div style="font-size:2em"><svg class="icon"><use href="#icon-warning"></use></svg></div><p><?= h($audit_error) ?></p></div>
            <?php elseif (!$audit_rows): ?>
            <div class="empty-state"><p><?= t('Nincs bejelentkezési adat.') ?></p></div>
            <?php else: ?>
            <?php $hint_csv(t('Utolsó bejelentkezés') . ' <strong>' . t('felhasználónként') . '</strong> ' . t('(pillanatkép, nem eseménynapló).'), 'user_logins'); ?>
            <div class="table-scroll">
            <table>
                <thead><tr><th scope="col"><?= t('Felhasználó') ?></th><th scope="col"><?= t('Utolsó bejelentkezés') ?></th><th scope="col"><?= t('Mikor') ?></th></tr></thead>
                <tbody>
                <?php foreach ($audit_rows as $r): $t = (int)$r['last_login']; ?>
                    <tr class="data-row">
                        <td class="col-user" data-label="<?= h(t('Felhasználó')) ?>"><?= h($r['username']) ?></td>
                        <td class="col-date local-ts" data-label="<?= h(t('Utolsó belépés')) ?>" data-ts="<?= $t ?>"><?= h(date('Y-m-d H:i:s', $t)) ?></td>
                        <td data-label="<?= h(t('Mikor')) ?>" style="color:#888"><?= h(rel_time($t)) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
            <?php if ($ul_total_pages > 1): ?>
            <div class="results-footer"><?= render_pager($ul_page, $ul_total_pages, fn($p) => $login_url('ul_page', $p), number_format($ul_total) . ' ' . t('tétel')) ?></div>
            <?php endif; ?>
            <?php endif; ?>
        </details>

    <?php else: /* ops | config */
        $is_cfg   = $audit_tab === 'config';
        $a_rows   = $apd['rows'];
        $a_total  = (int) $apd['total'];
        $a_page   = (int) $apd['page'];
        $a_pages  = (int) $apd['pages'];
        $a_pp     = max(1, (int) $apd['per_page']);
        $a_action = (string) $apd['action'];
        $a_sel_id = 'audit-action-f';
    ?>
        <div class="results-header" style="flex-wrap:wrap;gap:12px">
            <form method="get" action="" class="filter-row" style="flex:1 1 auto;align-self:stretch;min-width:0;max-width:560px">
                <input type="hidden" name="audit" value="<?= h($audit_tab) ?>">
                <div class="filter-group">
                    <label for="<?= $a_sel_id ?>"><?= t('Művelet típusa') ?></label>
                    <select name="action_f" id="<?= $a_sel_id ?>">
                        <option value=""><?= h(t('- összes művelet -')) ?></option>
                        <?php foreach ($apd['actions'] as $a_code => $a_label): ?>
                        <option value="<?= h((string) $a_code) ?>"<?= (string) $a_code === $a_action ? ' selected' : '' ?>><?= h($a_label) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="filter-group">
                    <label aria-hidden="true">&nbsp;</label>
                    <button type="submit" class="btn btn-primary"><?= t('Szűrés') ?></button>
                </div>
                <?php if ($a_action !== ''): ?>
                <div class="filter-group">
                    <label aria-hidden="true">&nbsp;</label>
                    <a class="btn" href="<?= h(audit_url($audit_tab, 1)) ?>"><?= t('Szűrők törlése') ?></a>
                </div>
                <?php endif; ?>
            </form>
            <div style="display:flex;align-items:center;gap:12px">
                <span class="meta">
                    <?php if ($a_total > 0): ?>
                        <?= (($a_page - 1) * $a_pp) + 1 ?>&ndash;<?= min($a_page * $a_pp, $a_total) ?> / <?= $a_total ?> <?= t('tétel') ?>
                    <?php else: ?><?= t('0 tétel') ?><?php endif; ?>
                </span>
                <?php // The export is the whole log, both tabs, in its fixed column format (see src/actions.php). ?>
                <a class="btn btn-sm btn-secondary" href="?export=audit" title="<?= h(t('A teljes audit-napló exportálása CSV-be (minden művelettípus)')) ?>"><svg class="icon" aria-hidden="true"><use href="#icon-download"></use></svg> CSV</a>
            </div>
        </div>

        <?php if (!$a_rows): ?>
        <div class="empty-state"><div style="font-size:2em"><svg class="icon" aria-hidden="true"><use href="#icon-<?= $is_cfg ? 'server' : 'mail' ?>"></use></svg></div>
            <p><?= $a_action !== '' ? t('Nincs a szűrésnek megfelelő bejegyzés.')
                  : ($is_cfg ? t('Még nincs rögzített konfigurációs művelet.') : t('Még nincs rögzített spam-művelet.')) ?></p></div>
        <?php elseif ($is_cfg): ?>
        <div class="table-scroll">
        <table>
            <thead><tr>
                <th scope="col"><?= t('Idő') ?></th><th scope="col"><?= t('Művelet') ?></th><th scope="col"><?= t('Cél') ?></th>
                <th scope="col"><?= t('Részletek') ?></th><th scope="col"><?= t('Eredmény') ?></th>
                <th scope="col"><?= t('Admin') ?></th><th scope="col"><?= t('IP') ?></th>
            </tr></thead>
            <tbody>
            <?php foreach ($a_rows as $r):
                $res_cls = ['ok' => 'verdict-clean', 'err' => 'verdict-malicious'][$r['result_state']] ?? '';
            ?>
                <tr class="data-row">
                    <td class="col-date local-ts" data-label="<?= h(t('Idő')) ?>" data-ts="<?= (int)$r['time'] ?>"><?= h(date('Y-m-d H:i:s', (int)$r['time'])) ?></td>
                    <td data-label="<?= h(t('Művelet')) ?>" title="<?= h($r['code']) ?>"><?= h($r['label']) ?></td>
                    <td data-label="<?= h(t('Cél')) ?>" style="overflow-wrap:anywhere"><?= $r['target'] !== '' ? h($r['target']) : '&ndash;' ?></td>
                    <td data-label="<?= h(t('Részletek')) ?>" style="overflow-wrap:anywhere"><?= $r['detail'] !== '' ? h($r['detail']) : '&ndash;' ?></td>
                    <td data-label="<?= h(t('Eredmény')) ?>"><?php if ($res_cls !== ''): ?><span class="op-tag <?= $res_cls ?>"><?= h($r['result']) ?></span><?php elseif ($r['result'] !== ''): ?><?= h($r['result']) ?><?php else: ?>&ndash;<?php endif; ?></td>
                    <td data-label="<?= h(t('Admin')) ?>"><?= h($r['admin']) ?></td>
                    <td data-label="<?= h(t('IP')) ?>" style="color:#666"><?= h($r['ip']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <?php else: ?>
        <div class="table-scroll">
        <table>
            <thead><tr>
                <th scope="col"><?= t('Idő') ?></th><th scope="col"><?= t('Művelet') ?></th><th scope="col"><?= t('Felhasználó') ?></th>
                <th scope="col"><?= t('Mappa') ?></th><th scope="col"><?= t('UID') ?></th><th scope="col"><?= t('Admin') ?></th><th scope="col"><?= t('IP') ?></th>
            </tr></thead>
            <tbody>
            <?php foreach ($a_rows as $r):
                if ($r['code'] === 'release') {
                    $act = '<span class="op-tag op-release"><svg class="icon" aria-hidden="true"><use href="#icon-play"></use></svg> ' . h($r['label']) . '</span>';
                } elseif ($r['code'] === 'delete') {
                    $act = '<span class="op-tag op-delete"><svg class="icon" aria-hidden="true"><use href="#icon-x"></use></svg> ' . h($r['label']) . '</span>';
                } else {
                    $act = h($r['label']);
                }
            ?>
                <tr class="data-row">
                    <td class="col-date local-ts" data-label="<?= h(t('Idő')) ?>" data-ts="<?= (int)$r['time'] ?>"><?= h(date('Y-m-d H:i:s', (int)$r['time'])) ?></td>
                    <td data-label="<?= h(t('Művelet')) ?>" title="<?= h($r['code']) ?>"><div><?= $act ?><?php if ($r['note'] !== ''): ?><div class="from-email"><?= h($r['note']) ?></div><?php endif; ?></div></td>
                    <td class="col-user" data-label="<?= h(t('Felhasználó')) ?>" style="overflow-wrap:anywhere"><?= $r['user'] !== '' ? h($r['user']) : '&ndash;' ?></td>
                    <td data-label="<?= h(t('Mappa')) ?>"><?php if ($r['folder'] !== ''): ?><span class="folder-tag folder-<?= h($r['folder']) ?>"><?= h($r['folder']) ?></span><?php else: ?>&ndash;<?php endif; ?></td>
                    <td data-label="<?= h(t('UID')) ?>"><?= $r['uid'] !== '' ? h($r['uid']) : '&ndash;' ?></td>
                    <td data-label="<?= h(t('Admin')) ?>"><?= h($r['admin']) ?></td>
                    <td data-label="<?= h(t('IP')) ?>" style="color:#666"><?= h($r['ip']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <?php endif; ?>

        <?php if ($a_pages > 1): ?>
        <div class="results-footer"><?= render_pager($a_page, $a_pages, fn($p) => audit_url($audit_tab, $p, $a_action), number_format($a_total) . ' ' . t('tétel')) ?></div>
        <?php endif; ?>
    <?php endif; ?>
</div>
