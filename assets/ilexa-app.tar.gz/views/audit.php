<!-- ── Audit section (rendered inside views/admin_system.php's <details>) ──
     No <h1> here any more: this is no longer a page, and a second page-title
     inside the Rendszer page would give it two headings. -->
<div class="results-card">
    <div class="results-header">
        <div class="results-header-spacer"></div>
        <div style="display:flex;align-items:center;gap:12px">
            <?php if ($audit_tab === 'ops'): ?>
            <span class="meta">
                <?php if ($total > 0): ?>
                    <?= (($page - 1) * $per_page) + 1 ?>&ndash;<?= min($page * $per_page, $total) ?> / <?= $total ?> <?= t('tétel') ?>
                <?php else: ?><?= t('0 tétel') ?><?php endif; ?>
            </span>
            <a class="btn btn-sm btn-secondary" href="?export=audit" title="<?= h(t('Spam műveletek exportálása CSV-be')) ?>"><svg class="icon"><use href="#icon-download"></use></svg> CSV</a>
            <?php endif; ?>
        </div>
    </div>

    <div class="tabbar">
        <a href="?sysconfig=1&amp;audit=ops#audit"    class="tab <?= $audit_tab === 'ops'    ? 'active' : '' ?>"><svg class="icon"><use href="#icon-mail"></use></svg> <?= t('Spam műveletek') ?></a>
        <a href="?sysconfig=1&amp;audit=logins#audit" class="tab <?= $audit_tab === 'logins' ? 'active' : '' ?>"><svg class="icon"><use href="#icon-user"></use></svg> <?= t('Bejelentkezések') ?></a>
    </div>

    <?php if ($audit_tab === 'logins'):
        // Preserves the OTHER three sections' current page while changing
        // just the one being paged -- without this, clicking "next" on one
        // list would silently reset the other three back to page 1.
        $login_url = function (string $which, int $p) use ($al_page, $af_page, $mf_page, $ul_page): string {
            $params = ['sysconfig' => 1, 'audit' => 'logins',
                       'al_page' => $al_page, 'af_page' => $af_page,
                       'mf_page' => $mf_page, 'ul_page' => $ul_page];
            $params[$which] = $p;
            return '?' . http_build_query($params) . '#audit';
        };
        // Always collapsed on load, even mid-pagination -- every collapsible
        // section on every page starts closed on every visit, no exceptions;
        // paging within a section re-collapses it same as any other reload.
        $ip_flag = function (string $ip): string {
            return $ip !== '' ? qa_country_flag(qa_ip_country($ip), $ip) . ' ' : '';
        };
        // Hint text + a CSV link exporting the WHOLE list, independent of
        // this section's own 10-per-page display pagination -- same
        // relationship the Archívum/Spam-műveletek CSV buttons already have
        // to their own paginated tables.
        $hint_csv = function (string $hint, string $exportType): void {
            echo '<div style="display:flex;align-items:center;justify-content:space-between;gap:12px;padding:6px 16px 0;flex-wrap:wrap">'
               . '<p class="filter-hint" style="margin:0">' . $hint . '</p>'
               . '<a class="btn btn-sm btn-secondary" href="?export=' . h($exportType) . '"'
               . ' title="' . h(t('A teljes lista, ezen oldalszámozástól függetlenül, CSV-be')) . '">'
               . '<svg class="icon"><use href="#icon-download"></use></svg> CSV</a></div>';
        };
    ?>
        <details class="sys-sec" id="af-section" style="margin:16px 16px 0">
            <summary class="results-header" style="padding:8px 12px">
                <h3 style="margin:0;font-size:1em;color:#b91c1c"><svg class="icon"><use href="#icon-warning"></use></svg> <?= h(t('Sikertelen admin belépési kísérletek')) ?> - <?= h(SITE_TITLE) ?></h3>
                <?php if ($af_total > 0): ?><span class="sys-sec-flag"><?= sprintf(t('%d kísérlet'), $af_total) ?></span><?php endif; ?>
            </summary>
            <?php $hint_csv(t('Hibás jelszóval vagy ismeretlen felhasználónévvel tett kísérletek, a webszerver hibanaplójából. A legutóbbi 8 nap.'), 'admin_login_failures'); ?>
            <?php if (!$admin_login_failures): ?>
            <div class="empty-state"><p><?= t('Nincs rögzített sikertelen admin belépési kísérlet.') ?></p></div>
            <?php else: ?>
            <table>
                <thead><tr><th scope="col"><?= t('Időpont') ?></th><th scope="col"><?= t('Megadott felhasználó') ?></th><th scope="col"><?= t('Forrás IP') ?></th><th scope="col"><?= t('Ok') ?></th><th scope="col"><?= t('Mikor') ?></th></tr></thead>
                <tbody>
                <?php foreach ($admin_login_failures as $f): ?>
                    <tr class="data-row">
                        <td class="col-date local-ts" data-label="<?= h(t('Időpont')) ?>" data-ts="<?= (int)$f['ts'] ?>"><?= h(date('Y-m-d H:i:s', $f['ts'])) ?></td>
                        <td class="col-user" data-label="Megadott felhasználó"><?= h($f['user']) ?></td>
                        <td data-label="<?= h(t('Forrás IP')) ?>"><?= $ip_flag($f['ip']) ?><?= h($f['ip']) ?></td>
                        <td data-label="Ok" style="color:#b91c1c"><?= h($f['reason']) ?></td>
                        <td data-label="Mikor" style="color:#888"><?= h(rel_time($f['ts'])) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php if ($af_total_pages > 1): ?>
            <div class="results-footer"><?= render_pager($af_page, $af_total_pages, fn($p) => $login_url('af_page', $p), number_format($af_total) . ' ' . t('tétel')) ?></div>
            <?php endif; ?>
            <?php endif; ?>
        </details>

        <details class="sys-sec" id="mf-section" style="margin:16px 16px 0">
            <summary class="results-header" style="padding:8px 12px">
                <h3 style="margin:0;font-size:1em;color:#b91c1c"><svg class="icon"><use href="#icon-warning"></use></svg> <?= t('Sikertelen POP3/IMAP/Webmail bejelentkezések') ?></h3>
                <?php if ($mf_total > 0): ?><span class="sys-sec-flag"><?= sprintf(t('%d kísérlet'), $mf_total) ?></span><?php endif; ?>
            </summary>
            <?php $hint_csv(t('Hibás jelszóval tett kísérletek levelesláda-fiókok ellen, a levelezőszerver naplójából. A Webmail forrás a valódi böngésző-oldali IP-t mutatja, nem a webmail szerver saját (loopback) IP-jét. A legutóbbi 8 nap.'), 'mail_auth_failures'); ?>
            <?php if (!$mail_auth_failures): ?>
            <div class="empty-state"><p><?= t('Nincs rögzített sikertelen bejelentkezés.') ?></p></div>
            <?php else: ?>
            <table>
                <thead><tr><th scope="col"><?= t('Időpont') ?></th><th scope="col"><?= t('Felhasználó') ?></th><th scope="col"><?= t('Forrás IP') ?></th><th scope="col"><?= t('Forrás') ?></th><th scope="col"><?= t('Mikor') ?></th></tr></thead>
                <tbody>
                <?php foreach ($mail_auth_failures as $f): ?>
                    <tr class="data-row">
                        <td class="col-date local-ts" data-label="<?= h(t('Időpont')) ?>" data-ts="<?= (int)$f['ts'] ?>"><?= h(date('Y-m-d H:i:s', $f['ts'])) ?></td>
                        <td class="col-user" data-label="<?= h(t('Felhasználó')) ?>"><?= h($f['user']) ?></td>
                        <td data-label="<?= h(t('Forrás IP')) ?>"><?= $ip_flag($f['ip']) ?><?= h($f['ip']) ?></td>
                        <td data-label="Forrás"><span class="folder-tag folder-<?= h($f['source']) ?>"><?= h($f['source']) ?></span></td>
                        <td data-label="Mikor" style="color:#888"><?= h(rel_time($f['ts'])) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php if ($mf_total_pages > 1): ?>
            <div class="results-footer"><?= render_pager($mf_page, $mf_total_pages, fn($p) => $login_url('mf_page', $p), number_format($mf_total) . ' ' . t('tétel')) ?></div>
            <?php endif; ?>
            <?php endif; ?>
        </details>

        <details class="sys-sec" id="al-section" style="margin:16px 16px 0">
            <summary class="results-header" style="padding:8px 12px">
                <h3 style="margin:0;font-size:1em;color:#1a3a5c"><svg class="icon"><use href="#icon-key"></use></svg> <?= h(t('Admin belépések')) ?> - <?= h(SITE_TITLE) ?></h3>
                <?php if ($al_total > 0): ?><span class="sys-sec-flag"><?= sprintf(t('%d belépés'), $al_total) ?></span><?php endif; ?>
            </summary>
            <?php $hint_csv('Sikeres <strong>' . t('rendszergazdai belépések') . '</strong> '
                . t('ehhez a felülethez, a webszerver hozzáférési naplójából származtatva, ~30 perces munkamenetekre bontva (nem minden kérés külön).'),
                'admin_logins'); ?>
            <?php if (!$admin_logins): ?>
            <div class="empty-state"><p><?= t('Nincs rögzített admin belépés a naplóban.') ?></p></div>
            <?php else: ?>
            <table>
                <thead><tr><th scope="col"><?= t('Belépés') ?></th><th scope="col">Admin</th><th scope="col"><?= t('Forrás IP') ?></th><th scope="col"><?= t('Kérések') ?></th><th scope="col"><?= t('Mikor') ?></th></tr></thead>
                <tbody>
                <?php foreach ($admin_logins as $s): ?>
                    <tr class="data-row">
                        <td class="col-date local-ts" data-label="<?= h(t('Belépés')) ?>" data-ts="<?= (int)$s['start'] ?>"><?= h(date('Y-m-d H:i:s', $s['start'])) ?></td>
                        <td class="col-user" data-label="Admin"><?= h($s['user']) ?></td>
                        <td data-label="<?= h(t('Forrás IP')) ?>"><?= $ip_flag($s['ip']) ?><?= h($s['ip']) ?></td>
                        <td data-label="<?= h(t('Kérések')) ?>" style="color:#666"><?= (int)$s['hits'] ?></td>
                        <td data-label="Mikor" style="color:#888"><?= h(rel_time($s['start'])) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php if ($al_total_pages > 1): ?>
            <div class="results-footer"><?= render_pager($al_page, $al_total_pages, fn($p) => $login_url('al_page', $p), number_format($al_total) . ' ' . t('tétel')) ?></div>
            <?php endif; ?>
            <?php endif; ?>
        </details>

        <details class="sys-sec" id="ul-section" style="margin:16px 16px 0">
            <summary class="results-header" style="padding:8px 12px">
                <h3 style="margin:0;font-size:1em;color:#1a3a5c"><svg class="icon"><use href="#icon-user"></use></svg> <?= t('Felhasználók utolsó belépése') ?></h3>
                <?php if ($ul_total > 0): ?><span class="sys-sec-flag"><?= sprintf(t('%d felhasználó'), $ul_total) ?></span><?php endif; ?>
            </summary>
            <?php if ($audit_error): ?>
            <div class="empty-state"><div style="font-size:2em"><svg class="icon"><use href="#icon-warning"></use></svg></div><p><?= h($audit_error) ?></p></div>
            <?php elseif (!$audit_rows): ?>
            <div class="empty-state"><p><?= t('Nincs bejelentkezési adat.') ?></p></div>
            <?php else: ?>
            <?php $hint_csv(t('Utolsó bejelentkezés') . ' <strong>' . t('felhasználónként') . '</strong> ' . t('(pillanatkép, nem eseménynapló).'), 'user_logins'); ?>
            <table>
                <thead><tr><th scope="col"><?= t('Felhasználó') ?></th><th scope="col"><?= t('Utolsó bejelentkezés') ?></th><th scope="col"><?= t('Mikor') ?></th></tr></thead>
                <tbody>
                <?php foreach ($audit_rows as $r): $t = (int)$r['last_login']; ?>
                    <tr class="data-row">
                        <td class="col-user" data-label="<?= h(t('Felhasználó')) ?>"><?= h($r['username']) ?></td>
                        <td class="col-date local-ts" data-label="Utolsó belépés" data-ts="<?= $t ?>"><?= h(date('Y-m-d H:i:s', $t)) ?></td>
                        <td data-label="Mikor" style="color:#888"><?= h(rel_time($t)) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php if ($ul_total_pages > 1): ?>
            <div class="results-footer"><?= render_pager($ul_page, $ul_total_pages, fn($p) => $login_url('ul_page', $p), number_format($ul_total) . ' ' . t('tétel')) ?></div>
            <?php endif; ?>
            <?php endif; ?>
        </details>
    <?php else: /* ops */ ?>
        <?php if (!$audit_rows): ?>
        <div class="empty-state"><div style="font-size:2em"><svg class="icon"><use href="#icon-mail"></use></svg></div><p><?= t('Még nincs rögzített spam-művelet.') ?></p></div>
        <?php else: ?>
        <table>
            <thead><tr>
                <th scope="col"><?= t('Idő') ?></th><th scope="col"><?= t('Művelet') ?></th><th scope="col"><?= t('Felhasználó') ?></th>
                <th scope="col"><?= t('Mappa') ?></th><th scope="col">UID</th><th scope="col">Admin</th><th scope="col">IP</th>
            </tr></thead>
            <tbody>
            <?php foreach ($audit_rows as $r):
                $act = $r['action'] === 'release'
                     ? '<span class="op-tag op-release"><svg class="icon"><use href="#icon-play"></use></svg> ' . t('Felszabadítás') . '</span>'
                     : ($r['action'] === 'delete'
                        ? '<span class="op-tag op-delete"><svg class="icon"><use href="#icon-x"></use></svg> ' . t('Törlés') . '</span>'
                        : h($r['action']));
            ?>
                <tr class="data-row">
                    <td class="col-date local-ts" data-label="<?= h(t('Idő')) ?>" data-ts="<?= (int)$r['ts'] ?>"><?= h(date('Y-m-d H:i:s', $r['ts'])) ?></td>
                    <td data-label="<?= h(t('Művelet')) ?>"><?= $act ?></td>
                    <td class="col-user" data-label="<?= h(t('Felhasználó')) ?>"><?= h($r['user']) ?></td>
                    <td data-label="Mappa"><span class="folder-tag folder-<?= h($r['folder']) ?>"><?= h($r['folder']) ?></span></td>
                    <td data-label="UID"><?= h($r['uid']) ?></td>
                    <td data-label="Admin"><?= h($r['admin']) ?></td>
                    <td data-label="IP" style="color:#666"><?= h($r['ip']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    <?php endif; ?>

    <?php if ($total_pages > 1): ?>
    <div class="results-footer">
        <div class="pager">
            <?php if ($page > 1): ?>
                <a class="btn btn-sm btn-primary" href="<?= audit_url($audit_tab, $page - 1) ?>"><svg class="icon icon-rot-180"><use href="#icon-chevron"></use></svg> <?= t('Előző') ?></a>
            <?php else: ?><span class="btn btn-sm pager-disabled"><svg class="icon icon-rot-180"><use href="#icon-chevron"></use></svg> <?= t('Előző') ?></span><?php endif; ?>
            <span class="pager-info"><?= $page ?>. / <?= $total_pages ?> oldal</span>
            <?php if ($page < $total_pages): ?>
                <a class="btn btn-sm btn-primary" href="<?= audit_url($audit_tab, $page + 1) ?>"><?= t('Következő') ?> <svg class="icon"><use href="#icon-chevron"></use></svg></a>
            <?php else: ?><span class="btn btn-sm pager-disabled"><?= t('Következő') ?> <svg class="icon"><use href="#icon-chevron"></use></svg></span><?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
</div>
