<!-- ── Áttekintés (dashboard) ── -->
<?php
    $rc = $dash['rspamc'] ?? [];
    $wk = $dash['week']; $mo = $dash['month'];
    $wk_pct = $wk['total'] ? round($wk['spam'] * 100 / $wk['total']) : 0;
    $nf = fn($n) => n_fmt((int)$n);
?>
<h1 class="page-title"><?= h(t('Áttekintés')) ?></h1>
<div class="dash-grid">
    <div class="stat-card brand-card">
        <img class="brand-lockup" src="<?= h(COOKIE_PATH) ?>assets/logo-lockup.png" alt="<?= h(t(SITE_TITLE)) ?>">
    </div>
    <div class="dash-col">
        <div class="stat-card">
            <div class="stat-label"><?= t('Archivált levél - 7 nap') ?></div>
            <div class="stat-value"><?= $nf($wk['total']) ?></div>
            <div class="stat-sub"><span class="dot-spam"></span><?= $nf($wk['spam']) ?> <?= h(t('spam')) ?> &middot; <?= $wk_pct ?>%</div>
        </div>
        <div class="stat-card">
            <div class="stat-label"><?= t('Archivált levél - 30 nap') ?></div>
            <div class="stat-value"><?= $nf($mo['total']) ?></div>
            <div class="stat-sub"><span class="dot-spam"></span><?= $nf($mo['spam']) ?> <?= h(t('spam')) ?></div>
        </div>
    </div>
    <div class="dash-col">
        <div class="stat-card">
            <div class="stat-label"><?= t('rspamd - vizsgált (összes)') ?></div>
            <div class="stat-value"><?= isset($rc['scanned']) ? $nf($rc['scanned']) : '-' ?></div>
            <div class="stat-sub"><?= isset($rc['spam_pct']) ? h($rc['spam_pct']) . '% ' . t('spam') : '' ?></div>
        </div>
        <div class="stat-card">
            <div class="stat-label"><?= t('Bayes tanítás (összes)') ?></div>
            <div class="stat-value"><?= isset($rc['learned']) ? $nf($rc['learned']) : '-' ?></div>
            <div class="stat-sub"><?= isset($rc['bayes_spam']) ? $nf($rc['bayes_spam']) . ' ' . t('spam') . ' / ' . $nf($rc['bayes_ham'] ?? 0) . ' ' . t('ham') : '' ?></div>
        </div>
    </div>
    <?php if (!empty($admin_sysinfo)): $si = $admin_sysinfo; ?>
    <div class="dash-col">
        <div class="stat-card">
            <?php if (!empty($si['hostname'])): ?>
            <?php
            // <wbr> after each dot so a wrapped FQDN prefers to break at a label
            // boundary ("mail." / "linuxforum." / "hu") rather than mid-word --
            // at the grid's 150px column floor it otherwise splits as
            // "mail.linuxfo|rum.hu". overflow-wrap:anywhere in .sys-host stays as
            // the fallback for a label too long to fit on its own.
            // ESCAPE FIRST, then insert markup: never the other way round.
            $sys_host_html = str_replace('.', '.<wbr>', h($si['hostname']));
            ?>
            <div class="sys-host" title="<?= h($si['hostname']) ?>"><?= $sys_host_html ?></div>
            <?php else: ?>
            <div class="stat-label"><?= h(t('Rendszer')) ?></div>
            <?php endif; ?>
            <?php
            $sys_meta_parts = [];
            if (!empty($si['uptime_seconds'])) {
                $sys_meta_parts[] = h(sprintf(t('Fut: %s'), admin_fmt_uptime((int)$si['uptime_seconds'])));
            }
            if (!empty($si['os_pretty'])) {
                $sys_meta_parts[] = h($si['os_pretty']);
            }
            ?>
            <?php if (!empty($sys_meta_parts)): ?>
            <div class="sys-meta"><?= implode('&nbsp;&middot; ', $sys_meta_parts) ?></div>
            <?php endif; ?>
            <?php if (!empty($si['disk'])): $d = $si['disk']; ?>
            <div class="sys-row" title="<?= h(t('Lemez')) ?> (<?= h(MAIL_DIR) ?>): <?= admin_fmt_bytes($d['used']) ?> / <?= admin_fmt_bytes($d['total']) ?> &middot; <?= $d['pct'] ?>% <?= h(t('használt')) ?> &middot; <?= admin_fmt_bytes($d['avail']) ?> <?= h(t('szabad')) ?>">
                <span class="sys-row-label"><?= h(t('Lemez')) ?></span>
                <span class="sys-row-bar"><span style="width:<?= $d['pct'] ?>%;background:<?= $d['pct']>85?'var(--danger)':($d['pct']>70?'var(--warning)':'var(--primary)') ?>"></span></span>
                <span class="sys-row-pct"><?= $d['pct'] ?>%</span>
            </div>
            <?php endif; ?>
            <?php if (!empty($si['mem'])): $m = $si['mem']; ?>
            <div class="sys-row" title="<?= h(t('Memória')) ?>: <?= admin_fmt_bytes($m['used']) ?> / <?= admin_fmt_bytes($m['total']) ?> &middot; <?= $m['pct'] ?>% <?= h(t('használt')) ?> &middot; <?= admin_fmt_bytes($m['avail']) ?> <?= h(t('szabad')) ?>">
                <span class="sys-row-label"><?= h(t('Memória')) ?></span>
                <span class="sys-row-bar"><span style="width:<?= $m['pct'] ?>%;background:<?= $m['pct']>85?'var(--danger)':($m['pct']>70?'var(--warning)':'var(--primary)') ?>"></span></span>
                <span class="sys-row-pct"><?= $m['pct'] ?>%</span>
            </div>
            <?php endif; ?>
            <?php if (!empty($si['swap'])): $sw = $si['swap']; ?>
            <div class="sys-row" title="<?= h(t('Swap')) ?>: <?= admin_fmt_bytes($sw['used']) ?> / <?= admin_fmt_bytes($sw['total']) ?> &middot; <?= $sw['pct'] ?>% <?= h(t('használt')) ?> &middot; <?= admin_fmt_bytes($sw['avail']) ?> <?= h(t('szabad')) ?>">
                <span class="sys-row-label"><?= h(t('Swap')) ?></span>
                <span class="sys-row-bar"><span style="width:<?= $sw['pct'] ?>%;background:<?= $sw['pct']>85?'var(--danger)':($sw['pct']>70?'var(--warning)':'var(--primary)') ?>"></span></span>
                <span class="sys-row-pct"><?= $sw['pct'] ?>%</span>
            </div>
            <?php endif; ?>
            <?php if (!empty($si['cpu'])): $cp = $si['cpu']; ?>
            <div class="sys-row" title="<?= h(t('CPU-terhelés')) ?>: <?= number_format($cp['load1'], 2) ?> / <?= number_format($cp['load5'], 2) ?> / <?= number_format($cp['load15'], 2) ?> &middot; <?= (int)$cp['cores'] ?> CPU<?= !empty($si['cache_kb']) ? ' &middot; ' . h(t('Cache')) . ': ' . h(dirname(SETTINGS_FILE)) . ' &middot; ' . number_format($si['cache_kb'] / 1024, 1) . ' MB' : '' ?>">
                <span class="sys-row-label"><?= h(t('CPU-terhelés')) ?></span>
                <span class="sys-row-bar"><span style="width:<?= $cp['pct'] ?>%;background:<?= $cp['pct']>85?'var(--danger)':($cp['pct']>70?'var(--warning)':'var(--primary)') ?>"></span></span>
                <span class="sys-row-pct"><?= $cp['pct'] ?>%</span>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<div class="results-card" style="margin-top:16px">
    <div class="results-header"><h2><?= t('Napi forgalom') ?></h2>
        <span class="meta">
            <span class="range-toggle">
                <button type="button" class="range-btn active" onclick="dashSetRange(this,'24h')"><?= t('24 óra') ?></button>
                <button type="button" class="range-btn" onclick="dashSetRange(this,'7')"><?= t('7 nap') ?></button>
                <button type="button" class="range-btn" onclick="dashSetRange(this,'30')"><?= t('30 nap') ?></button>
            </span>
            <span class="verdict verdict-spam" style="padding:1px 7px"><?= h(t('Spam')) ?></span>
            <span class="verdict verdict-ham" style="padding:1px 7px"><?= h(t('Ham')) ?></span>
        </span>
    </div>
    <?php
        // '24h' first so it is also the default panel -- the most recent view is
        // the one an operator opening the dashboard usually wants.
        $dash_ranges = ['24h' => $dash['hourly'] ?? [], '7' => $dash['daily'] ?? [], '30' => $dash['daily30'] ?? []];
        $dash_has_any = array_filter($dash_ranges, fn($rows) => array_filter($rows, fn($r) => (int)$r['c'] > 0));
    ?>
    <?php if ($dash_has_any): ?>
        <?php foreach ($dash_ranges as $range => $rows):
            $max = 1; $r_tot = 0; $r_spam = 0;
            foreach ($rows as $r) {
                $max = max($max, (int)$r['c']); $r_tot += (int)$r['c']; $r_spam += (int)$r['s'];
            }
            // Totals come from the bars already fetched -- no extra query, and
            // they can never disagree with the chart they sit above.
            $r_pct = $r_tot ? round($r_spam * 100 / $r_tot) : 0;
            $r_label = $range === '24h' ? t('Utolsó 24 óra') : sprintf(t('Utolsó %d nap'), (int)$range); ?>
        <div class="barchart-scroll<?= (string)$range === '24h' ? '' : ' hidden' ?>" data-range-panel="<?= h((string)$range) ?>">
        <div class="range-summary">
            <strong><?= h($r_label) ?>:</strong>
            <?= h(n_fmt($r_tot)) ?> <?= h(t('levél')) ?>
            <span class="dot-spam"></span><?= h(n_fmt($r_spam)) ?> <?= h(t('spam')) ?> &middot; <?= (int)$r_pct ?>%
        </div>
        <div class="barchart">
            <?php foreach ($rows as $r):
                $c = (int)$r['c']; $s = (int)$r['s'];
                $spamh = round($s * 100 / $max); $hamh = round(($c - $s) * 100 / $max); ?>
            <?php // hourly rows supply an explicit short 'label' (the hour); daily
                  // rows fall back to trimming the year off the ISO date. ?>
            <div class="bar-col" title="<?= h($r['d']) ?><?= isset($r['label']) ? ':00' : '' ?> - <?= $c ?> <?= h(t('levél')) ?> (<?= $s ?> <?= h(t('spam')) ?>, <?= $c - $s ?> <?= h(t('ham')) ?>)">
                <div class="bar-count"><?= $c ?></div>
                <div class="bar">
                    <div class="bar-spam" style="height:<?= $spamh ?>%"></div>
                    <div class="bar-ham"  style="height:<?= $hamh ?>%"></div>
                </div>
                <div class="bar-lbl"><?= h($r['label'] ?? substr((string)$r['d'], 5)) ?></div>
            </div>
            <?php endforeach; ?>
        </div>
        </div>
        <?php endforeach; ?>
    <?php else: ?>
    <div class="empty-state"><p><?= h(t('Nincs adat az archívumban.')) ?></p></div>
    <?php endif; ?>
</div>
<script>
function dashSetRange(btn, range) {
    var card = btn.closest('.results-card');
    card.querySelectorAll('.range-btn').forEach(function (b) { b.classList.toggle('active', b === btn); });
    card.querySelectorAll('[data-range-panel]').forEach(function (p) { p.classList.toggle('hidden', p.dataset.rangePanel !== range); });
}
</script>

<?php if (($dash['err'] ?? '') !== ''): ?>
    <p class="filter-hint"><svg class="icon"><use href="#icon-warning"></use></svg> <?= h(t('Néhány statisztika nem elérhető')) ?> (<?= h($dash['err']) ?>).</p>
<?php endif; ?>

<!-- ── ClamAV vírusvédelem ── -->
<?php if (!empty($admin_clamav)):
    $cv = $admin_clamav;
    $cv_up   = !empty($cv['daemon_active']);
    $cv_dage = (int)($cv['daily_age'] ?? -1);
    // daily.cld ships several times a day; >24h means freshclam is stuck.
    $cv_dcol = $cv_dage < 0 ? 'var(--text-subtle)'
             : ($cv_dage > 259200 ? 'var(--danger)' : ($cv_dage > 86400 ? 'var(--warning)' : '#27ae60'));
    $cv_hrs  = fn(int $s) => $s < 0 ? '-' : ($s < 3600 ? sprintf(t('%d perce'), intdiv($s, 60)) : sprintf(t('%d órája'), intdiv($s, 3600)));
    $cv_off  = 0;
    foreach (($cv['sources'] ?? []) as $s) {
        if (empty($s['master_enabled']) || strtoupper($s['rating'] ?? '') === 'DISABLE') $cv_off++;
    }
    $cv_tot = count($cv['sources'] ?? []);
    // See admin_system.php: without clamav-unofficial-sigs there are no
    // third-party sources and no YARA switch, and the two tiles below would
    // otherwise claim "0/0 forrás aktív" and a YARA state that is not settable
    // here. Missing key defaults to true so a stale status cache or an older
    // clamav-status.sh does not blank a working panel on a host that has it.
    $cv_unof = $cv['unofficial_installed'] ?? true;
?>
<div class="results-card" style="margin-top:16px">
    <div class="results-header">
        <h2><?= h(t('ClamAV vírusvédelem')) ?></h2>
        <span class="meta">
            <span style="color:<?= $cv_up ? '#27ae60' : 'var(--danger)' ?>;font-weight:600">
                &#9679; <?= h($cv_up ? t('clamd fut') : t('clamd áll')) ?>
            </span>
            &nbsp;/&nbsp; <?= h(t('motor')) ?> <?= h($cv['clam_version'] ?? '?') ?>
            &nbsp;&middot;&nbsp; <a href="?sysconfig=1#clamav" style="color:var(--primary);text-decoration:none"><?= h(t('beállítások')) ?> &raquo;</a>
        </span>
    </div>
    <div style="display:flex;flex-wrap:wrap;gap:10px;padding:16px 20px">
        <div class="cv-stat">
            <span class="cv-stat-k"><?= h(t('Adatbázis')) ?></span>
            <span class="cv-stat-v"><?= h($cv['db_version'] ?? '?') ?></span>
            <span class="cv-stat-s"><?= number_format((int)($cv['db_sigs'] ?? 0)) ?> <?= h(t('aláírás')) ?></span>
        </div>
        <div class="cv-stat">
            <span class="cv-stat-k">daily.cld</span>
            <span class="cv-stat-v" style="color:<?= $cv_dcol ?>"><?= $cv_hrs($cv_dage) ?></span>
            <span class="cv-stat-s"><?= h($cv['daily_updated'] ?? '') ?></span>
        </div>
        <?php if ($cv_unof): ?>
        <div class="cv-stat">
            <span class="cv-stat-k"><?= h(t('Nem hivatalos')) ?></span>
            <span class="cv-stat-v"><?= $cv_hrs((int)($cv['unofficial_age'] ?? -1)) ?></span>
            <span class="cv-stat-s"><?= $cv_tot - $cv_off ?>/<?= $cv_tot ?> <?= h(t('forrás aktív')) ?></span>
        </div>
        <div class="cv-stat">
            <span class="cv-stat-k">YARA</span>
            <span class="cv-stat-v" style="color:<?= !empty($cv['yara_enabled']) ? '#27ae60' : 'var(--text-subtle)' ?>">
                <?= h(!empty($cv['yara_enabled']) ? t('be') : t('ki')) ?>
            </span>
            <span class="cv-stat-s"><?= h(t('csak pontoz, nem tilt')) ?></span>
        </div>
        <?php else: ?>
        <div class="cv-stat">
            <span class="cv-stat-k"><?= h(t('Nem hivatalos')) ?></span>
            <span class="cv-stat-v" style="color:var(--text-subtle)"><?= h(t('nincs')) ?></span>
            <span class="cv-stat-s"><?= h(t('clamav-unofficial-sigs nincs telepítve')) ?></span>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>

<!-- ── Blokkolt levelek (SMTP-szinten elutasítva) ── -->
<?php if (!empty($blocked_stats)):
    $bt = $blocked_stats['today'] ?? [];
    $bw = $blocked_stats['week']  ?? [];
    // Ordered by how decisive the layer is: a virus or blocklist hit is a hard
    // verdict, protocol abuse is volume noise that never became a message.
    $b_rows = [
        ['virus',       t('Vírus (ClamAV)'),        'var(--danger)',
            t('A ClamAV vírusvédelem kártevőt talált a csatolmányban - a levél SMTP-szinten elutasításra került.')],
        ['blocklist',   t('Admin blokklista'),      'var(--danger)',
            t('A feladó címe, domainje vagy IP-je szerepel az admin által kezelt blokklistán.')],
        ['spam_reject', t('Spam pontszám'),         'var(--warning)',
            t('Az rspamd pontszáma túllépte az elutasítási küszöböt - ez a biztonsági háló a rendkívül magas pontszámú levelekre, a legtöbb spam csak megjelölésre kerül, nem elutasításra.')],
        ['dnsbl',       t('DNSBL (postscreen)'),    'var(--warning)',
            t('A küldő IP-címe szerepel valamelyik feketelistán (DNSBL), amit a postscreen ellenőriz a kapcsolódáskor, még a levél átvitele előtt.')],
        ['pregreet',    t('Protokollsértés'),       'var(--text-muted)',
            t('A küldő az SMTP-üdvözlő üzenet előtt küldött adatot (PREGREET) - valós levelezőprogramok ezt nem teszik, jellemzően automatizált spam-küldő eszközök viselkedése.')],
        ['hangup',      t('Megszakított kapcsolat'),'var(--text-muted)',
            t('A küldő megszakította a kapcsolatot, mielőtt a postscreen tesztje befejeződött volna (HANGUP) - gyakran automatizált, script-alapú küldők jele.')],
    ];
    $b_week_total = array_sum(array_map(fn($r) => (int)($bw[$r[0]] ?? 0), $b_rows));
    // Explanatory text folded into one tooltip (was two always-visible
    // paragraphs above/below the table) so the card takes less vertical space
    // while the detail stays one hover/tap away.
    $b_tooltip = t('Ezek a levelek SMTP-szinten elutasításra kerültek, így soha nem jutottak postafiókba - és az archívumban sem szerepelnek. Forrás: a Postfix napló.')
               . ' ' . t('A csomagszinten (tűzfal/ipset) eldobott forgalom itt nem jelenik meg - arról nem készül napló.');
    if (!empty($blocked_stats['dnsbl_lists'])) {
        $b_dnsbl_parts = [];
        foreach ($blocked_stats['dnsbl_lists'] as $_ln => $_lc) {
            $b_dnsbl_parts[] = $_ln . ' ' . n_fmt((int)$_lc);
        }
        $b_tooltip .= ' ' . t('DNSBL') . ': ' . implode(', ', $b_dnsbl_parts);
    }
?>
<div class="results-card" style="margin-top:16px">
    <div class="results-header">
        <h2><?= h(t('Blokkolt levelek')) ?> <span class="info-hint" title="<?= h($b_tooltip) ?>"><svg class="icon"><use href="#icon-info"></use></svg></span></h2>
        <span class="meta"><?= h(sprintf(t('%s elutasítva 7 nap alatt'), n_fmt($b_week_total))) ?></span>
    </div>
    <table class="msg-table sys-table" style="table-layout:fixed;margin-top:8px">
        <colgroup><col style="width:46%"><col style="width:18%"><col style="width:18%"><col style="width:18%"></colgroup>
        <thead><tr>
            <th scope="col"><?= h(t('Réteg')) ?></th>
            <th scope="col"><?= h(t('Ma')) ?></th>
            <th scope="col"><?= h(t('7 nap')) ?></th>
            <th scope="col"></th>
        </tr></thead>
        <tbody>
        <?php foreach ($b_rows as [$k, $lbl, $col, $tip]):
            $wv = (int)($bw[$k] ?? 0);
            $pct = $b_week_total > 0 ? (int)round($wv * 100 / $b_week_total) : 0; ?>
        <tr class="data-row">
            <td data-label="<?= h(t('Réteg')) ?>" title="<?= h($tip) ?>"><span style="color:<?= $col ?>;font-weight:600">&#9679;</span> <?= h($lbl) ?></td>
            <td data-label="<?= h(t('Ma')) ?>" style="font-variant-numeric:tabular-nums"><?= n_fmt((int)($bt[$k] ?? 0)) ?></td>
            <td data-label="<?= h(t('7 nap')) ?>" style="font-variant-numeric:tabular-nums;font-weight:600"><?= n_fmt($wv) ?></td>
            <td data-label="">
                <div style="background:var(--border);border-radius:3px;height:8px;overflow:hidden">
                    <div style="background:<?= $col ?>;height:100%;width:<?= $pct ?>%"></div>
                </div>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<!-- ── Adatvédelmi incidensek (XposedOrNot) ── -->
<?php
$_br      = $breach_data;
$_br_has  = !empty($_br);
$_BR_PP   = QA_PER_PAGE_BREACH;                 // rows per page
$_br_rows = [];
$_br_total = 0; $_br_page = 1; $_br_pages = 1;

if ($_br_has) {
    $_br_rows = $_br['exposed'] ?? [];
    // Newest incident first; ties broken by breach count, then address.
    usort($_br_rows, function ($a, $b) {
        $ya = breach_latest_year($a);
        $yb = breach_latest_year($b);
        if ($ya !== $yb) return $yb <=> $ya;
        $ca = (int)($a['breach_count'] ?? count($a['breaches'] ?? []));
        $cb = (int)($b['breach_count'] ?? count($b['breaches'] ?? []));
        if ($ca !== $cb) return $cb <=> $ca;
        return strcmp((string)($a['email'] ?? ''), (string)($b['email'] ?? ''));
    });
    $_br_total = count($_br_rows);
    $_br_pages = max(1, (int)ceil($_br_total / $_BR_PP));
    $_br_page  = max(1, min($_br_pages, (int)($_GET['bpage'] ?? 1)));
    $_br_rows  = array_slice($_br_rows, ($_br_page - 1) * $_BR_PP, $_BR_PP);
}
$_br_url = fn(int $p) => '?bpage=' . $p . '#incidensek';
?>
<div class="results-card" id="incidensek" style="margin-top:16px">
    <div class="results-header">
        <h2><?= h(t('Adatvédelmi incidensek')) ?> <span class="info-hint" title="<?= h(t('A postafiók-címeket a XposedOrNot adatbázisában ellenőrzi egy éjszakai feladat. Az API napi 100 kérést enged, ezért egy teljes körbeérés több éjszakát vesz igénybe.')) ?>"><svg class="icon"><use href="#icon-info"></use></svg></span></h2>
        <?php if ($_br_has): ?>
        <span class="meta">
            <?php if (($_br['exposed_count'] ?? 0) > 0): ?>
            <span style="color:var(--danger);font-weight:600"><?= $_br['exposed_count'] ?> <?= h(t('érintett')) ?></span>
            &nbsp;/&nbsp;
            <?php endif; ?>
            <?= $_br['checked_count'] ?>/<?= $_br['total_users'] ?> <?= h(t('ellenőrzött')) ?>
            <?php if ($_br['checked_count'] < $_br['total_users']): ?>
            <span style="color:var(--warning)"> - <?= h(t('folyamatban')) ?></span>
            <?php endif; ?>
        </span>
        <?php endif; ?>
    </div>

    <?php if ($_br_has): ?>
    <div style="padding:10px 20px 4px;font-size:.78rem;color:var(--text-subtle)">
        <?= h(t('Forrás')) ?>: <a href="https://xposedornot.com/" target="_blank" rel="noopener noreferrer"
                   style="color:var(--primary);text-decoration:none">XposedOrNot</a>
        &nbsp;&middot;&nbsp; <?= h(t('Legutóbbi futás')) ?>: <?= h($_br['last_run']) ?>
        &nbsp;&middot;&nbsp; <?= h(t('Napi limit: 45 cím/nap (API-kvóta: 100 kérés / 24 óra)')) ?>
        &nbsp;&middot;&nbsp; Cron: 02:00
    </div>

    <?php if (empty($_br_rows)): ?>
    <div style="padding:14px 20px 16px;display:flex;align-items:center;gap:10px">
        <span style="font-size:1.2rem;color:#27ae60"><svg class="icon"><use href="#icon-check"></use></svg></span>
        <span style="font-size:.9rem;color:#27ae60;font-weight:600">
            <?= h(sprintf(t('Nincs ismert adatvédelmi incidens a(z) %s ellenőrzött cím között.'), $_br['checked_count'])) ?>
        </span>
    </div>
    <?php else: ?>
    <table class="msg-table sys-table" style="table-layout:fixed;margin-top:4px">
        <colgroup>
            <col style="width:28%">
            <col style="width:10%">
            <col style="width:7%">
            <col style="width:41%">
            <col style="width:14%">
        </colgroup>
        <thead>
            <tr><th scope="col"><?= h(t('E-mail-cím')) ?></th><th scope="col"><?= h(t('Legutóbbi')) ?></th><th scope="col"><?= h(t('Db')) ?></th><th scope="col"><?= h(t('Incidensek')) ?></th><th scope="col"><?= h(t('Ellenőrizve')) ?></th></tr>
        </thead>
        <tbody>
        <?php foreach ($_br_rows as $r):
            $bnames = breach_names($r);
            $bcount = (int)($r['breach_count'] ?? count($r['breaches'] ?? []));
            $byear  = breach_latest_year($r);
            $show   = array_slice($bnames, 0, 4);
            $more   = count($bnames) - count($show);
        ?>
        <tr class="data-row">
            <td data-label="E-mail" style="font-family:monospace;font-size:.8rem"><?= h($r['email']) ?></td>
            <td data-label="Legutóbbi" style="font-variant-numeric:tabular-nums;font-weight:600">
                <?= $byear ? $byear : '<span style="color:var(--text-subtle);font-weight:400">-</span>' ?>
            </td>
            <td data-label="Db" style="font-weight:600;color:var(--danger);font-variant-numeric:tabular-nums">
                <?= $bcount ?>
            </td>
            <?php
            // Each breach links to its XposedOrNot page (what was leaked, when,
            // how many records). Title carries the leaked-data classes.
            $blink = fn(array $b) => '<a class="breach-link" href="' . h($b['url']) . '"'
                   . ' target="_blank" rel="noopener noreferrer"'
                   . ($b['data'] !== '' ? ' title="' . h(str_replace(';', ', ', $b['data'])) . '"' : '')
                   . '>' . h($b['label']) . '</a>';
            ?>
            <td data-label="Incidensek" style="font-size:.78rem">
                <?php if (empty($bnames)): ?>
                <span style="color:var(--text-subtle);font-style:italic"><?= h(t('részletek következő frissítéskor')) ?></span>
                <?php elseif ($more > 0): ?>
                <details>
                    <summary style="cursor:pointer;list-style:none;color:var(--text-muted)">
                        <?= implode(', ', array_map($blink, $show)) ?>
                        <span style="color:var(--primary)">+<?= $more ?> <?= h(t('további')) ?> &raquo;</span>
                    </summary>
                    <div style="margin-top:4px"><?= implode(', ', array_map($blink, $bnames)) ?></div>
                </details>
                <?php else: ?>
                <span><?= implode(', ', array_map($blink, $bnames)) ?></span>
                <?php endif; ?>
            </td>
            <td data-label="Ellenőrizve" style="font-size:.75rem;color:var(--text-subtle)">
                <?= h(substr($r['checked_at'] ?? '', 0, 10)) ?>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

    <div class="results-footer"><?= render_pager($_br_page, $_br_pages, $_br_url, $_br_total . ' ' . t('érintett cím')) ?></div>
    <?php endif; ?>

    <?php else: ?>
    <div style="padding:14px 20px;font-size:.875rem;color:var(--text-muted)">
        <?= t('Még nincs adat. Az első ellenőrzés holnap 02:00-kor fut le automatikusan (napi limit: 45 cím - az API-kvóta 100 kérés / 24 óra).') ?>
    </div>
    <?php endif; ?>
</div>

<!-- ── Blokklista-források ── -->
<?php if (!empty($admin_feeds)):
    $_dash_feeds = [
        'otx'      => ['label' => 'OTX IP',      'cadence' => 21600],
        'otx_dnsbl'=> ['label' => 'OTX DNSBL',   'cadence' => 21600],
        'otx_uri'  => ['label' => 'OTX URI',      'cadence' => 86400],
        'urlhaus'  => ['label' => 'URLhaus',       'cadence' => 86400],
        'spamhaus' => ['label' => 'Spamhaus',      'cadence' => 86400],
        'c2'       => ['label' => 'Abuse C2',      'cadence' => 86400],
        'geoblock' => ['label' => 'Geoblock',      'cadence' => 604800],
        'firehol'  => ['label' => 'FireHOL L1',    'cadence' => 86400],
        'abuseipdb'=> ['label' => 'AbuseIPDB',     'cadence' => 86400],
        'et'       => ['label' => 'Emerging Thr.', 'cadence' => 86400],
        'rspamd_rules' => ['label' => 'Community Rules', 'cadence' => 86400],
        'yara_forge'   => ['label' => 'YARA Forge',      'cadence' => 86400],
    ];
?>
<div class="results-card" style="margin-top:16px">
    <div class="results-header">
        <h2><?= h(t('Blokklista-források')) ?> <span class="info-hint" title="<?= h(t('Az egyes források frissességét a saját frissítési ciklusukhoz mérjük: zöld = OK, narancs = elavult, piros = régi, szürke = nincs adat. Alatta a bejegyzések száma és az utolsó frissítés dátuma.')) ?>"><svg class="icon"><use href="#icon-info"></use></svg></span></h2>
        <span class="meta"><?= h(t('Állapot áttekintés')) ?></span>
    </div>
    <div class="feed-grid">
    <?php foreach ($_dash_feeds as $fk => $fm):
        $fd  = $admin_feeds[$fk] ?? [];
        // feed_health() (src/feed_health.php) so a feed that refreshed on
        // schedule but came back collapsed doesn't read as a green "ok" dot
        // here while the Rendszer page already flags it -- the two surfaces
        // must agree, per admin_system.php's own use of the same function.
        $st  = feed_health($fk, $fd, $fm['cadence'])['state'];
        $dot = match($st) { 'ok' => '#27ae60', 'stale' => '#e67e22', 'old', 'collapsed' => '#e74c3c', default => '#95a5a6' };
    ?>
    <div style="background:var(--bg);border:1px solid var(--border);border-radius:var(--radius);padding:10px 12px">
        <div style="display:flex;align-items:center;gap:6px;margin-bottom:4px">
            <span style="width:9px;height:9px;border-radius:50%;background:<?= $dot ?>;flex-shrink:0;display:inline-block"></span>
            <span style="font-size:.8rem;font-weight:600"><?= h($fm['label']) ?></span>
        </div>
        <div style="font-size:.75rem;color:var(--text-muted)">
            <?= $fd ? number_format((int)($fd['count'] ?? 0)) : '-' ?>
            <?php if ($fd && ($fd['updated'] ?? '') !== ''): ?>
            <br><?= h(substr((string)$fd['updated'], 5)) ?>
            <?php endif; ?>
        </div>
    </div>
    <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>
