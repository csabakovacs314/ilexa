<!-- ── PostfixAdmin (embedded) ──────────────────────────────────────────────
     PostfixAdmin is a separate application with its own login and its own
     session. It used to open in a new tab, which meant leaving the console
     entirely; embedding it keeps the sidebar visible so mailbox/domain work
     happens without losing your place.

     Framing is safe here because both applications are served from the SAME
     origin: PostfixAdmin sends X-Frame-Options: SAMEORIGIN and
     frame-ancestors 'self', which permits this and would block any third-party
     site from doing the same. If it is ever moved to a different host, the
     frame will refuse to load -- hence the "open in a new tab" escape hatch
     below, which always works.

     Deliberately NOT sandboxed: PostfixAdmin needs same-origin cookies, forms
     and scripts to function, so a sandbox attribute permissive enough to run it
     would grant everything it removes. The same-origin trust boundary is the
     real control, and it is the same one that already applies when the app is
     opened directly. -->
<div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;flex-wrap:wrap">
    <h1 class="page-title" style="margin:0">PostfixAdmin</h1>
    <span class="meta"><?= h(t('Postafiókok és domainek kezelése - saját bejelentkezéssel')) ?></span>
    <a class="btn btn-sm btn-secondary" style="margin-left:auto"
       href="<?= h(POSTFIXADMIN_URL) ?>" target="_blank" rel="noopener noreferrer">
        <?= h(t('Megnyitás új lapon')) ?> <span aria-hidden="true">&#8599;</span>
    </a>
</div>

<!-- The height is viewport-based rather than a fixed pixel count so the frame
     fills whatever space is left under the heading on any screen; .wrap's own
     24px vertical padding plus the heading row is the ~110px subtracted here.
     The frame scrolls internally, so the outer page never gets a second
     scrollbar. -->
<iframe src="<?= h(POSTFIXADMIN_URL) ?>"
        title="PostfixAdmin"
        style="width:100%;height:calc(100vh - 110px);min-height:420px;border:1px solid var(--border);border-radius:var(--radius);background:var(--surface)">
</iframe>
