<?php
// Left sidebar: brand mark, grouped nav (role-gated per item, not per group - a
// group header renders whenever at least one of its own children is visible, so
// e.g. Audit alone keeps RENDSZER visible for non-admins). Mirrors index.php's
// existing $is_*/can('admin') gates exactly; never adds or removes a gate.
$learn_live   = is_file(LEARN_FLAG);
$_qa_role_lbl = t(ROLE_LABELS[qa_role()] ?? qa_role());
$_qa_role_cls = 'role-' . qa_role();
$_qa_is_admin = can('admin');

// [href, active-flag, label key, icon name, always-visible?]
// i18n-deferred-start -- labels are Hungarian source strings, translated
// where they are rendered below via t($item['label']).
$_nav_top    = ['href' => '?', 'active' => $is_dash, 'label' => 'Áttekintés'];
$_nav_groups = [
    'LEVELEK' => [
        ['href' => '?arc=1',   'active' => $is_archive, 'label' => 'Archívum',       'show' => can('archive')],
        ['href' => '?quar=1',  'active' => $is_quar,    'label' => 'Jelentett spam', 'show' => true],
        ['href' => '?block=1', 'active' => $is_block,   'label' => 'Blokkolás',      'show' => true],
        ['href' => '?white=1', 'active' => $is_white,   'label' => 'Fehérlista',     'show' => true],
    ],
    'BIZTONSÁG' => [
        ['href' => '?ioc=1',       'active' => $is_ioc,       'label' => 'IOC',        'show' => $_qa_is_admin],
        ['href' => '?campaigns=1', 'active' => $is_campaigns, 'label' => 'Kampányok',  'show' => $_qa_is_admin],
    ],
    'RENDSZER' => [
        ['href' => '?admin=1',     'active' => $is_admin,     'label' => 'Admin',    'show' => $_qa_is_admin],
        ['href' => '?sysconfig=1', 'active' => $is_sysconfig, 'label' => 'Rendszer', 'show' => $_qa_is_admin],
        // PostfixAdmin is a SEPARATE application with its own login, but it is
        // embedded in the console shell (?pfa=1 -> views/postfixadmin.php) so
        // this sidebar stays visible while working in it. That page carries its
        // own "open in a new tab" link for anyone who wants the full width.
        // Hidden when POSTFIXADMIN_URL is '' (deployments without it) so the
        // menu never offers a dead link.
        ['href' => '?pfa=1', 'active' => $is_pfa, 'label' => 'PostfixAdmin',
         'show' => $_qa_is_admin && POSTFIXADMIN_URL !== ''],
    ],
];
$_nav_bottom = ['href' => '?about=1', 'active' => $is_about, 'label' => 'Névjegy'];
// i18n-deferred-end
?>
<header class="sidebar" id="sidebar">
    <a href="?" class="sidebar-brand" title="<?= h(t(SITE_TITLE)) ?>">
        <img src="<?= h(COOKIE_PATH) ?>assets/logo-lockup.png" alt="<?= h(t(SITE_TITLE)) ?>" width="170" height="170">
    </a>
    <nav class="snav">
        <a href="<?= h($_nav_top['href']) ?>" class="snav-item<?= $_nav_top['active'] ? ' active' : '' ?>">
            <?= h(t($_nav_top['label'])) ?>
        </a>
        <?php foreach ($_nav_groups as $_group_label => $_items):
            $_visible = array_filter($_items, fn($i) => $i['show']);
            if (!$_visible) continue;
        ?>
        <div class="snav-group">
            <div class="snav-group-label"><?= h(t($_group_label)) ?></div>
            <?php foreach ($_visible as $_item): ?>
            <a href="<?= h($_item['href']) ?>" class="snav-item<?= $_item['active'] ? ' active' : '' ?>"<?php
                // rel="noopener": a target=_blank link otherwise hands the new
                // page a window.opener handle back into this one.
                if (!empty($_item['external'])) echo ' target="_blank" rel="noopener noreferrer"'; ?>>
                <?= h(t($_item['label'])) ?><?php if (!empty($_item['external'])): ?> <span aria-hidden="true">↗</span><?php endif; ?>
            </a>
            <?php endforeach; ?>
        </div>
        <?php endforeach; ?>
        <a href="<?= h($_nav_bottom['href']) ?>" class="snav-item snav-bottom<?= $_nav_bottom['active'] ? ' active' : '' ?>">
            <?= h(t($_nav_bottom['label'])) ?>
        </a>
    </nav>
    <div class="sidebar-foot">
        <span class="sidebar-user"
              title="<?= h(t('Bejelentkezve')) ?>: <?= h(qa_user()) ?> (<?= h($_qa_role_lbl) ?>)">
            <svg class="icon"><use href="#icon-user"></use></svg>
            <?= h(qa_user()) ?>
            <span class="role-chip"><?= h($_qa_role_lbl) ?></span>
        </span>
        <span class="learn-badge <?= $learn_live ? 'learn-live' : 'learn-log' ?>"
              title="<?= h(t('Felszabadítás → ham, törlés → spam tanítás az rspamd-nek.')) ?><?= $learn_live ? '' : h(t(' Jelenleg csak naplózás történik, tényleges tanulás nem.')) ?>">
            <?= h(t('rspamd-tanulás')) ?>: <?= h($learn_live ? t('ÉLES') : t('napló-mód')) ?>
        </span>
    </div>
</header>
<button type="button" class="nav-toggle" aria-expanded="false" aria-controls="sidebar"
        aria-label="<?= h(t('Menü')) ?>">
    <svg class="icon"><use href="#icon-menu"></use></svg>
</button>
<div class="nav-backdrop" id="navBackdrop"></div>
<script>
// Mobile-only: the stylesheet keeps .nav-toggle display:none above 720px.
(function () {
    var sidebar  = document.getElementById('sidebar');
    var toggle   = document.querySelector('.nav-toggle');
    var backdrop = document.getElementById('navBackdrop');
    function setOpen(open) {
        sidebar.classList.toggle('nav-open', open);
        toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    }
    toggle.addEventListener('click', function () { setOpen(!sidebar.classList.contains('nav-open')); });
    backdrop.addEventListener('click', function () { setOpen(false); });
})();
</script>
