<?php
require __DIR__ . '/src/bootstrap.php';

// Update-apply maintenance gate (install/qa-update-apply.sh Phase 4/5). Must
// come before auth: a visitor should see "briefly unavailable", not an auth
// prompt that then 503s. PHP_SAPI!=='cli' is load-bearing, not decorative --
// it is what lets tools/smoke/render-route.php (CLI-only by its own guard)
// verify the just-deployed tree WHILE .maintenance is still up, so the apply
// script can confirm the new code works before ever re-exposing it to a
// browser. Nothing here touches Postfix/Dovecot/rspamd -- this console is
// not in the mail delivery path, so the only outage is the admin UI itself.
if (PHP_SAPI !== 'cli' && is_file(__DIR__ . '/.maintenance')) {
    http_response_code(503);
    header('Retry-After: 120');
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><html><head><meta charset="utf-8"><title>ilexa</title></head>'
       . '<body style="font-family:sans-serif;text-align:center;padding:80px 20px">'
       . '<h1>' . h(t('Frissítés telepítése folyamatban')) . '</h1>'
       . '<p>' . h(t('A konzol néhány percen belül újra elérhető lesz.')) . '</p></body></html>';
    exit;
}

// Must precede every endpoint below, including the early exits.
qa_require_auth();

// ── Early-exit endpoints (before any HTML output) ─────────────────
if (isset($_GET['export'])) handle_export();
if (isset($_GET['view']))   handle_view();
if (isset($_GET['lcheck'])) handle_list_check();
if (isset($_GET['rmods']))  handle_rspamd_modules();
if (isset($_GET['bgbody'])) handle_brandguard_body();
if (isset($_GET['feedsbody'])) handle_feeds_body();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_ok()) {
        if (($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'XMLHttpRequest') {
            header('Content-Type: application/json; charset=utf-8');
            $csrfMsg = t('A művelet biztonsági okból elutasításra került (érvénytelen munkamenet). Próbáld újra.');
            // Both keys are populated: arcSubmit()/arcResend() read `message` directly;
            // the IOC/list reputation-lookup handlers (views/layout_foot.php) already have
            // an existing `d.errors._` fallback for exactly this case -- populate it instead
            // of leaving those handlers to misreport a session expiry as "check failed for
            // all services".
            echo json_encode(['ok' => false, 'message' => $csrfMsg, 'errors' => ['_' => $csrfMsg]]);
            exit;
        }
        header('Location: ?csrf=1'); exit;
    }
    if (isset($_POST['admin_action'])) handle_admin_post();
    else handle_post();
}

// ── Read filters from GET ─────────────────────────────────────────
$f_domain = valid_domain($_GET['domain'] ?? '') ? ($_GET['domain'] ?? '') : '';
$f_user   = valid_user($_GET['user']     ?? '') ? ($_GET['user']   ?? '') : '';
// Spam is the only remaining quarantine folder (Junk retired, Quarantine never used).
$f_folder = valid_folder($_GET['folder'] ?? '') ? ($_GET['folder'] ?? '') : 'Spam';
$f_since  = valid_date($_GET['since']    ?? '') ? ($_GET['since']  ?? '') : date('Y-m-d', strtotime('-7 days'));
$f_before = valid_date($_GET['before']   ?? '') ? ($_GET['before'] ?? '') : '';
// Free-text filters matched in PHP against decoded headers (never passed to doveadm,
// which would trigger FTS Xapian indexing across all mailboxes).
$f_from    = mb_substr(trim((string)($_GET['from']    ?? '')), 0, 120);
$f_subject = mb_substr(trim((string)($_GET['subject'] ?? '')), 0, 120);
$do_search = true;

// ── Mode ──────────────────────────────────────────────────────────
// Audit is no longer a page of its own: it renders as a collapsed section on
// the Rendszer (System) page. A bare ?audit= URL therefore still works -- old
// links and the sidebar entry that used to exist both land on Rendszer with
// the section expanded -- but it is the same page, so it is $is_sysconfig that
// governs. $audit_open only decides whether the <details> starts open.
$audit_open = isset($_GET['audit']) && can('admin');
$is_quar    = isset($_GET['quar']);
$is_block   = isset($_GET['block']);
$is_white   = isset($_GET['white']);
$is_archive = isset($_GET['arc']) && can('archive');
$is_about   = isset($_GET['about']);
$is_admin      = isset($_GET['admin'])     && can('admin');  // non-admins silently land on dash
$is_sysconfig  = (isset($_GET['sysconfig']) || $audit_open) && can('admin');  // same gate as Admin
$is_ioc        = isset($_GET['ioc'])       && can('admin');  // same gate as Admin
$is_campaigns  = isset($_GET['campaigns']) && can('admin');  // same gate as Admin
// PostfixAdmin embedded in the console shell (see views/postfixadmin.php).
// Gated on POSTFIXADMIN_URL as well as the role, so a deployment that hides the
// menu entry cannot be reached by typing the URL either.
$is_pfa        = isset($_GET['pfa']) && can('admin') && POSTFIXADMIN_URL !== '';
$is_dash    = !$is_pfa && !$is_quar && !$is_block && !$is_white && !$is_archive && !$is_admin && !$is_sysconfig && !$is_about && !$is_ioc && !$is_campaigns;
$audit_tab  = in_array($_GET['audit'] ?? '', ['logins', 'ops'], true) ? ($_GET['audit'] ?? '') : 'ops';

// ── Domain restriction for domain_admin role ──────────────────────
// Must be assigned before it is read: it used to be set ~18 lines further down,
// so this clamp never ran and a domain_admin's list view was not restricted to
// their own domains (actions were still checked server-side by
// qa_domain_allowed(), but subjects and senders from other domains showed).
$domain_restricted = (qa_role() === 'domain_admin') ? qa_domains() : [];
if (!empty($domain_restricted)) {
    if ($f_domain === '' || !in_array($f_domain, $domain_restricted, true)) {
        $f_domain = $domain_restricted[0];
    }
    // ...and clamp ?user= too. The $f_domain clamp above does NOT cover it:
    // the listing path branches on $f_user and fetches that mailbox directly
    // (see the `if ($f_user)` branch below), never consulting $f_domain. So
    // ?quar=1&user=someone@other-domain returned a full From/Subject/date
    // listing for a mailbox outside this admin's domains. qa_domain_allowed()
    // existed but was only ever called from POST handlers (src/actions.php),
    // which is why the earlier fix to this block -- concerned with the same
    // class of leak -- still left the read path open.
    // Cleared rather than rejected, matching the $f_domain clamp's style: an
    // explicit error would also confirm that the mailbox exists.
    if ($f_user !== '' && !qa_domain_allowed($f_user)) {
        $f_user = '';
    }
}

// ── Pagination (25/page, newest first) ────────────────────────────
$per_page = QA_PER_PAGE;
$page     = (isset($_GET['page']) && ctype_digit((string)$_GET['page'])) ? max(1, (int)$_GET['page']) : 1;

// Audit > Bejelentkezések has five independent lists on one page (unlike
// every other paginated view here, which has exactly one) -- each needs its
// own page number so paging one does not reset the others.
$qp = fn(string $k) => (isset($_GET[$k]) && ctype_digit((string)$_GET[$k])) ? max(1, (int)$_GET[$k]) : 1;
$al_page = $qp('al_page'); // admin_logins (successful)
$af_page = $qp('af_page'); // admin_login_failures
$mf_page = $qp('mf_page'); // mail_auth_failures
$ms_page = $qp('ms_page'); // mail_auth_successes
$ms_anom = isset($_GET['ms_anom']) && $_GET['ms_anom'] === '1'; // anomalies-only filter (tier >= medium)
$ul_page = $qp('ul_page'); // users' last login (DB)

// ── Shared holders ────────────────────────────────────────────────
$results = []; $page_results = []; $search_time = 0;
$total = 0; $total_pages = 1;
$audit_rows = []; $audit_error = ''; $admin_logins = [];
$admin_login_failures = []; $mail_auth_failures = []; $mail_auth_successes = [];
$al_total_pages = 1; $af_total_pages = 1; $mf_total_pages = 1; $ms_total_pages = 1; $ul_total_pages = 1;
$al_total = 0; $af_total = 0; $mf_total = 0; $ms_total = 0; $ul_total = 0;
$archive_rows = []; $archive_error = '';
$dash = [];
$signin_anomalies = ['24h' => ['high' => 0, 'medium' => 0, 'detail' => []],
                     '7'   => ['high' => 0, 'medium' => 0, 'detail' => []],
                     '30'  => ['high' => 0, 'medium' => 0, 'detail' => []]];
$domains = []; $domain_users = []; $filter_hidden = ''; $dropped_uids = [];
$admin_settings = []; $admin_fts = []; $admin_sysinfo = []; $admin_users = []; $admin_feeds = []; $breach_data = []; $admin_clamav = []; $blocked_stats = []; $feed_sources = []; $ioclookup_sources = []; $dnsbl_sites = []; $geoblock_countries = '';
$update_status = ['known' => false, 'check_disabled' => false, 'reason' => 'never_checked'];
$migration_status_data = [];
$postfix_settings = []; $postfix_restrictions = [];
$folder_counts = [];
$pfilters = ['domain' => $f_domain, 'user' => $f_user, 'folder' => $f_folder,
             'since' => $f_since, 'before' => $f_before, 'from' => $f_from, 'subject' => $f_subject];
$af = parse_af();

// ── Data loading ──────────────────────────────────────────────────
if ($is_admin) {
    $admin_settings         = admin_settings_load();
    $admin_sysinfo          = admin_system_info();
    $admin_users            = admin_users_list();
    $admin_pwexpiry_coverage = admin_pwexpiry_coverage();

} elseif ($is_sysconfig) {
    $admin_fts          = admin_fts_list();
    $admin_clamav       = admin_clamav_status();
    $update_status         = update_status();
    $migration_status_data = admin_migration_status();
    // $feed_sources stays: the feeds SUMMARY (rendered inline) counts from it.
    $feed_sources       = admin_feed_sources();
    // admin_feeds_status() and admin_geoblock_get_countries() are NOT loaded
    // here any more. Only the feed ROWS use them, and those moved behind
    // ?feedsbody=1 -- handle_feeds_body() loads them itself. Leaving the calls
    // meant the page still paid for a sudo helper it no longer rendered, so
    // the stated win of lazy-loading that card was not actually being had.
    // Both are pre-initialised at the top of this file, so the partial that
    // does use them still sees a defined variable.
    $postfix_settings   = postfix_settings_load();
    $dnsbl_sites        = postfix_dnsbl_sites();

    // Audit lives on this page now, as a collapsed section. The "ops" tab reads
    // a logrotated file and is cheap, so it always loads and the section has
    // something to show the moment it is expanded. The "logins" tab parses the
    // Apache access logs via admin_logins(), which is not cheap, so it only
    // loads when that tab was actually asked for.
    if ($audit_tab === 'logins') {
        // Each list is fetched once, generously capped (the underlying
        // source is already bounded to the last 8 days at the shell-script
        // level -- see qa-audit-log.sh), then sliced to QA_PER_PAGE_LOGINS
        // for display. A log-derived list has no COUNT(*) equivalent to
        // page against server-side the way the DB-backed one below does.
        $paginate = function (array $all, int $page) {
            $total       = count($all);
            $total_pages = max(1, (int)ceil($total / QA_PER_PAGE_LOGINS));
            $page        = min($page, $total_pages);
            $slice       = array_slice($all, ($page - 1) * QA_PER_PAGE_LOGINS, QA_PER_PAGE_LOGINS);
            return [$slice, $total, $total_pages, $page];
        };

        [$admin_logins,         $al_total, $al_total_pages, $al_page] = $paginate(admin_logins(300), $al_page);
        [$admin_login_failures, $af_total, $af_total_pages, $af_page] = $paginate(admin_login_failures(300), $af_page);
        [$mail_auth_failures,   $mf_total, $mf_total_pages, $mf_page] = $paginate(mail_auth_failures(500), $mf_page);
        // DB-backed (logins.db, kept current by qa-signin-monitor.php's own
        // 5-minute cron), NOT a live log parse like the three lists above --
        // see signin_events_success()'s own comment for why.
        [$mail_auth_successes,  $ms_total, $ms_total_pages, $ms_page] = $paginate(signin_events_success(500, $ms_anom), $ms_page);

        $db = audit_db();
        if (!$db) {
            $audit_error = t('Az audit-adatbázis nem elérhető (ellenőrizze a hozzáférési fájlt).');
        } else {
            try {
                $ul_total       = (int) $db->query('SELECT COUNT(*) FROM last_login')->fetchColumn();
                $ul_total_pages = max(1, (int)ceil($ul_total / QA_PER_PAGE_LOGINS));
                if ($ul_page > $ul_total_pages) { $ul_page = $ul_total_pages; }
                $off = ($ul_page - 1) * QA_PER_PAGE_LOGINS;
                $audit_rows  = $db->query(
                    "SELECT username, last_login FROM last_login ORDER BY last_login DESC LIMIT " . QA_PER_PAGE_LOGINS . " OFFSET $off"
                )->fetchAll(PDO::FETCH_ASSOC);
            } catch (Throwable $e) {
                $audit_error = t('Adatbázis-hiba a lekérdezés során.');
            }
        }
    } else {
        [$all_ops, $total] = audit_ops_all();
        $total_pages = max(1, (int)ceil($total / $per_page));
        if ($page > $total_pages) { $page = $total_pages; }
        $audit_rows = array_slice($all_ops, ($page - 1) * $per_page, $per_page);
    }

} elseif ($is_ioc) {
    // data loaded inside views/ioc.php via ioc_list()

} elseif ($is_campaigns) {
    // data loaded inside views/campaigns.php via campaign_list()

} elseif ($is_dash) {
    $dash              = dashboard_data();
    $admin_sysinfo     = admin_system_info();
    $admin_feeds       = admin_feeds_status();
    $update_status     = update_status();
    update_reconcile_audit(); // one-time latch, see src/update.php
    $admin_clamav      = admin_clamav_status();
    $breach_data       = admin_breach_status();
    $blocked_stats     = admin_blocked_stats();
    // Same three windows as the "Napi forgalom" chart's own range toggle
    // (24h / 7 / 30), reusing that card's dashSetRange() JS -- one query
    // per window since each is a different WHERE ts >= cutoff, not
    // something a single fetch can slice after the fact without also
    // fetching (and paying for) 30 days of detail on every page load.
    $signin_anomalies  = ['24h' => signin_anomaly_counts(24),
                          '7'   => signin_anomaly_counts(24 * 7),
                          '30'  => signin_anomaly_counts(24 * 30)];

} elseif ($is_about) {
    // static page - nothing to load

} elseif ($is_archive) {
    $domains = get_domains();
    [$archive_rows, $total, $archive_error] = archive_search($af, $page, $per_page);
    $total_pages = max(1, (int)ceil($total / $per_page));
    if ($page > $total_pages) {
        $page = $total_pages;
        [$archive_rows, $total, $archive_error] = archive_search($af, $page, $per_page);
    }

} elseif ($is_block || $is_white) {
    // data loaded inside views/lists.php via list_load()

} else {
    // ── Build quarantine results ──────────────────────────────────
    // KNOWN LIMITATION (accepted, not a bug): unlike the Archívum tab (backed by
    // the archive_index SQL table with cheap COUNT/OFFSET), quarantine has no
    // metadata index -- doveadm offers no cheap paginated/offset access -- so we
    // fetch headers for ALL matching messages, filter/sort in PHP, then slice one
    // page. Fine at typical volumes; the proper fix at large scale is a quarantine
    // metadata index mirroring archive_index, a separate project of its own.
    if ($do_search) {
        $t0 = microtime(true);

        $folders_to_check = match ($f_folder) {
            'Junk'       => ['Junk'],
            'Quarantine' => ['Quarantine'],
            'Spam'       => ['Spam'],
            'both'       => ['Junk', 'Quarantine'],
            default      => ['Junk', 'Quarantine', 'Spam'],
        };

        if ($f_user) {
            foreach ($folders_to_check as $folder) {
                $results = array_merge($results, fetch_folder($f_user, $folder, $f_since, $f_before));
            }
        } else {
            foreach ($folders_to_check as $folder) {
                foreach (search_all($folder, $f_since, $f_before) as $user => $uids) {
                    if ($user === 'postfix' || strpos($user, '@') === false) continue;
                    if ($f_domain && !str_ends_with($user, '@' . $f_domain)) continue;
                    $results = array_merge($results, fetch_uids($user, $folder, $uids));
                }
            }
        }

        // Free breakdown: the rows are already in hand, so counting them per
        // folder costs nothing and answers "which folder should I look in".
        $folder_counts = [];
        foreach ($results as $m) {
            $fk = $m['folder'] ?? '';
            if ($fk !== '') $folder_counts[$fk] = ($folder_counts[$fk] ?? 0) + 1;
        }

        if ($f_from !== '' || $f_subject !== '') {
            $results = array_values(array_filter($results, function ($m) use ($f_from, $f_subject) {
                if ($f_from !== '' && mb_stripos(decode_subject($m['hdr_from'] ?? ''), $f_from, 0, 'UTF-8') === false) return false;
                if ($f_subject !== '' && mb_stripos(decode_subject($m['hdr_subject'] ?? ''), $f_subject, 0, 'UTF-8') === false) return false;
                return true;
            }));
        }

        $qs_map = ['date' => 'date_received', 'user' => 'user', 'from' => 'hdr_from', 'subject' => 'hdr_subject'];
        $qs_key = $qs_map[$_GET['qsort'] ?? ''] ?? 'date_received';
        $qs_asc = strtoupper($_GET['qdir'] ?? '') === 'ASC';
        usort($results, function ($a, $b) use ($qs_key, $qs_asc) {
            $va = $qs_key === 'date_received' ? ($a[$qs_key] ?? '') : mb_strtolower(decode_subject($a[$qs_key] ?? ''));
            $vb = $qs_key === 'date_received' ? ($b[$qs_key] ?? '') : mb_strtolower(decode_subject($b[$qs_key] ?? ''));
            $cmp = strcmp((string)$va, (string)$vb);
            return $qs_asc ? $cmp : -$cmp;
        });
        $search_time = round(microtime(true) - $t0, 2);
        // Read after the search loop above, which is the only place in this
        // request that calls fetch_uids() -- see qa_fetch_dropped_uids() in
        // src/doveadm.php. Empty in the normal case.
        $dropped_uids = qa_fetch_dropped_uids();
    }

    $total       = count($results);
    $total_pages = max(1, (int)ceil($total / $per_page));
    if ($page > $total_pages) { $page = $total_pages; }
    $page_results = array_slice($results, ($page - 1) * $per_page, $per_page);

    $domains      = get_domains();
    $domain_users = $f_domain ? get_users($f_domain) : [];

    $filter_hidden = sprintf(
        '<input type="hidden" name="f_domain"  value="%s">
         <input type="hidden" name="f_user"    value="%s">
         <input type="hidden" name="f_folder"  value="%s">
         <input type="hidden" name="f_since"   value="%s">
         <input type="hidden" name="f_before"  value="%s">
         <input type="hidden" name="f_from"    value="%s">
         <input type="hidden" name="f_subject" value="%s">',
        h($f_domain), h($f_user), h($f_folder), h($f_since), h($f_before), h($f_from), h($f_subject)
    );
}

// ── Render ────────────────────────────────────────────────────────
require __DIR__ . '/views/layout_head.php';
require __DIR__ . '/views/layout_header.php';
echo '<div class="wrap">' . "\n";

if (isset($_GET['csrf'])):
    echo '<div class="notice notice-err"><svg class="icon"><use href="#icon-warning"></use></svg> ' . t('A művelet biztonsági okból elutasításra került (érvénytelen munkamenet). Próbáld újra.') . '</div>';
elseif (($_GET['listed'] ?? '') === 'block'):
    echo '<div class="notice notice-ok"><svg class="icon"><use href="#icon-block"></use></svg> ' . t('A feladó felkerült a <strong>blokklistára</strong>.') . '</div>';
elseif (($_GET['listed'] ?? '') === 'white'):
    echo '<div class="notice notice-ok"><svg class="icon"><use href="#icon-check"></use></svg> ' . t('A feladó felkerült a <strong>fehérlistára</strong>.') . '</div>';
elseif (($_GET['qerr'] ?? '') !== ''):
    echo '<div class="notice notice-err"><svg class="icon"><use href="#icon-warning"></use></svg> ' . h((string) $_GET['qerr']) . '</div>';
endif;

// Independent of the chain above (not an elseif): this can legitimately
// co-occur with a PRG banner (release/delete just happened, and this same
// search also hit a duplicate-uid drop). See qa_fetch_dropped_uids() /
// qa_fetch_sane_records() in src/doveadm.php for what this means.
//
// Suppressed while a free-text from/subject filter is active. A dropped
// record was never successfully parsed into a trustworthy From/Subject (that
// is *why* it was dropped), so there is no reliable way to tell whether it
// would have matched the filter -- it structurally can never satisfy one.
// Showing "N message(s) not shown" underneath a filtered result list (which
// already displays its own, unrelated match count) reads as "one of these
// filtered results is hidden", which is very likely false: the drop is far
// more often a normal narrow search hitting an unrelated old message
// somewhere else in the unfiltered date-range/folder scan than an actual
// forged header. Domain/user/folder scoping doesn't need the same treatment
// here: index.php never calls fetch_uids()/fetch_folder() for a domain or
// user outside the current filter in the first place (see the search loop
// above), so every entry in $dropped_uids already belongs to a mailbox this
// request actually searched -- only the free-text match is unknowable after
// the fact. The drop itself is never silent either way: qa_fetch_sane_records()
// still error_log()s it every time, filtered view or not.
if (!empty($dropped_uids) && $f_from === '' && $f_subject === ''):
    echo '<div class="notice notice-err"><svg class="icon"><use href="#icon-warning"></use></svg> '
        . h(sprintf(
            t('%1$d levél nincs megjelenítve, mert a postafiók-rendszer ismétlődő azonosítót (UID) adott vissza ugyanahhoz az üzenethez - ez hamisított fejléc jele lehet. Érintett üzenetek (postafiók/mappa: UID): %2$s'),
            count($dropped_uids), qa_fetch_dropped_display($dropped_uids)
        )) . '</div>';
endif;

// A doveadm gateway call failed somewhere in this request. Unconditional (not
// tied to the search path): without this the operator sees an ordinary empty
// result list and reasonably concludes there is no mail, when in fact nothing
// was searched. See qa_da() / qa_da_failures() in src/doveadm.php -- this is
// the visible half of the 2026-08-13 /dev/null incident's fix.
$da_failures = qa_da_failures();
if (!empty($da_failures)):
    echo '<div class="notice notice-err"><svg class="icon"><use href="#icon-warning"></use></svg> '
        . h(sprintf(
            t('A postafiók-átjáró hibára futott (%s), ezért ez a lista NEM teljes - a hiányzó találatok nem azt jelentik, hogy nincs levél. Nézd meg a webszerver hibanaplóját.'),
            implode(', ', $da_failures)
        )) . '</div>';
endif;

if ($is_admin)                  require __DIR__ . '/views/admin.php';
elseif ($is_sysconfig)          require __DIR__ . '/views/admin_system.php';
elseif ($is_ioc)                require __DIR__ . '/views/ioc.php';
elseif ($is_campaigns)          require __DIR__ . '/views/campaigns.php';
elseif ($is_pfa)                require __DIR__ . '/views/postfixadmin.php';
elseif ($is_dash)               require __DIR__ . '/views/dashboard.php';
elseif ($is_about)              require __DIR__ . '/views/about.php';
elseif ($is_archive)            require __DIR__ . '/views/archive.php';
elseif ($is_block || $is_white) require __DIR__ . '/views/lists.php';
else                            require __DIR__ . '/views/quarantine.php';

echo '</div><!-- .wrap -->' . "\n";
require __DIR__ . '/views/layout_foot.php';
