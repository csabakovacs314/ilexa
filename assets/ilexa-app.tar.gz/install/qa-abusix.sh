#!/bin/bash
#
# Abusix Mail Intelligence key control: enable/replace/clear the DNS datafeed
# key that routes IP, domain and allowlist lookups through Abusix.
#
# Like Spamhaus DQS there is no separate keyfile: the key is embedded directly
# in the DNS zone hostnames rspamd queries, so it lives in the config itself --
# rbl.d/20-abusix.conf, this script's slice and the ONLY file it writes.
#
# rbl.conf is a shared wrapper whose rbls{} block glob-includes rbl.d/*.conf.
# That layout is why this script can exist at all: on 2026-08-16 the Spamhaus
# DQS script assumed it owned the whole of rbl.conf and silently destroyed a
# live Abusix config (3 rules, this same key) for ~4.5 hours. Writing an Abusix
# script against that layout would have reproduced the bug in mirror image --
# the next Abusix key-set would have wiped Spamhaus DQS. Each owner now writes
# one slice and cannot touch another's.
#
# CORRECTION, 2026-08-17. Earlier versions of this file (and the commits that
# introduced it) stated that Abusix also required this server's public IP to be
# allowlisted in their portal, and the console repeated it. THAT WAS WRONG.
# Tested directly: the same key answers from two hosts with different public
# IPs, each running its own recursive unbound so Abusix genuinely saw two
# different source addresses -- and it answers through public resolvers too.
# The key alone authorizes the query. A key they will not serve is REFUSED,
# which a recursive resolver reports as SERVFAIL (not NXDOMAIN). No portal
# allowlist exists to configure, and telling an operator to go find one sent
# them looking for a setting that is not there.
#
# What CAN still silence the feed, and what `test` now reports instead: a wrong
# or revoked key, a lapsed subscription, or a resolver that cannot reach the
# Abusix nameservers. All three look identical from a bare lookup -- an empty
# answer -- so the probe uses a keyless control query to separate "reachable,
# key refused" from "the resolver never got there".
#
#   qa-abusix.sh status    JSON: {"has_key":bool,"reachable":true|false|null,
#                          "state":"..."} -- reachable is null when no key is
#                          set. Runs the same live probe as `test`, so the
#                          console can show a source as working rather than
#                          merely configured; the PHP side caches it.
#   qa-abusix.sh set-key   key on stdin; empty input clears (removes the slice)
#   qa-abusix.sh test      JSON: {"ok":true|false,"detail":"..."} -- live DNS
#                          probe of 2.0.0.127 in the combined zone, Abusix's
#                          own test point. Reads the key from the slice; never
#                          takes it as an argument and never prints it.
set -uo pipefail

LOCALD=/etc/rspamd/local.d
RBL_CONF="$LOCALD/rbl.conf"          # shared wrapper: created if absent, never edited
RBL_D="$LOCALD/rbl.d"
AMI_CONF="$RBL_D/20-abusix.conf"     # this script's slice -- the only file it writes
# shellcheck disable=SC2016  # $LOCAL_CONFDIR is rspamd's own variable, must stay literal
RBL_GLOB='.include(glob=true,try=true,priority=1,duplicate=merge) "$LOCAL_CONFDIR/local.d/rbl.d/*.conf"'
die() { echo "qa-abusix: $*" >&2; exit 2; }

_reload_rspamd() {
    systemctl is-active --quiet rspamd || return 0
    if rspamadm configtest >/dev/null 2>&1; then
        systemctl reload rspamd
    else
        die "rspamd configtest failed after this change -- reload skipped, check $AMI_CONF"
    fi
}

# Same guard as qa-spamhaus-dqs.sh: refuse to write a slice on a host still
# carrying the old monolithic rbl.conf, where rbl.d/ is never included and the
# write would be a silent no-op leaving the previous key live.
_ensure_split_layout() {
    mkdir -p "$RBL_D" || die "cannot create $RBL_D"
    chown root:_rspamd "$RBL_D" 2>/dev/null || chown root:root "$RBL_D"
    chmod 0750 "$RBL_D"

    if [ ! -s "$RBL_CONF" ]; then
        umask 027
        printf '%s\n' \
          '# Shared wrapper. Every rbls{} rule lives in its own file under' \
          '# rbl.d/, one per owner, so no feature can overwrite another'"'"'s.' \
          '# Do not add rules here -- add rbl.d/<NN>-<owner>.conf instead.' \
          'rbls {' \
          "  $RBL_GLOB" \
          '}' > "$RBL_CONF" || die "cannot create $RBL_CONF"
        chown root:_rspamd "$RBL_CONF" 2>/dev/null || chown root:root "$RBL_CONF"
        chmod 0640 "$RBL_CONF"
        return 0
    fi

    grep -qF 'local.d/rbl.d/*.conf' "$RBL_CONF" && return 0
    die "$RBL_CONF does not glob-include rbl.d/ -- this host still has the old monolithic layout, so writing a slice would silently have no effect. Migrate it first: move each rbls{} sub-block into its own $RBL_D/<NN>-<owner>.conf and leave rbl.conf containing only the include."
}

# Weights live in groups.conf, which several modules append to -- so touch it
# the same way they do (grep-guard + append), never rewrite it.
_ensure_ami_weights() {
    touch "$LOCALD/groups.conf"
    grep -q '"RBL_AMI_BLACK"' "$LOCALD/groups.conf" && return 0
    cat >> "$LOCALD/groups.conf" <<'EOF'

group "rbl" {
  symbols {
    "RBL_AMI_BLACK" {
      weight = 4.0;
      description = "Sending IP in Abusix Mail Intelligence black (spam/abuse source)";
    }
    "RBL_AMI_EXPLOIT" {
      weight = 4.5;
      description = "Sending IP in Abusix Mail Intelligence exploit (compromised host / botnet)";
    }
    "RBL_AMI_POLICY" {
      weight = 1.5;
      description = "Sending IP in Abusix Mail Intelligence policy (dynamic/residential)";
    }
    "URIBL_AMI_BLACK" {
      weight = 4.0;
      description = "URL/email domain in Abusix Mail Intelligence dblack";
    }
    "RWL_AMI" {
      weight = -2.0;
      description = "Sending IP in Abusix Mail Intelligence allowlist";
    }
  }
}
EOF
}

# Read the key out of the slice. Never taken as an argument, never printed.
_slice_key() {
    [ -s "$AMI_CONF" ] || return 1
    grep -oP 'rbl = "\K[^.]+(?=\.combined\.mail\.abusix\.zone)' "$AMI_CONF" | head -1
}

# Probe Abusix's own test point, 2.0.0.127, which is listed in every combined-
# zone sub-list. Sets PROBE_STATE and PROBE_ANS.
#
#   answered    -> the key works and the resolver reached Abusix
#   rejected    -> Abusix is reachable but will not serve this key (mistyped,
#                  revoked, or the subscription lapsed)
#   unreachable -> the resolver could not reach Abusix at all
#
# A key Abusix does not accept comes back SERVFAIL, NOT NXDOMAIN -- measured, an
# earlier version of this function guessed NXDOMAIN and so reported every bad
# key as "unreachable". But SERVFAIL alone cannot carry the verdict either: a
# resolver that cannot reach Abusix returns SERVFAIL for a perfectly good key
# too. So when the keyed lookup fails, ask a question that needs no key -- the
# zone's own NS record. If that answers, Abusix is reachable and the key is what
# was refused; if it does not, the problem is the resolver, not the key.
#
# Two attempts before reporting unreachable: a single +time=3 +tries=1 miss on a
# momentarily busy resolver is not evidence the feed is broken, and painting the
# row red on one timeout would just swap a dishonest green for a dishonest red.
_probe() {
    local key="$1" name attempt ans
    name="2.0.0.127.${key}.combined.mail.abusix.zone"
    PROBE_ANS=''; PROBE_STATE=unreachable
    for attempt in 1 2; do
        ans="$(dig +short +time=3 +tries=1 A "$name" 2>/dev/null)"
        if printf '%s' "$ans" | grep -q '^127\.0\.0\.'; then
            PROBE_ANS="$(printf '%s' "$ans" | tr '\n' ' ' | sed 's/ $//')"
            PROBE_STATE=answered
            return 0
        fi
    done
    # Keyed lookup failed twice. Keyless control: is Abusix reachable at all?
    #
    # Match the shape of an actual NS answer rather than testing for non-empty
    # output. `dig +short` writes ";; connection timed out; no servers could be
    # reached" to STDOUT and still exits 0, so a plain -n test treats a totally
    # dead resolver as a successful control -- and then blames the key. That is
    # the worst possible failure for this function: it sends the operator to
    # re-check a key that is fine while the real fault is DNS.
    if dig +short +time=3 +tries=1 NS mail.abusix.zone 2>/dev/null \
         | grep -qE '^[a-z0-9][a-z0-9.-]*\.$'; then
        PROBE_STATE=rejected
    else
        PROBE_STATE=unreachable
    fi
    return 1
}

op="${1:-}"

case "$op" in
  status)
    # "A key is configured" is NOT the same as "the feed works", and reporting
    # the first as if it were the second is how a source sits green in the
    # console while every lookup silently returns nothing. So probe.
    key="$(_slice_key)" || { printf '{"has_key":false,"reachable":null,"state":"nokey"}\n'; exit 0; }
    if [ -z "$key" ]; then
      printf '{"has_key":true,"reachable":false,"state":"unreadable"}\n'; exit 0
    fi
    if _probe "$key"; then
      printf '{"has_key":true,"reachable":true,"state":"answered"}\n'
    else
      printf '{"has_key":true,"reachable":false,"state":"%s"}\n' "$PROBE_STATE"
    fi
    ;;

  set-key)
    _ensure_split_layout
    key="$(cat)"                      # stdin only - never an argument
    key="${key//[$'\r\n']/}"          # a trailing newline breaks the DNS hostname
    if [ -z "$key" ]; then
        # Delete ONLY this slice. Removing rbl.conf here would take Spamhaus
        # DQS and every other owner down with it.
        rm -f "$AMI_CONF"
        _reload_rspamd
        echo "OK cleared"
        exit 0
    fi
    umask 027
    tmp="$(mktemp "$RBL_D/.20-abusix.conf.XXXXXX")" || die "mktemp failed"
    # No `rbls {` wrapper: this file is glob-included from INSIDE rbl.conf's own
    # rbls{} block, so its rules sit at top level. Wrapping them again nests
    # rbls{} in rbls{} and nothing registers -- while configtest still reports
    # "syntax OK", because try=true also makes an unresolved include non-fatal.
    # Verify a change here with `rspamadm configdump rbl`, never configtest.
    cat > "$tmp" <<EOF
# Abusix Mail Intelligence -- DNS datafeed key embedded in the zone hostnames
# below. The key is what authorizes the query; there is no per-IP allowlist to
# configure (an earlier version of this comment claimed otherwise and was
# wrong). A key Abusix does not accept returns NXDOMAIN for every lookup, which
# is silent -- verify with 'qa-abusix.sh test' rather than assuming it works.
# (No backticks in this heredoc: it is unquoted so the key interpolates, which
# means backticks would RUN as a command -- they did, printing an error onto
# stderr that the console then read as a failed save.)
# CONTAINS A SECRET KEY -> kept at 0640 root:_rspamd.
# Managed by qa-abusix.sh -- do not hand-edit, changes are overwritten.
#
# Return codes checked against Abusix's published production-zone table:
# combined=127.0.0.x, dblack=127.0.1.x, white=127.0.2.x. combined and white use
# the default IP check; dblack is domain-only (no_ip). In combined, .2/.3 are
# black.zone (trap hits / low reputation near traps), .200 is black.zone manual
# network listings, .4 is exploit.zone, .11/.12 are dynamic.zone (generic and
# missing rDNS). .200 was previously left unmapped, so an IP that Abusix had
# manually listed matched no returncode and scored nothing at all.
ABUSIX_MAIL {
  rbl = "${key}.combined.mail.abusix.zone";
  ipv6 = true;
  checks = ["from"];
  returncodes {
    RBL_AMI_BLACK = ["127.0.0.2", "127.0.0.3", "127.0.0.200"];
    RBL_AMI_EXPLOIT = ["127.0.0.4"];
    RBL_AMI_POLICY = ["127.0.0.11", "127.0.0.12"];
  }
}
URIBL_AMI {
  rbl = "${key}.dblack.mail.abusix.zone";
  no_ip = true;
  emails_domainonly = true;
  ignore_defaults = true;
  checks = ["urls", "content_urls", "emails", "dkim"];
  returncodes {
    URIBL_AMI_BLACK = ["127.0.1.1", "127.0.1.2", "127.0.1.3"];
  }
}
RWL_AMI {
  rbl = "${key}.white.mail.abusix.zone";
  is_whitelist = true;
  ipv6 = true;
  checks = ["from"];
  returncodes {
    RWL_AMI = ["127.0.2.1", "127.0.2.2", "127.0.2.3", "127.0.2.4", "127.0.2.5"];
  }
}
EOF
    chown root:_rspamd "$tmp" 2>/dev/null || chown root:root "$tmp"
    chmod 0640 "$tmp"
    mv -f "$tmp" "$AMI_CONF"
    _ensure_ami_weights
    _reload_rspamd
    echo OK
    ;;

  test)
    if [ ! -s "$AMI_CONF" ]; then
      printf '{"ok":false,"detail":"nincs beallitva kulcs"}\n'
      exit 0
    fi
    key="$(_slice_key)"
    if [ -z "$key" ]; then
      printf '{"ok":false,"detail":"a kulcs nem olvashato ki a rbl.d/20-abusix.conf-bol"}\n'
      exit 0
    fi
    if _probe "$key"; then
      printf '{"ok":true,"detail":"combined zona valaszolt: %s"}\n' "$PROBE_ANS"
    elif [ "$PROBE_STATE" = rejected ]; then
      # Abusix is reachable (its NS record resolves) but will not serve this
      # key. Nothing to do with this server's IP: there is no portal allowlist
      # (verified 2026-08-17, same key answering from two hosts with different
      # public IPs).
      printf '{"ok":false,"detail":"az Abusix elerheto, de ezt a kulcsot nem szolgalja ki - elgepelt, visszavont, vagy lejart az elofizetes"}\n'
    else
      printf '{"ok":false,"detail":"az Abusix nevszerverei nem valaszoltak ket probalkozasra sem - a DNS-feloldo nem eri el oket (halozat, tuzfal, vagy a feloldo maga)"}\n'
    fi
    ;;

  *) die "usage: status | set-key | test" ;;
esac
