#!/bin/bash
#
# Brand-guard standing config: which brands the rspamd Lua rule
# HU_BRAND_DN_SPOOF (lua.d/brand_guard.lua) protects against display-name
# impersonation, each brand's name variants and REAL sending domains. The
# console's Rendszer card edits it; the installer seeds it.
#
# Single source of truth: /etc/rspamd/local.d/brand_definitions.json —
# the very file the Lua rule reads, so there is nothing to render and
# nothing to drift. Every mutation is validated in python, written
# atomically (tmp + mv, .bak kept) and finished with `apply`.
#
# apply RESTARTS rspamd rather than reloading it: the Lua rule and its JSON
# are executed once at worker start, and a reload demonstrably does NOT
# re-run them (verified on the reference host — the symbol only appeared
# after a full restart). The restart takes a few seconds; postfix's milter
# keeps mail queued meanwhile.
#
# Lure phrases (brand_lures.json) are managed by the same helper: they are
# the SECOND half of the same feature -- a phrase only ever scores next to a
# brand hit -- so one card, one helper, one restart.
#
#   qa-brand-guard.sh list                          the JSON as-is
#   qa-brand-guard.sh lures                         the lure JSON as-is
#   qa-brand-guard.sh init                          create an empty skeleton (only if absent)
#   qa-brand-guard.sh set-enabled yes|no            master switch + apply
#   qa-brand-guard.sh lure-set-enabled yes|no       lure-layer switch + apply
#   qa-brand-guard.sh lure-add <lang> <phrase>      add a phrase (new lang = new list)
#   qa-brand-guard.sh lure-remove <lang> <phrase>   remove a phrase (drops an emptied lang)
#   qa-brand-guard.sh add-brand <id> <name>         new brand (no variants/domains yet)
#   qa-brand-guard.sh remove-brand <id>
#   qa-brand-guard.sh add-variant <id> <variant>    "=variant" = whole-name-only match
#   qa-brand-guard.sh remove-variant <id> <variant>
#   qa-brand-guard.sh add-domain <id> <domain>      the brand's REAL domain (never flagged)
#   qa-brand-guard.sh remove-domain <id> <domain>
#   qa-brand-guard.sh apply                         validate + restart rspamd
set -uo pipefail

CONF=/etc/rspamd/local.d/brand_definitions.json
LURES=/etc/rspamd/local.d/brand_lures.json
die() { echo "qa-brand-guard: $*" >&2; exit 2; }

valid_id()      { [[ "$1" =~ ^[a-z0-9][a-z0-9_-]{0,31}$ ]]; }
valid_variant() { [[ "$1" =~ ^=?[a-z0-9][a-z0-9\ ]{2,46}$ ]]; }   # min 3 chars: shorter matches half the alphabet at distance 1
valid_domain()  { [[ "$1" =~ ^[a-z0-9]([a-z0-9._-]{0,251}[a-z0-9])?$ ]] && [[ "$1" == *.* ]]; }

init_conf() {
  [ -s "$CONF" ] && { echo "already initialised"; return 0; }
  printf '{\n  "enabled": true,\n  "brands": []\n}\n' > "$CONF"
  chmod 644 "$CONF"
  echo "OK initialised empty"
}

# Returns 0/1 instead of dying, so a caller that has just replaced a live file
# can roll it back. The `apply` verb turns a non-zero into die() itself.
_apply() {
  [ -s "$CONF" ] || { echo "qa-brand-guard: no config at $CONF — run 'init' first" >&2; return 1; }
  python3 -c "import json,sys; json.load(open('$CONF'))" \
    || { echo "qa-brand-guard: $CONF is not valid JSON — nothing restarted" >&2; return 1; }
  rspamadm configtest >/dev/null 2>&1 \
    || { echo "qa-brand-guard: rspamadm configtest failed — nothing restarted" >&2; return 1; }

  # Clear systemd's start-limit counter BEFORE restarting.
  #
  # rspamd ships Restart=always with StartLimitBurst=5 / StartLimitIntervalUSec=10s
  # (verified on both supported families). Every brand or lure edit restarts
  # rspamd -- and the console renders one submit button per chip, so tidying a
  # handful of variants, a double-clicked button, or two admins editing at once
  # trips that limit. systemd then REFUSES the start and rspamd stays down on a
  # production mail server, with Restart=always powerless to recover it.
  # reset-failed zeroes the counter, so an operator editing quickly cannot
  # switch off their own spam filtering.
  systemctl reset-failed rspamd >/dev/null 2>&1 || true
  systemctl restart rspamd >/dev/null 2>&1 \
    || { echo "qa-brand-guard: rspamd restart failed" >&2; return 1; }

  # Do not report success until it is genuinely back: a restart that exits 0
  # and then dies during startup would otherwise read as "applied".
  local i
  for i in $(seq 1 30); do
    systemctl is-active --quiet rspamd && { echo "OK applied (rspamd restarted)"; return 0; }
    sleep 1
  done
  echo "qa-brand-guard: rspamd did not come back after the restart" >&2
  return 1
}

# All structural edits happen here: python owns the JSON, bash owns argv
# validation and the surrounding transaction (backup, atomic replace).
_edit() { # op args...
  [ -s "$CONF" ] || init_conf >/dev/null
  local tmp
  tmp=$(mktemp "${CONF}.XXXXXX") || die "mktemp failed"
  if ! python3 - "$@" > "$tmp" <<'PYEOF'
import json, re, sys

op = sys.argv[1]; args = sys.argv[2:]
CONF = '/etc/rspamd/local.d/brand_definitions.json'
def die(msg): print('ERR ' + msg, file=sys.stderr); sys.exit(1)

with open(CONF) as f: data = json.load(f)
if not isinstance(data.get('brands'), list): die('malformed config: no brands list')
brands = data['brands']
def find(bid):
    for b in brands:
        if b.get('id') == bid: return b
    return None

if op == 'set-enabled':
    data['enabled'] = (args[0] == 'yes')
elif op == 'add-brand':
    bid, name = args
    name = name.strip()
    if not (1 <= len(name) <= 64) or \
       not all(ch.isalnum() or ch in " &.,()'-" for ch in name) or \
       any(ord(ch) < 32 for ch in name):
        die('invalid brand name')
    if find(bid): die('brand %s already exists' % bid)
    if len(brands) >= 64: die('brand limit (64) reached')
    brands.append({'id': bid, 'name': name, 'variants': [], 'domains': []})
elif op == 'remove-brand':
    b = find(args[0]) or die('no such brand: %s' % args[0])
    brands.remove(b)
elif op in ('add-variant', 'remove-variant', 'add-domain', 'remove-domain'):
    bid, val = args
    b = find(bid) or die('no such brand: %s' % bid)
    key = 'variants' if 'variant' in op else 'domains'
    lst = b.setdefault(key, [])
    if op.startswith('add'):
        if val in lst: die('%s already listed for %s' % (val, bid))
        if len(lst) >= 16: die('%s limit (16) reached for %s' % (key, bid))
        lst.append(val)
    else:
        if val not in lst: die('%s is not listed for %s' % (val, bid))
        lst.remove(val)
else:
    die('unknown op ' + op)

json.dump(data, sys.stdout, ensure_ascii=False, indent=2)
sys.stdout.write('\n')
PYEOF
  then rm -f "$tmp"; exit 2; fi
  python3 -c "import json,sys; json.load(open(sys.argv[1]))" "$tmp" || { rm -f "$tmp"; die "internal error: produced invalid JSON"; }
  cp -a "$CONF" "$CONF.bak" 2>/dev/null || true
  chmod 644 "$tmp" && mv "$tmp" "$CONF" || { rm -f "$tmp"; die "cannot replace $CONF"; }
  # The live file is already replaced at this point, so a failure here must not
  # simply report "nothing restarted" and walk away leaving the new content in
  # place -- the next restart from any cause would then load it.
  if ! _apply; then
    cp -a "$CONF.bak" "$CONF" 2>/dev/null && _apply >/dev/null 2>&1
    die "change rejected and rolled back — $CONF is as it was"
  fi
}

init_lures() {
  [ -s "$LURES" ] && return 0
  printf '{\n  "enabled": true,\n  "phrases": {}\n}\n' > "$LURES"
  chmod 644 "$LURES"
}

# Same transaction shape as _edit, against the lures file. Python owns the
# JSON and the phrase/language charset rules; bash owns the transaction.
_edit_lures() { # op args...
  init_lures
  local tmp
  tmp=$(mktemp "${LURES}.XXXXXX") || die "mktemp failed"
  if ! python3 - "$@" > "$tmp" <<'PYEOF'
import json, re, sys

op = sys.argv[1]; args = sys.argv[2:]
LURES = '/etc/rspamd/local.d/brand_lures.json'
def die(msg): print('ERR ' + msg, file=sys.stderr); sys.exit(1)

with open(LURES) as f: data = json.load(f)
ph = data.setdefault('phrases', {})
if not isinstance(ph, dict): die('malformed config: phrases is not an object')

if op == 'lure-set-enabled':
    data['enabled'] = (args[0] == 'yes')
elif op in ('lure-add', 'lure-remove'):
    lang, phrase = args[0], ' '.join(args[1].split())
    if not re.fullmatch(r'[a-z]{2,8}', lang):
        die('invalid language code (2-8 lowercase letters, e.g. en, hu, de)')
    # The rule folds accents and case anyway, so any script is fine here; what
    # must not get in is control characters or JSON-hostile junk.
    if not (8 <= len(phrase) <= 64):
        die('phrase must be 8-64 characters (shorter phrases match ordinary prose)')
    if any(ord(c) < 32 for c in phrase) or not all(
            c.isalnum() or c in " -'&.," for c in phrase):
        die('phrase may contain only letters, digits, spaces and - \' & . ,')
    lst = ph.setdefault(lang, [])
    low = phrase.lower()
    if op == 'lure-add':
        if any(x.lower() == low for x in lst): die('phrase already listed for %s' % lang)
        if len(lst) >= 200: die('phrase limit (200) reached for %s' % lang)
        if len(ph) > 12 and lang not in ph: die('language limit (12) reached')
        lst.append(phrase)
    else:
        keep = [x for x in lst if x.lower() != low]
        if len(keep) == len(lst): die('phrase is not listed for %s' % lang)
        # An emptied language would otherwise linger as a dead heading.
        if keep: ph[lang] = keep
        else: del ph[lang]
else:
    die('unknown op ' + op)

json.dump(data, sys.stdout, ensure_ascii=False, indent=2)
sys.stdout.write('\n')
PYEOF
  then rm -f "$tmp"; exit 2; fi
  python3 -c "import json,sys; json.load(open(sys.argv[1]))" "$tmp" || { rm -f "$tmp"; die "internal error: produced invalid JSON"; }
  cp -a "$LURES" "$LURES.bak" 2>/dev/null || true
  chmod 644 "$tmp" && mv "$tmp" "$LURES" || { rm -f "$tmp"; die "cannot replace $LURES"; }
  if ! _apply; then
    cp -a "$LURES.bak" "$LURES" 2>/dev/null && _apply >/dev/null 2>&1
    die "change rejected and rolled back — $LURES is as it was"
  fi
}

# SERIALIZE mutations. The card renders one submit button per chip, so two
# admins -- or one impatient double-click -- can land two edits at once. Both
# would read the same JSON, and the second write would silently discard the
# first. A read verb takes no lock: `list`/`lures` must stay fast, they are on
# the page-render path.
LOCK=/run/qa-brand-guard.lock
case "${1:-}" in
  list|lures|init) ;;
  *)
    if [ -z "${QA_BG_LOCKED:-}" ] && command -v flock >/dev/null 2>&1; then
      export QA_BG_LOCKED=1
      exec flock -w 120 "$LOCK" "$0" "$@"
    fi
    ;;
esac

case "${1:-}" in
  list)
    [ -s "$CONF" ] || init_conf >/dev/null
    cat "$CONF" ;;
  lures)
    init_lures
    cat "$LURES" ;;
  lure-set-enabled)
    [[ "${2:-}" =~ ^(yes|no)$ ]] || die "lure-set-enabled takes yes|no"
    _edit_lures lure-set-enabled "$2" ;;
  lure-add|lure-remove)
    [ -n "${2:-}" ] && [ -n "${3:-}" ] || die "usage: $1 <lang> <phrase>"
    [ "${#3}" -le 64 ] || die "phrase too long"
    _edit_lures "$1" "$2" "$3" ;;
  init)         init_conf ;;
  set-enabled)
    [[ "${2:-}" =~ ^(yes|no)$ ]] || die "set-enabled takes yes|no"
    _edit set-enabled "$2" ;;
  add-brand)
    valid_id "${2:-}" || die "invalid brand id (a-z0-9_-, max 32)"
    [ -n "${3:-}" ] || die "missing brand name"
    _edit add-brand "$2" "$3" ;;
  remove-brand)
    valid_id "${2:-}" || die "invalid brand id"
    _edit remove-brand "$2" ;;
  add-variant|remove-variant)
    valid_id "${2:-}" || die "invalid brand id"
    valid_variant "${3:-}" || die "invalid variant (lowercase a-z0-9/spaces, 3-47 chars, optional '=' prefix)"
    _edit "$1" "$2" "$3" ;;
  add-domain|remove-domain)
    valid_id "${2:-}" || die "invalid brand id"
    valid_domain "${3:-}" || die "invalid domain"
    _edit "$1" "$2" "$3" ;;
  apply)        _apply || die "apply failed" ;;
  *) die "usage: list | lures | init | set-enabled yes|no | add-brand <id> <name> | remove-brand <id> | add-variant <id> <v> | remove-variant <id> <v> | add-domain <id> <d> | remove-domain <id> <d> | lure-set-enabled yes|no | lure-add <lang> <phrase> | lure-remove <lang> <phrase> | apply" ;;
esac
