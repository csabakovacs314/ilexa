#!/bin/bash
#
# Brand-guard standing config: which brands the rspamd Lua rule
# HU_BRAND_DN_SPOOF (lua.d/brand_guard.lua) protects against display-name
# impersonation, each brand's name variants and REAL sending domains. The
# console's Rendszer card edits it; the installer seeds it.
#
# Single source of truth: /etc/rspamd/local.d/brand_definitions.json —
# the very file the Lua rule reads, so there is nothing to render and
# nothing to drift. Every mutation is validated in python, written
# atomically (tmp + mv, .bak kept) and finished with `apply`.
#
# apply RESTARTS rspamd rather than reloading it: the Lua rule and its JSON
# are executed once at worker start, and a reload demonstrably does NOT
# re-run them (verified on the reference host — the symbol only appeared
# after a full restart). The restart takes a few seconds; postfix's milter
# keeps mail queued meanwhile.
#
#   qa-brand-guard.sh list                          the JSON as-is
#   qa-brand-guard.sh init                          create an empty skeleton (only if absent)
#   qa-brand-guard.sh set-enabled yes|no            master switch + apply
#   qa-brand-guard.sh add-brand <id> <name>         new brand (no variants/domains yet)
#   qa-brand-guard.sh remove-brand <id>
#   qa-brand-guard.sh add-variant <id> <variant>    "=variant" = whole-name-only match
#   qa-brand-guard.sh remove-variant <id> <variant>
#   qa-brand-guard.sh add-domain <id> <domain>      the brand's REAL domain (never flagged)
#   qa-brand-guard.sh remove-domain <id> <domain>
#   qa-brand-guard.sh apply                         validate + restart rspamd
set -uo pipefail

CONF=/etc/rspamd/local.d/brand_definitions.json
die() { echo "qa-brand-guard: $*" >&2; exit 2; }

valid_id()      { [[ "$1" =~ ^[a-z0-9][a-z0-9_-]{0,31}$ ]]; }
valid_variant() { [[ "$1" =~ ^=?[a-z0-9][a-z0-9\ ]{2,46}$ ]]; }   # min 3 chars: shorter matches half the alphabet at distance 1
valid_domain()  { [[ "$1" =~ ^[a-z0-9]([a-z0-9._-]{0,251}[a-z0-9])?$ ]] && [[ "$1" == *.* ]]; }

init_conf() {
  [ -s "$CONF" ] && { echo "already initialised"; return 0; }
  printf '{\n  "enabled": true,\n  "brands": []\n}\n' > "$CONF"
  chmod 644 "$CONF"
  echo "OK initialised empty"
}

_apply() {
  [ -s "$CONF" ] || die "no config at $CONF — run 'init' first"
  python3 -c "import json,sys; json.load(open('$CONF'))" || die "$CONF is not valid JSON — nothing restarted"
  rspamadm configtest >/dev/null 2>&1 || die "rspamadm configtest failed — nothing restarted"
  systemctl restart rspamd >/dev/null 2>&1 || die "rspamd restart failed"
  echo "OK applied (rspamd restarted)"
}

# All structural edits happen here: python owns the JSON, bash owns argv
# validation and the surrounding transaction (backup, atomic replace).
_edit() { # op args...
  [ -s "$CONF" ] || init_conf >/dev/null
  local tmp
  tmp=$(mktemp "${CONF}.XXXXXX") || die "mktemp failed"
  if ! python3 - "$@" > "$tmp" <<'PYEOF'
import json, re, sys

op = sys.argv[1]; args = sys.argv[2:]
CONF = '/etc/rspamd/local.d/brand_definitions.json'
def die(msg): print('ERR ' + msg, file=sys.stderr); sys.exit(1)

with open(CONF) as f: data = json.load(f)
if not isinstance(data.get('brands'), list): die('malformed config: no brands list')
brands = data['brands']
def find(bid):
    for b in brands:
        if b.get('id') == bid: return b
    return None

if op == 'set-enabled':
    data['enabled'] = (args[0] == 'yes')
elif op == 'add-brand':
    bid, name = args
    name = name.strip()
    if not (1 <= len(name) <= 64) or \
       not all(ch.isalnum() or ch in " &.,()'-" for ch in name) or \
       any(ord(ch) < 32 for ch in name):
        die('invalid brand name')
    if find(bid): die('brand %s already exists' % bid)
    if len(brands) >= 64: die('brand limit (64) reached')
    brands.append({'id': bid, 'name': name, 'variants': [], 'domains': []})
elif op == 'remove-brand':
    b = find(args[0]) or die('no such brand: %s' % args[0])
    brands.remove(b)
elif op in ('add-variant', 'remove-variant', 'add-domain', 'remove-domain'):
    bid, val = args
    b = find(bid) or die('no such brand: %s' % bid)
    key = 'variants' if 'variant' in op else 'domains'
    lst = b.setdefault(key, [])
    if op.startswith('add'):
        if val in lst: die('%s already listed for %s' % (val, bid))
        if len(lst) >= 16: die('%s limit (16) reached for %s' % (key, bid))
        lst.append(val)
    else:
        if val not in lst: die('%s is not listed for %s' % (val, bid))
        lst.remove(val)
else:
    die('unknown op ' + op)

json.dump(data, sys.stdout, ensure_ascii=False, indent=2)
sys.stdout.write('\n')
PYEOF
  then rm -f "$tmp"; exit 2; fi
  python3 -c "import json,sys; json.load(open(sys.argv[1]))" "$tmp" || { rm -f "$tmp"; die "internal error: produced invalid JSON"; }
  cp -a "$CONF" "$CONF.bak" 2>/dev/null || true
  chmod 644 "$tmp" && mv "$tmp" "$CONF" || { rm -f "$tmp"; die "cannot replace $CONF"; }
  _apply
}

case "${1:-}" in
  list)
    [ -s "$CONF" ] || init_conf >/dev/null
    cat "$CONF" ;;
  init)         init_conf ;;
  set-enabled)
    [[ "${2:-}" =~ ^(yes|no)$ ]] || die "set-enabled takes yes|no"
    _edit set-enabled "$2" ;;
  add-brand)
    valid_id "${2:-}" || die "invalid brand id (a-z0-9_-, max 32)"
    [ -n "${3:-}" ] || die "missing brand name"
    _edit add-brand "$2" "$3" ;;
  remove-brand)
    valid_id "${2:-}" || die "invalid brand id"
    _edit remove-brand "$2" ;;
  add-variant|remove-variant)
    valid_id "${2:-}" || die "invalid brand id"
    valid_variant "${3:-}" || die "invalid variant (lowercase a-z0-9/spaces, 3-47 chars, optional '=' prefix)"
    _edit "$1" "$2" "$3" ;;
  add-domain|remove-domain)
    valid_id "${2:-}" || die "invalid brand id"
    valid_domain "${3:-}" || die "invalid domain"
    _edit "$1" "$2" "$3" ;;
  apply)        _apply ;;
  *) die "usage: list | init | set-enabled yes|no | add-brand <id> <name> | remove-brand <id> | add-variant <id> <v> | remove-variant <id> <v> | add-domain <id> <d> | remove-domain <id> <d> | apply" ;;
esac
