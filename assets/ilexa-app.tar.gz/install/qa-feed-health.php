#!/usr/bin/php
<?php
// Feed-health verdicts (feed_health()) as JSON, for a caller that must not
// touch iocs.db directly. Deliberately run as the WEB USER (apache) -- see
// qa-feed-sample.php's header: a root-owned iocs.db journal in apache's 0700
// cache dir has broken this app twice. qa-weekly-digest.php (root, weekly
// cron) shells out to this via `runuser -u apache` instead of loading
// feed_health.php in its own (root) process.
//
// Prints one JSON object {feed_key: {state, baseline, pct}, ...} to stdout.
// A feed whose status entry isn't an array is skipped -- the caller already
// has its own age-only fallback for that case and doesn't need a fabricated
// 'unknown' row here.

$root = getenv('QA_APP_ROOT') ?: '/var/www/html/quarantine-admin';
require "$root/config.php";
require "$root/src/bootstrap.php";

$feeds = admin_feeds_status();
$out = [];
foreach ($feeds as $k => $st) {
    if (!is_array($st)) continue;
    $cad = (int) ($st['cadence'] ?? 86400);
    $fh  = feed_health((string) $k, $st, $cad);
    $out[$k] = ['state' => $fh['state'], 'baseline' => $fh['baseline'], 'pct' => $fh['pct']];
}
echo json_encode($out), "\n";
