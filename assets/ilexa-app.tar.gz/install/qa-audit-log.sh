#!/bin/bash
#
# Root-owned reader for privileged log sources the Audit tab needs:
# successful/failed ilexa console logins (Apache access/error logs) and
# failed POP3/IMAP/webmail authentication (Dovecot's log -- Roundcube
# authenticates AS an IMAP client, so a failed Roundcube login already
# shows up here as an imap-login failure, no separate source needed).
#
# All three underlying logs are root-only (0700 containing dir for the
# Apache logs, 0600 for Dovecot's -- and Dovecot recreates that file fresh
# at every rotation, so even a one-time ACL grant on it would silently stop
# working again within a day). A sudo-invoked root-owned reader is the only
# approach here that survives log rotation, unlike a directory ACL.
#
# Usage:
#   qa-audit-log.sh admin-logins          <cookie_path>
#   qa-audit-log.sh admin-login-failures  <cookie_path>
#   qa-audit-log.sh mail-auth-failures
#
# Emits raw matching log lines (newest-file-last, original order within a
# file) for the caller to parse -- same "wrapper reads, PHP parses" split
# already used by admin_logins() before this script existed.
set -uo pipefail

die() { echo "qa-audit-log: $*" >&2; exit 2; }

# A URL path this app is mounted at -- validated defensively even though it
# only ever comes from this app's own config.php, not request input (every
# other privileged-read wrapper in this app validates its arguments the same
# way, on the principle that a root-run script should never trust its caller
# implicitly just because the caller is "supposed to be" apache).
v_cookie_path() {
    [[ "$1" =~ ^/[A-Za-z0-9_-]+/$ ]] || die "invalid cookie path: $1"
}

# Collect readable candidates for a log "base name" across both log-rotation
# naming conventions this app's installer produces (see modules/50-web.sh):
# plain rotated siblings (ssl_access_log-20260815) and logrotate's dateext
# form, PLUS gzipped older copies. Bounded to files touched in the last 8
# days -- recent failed-auth activity is what an admin actually wants to see;
# scanning a year of rotated logs on every page load is not.
collect() {
    local dir="$1" base="$2" f
    [ -d "$dir" ] || return 0
    while IFS= read -r f; do
        [ -r "$f" ] && printf '%s\n' "$f"
    done < <(find "$dir" -maxdepth 1 -type f \( -name "$base" -o -name "${base}[-.]*" \) \
                   -mtime -8 2>/dev/null | sort)
}

read_matching() {  # dir base grep-pattern [second-pattern]
    local dir="$1" base="$2" pattern="$3" pattern2="${4:-}" f
    while IFS= read -r f; do
        if [ -n "$pattern2" ]; then
            case "$f" in
                *.gz) zgrep -h -- "$pattern" "$f" 2>/dev/null | grep -- "$pattern2" ;;
                *)    grep  -h -- "$pattern" "$f" 2>/dev/null | grep -- "$pattern2" ;;
            esac
        else
            case "$f" in
                *.gz) zgrep -h -- "$pattern" "$f" 2>/dev/null ;;
                *)    grep  -h -- "$pattern" "$f" 2>/dev/null ;;
            esac
        fi
    done < <(collect "$dir" "$base")
}

cmd="${1:-}"; shift || true

case "$cmd" in
    admin-logins)
        [ $# -eq 1 ] || die "usage: admin-logins <cookie_path>"
        v_cookie_path "$1"
        # EL: /var/log/httpd/ssl_access_log*. Debian/Ubuntu: the installer
        # renames the SSL vhost's CustomLog to the same "ssl_access_log"
        # basename (modules/50-web.sh), so one glob covers both.
        for d in /var/log/httpd /var/log/apache2; do
            read_matching "$d" "ssl_access_log" "$1"
        done
        ;;

    admin-login-failures)
        [ $# -eq 1 ] || die "usage: admin-login-failures <cookie_path>"
        v_cookie_path "$1"
        # error_log has non-auth lines mentioning this same path too (a
        # missing static asset logs an [core:error] AH00035 permission-denied
        # line, for instance) -- filter on the auth_basic module tag AND the
        # cookie path, not the path alone, or those show up as false
        # "login failures". mod_auth_basic logs a failed attempt's URI
        # unquoted (AH01618: "user not found") or quoted (AH01617:
        # "authentication failure"); grep on the bare path, without the
        # quote, matches both shapes.
        for d in /var/log/httpd /var/log/apache2; do
            read_matching "$d" "ssl_error_log" "auth_basic:error" "$1"
            # Debian's default-ssl.conf shares the plain vhost's error.log
            # (no ssl_error_log rename exists for ErrorLog, unlike CustomLog)
            read_matching "$d" "error.log" "auth_basic:error" "$1"
        done
        ;;

    mail-auth-failures)
        [ $# -eq 0 ] || die "usage: mail-auth-failures"
        # 10-logging.conf sets log_path = /var/log/dovecotlog on this host;
        # stock Dovecot defaults to /var/log/dovecot.log. Try both rather
        # than hardcoding one, since this script must not assume its own
        # deployment's config choice is universal.
        for f in dovecotlog dovecot.log; do
            read_matching /var/log "$f" "auth failed"
        done
        ;;

    *)
        die "usage: qa-audit-log.sh {admin-logins|admin-login-failures|mail-auth-failures} [args]"
        ;;
esac
exit 0
