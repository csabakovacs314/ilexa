#!/bin/bash
#
# Notification recipient for cron-alert.sh.
#
# The ilexa Admin tab drives this through the one script, matching
# qa-feeds-config.sh / qa-geoblock-config.sh -- the web user never touches the
# config file directly, only asks this helper to read or replace it.
#
#   qa-alerts-config.sh get     prints the configured address, or nothing at all
#                               when notifications are off
#   qa-alerts-config.sh set     address on stdin; validates it, then writes
#   qa-alerts-config.sh clear   removes the file -> notifications off
#
# DEFAULT IS OFF. No file means cron-alert.sh sends no mail to anyone, which is
# deliberate: these jobs run on a mail server, and a monitoring alert that
# arrives before an operator has asked for one is at best noise and at worst a
# loop (a failing mail path trying to mail about itself). An address has to be
# entered before anything is ever sent.
set -uo pipefail

CONF=/etc/ilexa/alerts.conf
die() { echo "qa-alerts-config: $*" >&2; exit 2; }

op="${1:-}"

case "$op" in
  get)
    # Missing file is the normal "off" state, not an error.
    [ -f "$CONF" ] || exit 0
    grep -vE '^\s*#|^\s*$' "$CONF" | head -1 | tr -d '[:space:]'
    echo
    ;;

  set)
    addr="$(head -c 320 | tr -d '[:space:]')"
    [ -n "$addr" ] || die "empty address (use 'clear' to turn notifications off)"
    # Deliberately strict, and validated HERE rather than trusting the caller:
    # this value is handed to mail(1) as a recipient argument, so anything
    # shell- or header-injectable must never reach the file. One address only.
    case "$addr" in
      *[!A-Za-z0-9.@_+-]*) die "address contains characters that are not allowed" ;;
    esac
    printf '%s' "$addr" | grep -qE '^[A-Za-z0-9._+-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)+$' \
      || die "not a valid email address: $addr"
    umask 022
    { echo "# ilexa notification recipient for cron-alert.sh."
      echo "# Managed from the console's Admin tab (qa-alerts-config.sh)."
      echo "# Delete this file, or use 'qa-alerts-config.sh clear', to stop all alerts."
      echo "$addr"
    } > "$CONF.tmp" || die "cannot write $CONF.tmp"
    mv -f "$CONF.tmp" "$CONF" || die "cannot install $CONF"
    chmod 0644 "$CONF"
    echo "OK $addr"
    ;;

  clear)
    rm -f "$CONF"
    echo "OK off"
    ;;

  *)
    die "usage: qa-alerts-config.sh get|set|clear"
    ;;
esac
