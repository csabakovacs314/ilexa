#!/usr/bin/php
<?php
/**
 * Daily campaign-detection sweep for the Mail Security Operations Console.
 *
 * Groups recent spam-flagged archive_index rows by (from-domain,
 * normalized-subject) and upserts any group meeting the message-count
 * threshold into iocs.db's campaigns table. Runs as the apache user (the
 * SQLite file's owner) -- no root, no sudo helper needed, same as
 * qa-ioc-expire.php.
 *
 * Run from cron as apache:  0 4 * * *  apache  /usr/local/sbin/qa-campaign-detect.php
 * Dry run (counts, writes nothing):    /usr/local/sbin/qa-campaign-detect.php --dry-run
 */

$APP = '/var/www/html/quarantine-admin';
require $APP . '/src/bootstrap.php';

$dry = in_array('--dry-run', $argv ?? [], true);

$rows   = campaign_fetch_candidates();
$groups = campaign_group_candidates($rows);

if ($dry) {
    echo "[dry-run] would upsert " . count($groups) . " campaign(s):\n";
    foreach ($groups as $g) {
        echo "  {$g['domain']} / \"{$g['subject_sample']}\" -- {$g['count']} messages\n";
    }
    exit;
}

$ok = 0;
$failed = 0;
foreach ($groups as $g) {
    if (campaign_upsert($g)) $ok++;
    else $failed++;
}
echo "upserted: $ok" . ($failed > 0 ? " (failed: $failed)" : "") . "\n";
if ($failed > 0) exit(1);
