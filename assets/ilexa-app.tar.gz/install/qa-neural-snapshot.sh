#!/bin/bash
#
# Daily progress snapshot of rspamd's neural training, and an alert the day
# it finally trains an ANN.
#
# WHY: this module sat enabled-but-untrained for two weeks and nothing said
# so -- the failure is completely silent (symbols simply never fire). Two
# separate causes were diagnosed 2026-08-22 (balanced-class deadlock, and
# training vectors resetting whenever the symbol set changes); see the header
# of /etc/rspamd/local.d/neural.conf. This snapshot exists so a repeat stall,
# or a reset caused by adding new symbols, is visible in a log rather than
# discovered months later.
#
# Reads only redis key cardinalities -- no message content is touched.
# Exits non-zero ONLY on a real error, so cron-alert.sh emails just those;
# the "ANN trained" milestone is recorded in the log and in the journal.
set -euo pipefail

OUT=/var/log/qa-neural-snapshots.log
STAMP_TRAINED=/var/lib/ilexa/neural-trained.stamp

command -v redis-cli >/dev/null || { echo "redis-cli not found"; exit 1; }

# Current profile = the newest rn_* set. Older digests are previous symbol
# profiles whose vectors were orphaned by a symbol-set change; they are shown
# so churn is visible, and they expire on their own (ann_expire).
line="$(date -Is)"
trained=0
for k in $(redis-cli --scan --pattern 'rn_*_set' 2>/dev/null | sort); do
  n=$(redis-cli scard "$k" 2>/dev/null | head -1)
  line="$line ${k##rn_}=$n"
done

# A trained ANN is stored under the profile key WITHOUT the _set suffix.
anns=$(redis-cli --scan --pattern 'rn_*' 2>/dev/null | grep -vE '_set$' | head -5 || true)
if [ -n "$anns" ]; then
  trained=1
  line="$line ANN=$(echo "$anns" | tr '\n' ',' | sed 's/,$//')"
else
  line="$line ANN=none"
fi

printf '%s\n' "$line" >> "$OUT"

# One-shot notice the first time an ANN appears: that is the moment the
# shadow-mode weights in local.d/groups.conf become worth promoting.
if [ "$trained" = 1 ] && [ ! -e "$STAMP_TRAINED" ]; then
  mkdir -p "$(dirname "$STAMP_TRAINED")"
  date -Is > "$STAMP_TRAINED"
  logger -t qa-neural-snapshot "rspamd neural ANN trained for the first time -- review hits, then promote NEURAL_SPAM/NEURAL_HAM weights in /etc/rspamd/local.d/groups.conf"
  echo "rspamd neural ANN trained for the first time."
  echo "Next: watch NEURAL_SPAM / NEURAL_HAM hits, then restore the 3.0 / -2.0"
  echo "weights in /etc/rspamd/local.d/groups.conf (currently 0 = shadow mode)."
fi
