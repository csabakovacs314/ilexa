#!/bin/bash
#
# Daily progress snapshot of rspamd's neural training, and an ALERT the day
# it finally trains an ANN.
#
# WHY: this module sat enabled-but-untrained for two weeks and nothing said
# so -- the failure is completely silent (symbols simply never fire). Two
# separate causes were diagnosed 2026-08-22 (balanced-class deadlock, and
# training vectors resetting whenever the symbol set changes); see the header
# of /etc/rspamd/local.d/neural.conf. This snapshot exists so a repeat stall,
# or a reset caused by adding new symbols, is visible in a log rather than
# discovered months later.
#
# EXIT CODES ARE THE NOTIFICATION CHANNEL. cron-alert.sh mails only on a
# non-zero exit ("success is journal-only, so a healthy job never spams the
# inbox") -- so a milestone that exits 0 reaches nobody. The first version of
# this script did exactly that and would have notified no one. Hence:
#
#   0   nothing to report (still training, or already promoted)
#   10  ANN trained for the FIRST time -- one-shot, guarded by a stamp file
#   11  ANN trained but NEURAL_* still at weight 0 (shadow mode) -- weekly
#       Monday reminder, because a model left shadowed forever is the same
#       silent-stall failure in a different costume
#   1   real error (redis unreachable, etc.)
#
# Neither 10 nor 11 is a failure; they are "mail-worthy events" in the only
# vocabulary cron-alert.sh has.
#
# Reads only redis key cardinalities -- no message content is touched.
set -uo pipefail

OUT=/var/log/qa-neural-snapshots.log
STAMP_TRAINED=/var/lib/ilexa/neural-trained.stamp
GROUPS_CONF=/etc/rspamd/local.d/groups.conf

command -v redis-cli >/dev/null || { echo "redis-cli not found"; exit 1; }

# Current profile = the newest rn_* set. Older digests are previous symbol
# profiles whose vectors were orphaned by a symbol-set change; they are shown
# so churn is visible, and they expire on their own (ann_expire).
sets=$(redis-cli --scan --pattern 'rn_*_set' 2>/dev/null | sort)
if [ -z "$sets" ] && ! redis-cli ping >/dev/null 2>&1; then
  echo "redis unreachable"; exit 1
fi

line="$(date -Is)"
for k in $sets; do
  n=$(redis-cli scard "$k" 2>/dev/null | head -1)
  line="$line ${k##rn_}=$n"
done

# A trained ANN is stored under the profile key WITHOUT the _set suffix.
anns=$(redis-cli --scan --pattern 'rn_*' 2>/dev/null | grep -vE '_set$' | head -5)
if [ -n "$anns" ]; then
  line="$line ANN=$(echo "$anns" | tr '\n' ',' | sed 's/,$//')"
else
  line="$line ANN=none"
fi
printf '%s\n' "$line" >> "$OUT"

[ -n "$anns" ] || exit 0     # still training: nothing to say

# Is the ANN still in shadow mode (weights zeroed pending measurement)?
shadowed=0
grep -qE '"NEURAL_SPAM"[^}]*weight[[:space:]]*=[[:space:]]*0(\.0)?[[:space:]]*;' "$GROUPS_CONF" 2>/dev/null && shadowed=1

# First sighting: one-shot alert.
if [ ! -e "$STAMP_TRAINED" ]; then
  mkdir -p "$(dirname "$STAMP_TRAINED")"
  date -Is > "$STAMP_TRAINED"
  logger -t qa-neural-snapshot "rspamd neural ANN trained for the first time"
  echo "rspamd's neural network has trained its first ANN on $(hostname -f 2>/dev/null || hostname)."
  echo
  echo "It is currently in SHADOW MODE: NEURAL_SPAM / NEURAL_HAM fire and are"
  echo "logged, but carry weight 0, so they do not move any verdict yet."
  echo
  echo "To review before promoting:"
  echo "  grep -o 'NEURAL_[A-Z]*' /var/log/rspamd/rspamd.log | sort | uniq -c"
  echo "Then restore the upstream weights (3.0 / -2.0) in $GROUPS_CONF"
  echo "and: systemctl reload rspamd"
  echo
  echo "Blocks promotion: NEURAL_HAM firing on mail other symbols score as"
  echo "spam, or NEURAL_SPAM firing on obvious ham."
  [ "$shadowed" = 1 ] && exit 10
  exit 0     # already promoted before it first trained: nothing to chase
fi

# Already known: nag weekly while it is still shadowed, so a trained model
# does not quietly sit at weight 0 forever.
if [ "$shadowed" = 1 ] && [ "$(date +%u)" = 1 ]; then
  echo "Reminder: rspamd's neural ANN is trained but still in SHADOW MODE"
  echo "(NEURAL_SPAM / NEURAL_HAM weight 0 in $GROUPS_CONF)."
  echo "Trained first on: $(cat "$STAMP_TRAINED" 2>/dev/null)"
  echo "Review hits, then restore 3.0 / -2.0 and reload rspamd -- or set the"
  echo "weights deliberately to something else to silence this reminder."
  exit 11
fi

exit 0
