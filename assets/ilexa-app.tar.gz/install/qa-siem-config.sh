#!/bin/bash
#
# SIEM export settings (console-managed) -- ip/host, port, protocol, optional
# CA cert for TLS, and whether forwarding is actually on. The ilexa Admin tab
# drives this through this one script, matching qa-alerts-config.sh /
# qa-geoblock-config.sh: the web user never touches rsyslog config directly,
# only asks this helper to read the current settings or replace them.
#
# This script is the SOLE writer of /etc/rsyslog.d/60-siem-forward.conf
# after the first `set` -- it regenerates the whole file every time,
# imfile inputs included, so there is exactly one place (this script) that
# defines what gets pulled into local2/local3/local4 and whether any of it
# leaves the box. The imfile inputs stay in the file unconditionally
# (pulling Fail2Ban/Apache/ilexa-audit events into local syslog is useful
# on its own, e.g. for `journalctl`/local review); only the forward action
# is conditional on enabled=yes and a configured host.
#
#   qa-siem-config.sh get     prints enabled/host/port/protocol, one KEY=VALUE
#                              per line; safe defaults (enabled=no, empty
#                              host, port=514, protocol=udp) if never
#                              configured; also prints ca_cert_configured
#                              (yes/no) and, when yes, ca_cert_subject/
#                              ca_cert_expiry (metadata only -- never the
#                              PEM content itself, the browser does not need
#                              it back to leave the field looking "set")
#   qa-siem-config.sh set     enabled=/host=/port=/protocol= on stdin, one
#                              per line and in that exact order; validates,
#                              writes both the settings file and the
#                              rendered rsyslog config, reloads rsyslog. May
#                              be followed by a 5th line: `SET` (with the
#                              base64-encoded pasted PEM cert as the rest of
#                              stdin) installs a new CA cert, `CLEAR` removes
#                              the currently-installed one, or omit the 5th
#                              line entirely to leave whatever CA cert is
#                              already installed untouched.
#   qa-siem-config.sh disable turns forwarding off (imfile inputs stay active);
#                              equivalent to `set` with enabled=no
#
# DEFAULT IS OFF (enabled=no, no host). No forwarding happens until an
# admin has explicitly entered a collector and saved with enabled=yes.
set -uo pipefail

CONF=/etc/ilexa/siem.conf
RSYSLOG_CONF=/etc/rsyslog.d/60-siem-forward.conf
CA_CERT_FILE=/etc/ilexa/siem-ca.pem
STATS_FILE=/var/log/rsyslog-siem-stats.json
WEB_LOG_DIR="${WEB_LOG_DIR:-/var/log/httpd}"

die() { echo "qa-siem-config: $*" >&2; exit 2; }

# Defaults, overridden by whatever is already on disk. UDP/514 is the
# classic syslog default (RFC 3164) and the lowest-friction choice for a
# first-time collector -- no listener-side TLS cert to provision, works
# with literally every syslog receiver. TCP/TLS are there for anyone who
# wants delivery guarantees or confidentiality once they know they need them.
enabled=no
host=
port=514
protocol=udp

load_current() {
    [ -f "$CONF" ] || return 0
    # shellcheck disable=SC1090
    source "$CONF"
}

v_host() {
    # Hostname (RFC1123-ish, one or more labels) or a literal IPv4/IPv6
    # address. Deliberately conservative: this value is interpolated
    # directly into an rsyslog action(target="...") string below.
    case "$1" in
        "") die "empty host" ;;
    esac
    if [[ "$1" =~ ^[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?(\.[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?)*$ ]]; then
        return 0
    fi
    if [[ "$1" =~ ^[0-9]{1,3}(\.[0-9]{1,3}){3}$ ]]; then
        return 0
    fi
    if [[ "$1" =~ ^[0-9A-Fa-f:]+$ ]] && [[ "$1" == *:* ]]; then
        return 0  # crude IPv6 literal check -- rsyslog itself will reject garbage at reload/validate
    fi
    die "not a valid hostname or IP address: $1"
}

v_port() {
    [[ "$1" =~ ^[0-9]+$ ]] || die "port must be numeric: $1"
    (( "$1" >= 1 && "$1" <= 65535 )) || die "port out of range (1-65535): $1"
}

v_protocol() {
    case "$1" in
        udp|tcp|tls) return 0 ;;
        *) die "protocol must be udp, tcp or tls: $1" ;;
    esac
}

# Decodes+validates a base64-wrapped pasted PEM cert and installs it as the
# CA file, or removes the CA file when given an empty string. Never writes
# anything to CA_CERT_FILE unless the content actually parses as a real
# X.509 certificate -- this also naturally rejects a pasted private key or
# CSR (openssl x509 fails to parse those), which matters since someone
# fat-fingering the wrong PEM block into this field is the realistic failure
# mode, not a hostile input.
install_ca_cert() {
    local b64="$1" tmp
    if [ -z "$b64" ]; then
        rm -f "$CA_CERT_FILE"
        return 0
    fi
    tmp="$(mktemp /tmp/qa-siem-ca.XXXXXX)" || die "cannot create temp file for CA cert"
    if ! printf '%s' "$b64" | base64 -d > "$tmp" 2>/dev/null; then
        rm -f "$tmp"
        die "pasted CA cert is not valid base64 (client-side encoding bug?)"
    fi
    if ! openssl x509 -noout -in "$tmp" >/dev/null 2>&1; then
        rm -f "$tmp"
        die "pasted content is not a valid PEM X.509 certificate"
    fi
    install -m 0644 -o root -g root "$tmp" "$CA_CERT_FILE" || { rm -f "$tmp"; die "cannot install CA cert file"; }
    rm -f "$tmp"
}

# Regenerates the whole rsyslog drop-in from the current in-memory settings.
render_rsyslog_conf() {
    {
        cat <<'HDR'
# SIEM export, rendered by qa-siem-config.sh (ilexa console -> Admin ->
# SIEM export). Do not hand-edit -- the next console save overwrites this
# file whole. To change anything, use the console, or run
# qa-siem-config.sh directly.
#
#   local2 = Fail2Ban bans/unbans
#   local3 = Apache SSL vhost errors (Basic-Auth failures for the ilexa
#            console/rspamd-proxy/webmin, PHP errors)
#   local4 = ilexa console's own audit trail (release/delete/quarantine
#            actions, view-policy changes, IOC changes)
# mail.*     already covers Postfix and (on a default install) Dovecot.
# authpriv.* already covers sshd/sudo.

module(load="imfile")

input(type="imfile"
      File="/var/log/fail2ban.log"
      Tag="fail2ban:"
      Facility="local2"
      Severity="info")

HDR
        cat <<EOF
input(type="imfile"
      File="$WEB_LOG_DIR/ssl_error_log"
      Tag="apache-ssl-error:"
      Facility="local3"
      Severity="info")

input(type="imfile"
      File="$WEB_LOG_DIR/error.log"
      Tag="apache-ssl-error:"
      Facility="local3"
      Severity="info")
EOF
        # Only add a Dovecot input when this host's logging is actually
        # redirected away from syslog -- on a stock install Dovecot already
        # goes out via mail.* natively, and adding a redundant imfile input
        # for a file that does not exist just leaves a permanent (harmless
        # but noisy) "file not found" warning in rsyslog's own log.
        if grep -qE '^\s*log_path\s*=' /etc/dovecot/conf.d/10-logging.conf 2>/dev/null; then
            cat <<'EOF'

input(type="imfile"
      File="/var/log/dovecotlog"
      Tag="dovecot-imap:"
      Facility="local1"
      Severity="info")
EOF
        fi

        if [ "$enabled" = yes ] && [ -n "$host" ]; then
            # omfwd's own `protocol` parameter only ever accepts udp/tcp --
            # "tls" is not a wire protocol, it is TCP plus a stream driver
            # layered on top, configured via the separate StreamDriver*
            # parameters below. Rejected outright by rsyslogd otherwise
            # (confirmed: "omfwd: invalid protocol \"tls\"").
            omfwd_protocol="$protocol"
            driver_lines=""
            ca_line=""
            if [ "$protocol" = tls ]; then
                omfwd_protocol=tcp
                if [ -f "$CA_CERT_FILE" ]; then
                    # Cert-chain validated against the installed CA file
                    # (x509/certvalid) -- rejects a collector presenting an
                    # untrusted/self-signed cert. No hostname/SAN check
                    # (that would be x509/name + StreamDriverPermittedPeers),
                    # so this does not care whether the collector is reached
                    # by IP, hostname or internal alias. CA_CERT_FILE is a
                    # fixed path this script alone writes (install_ca_cert),
                    # never user input, so no interpolation risk here.
                    ca_line=$'\nglobal(DefaultNetstreamDriverCAFile="'"$CA_CERT_FILE"$'")\n'
                    driver_lines=$'\n           StreamDriver="ossl" StreamDriverMode="1" StreamDriverAuthMode="x509/certvalid"'
                else
                    # No CA installed: encrypted but unauthenticated (anon
                    # peer auth) -- gets traffic off the box confidentially
                    # without requiring a CA cert to be pasted first. Paste
                    # one in the console to require real chain validation.
                    driver_lines=$'\n           StreamDriver="ossl" StreamDriverMode="1" StreamDriverAuthMode="anon"'
                fi
            fi
            cat <<EOF
$ca_line
# Per-action counters for the forward action below (name="siemfwd"), written
# as JSON lines to STATS_FILE -- this is what qa-siem-healthcheck.sh reads to
# catch the action silently sitting in a resume/retry loop (config valid,
# rsyslog running, but zero packets actually leaving the box -- confirmed
# possible in practice: an early unreachable target can wedge omfwd into
# backoff, from which only a service restart recovers it). log.syslog="off"
# keeps the stats lines out of the normal message pipeline entirely, so they
# can never accidentally get matched by the facility filter below and
# forwarded to the collector themselves.
module(load="impstats"
       interval="60"
       format="json"
       log.file="$STATS_FILE"
       log.syslog="off")

# ── Forward to the SIEM collector ──────────────────────────────────────
template(name="siem-fwd" type="string"
         string="<%PRI%>1 %TIMESTAMP:::date-rfc3339% %HOSTNAME% %APP-NAME% %PROCID% %MSGID% - %MSG%\n")

if (\$syslogfacility-text == 'mail' or \$syslogfacility-text == 'authpriv'
    or \$syslogfacility-text == 'local1' or \$syslogfacility-text == 'local2'
    or \$syslogfacility-text == 'local3' or \$syslogfacility-text == 'local4') then {
    action(type="omfwd" name="siemfwd" target="$host" port="$port" protocol="$omfwd_protocol"
           template="siem-fwd" action.resumeRetryCount="-1"$driver_lines
           queue.type="linkedList" queue.filename="siemfwd_q")
}
EOF
        else
            cat <<'EOF'

# ── Forward to the SIEM collector ──────────────────────────────────────
# Currently disabled (no host configured, or disabled from the console).
EOF
        fi
    } > "$RSYSLOG_CONF.tmp" || die "cannot write $RSYSLOG_CONF.tmp"
    chmod 0644 "$RSYSLOG_CONF.tmp"

    # Install-then-validate-then-rollback, not validate-then-install:
    # rsyslogd -N1 validates the actual on-disk /etc/rsyslog.d/*.conf tree,
    # it has no "also check this one extra file" mode, so there is no way
    # to check the new content before it is the real file. What matters is
    # that a bad render never survives past this function and never reaches
    # `systemctl reload` -- restore the previous good file immediately on
    # failure, before returning control to the caller.
    local had_prev=0
    if [ -f "$RSYSLOG_CONF" ]; then
        cp -p "$RSYSLOG_CONF" "$RSYSLOG_CONF.prev" && had_prev=1
    fi
    mv -f "$RSYSLOG_CONF.tmp" "$RSYSLOG_CONF" || die "cannot install $RSYSLOG_CONF"

    if ! rsyslogd -N1 >/dev/null 2>&1; then
        if [ "$had_prev" = 1 ]; then
            mv -f "$RSYSLOG_CONF.prev" "$RSYSLOG_CONF"
            die "rendered rsyslog config failed validation -- reverted to the previous working config, nothing was reloaded"
        else
            rm -f "$RSYSLOG_CONF"
            die "rendered rsyslog config failed validation -- removed (there was no previous config to revert to), nothing was reloaded"
        fi
    fi
    rm -f "$RSYSLOG_CONF.prev"
}

write_settings() {
    umask 022
    { echo "# ilexa SIEM export settings. Managed from the console's Admin tab"
      echo "# (qa-siem-config.sh) -- do not hand-edit, the next console save overwrites it."
      echo "enabled=$enabled"
      echo "host=$host"
      echo "port=$port"
      echo "protocol=$protocol"
    } > "$CONF.tmp" || die "cannot write $CONF.tmp"
    mv -f "$CONF.tmp" "$CONF" || die "cannot install $CONF"
    chmod 0644 "$CONF"
}

reload_rsyslog() {
    # render_rsyslog_conf() already validated (and rolled back on failure)
    # before returning, so by the time this runs the on-disk config is
    # known-good -- this only needs to make rsyslogd pick it up.
    systemctl reload rsyslog 2>/dev/null || systemctl restart rsyslog \
        || die "rsyslog reload/restart failed"
}

op="${1:-}"

case "$op" in
  get)
    load_current
    echo "enabled=$enabled"
    echo "host=$host"
    echo "port=$port"
    echo "protocol=$protocol"
    if [ -f "$CA_CERT_FILE" ]; then
        echo "ca_cert_configured=yes"
        echo "ca_cert_subject=$(openssl x509 -noout -subject -in "$CA_CERT_FILE" 2>/dev/null | sed 's/^subject=//')"
        echo "ca_cert_expiry=$(openssl x509 -noout -enddate -in "$CA_CERT_FILE" 2>/dev/null | sed 's/^notAfter=//')"
    else
        echo "ca_cert_configured=no"
    fi
    ;;

  set)
    load_current
    # Fixed-format input: 4 known KEY=VALUE lines (none of these values can
    # ever contain '=', so per-line IFS='=' splitting is safe here), then an
    # optional CA-cert instruction. The CA blob is deliberately NOT parsed
    # via '='-splitting -- base64 padding ends in '=', and bash's `read`
    # silently drops a trailing IFS delimiter that has nothing after it,
    # which truncated the last byte of every base64 value ending in a
    # single '=' (confirmed: 1628-char b64 string came out as 1627 chars
    # through `IFS='=' read -r k v`). head -c/command substitution below
    # copies raw bytes with no field-splitting, so it doesn't have that bug.
    IFS='=' read -r k v; [ "$k" = enabled ]  || die "malformed input (expected enabled=...)";  enabled="$v"
    IFS='=' read -r k v; [ "$k" = host ]     || die "malformed input (expected host=...)";     host="$v"
    IFS='=' read -r k v; [ "$k" = port ]     || die "malformed input (expected port=...)";     port="$v"
    IFS='=' read -r k v; [ "$k" = protocol ] || die "malformed input (expected protocol=...)"; protocol="$v"
    ca_action=""
    IFS= read -r ca_action || true

    case "$enabled" in yes|no) : ;; *) die "enabled must be yes or no: $enabled" ;; esac
    v_port "$port"
    v_protocol "$protocol"
    if [ "$enabled" = yes ]; then
        v_host "$host"
    elif [ -n "$host" ]; then
        v_host "$host"   # still validate if given, even while disabled -- never store garbage
    fi
    # Validate the pasted cert BEFORE writing anything else, so a bad paste
    # aborts the whole save (nothing partially applied) rather than silently
    # keeping the old CA file while everything else moves on. No ca_action
    # line at all (most saves -- e.g. just flipping enabled) leaves whatever
    # CA cert is already installed untouched.
    case "$ca_action" in
        SET)   install_ca_cert "$(head -c 24576)" ;;
        CLEAR) install_ca_cert "" ;;
        "")    : ;;
        *)     die "unknown ca_cert action: $ca_action" ;;
    esac

    write_settings
    render_rsyslog_conf
    reload_rsyslog
    echo "OK $enabled $host $port $protocol"
    ;;

  disable)
    load_current
    enabled=no
    write_settings
    render_rsyslog_conf
    reload_rsyslog
    echo "OK off"
    ;;

  *)
    die "usage: qa-siem-config.sh get|set|disable"
    ;;
esac
