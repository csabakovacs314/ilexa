#!/bin/bash
# qa-update-apply.sh <version> -- install a signed ilexa release.
#
# Root-run via sudo, one narrowly-scoped grant (install/sudoers.example).
# ALWAYS human-triggered: src/admin.php's `update_apply` POST case is the
# only caller, gated by can('admin'), and there is no automated path that
# invokes this -- the "automated updates" toggle governs qa-update-check.sh
# only. See db/migrations/README.md for the migration side of this.
#
# The version argument from PHP is treated as a HINT, never authority: this
# script re-fetches and re-verifies RELEASES.json itself before trusting
# anything about the target version, so a compromised web layer can at most
# trigger installation of a legitimately-signed newer release -- it cannot
# cause a downgrade, an arbitrary URL fetch, or arbitrary code execution.
#
# Phases (one function each, run in order by run_phases):
#   fetch_verify      re-verify manifest, download+checksum the tarball
#   snapshot          webroot/sbin/db backup -- the rollback substrate
#   stage_verify      migration dry-run + lint the STAGED tree
#   go_live           .maintenance up, swap the tree, migrate for real
#   verify_or_rollback  smoke-test; roll back automatically on failure
#
# Progress is NOT polled by PHP -- it reads /var/cache/quarantine-admin/
# update-run.json on the next page render, matching this app's classic
# form-POST+redirect convention. write_run_state() below chowns this file
# to the web user/group (0664) rather than leaving it root:root -- PHP also
# needs to WRITE it once, to flip the one-time audit_written latch.
#
# Usage:
#   qa-update-apply.sh <version>              normal entry point (backgrounds itself)
#   qa-update-apply.sh --run-phases <version> <run_id> <from_version>   internal, do not call directly
set -uo pipefail
export LC_ALL=C

# ── Config (env-overridable for testing) ─────────────────────────────────────
WEBROOT="${QA_WEBROOT:-/var/www/html/quarantine-admin}"
STATE_DIR="${QA_UPDATE_STATE_DIR:-/var/lib/ilexa/update}"
CACHE_DIR="${QA_CACHE_DIR:-/var/cache/quarantine-admin}"
LOG_DIR="${QA_UPDATE_LOG_DIR:-/var/log/ilexa-update}"
PUBKEY_FILE="${QA_UPDATE_PUBKEY:-/etc/ilexa/update-release.pub}"
MIG_CRED="${QA_MIG_CRED:-/etc/ilexa/secrets/db-migrate.php}"
MANIFEST_URL="${QA_UPDATE_MANIFEST_URL:-https://raw.githubusercontent.com/csabakovacs314/ilexa/main/RELEASES.json}"
SIG_URL="${QA_UPDATE_SIG_URL:-${MANIFEST_URL}.sig}"
HELPERS_LIST_LIVE="${QA_HELPERS_LIST:-$WEBROOT/install/helpers.list}"
LOCKFILE="/var/lock/qa-update-apply.lock"
NEEDS_ATTENTION="$STATE_DIR/NEEDS_ATTENTION"
RUN_STATE="$CACHE_DIR/update-run.json"

# ── Shared helpers ────────────────────────────────────────────────────────────
LOGFILE=""  # set once run_id is known
log() { [ -n "$LOGFILE" ] && echo "[$(date '+%F %T')] $*" >>"$LOGFILE"; }

# Verify $1 (file) against $2 (sigfile) using EITHER pinned key in
# $PUBKEY_FILE -- identical logic to qa-update-check.sh, kept in sync by hand
# since this app's install/ scripts are each self-contained by convention
# (see helpers.list's own header on why a THIRD shared-lib pattern was not
# introduced just for this).
verify_sig() { # file sigfile
    local file="$1" sigfile="$2" tmp
    tmp="$(mktemp -d)"
    awk -v d="$tmp" '
        /-----BEGIN PUBLIC KEY-----/ { n++; f = d "/key" n ".pem" }
        n>0 { print > f }
    ' "$PUBKEY_FILE"
    local ok=1
    for k in "$tmp"/key*.pem; do
        [ -s "$k" ] || continue
        if openssl pkeyutl -verify -pubin -inkey "$k" -rawin -in "$file" -sigfile "$sigfile" >/dev/null 2>&1; then
            ok=0; break
        fi
    done
    rm -rf "$tmp"
    return $ok
}

write_run_state() { # state phase [error]
    local state="$1" phase="$2" err="${3:-}"
    # audit_written is flipped by update_reconcile_audit() (src/update.php),
    # which runs as apache on the next page render -- so this file must be
    # apache-writable, not just apache-readable. root:root 0644 (the earlier
    # bug here) let apache read the terminal state but never persist the
    # flip, so the reconcile's write silently failed every time and the
    # one-time audit_log() row got re-appended on every subsequent page
    # load. Match ownership to $CACHE_DIR itself (already apache-owned by
    # the installer) rather than hardcoding "apache", same reasoning as the
    # sqlite restore a few lines below.
    local web_owner web_group
    web_owner="$(stat -c%U "$CACHE_DIR" 2>/dev/null || echo apache)"
    web_group="$(stat -c%G "$CACHE_DIR" 2>/dev/null || echo apache)"
    php -r '
        $f = $argv[1]; $runId = $argv[2]; $from = $argv[3]; $to = $argv[4];
        $state = $argv[5]; $phase = $argv[6]; $err = $argv[7]; $log = $argv[8];
        $prev = is_readable($f) ? json_decode(file_get_contents($f), true) : null;
        $startedAt = (is_array($prev) && ($prev["run_id"] ?? "") === $runId) ? $prev["started_at"] : time();
        $out = [
            "run_id" => $runId, "from" => $from, "to" => $to,
            "state" => $state, "phase" => $phase,
            "started_at" => $startedAt, "updated_at" => time(),
            "finished_at" => in_array($state, ["ok","failed","rolled_back","needs_attention"], true) ? time() : null,
            "error" => $err, "log" => $log, "audit_written" => false,
        ];
        $tmp = $f . "." . getmypid();
        file_put_contents($tmp, json_encode($out, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        rename($tmp, $f);
        chown($f, $argv[9]);
        chgrp($f, $argv[10]);
        chmod($f, 0664);
    ' "$RUN_STATE" "$RUN_ID" "$FROM_VERSION" "$TARGET_VER" "$state" "$phase" "$err" "$LOGFILE" "$web_owner" "$web_group"
}

WENT_LIVE=0  # flips to 1 at the top of phase_go_live -- fail() before that
             # point means the live webroot/DB were never touched, so there
             # is nothing to roll back and no reason to put .maintenance up.

fail() { # phase error_token
    log "FAIL at $1: $2"
    if [ "$WENT_LIVE" = 1 ]; then
        write_run_state running "$1" "$2"
        do_rollback "$1" "$2"
    else
        # NOT "rolled_back": nothing was rolled back because nothing was ever
        # changed. Labelling this rolled_back put a rollback that never
        # happened into the audit log and told the admin production had been
        # touched and reverted, when the live tree was never opened at all.
        write_run_state failed "$1" "$2"
        log "no production changes were made (failed before go_live) -- nothing to roll back"
        rm -rf "$STAGE_DIR" 2>/dev/null
    fi
    exit 0
}

# ── Phase: fetch_verify ────────────────────────────────────────────────────────
phase_fetch_verify() {
    write_run_state running fetch
    STAGE_DIR="$STATE_DIR/staging/$TARGET_VER"
    rm -rf "$STAGE_DIR"; mkdir -p "$STAGE_DIR"

    local tmp; tmp="$(mktemp -d)"

    # Acquire a VERIFIED manifest, retrying the known-transient failures.
    #
    # raw.githubusercontent.com caches RELEASES.json and RELEASES.json.sig
    # INDEPENDENTLY (max-age=300) and consecutive requests can land on
    # different edge nodes, so for ~5 minutes after a release is published the
    # pair oscillates between fresh-manifest/stale-sig (ERR_MANIFEST_SIG) and
    # stale-manifest/fresh-sig (ERR_MANIFEST_NO_SUCH_VERSION). Both are this
    # script correctly refusing to trust an inconsistent pair -- but hard-
    # failing an admin's one-click on a condition that clears itself in a few
    # minutes is a bad trade, so retry instead.
    #
    # There is NO reliable client-side bypass, which is why this is time-based
    # rather than cache-busting: measured against the live CDN, a
    # "Cache-Control: no-cache" request header returned x-cache HIT while a
    # plain request to the same URL returned MISS, and a random ?cb= query
    # parameter also returned HIT (the cache key ignores the query string).
    # The delay list therefore spans >300s in total so the edge entry expires
    # on its own within the retry window.
    #
    # SECURITY: retrying does NOT weaken verification. Every attempt re-fetches
    # BOTH files and re-runs the full signature check from scratch; there is no
    # accumulated or partial trust, and no "accept after N attempts" path. A
    # genuinely bad signature simply fails every attempt and then fails the
    # phase. Only the four transient tokens below are ever retried -- a
    # deterministic rejection (ERR_NOT_NEWER, ERR_CHECKSUM, ERR_REQUIRES_
    # INSTALLER, ...) still fails immediately, because retrying it would only
    # delay an answer that will never change.
    local entry_json="" last_err="" attempt=1 delay ok=0
    for delay in ${QA_MANIFEST_RETRY_DELAYS-0 20 40 60 90 120}; do
        [ "$delay" -gt 0 ] && {
            log "fetch: $last_err (attempt $attempt) -- known-transient, retrying in ${delay}s"
            write_run_state running "fetch (retry $attempt)"
            sleep "$delay"
            attempt=$((attempt + 1))
        }
        rm -f "$tmp/manifest.json" "$tmp/manifest.json.sig"
        if ! curl -fsS --proto '=https' --tlsv1.2 --max-time 20 --retry 2 --max-filesize 262144 \
            -o "$tmp/manifest.json" "$MANIFEST_URL"; then last_err=ERR_MANIFEST_FETCH; continue; fi
        if ! curl -fsS --proto '=https' --tlsv1.2 --max-time 20 --retry 2 --max-filesize 4096 \
            -o "$tmp/manifest.json.sig" "$SIG_URL"; then last_err=ERR_MANIFEST_FETCH_SIG; continue; fi
        if ! verify_sig "$tmp/manifest.json" "$tmp/manifest.json.sig"; then last_err=ERR_MANIFEST_SIG; continue; fi

        # Authority lives HERE, not in whatever PHP passed as $1 -- re-derive
        # everything about the target release from the freshly verified manifest.
        entry_json="$(php -r '
            $m = json_decode(file_get_contents($argv[1]), true);
            if (!is_array($m)) { exit(1); }
            foreach ($m["releases"] ?? [] as $r) { if (($r["version"] ?? "") === $argv[2]) { echo json_encode($r); exit(0); } }
            exit(1);
        ' "$tmp/manifest.json" "$TARGET_VER")"
        if [ -z "$entry_json" ]; then last_err=ERR_MANIFEST_NO_SUCH_VERSION; continue; fi
        ok=1; break
    done
    if [ "$ok" != 1 ]; then
        log "fetch: giving up after $attempt attempt(s), last error $last_err"
        fail fetch "$last_err"
    fi
    [ "$attempt" -gt 1 ] && log "fetch: recovered on attempt $attempt after transient $last_err"
    write_run_state running fetch
    MANIFEST_SERIAL="$(php -r '$m=json_decode(file_get_contents($argv[1]),true); echo (int)($m["serial"] ?? 0);' "$tmp/manifest.json")"

    REQUIRES_INSTALLER="$(php -r '$e=json_decode($argv[1],true); echo !empty($e["requires_installer"]) ? "1" : "0";' "$entry_json")"
    if [ "$REQUIRES_INSTALLER" = "1" ]; then fail fetch ERR_REQUIRES_INSTALLER; fi

    MIN_UPGRADE_FROM="$(php -r '$e=json_decode($argv[1],true); echo $e["min_upgrade_from"] ?? "0.0.0";' "$entry_json")"
    if php -r 'exit(version_compare($argv[1], $argv[2], "<") ? 0 : 1);' "$FROM_VERSION" "$MIN_UPGRADE_FROM"; then
        fail fetch ERR_TOO_OLD_TO_UPGRADE
    fi
    if ! php -r 'exit(version_compare($argv[1], $argv[2], ">") ? 0 : 1);' "$TARGET_VER" "$FROM_VERSION"; then
        fail fetch ERR_NOT_NEWER
    fi

    TARBALL_PATH="$(php -r '$e=json_decode($argv[1],true); echo $e["app_tarball"]["path"] ?? "";' "$entry_json")"
    TARBALL_SHA="$(php -r '$e=json_decode($argv[1],true); echo $e["app_tarball"]["sha256"] ?? "";' "$entry_json")"
    CODENAME_NEW="$(php -r '$e=json_decode($argv[1],true); echo $e["codename"] ?? "";' "$entry_json")"
    COMMIT_NEW="$(php -r '$e=json_decode($argv[1],true); echo $e["commit"] ?? "unknown";' "$entry_json")"
    [ -n "$TARBALL_PATH" ] && [ -n "$TARBALL_SHA" ] || fail fetch ERR_MANIFEST_SHAPE

    local tar_url="https://raw.githubusercontent.com/csabakovacs314/ilexa/v${TARGET_VER}/${TARBALL_PATH}"
    if ! curl -fsS --proto '=https' --tlsv1.2 --max-time 180 --retry 2 --max-filesize 33554432 \
        -o "$tmp/app.tar.gz" "$tar_url"; then fail fetch ERR_TARBALL_FETCH; fi

    local got_sha; got_sha="$(sha256sum "$tmp/app.tar.gz" | cut -d' ' -f1)"
    [ "$got_sha" = "$TARBALL_SHA" ] || fail fetch ERR_CHECKSUM

    if tar tzf "$tmp/app.tar.gz" | grep -Eq '(^|/)\.\.(/|$)|^/'; then fail fetch ERR_TAR_UNSAFE; fi

    mkdir -p "$STAGE_DIR/tree"
    tar -xzf "$tmp/app.tar.gz" --no-same-owner -C "$STAGE_DIR/tree"
    # Kept past this phase (go_live's delete-set diff and verify_or_rollback's
    # current.tar.gz refresh both need it) -- $tmp itself is scratch and dies here.
    cp "$tmp/app.tar.gz" "$STAGE_DIR/app.tar.gz"
    rm -rf "$tmp"

    for f in index.php src/bootstrap.php VERSION CODENAME install/helpers.list tools/smoke-test.sh; do
        [ -e "$STAGE_DIR/tree/$f" ] || fail fetch ERR_TARBALL_SHAPE
    done
    local staged_ver; staged_ver="$(tr -d '[:space:]' < "$STAGE_DIR/tree/VERSION")"
    [ "$staged_ver" = "$TARGET_VER" ] || fail fetch ERR_VERSION_MISMATCH

    log "fetch_verify OK: $TARGET_VER ($CODENAME_NEW), tarball sha256 $got_sha"
}

# ── Phase: snapshot ─────────────────────────────────────────────────────────
phase_snapshot() {
    write_run_state running snapshot
    ROLLBACK_DIR="$STATE_DIR/rollback/$RUN_ID"
    mkdir -p "$ROLLBACK_DIR"; chmod 0700 "$ROLLBACK_DIR"

    tar -czf "$ROLLBACK_DIR/webroot.tar.gz" -C "$(dirname "$WEBROOT")" "$(basename "$WEBROOT")" \
        || fail snapshot ERR_SNAPSHOT_WEBROOT
    chmod 0600 "$ROLLBACK_DIR/webroot.tar.gz"  # contains config.php (real DB password)

    if [ -r "$HELPERS_LIST_LIVE" ]; then
        local sbin_files=()
        while IFS= read -r line; do
            [ -z "$line" ] && continue; [[ "$line" == \#* ]] && continue
            local name; name="$(awk '{print $1}' <<<"$line")"
            [ -f "/usr/local/sbin/$name" ] && sbin_files+=("$name")
        done < "$HELPERS_LIST_LIVE"
        if [ "${#sbin_files[@]}" -gt 0 ]; then
            tar -czf "$ROLLBACK_DIR/sbin.tar.gz" -C /usr/local/sbin "${sbin_files[@]}" \
                || fail snapshot ERR_SNAPSHOT_SBIN
        fi
    fi

    # .timeout is load-bearing, not decoration. The console has a public login
    # page and failed-login tracking writes to logins.db on every attempt, so
    # this host takes scanner traffic that writes these databases at random
    # moments. SQLite's backup API restarts whenever the source is written
    # mid-copy, and with no busy timeout a concurrent commit returns
    # "database is locked" immediately -- which aborted a real 1.0.5->1.0.6
    # apply at this exact line (logins.db had been written that same second).
    # Measured under a write-hammering writer: 1 in 6 backups failed with no
    # timeout, 0 in 6 with one.
    mkdir -p "$ROLLBACK_DIR/sqlite"
    for db in iocs logins; do
        local path="$CACHE_DIR/$db.db"
        [ -f "$path" ] && { sqlite3 -cmd ".timeout 30000" "$path" ".backup '$ROLLBACK_DIR/sqlite/$db.db'" || fail snapshot ERR_SNAPSHOT_SQLITE; }
    done

    # Only if this release actually carries pending mysql migrations -- the
    # dump is scoped to the two console-owned tables (archive_index,
    # schema_migrations), never postfix's mailbox/alias/domain tables and
    # never last_login (Dovecot's, see db/migrations/README.md).
    if [ -d "$STAGE_DIR/tree/db/migrations" ]; then
        local pending_mysql
        pending_mysql="$(php -r '
            require $argv[1]."/src/migrate.php";
            $c = @include $argv[2]; if (!is_array($c)) exit(1);
            $db = new PDO("mysql:unix_socket={$c["socket"]};dbname={$c["db"]};charset=utf8mb4", $c["user"], $c["pass"]);
            migration_ensure_ledger_table($db, "mysql");
            $files = migration_files($argv[1]."/db/migrations");
            $pending = migration_pending("mysql", $files, migration_ledger($db));
            echo count($pending);
        ' "$STAGE_DIR/tree" "$MIG_CRED" 2>>"$LOGFILE")"
        if [ "${pending_mysql:-0}" -gt 0 ] 2>/dev/null; then
            mysqldump --single-transaction --no-tablespaces postfix archive_index schema_migrations 2>>"$LOGFILE" \
                | gzip > "$ROLLBACK_DIR/postfix-db.sql.gz" || fail snapshot ERR_SNAPSHOT_MYSQL
            gzip -t "$ROLLBACK_DIR/postfix-db.sql.gz" || fail snapshot ERR_SNAPSHOT_MYSQL_CORRUPT
        fi
    fi

    # Prune, keep newest 3.
    ls -1dt "$STATE_DIR"/rollback/*/ 2>/dev/null | tail -n +4 | while IFS= read -r old; do
        rm -rf "${old:?}"
    done

    log "snapshot OK: $ROLLBACK_DIR"
}

# ── Phase: stage_verify ───────────────────────────────────────────────────────
phase_stage_verify() {
    write_run_state running stage_verify

    # .tmpl helper drift check -- a changed templated helper needs site
    # values one-click does not have. Refuse rather than ship a half-render.
    for f in "$STAGE_DIR/tree"/install/*.tmpl; do
        [ -e "$f" ] || continue
        local base; base="$(basename "$f")"
        local last="$STATE_DIR/last-tmpl/$base"
        if [ -f "$last" ] && ! diff -q "$f" "$last" >/dev/null 2>&1; then
            fail stage_verify ERR_TMPL_CHANGED
        fi
    done

    # Migration dry-run against a throwaway shadow schema -- cheap because it
    # is structure-only (no rows), catches the realistic failure (bad DDL
    # syntax), does not catch slowness on real data volume (that risk is
    # documented, not solved, by this dry-run; the Phase 2 dump is what
    # covers it if a migrate-for-real later goes wrong).
    if [ -d "$STAGE_DIR/tree/db/migrations" ]; then
        local shadow_db="ilexa_migtest_$$"
        mysql --defaults-extra-file=<(php -r '$c=include $argv[1]; echo "[client]\nsocket={$c["socket"]}\nuser={$c["user"]}\npassword={$c["pass"]}\n";' "$MIG_CRED") \
            -e "CREATE DATABASE IF NOT EXISTS $shadow_db;" 2>>"$LOGFILE" || fail stage_verify ERR_DRYRUN_DB
        mysqldump --no-data postfix archive_index 2>>"$LOGFILE" | mysql "$shadow_db" 2>>"$LOGFILE"

        local dryrun_ok
        dryrun_ok="$(php -r '
            require $argv[1]."/src/migrate.php";
            $c = @include $argv[2]; if (!is_array($c)) { echo "0"; exit; }
            try {
                $db = new PDO("mysql:unix_socket={$c["socket"]};dbname={$argv[3]};charset=utf8mb4", $c["user"], $c["pass"],
                               [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
                migration_ensure_ledger_table($db, "mysql");
                $files = migration_files($argv[1]."/db/migrations");
                $pending = migration_pending("mysql", $files, migration_ledger($db));
                $results = migration_apply_pending($db, "mysql", $pending, true);
                foreach ($results as $r) if (!$r["ok"]) { echo "0"; exit; }
                echo "1";
            } catch (Throwable $e) { fwrite(STDERR, $e->getMessage()."\n"); echo "0"; }
        ' "$STAGE_DIR/tree" "$MIG_CRED" "$shadow_db" 2>>"$LOGFILE")"
        mysql --defaults-extra-file=<(php -r '$c=include $argv[1]; echo "[client]\nsocket={$c["socket"]}\nuser={$c["user"]}\npassword={$c["pass"]}\n";' "$MIG_CRED") \
            -e "DROP DATABASE IF EXISTS $shadow_db;" 2>>"$LOGFILE"
        [ "$dryrun_ok" = "1" ] || fail stage_verify ERR_MIGRATION_DRYRUN
    fi

    # config.php is deliberately never in the bundle (bundle-ilexa.sh excludes
    # it -- it carries this host's real DB password and has no business
    # leaving the host, let alone traveling through a downloaded tarball).
    # tools/check-views.php's render sweep needs a real config.php to boot
    # bootstrap.php, so supply the LIVE one here, staging-directory-local and
    # root-only (0700 STAGE_DIR), and remove it again before this function
    # returns either way -- it must never reach phase_go_live's deploy-tree.sh,
    # which does not exclude config.php from its rsync (nothing in the bundle
    # ever needs to exclude it there; this copy is the one and only exception).
    cp "$WEBROOT/config.php" "$STAGE_DIR/tree/config.php"
    ( cd "$STAGE_DIR/tree" && bash tools/lint-all.sh --quiet ) >>"$LOGFILE" 2>&1
    local lint_rc=$?
    rm -f "$STAGE_DIR/tree/config.php"
    [ "$lint_rc" = 0 ] || fail stage_verify ERR_STAGED_LINT

    log "stage_verify OK"
}

# ── Phase: go_live ────────────────────────────────────────────────────────────
phase_go_live() {
    WENT_LIVE=1
    write_run_state running go_live
    touch "$WEBROOT/.maintenance"

    # Delete-set: files the PREVIOUS tarball had that the NEW one does not,
    # intersected with what is actually live -- never `rsync --delete`
    # (see deploy.sh's own history for why that is unsafe here).
    if [ -f "$STATE_DIR/current.tar.gz" ] && [ -f "$STAGE_DIR/app.tar.gz" ]; then
        comm -23 <(tar tzf "$STATE_DIR/current.tar.gz" | sed 's#^\./##' | grep -v '/$' | sort -u) \
                 <(tar tzf "$STAGE_DIR/app.tar.gz" | sed 's#^\./##' | grep -v '/$' | sort -u) \
            > "$STAGE_DIR/delete-set.txt" 2>/dev/null || true
        while IFS= read -r rel; do
            [ -z "$rel" ] && continue
            case "$rel" in install/*|.git*|docs/*|.superpowers/*|.claude/*|deploy.sh|README.md|INSTALL.md) continue ;; esac
            [ -f "$WEBROOT/$rel" ] && rm -f "$WEBROOT/$rel"
        done < "$STAGE_DIR/delete-set.txt"
    fi

    bash "$STAGE_DIR/tree/tools/deploy-tree.sh" "$STAGE_DIR/tree" "$WEBROOT" >>"$LOGFILE" 2>&1 \
        || fail go_live ERR_DEPLOY

    # source=list helpers only -- source=tmpl ones are refused earlier
    # (ERR_TMPL_CHANGED) rather than installed unrendered here.
    if [ -r "$STAGE_DIR/tree/install/helpers.list" ]; then
        while IFS= read -r line; do
            [ -z "$line" ] && continue; [[ "$line" == \#* ]] && continue
            local name source
            read -r name _ source _ <<<"$line"
            [ "$source" = "list" ] || continue
            [ -f "$STAGE_DIR/tree/install/$name" ] || continue
            install -m 0755 -o root -g root "$STAGE_DIR/tree/install/$name" "/usr/local/sbin/$name"
        done < "$STAGE_DIR/tree/install/helpers.list"
    fi

    if [ -d "$STAGE_DIR/tree/db/migrations" ]; then
        QA_WEBROOT="$WEBROOT" QA_SETTINGS_DIR="$CACHE_DIR" QA_MIG_CRED="$MIG_CRED" \
            php /usr/local/sbin/qa-db-migrate.php --apply --json >>"$LOGFILE" 2>&1
        local mig_rc=$?
        if [ "$mig_rc" != 0 ]; then fail go_live ERR_MIGRATE; fi
        if ! grep -q '"ok": *true' "$LOGFILE"; then log "WARNING: migration JSON did not report ok:true, continuing to smoke test"; fi
    fi

    log "go_live OK"
}

# ── Rollback ──────────────────────────────────────────────────────────────────
do_rollback() { # failed_phase error_token
    local failed_phase="$1" err="$2"
    log "ROLLBACK starting (failed at $failed_phase: $err)"
    touch "$WEBROOT/.maintenance"

    if [ -f "$ROLLBACK_DIR/webroot.tar.gz" ]; then
        local restore_tmp; restore_tmp="$(mktemp -d)"
        tar -xzf "$ROLLBACK_DIR/webroot.tar.gz" -C "$restore_tmp"
        bash "$restore_tmp/$(basename "$WEBROOT")/tools/deploy-tree.sh" "$restore_tmp/$(basename "$WEBROOT")" "$WEBROOT" >>"$LOGFILE" 2>&1
        # config.php is never in any tarball (bundle-ilexa.sh excludes it) --
        # deploy-tree.sh's rsync therefore cannot have touched it either way.
        rm -rf "$restore_tmp"
    fi
    if [ -f "$ROLLBACK_DIR/sbin.tar.gz" ]; then
        tar -xzf "$ROLLBACK_DIR/sbin.tar.gz" -C /usr/local/sbin >>"$LOGFILE" 2>&1
    fi
    if [ -f "$ROLLBACK_DIR/postfix-db.sql.gz" ]; then
        gunzip -c "$ROLLBACK_DIR/postfix-db.sql.gz" | mysql postfix >>"$LOGFILE" 2>&1
    fi
    for db in iocs logins; do
        if [ -f "$ROLLBACK_DIR/sqlite/$db.db" ]; then
            install -m 0640 -o "$(stat -c%U "$CACHE_DIR" 2>/dev/null || echo apache)" \
                    -g "$(stat -c%G "$CACHE_DIR" 2>/dev/null || echo apache)" \
                    "$ROLLBACK_DIR/sqlite/$db.db" "$CACHE_DIR/$db.db"
        fi
    done

    if bash "$WEBROOT/tools/smoke-test.sh" "$WEBROOT" >>"$LOGFILE" 2>&1; then
        rm -f "$WEBROOT/.maintenance"
        write_run_state rolled_back "$failed_phase" "$err"
        log "ROLLBACK verified OK"
    else
        write_run_state needs_attention "$failed_phase" "$err"
        touch "$NEEDS_ATTENTION"
        log "ROLLBACK ITSELF FAILED SMOKE TEST -- leaving .maintenance up, NEEDS_ATTENTION set"
        logger -t ilexa-update -p local4.crit "update-apply rollback failed smoke test, run_id=$RUN_ID -- manual attention required"
    fi
}

# ── Phase: verify_or_rollback ──────────────────────────────────────────────────
phase_verify_or_rollback() {
    write_run_state running smoke
    if bash "$WEBROOT/tools/smoke-test.sh" "$WEBROOT" >>"$LOGFILE" 2>&1; then
        rm -f "$WEBROOT/.maintenance"
        [ -f "$STAGE_DIR/app.tar.gz" ] && install -m 0644 -o root -g root "$STAGE_DIR/app.tar.gz" "$STATE_DIR/current.tar.gz"
        php -r '
            $out = ["version"=>$argv[1],"codename"=>$argv[2],"commit"=>$argv[3],"applied_at"=>time(),
                     "applied_by"=>$argv[4],"method"=>"console","previous_version"=>$argv[5],
                     "source_url"=>$argv[6],"sha256"=>$argv[7],"manifest_serial"=>(int)$argv[9]];
            file_put_contents($argv[8], json_encode($out, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES)."\n");
            chmod($argv[8], 0644);
        ' "$TARGET_VER" "$CODENAME_NEW" "$COMMIT_NEW" \
          "${SUDO_USER:-console}" "$FROM_VERSION" "" "$TARBALL_SHA" "$STATE_DIR/installed.json" "$MANIFEST_SERIAL"
        for f in "$STAGE_DIR/tree"/install/*.tmpl; do
            [ -e "$f" ] && install -m 0644 -o root -g root "$f" "$STATE_DIR/last-tmpl/$(basename "$f")"
        done
        # Regenerate the status cache, do not merely delete it. The cached
        # status is genuinely stale now (it said "$TARGET_VER available" and
        # we just installed it), but deleting alone left a HOLE: update_status()
        # reads a missing cache as "never_checked", so the dashboard tile went
        # grey with "Meg nincs ellenorizve" the instant an update succeeded and
        # stayed that way until the 04:17 cron or a manual "Ellenorzes most".
        # Updating and then being told the version is unknown is exactly the
        # moment the tile most needs to say "Naprakesz".
        #
        # Run as the WEB user, not root: $CACHE_DIR is apache-owned 0700 and
        # qa-update-check.sh chmods its output 0640 without chowning, so a
        # root-run refresh would leave a root:root 0640 file that apache cannot
        # read -- swapping a 24h grey tile for a permanently broken one. Same
        # user the cron entry and the "Ellenorzes most" button already use.
        #
        # --now (not --cron) on purpose: --cron honours the automated-check
        # toggle, but applying an update is a human action, and refreshing the
        # status of what a human just did is part of that action. The toggle
        # governs the SCHEDULE only -- see this script's header.
        #
        # Never allowed to affect the outcome: the apply has already passed its
        # smoke test and is a success no matter what the network does here.
        local _web_user; _web_user="$(stat -c%U "$CACHE_DIR" 2>/dev/null || echo apache)"
        if ! runuser -u "$_web_user" -- timeout 60 /usr/local/sbin/qa-update-check.sh --now >>"$LOGFILE" 2>&1; then
            log "post-apply status refresh failed (non-fatal) -- tile shows unknown until the next check"
            rm -f "$CACHE_DIR/update-status.cache.json"
        fi
        write_run_state ok "done"
        rm -rf "$STAGE_DIR"
        log "APPLY OK: now at $TARGET_VER ($CODENAME_NEW)"
    else
        fail smoke ERR_SMOKE_TEST
    fi
}

run_phases() {
    phase_fetch_verify
    phase_snapshot
    phase_stage_verify
    phase_go_live
    phase_verify_or_rollback
}

# ── Entry point ────────────────────────────────────────────────────────────────
if [ "${1:-}" = "--run-phases" ]; then
    TARGET_VER="$2"; RUN_ID="$3"; FROM_VERSION="$4"
    LOGFILE="$LOG_DIR/$RUN_ID.log"
    run_phases
    exit 0
fi

target_ver="${1:-}"
if ! [[ "$target_ver" =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,4}$ ]] || [ "${#target_ver}" -gt 13 ]; then
    echo "ERR_BAD_VERSION"; exit 0
fi

if [ -f "$LOCKFILE" ]; then
    pid="$(cat "$LOCKFILE" 2>/dev/null)"
    if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then echo "ALREADY_RUNNING"; exit 0; fi
    rm -f "$LOCKFILE"
fi
if [ -f "$NEEDS_ATTENTION" ]; then echo "ERR_PREVIOUS_FAILED"; exit 0; fi

avail_kb="$(df -Pk "$STATE_DIR" 2>/dev/null | awk 'NR==2{print $4}')"
[ -n "$avail_kb" ] && [ "$avail_kb" -ge 204800 ] || { echo "ERR_PREFLIGHT_DISK"; exit 0; }
mysqladmin ping >/dev/null 2>&1 || { echo "ERR_PREFLIGHT_MYSQL"; exit 0; }
for bin in curl tar sha256sum openssl mysqldump sqlite3 rsync php; do
    command -v "$bin" >/dev/null 2>&1 || { echo "ERR_PREFLIGHT_BIN_$bin"; exit 0; }
done

installed_version="$(tr -d '[:space:]' < "$WEBROOT/VERSION" 2>/dev/null)"
[ -n "$installed_version" ] || { echo "ERR_NO_VERSION_FILE"; exit 0; }
run_id="$(date +%Y%m%d-%H%M%S)-$target_ver"
mkdir -p "$LOG_DIR"

setsid nohup bash -c "
    echo \$\$ > '$LOCKFILE'
    '$0' --run-phases '$target_ver' '$run_id' '$installed_version' >> '$LOG_DIR/$run_id.log' 2>&1
    rm -f '$LOCKFILE'
" </dev/null >>/dev/null 2>&1 &

echo "OK"
exit 0
