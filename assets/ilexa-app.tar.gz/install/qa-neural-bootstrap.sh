#!/bin/bash
#
# Bootstrap rspamd's neural network from the 30-day archive.
#
# WHY: the neural module only learns from vectors captured during live scans,
# and it needs hundreds of each class before it trains at all. On a
# small/medium server that is weeks of waiting -- and any change to the symbol
# set resets the count (see /etc/rspamd/local.d/neural.conf). This replays
# already-classified archived mail through rspamd with an explicit
# `ANN-Train: spam|ham` request header, which is rspamd's own supported
# forced-learn path (plugins/neural.lua: manual_train), so the vectors land in
# the current profile exactly as a live scan would store them.
#
# WHAT IT IS NOT: this does not teach Bayes, fuzzy, or any list. It only
# produces neural training vectors.
#
# MEASURED SIDE EFFECTS (reference host, 2026-08-22):
#   - Bayes: NOT re-taught. Verified before/after on a real archived message;
#     "Messages learned" was unchanged. Autolearn is additionally disabled for
#     the duration of the run as belt-and-braces, and restored by a trap.
#   - Reputation module (IP/SPF/DKIM/URL): IS live on the reference host and
#     WILL see these messages a second time. Accepted deliberately: the senders
#     are genuine mail from the last 30 days, so the effect is mild
#     double-counting of recent history, not fabricated reputation.
#   - DNS: every replayed message re-queries the DNSBL/URIBL/reputation zones.
#     The run is throttled for that reason; a few hundred messages is well
#     inside normal daily query volume for this host, but do not loop it.
#
# HONEST CAVEATS about the resulting model -- read before promoting weights:
#   - Labels come from rspamd's own past verdicts (archive_index.is_spam),
#     so the ANN partly learns to imitate the existing rule stack. Rows a
#     human re-classified in the console (learned_as) are preferred where
#     available. Note the normal live path has the same property: autolearn
#     also keys off the score thresholds.
#   - Archived mail is already in Bayes and possibly the local fuzzy store, so
#     BAYES_*/FUZZY_* fire more confidently on replay than on genuinely new
#     mail. The ANN may therefore over-trust Bayes. This is exactly why the
#     weights ship at 0: measure NEURAL_* against the rest of the stack on
#     LIVE mail before promoting.
#   - DNS answers are today's, applied to mail up to 30 days old.
#
# Usage:
#   qa-neural-bootstrap.sh [--spam N] [--ham N] [--sleep SECS] [--dry-run]
#
# Defaults aim at the configured training target with a mild, realistic ham
# majority rather than the archive's natural 11:1 -- a wildly imbalanced
# training set produces a model that simply says "ham".
set -uo pipefail

SPAM_N=400
HAM_N=600
SLEEP=0.25
DRY=0
DB=postfix
ARCHIVE_USER="$(grep -oE "'archive_user'[^']*'[^']+'" /var/www/html/quarantine-admin/config.php 2>/dev/null | grep -oE "[^']+@[^']+" | head -1)"
BAYES_CONF=/etc/rspamd/local.d/classifier-bayes.conf
RSPAMD_URL=http://127.0.0.1:11333/checkv2

while [ $# -gt 0 ]; do
  case "$1" in
    --spam)    SPAM_N="${2:?}"; shift 2 ;;
    --ham)     HAM_N="${2:?}"; shift 2 ;;
    --sleep)   SLEEP="${2:?}"; shift 2 ;;
    --dry-run) DRY=1; shift ;;
    *) echo "usage: $0 [--spam N] [--ham N] [--sleep SECS] [--dry-run]" >&2; exit 2 ;;
  esac
done

die() { echo "qa-neural-bootstrap: $*" >&2; exit 2; }
[ -n "$ARCHIVE_USER" ] || die "cannot determine the archive user from the console config"
# Check EVERY external command up front, before the bayes config is touched.
# Only doveadm was checked, so a host without mysql printed "spam: 0 selected,
# 0 trained" and exited 0 -- a run that did nothing, reported success, and had
# already disabled autolearn on its way there. redis-cli is needed for the
# before/after vector counts the run reports.
command -v doveadm   >/dev/null || die "doveadm not found"
command -v mysql     >/dev/null || die "mysql not found — the corpus is selected from archive_index"
command -v redis-cli >/dev/null || die "redis-cli not found — needed to count the stored vectors"
curl -s --max-time 5 "$RSPAMD_URL" -X POST --data-binary "" >/dev/null 2>&1 \
  || die "rspamd is not answering on $RSPAMD_URL"

# --- Bayes autolearn off for the duration, restored on ANY exit -------------
autolearn_disabled=0
restore_autolearn() {
  if [ "$autolearn_disabled" = 1 ]; then
    if mv -f "${BAYES_CONF}.neural-bootstrap.bak" "$BAYES_CONF" 2>/dev/null; then
      systemctl reload rspamd >/dev/null 2>&1
      autolearn_disabled=0
      echo "bayes autolearn restored"
    else
      # Say so LOUDLY. A failed restore leaves autolearn commented out
      # indefinitely, and the guard below ('grep -q ^autolearn') then no longer
      # matches, so the next run would not even try to restore it.
      echo "qa-neural-bootstrap: FAILED to restore $BAYES_CONF from" >&2
      echo "  ${BAYES_CONF}.neural-bootstrap.bak — bayes autolearn is still DISABLED" >&2
    fi
  fi
}

# An INT/TERM handler must also STOP. Bash runs the trap and then RESUMES the
# loop after the interrupted command, so Ctrl-C used to restore autolearn and
# then keep replaying every remaining message -- with autolearn back ON, which
# is precisely the Bayes contamination this script disables it to avoid, while
# the operator believed they had stopped it.
on_signal() { echo; echo "interrupted — stopping"; restore_autolearn; exit 130; }
trap restore_autolearn EXIT
trap on_signal INT TERM

if [ "$DRY" = 0 ] && grep -q '^autolearn' "$BAYES_CONF" 2>/dev/null; then
  cp -a "$BAYES_CONF" "${BAYES_CONF}.neural-bootstrap.bak"
  sed -i 's/^autolearn/#neural-bootstrap# autolearn/' "$BAYES_CONF"
  autolearn_disabled=1
  systemctl reload rspamd >/dev/null 2>&1
  echo "bayes autolearn temporarily disabled"
fi

# --- pick the corpus --------------------------------------------------------
# Human re-classification (learned_as) wins over the automatic verdict.
sql_spam="SELECT CONCAT_WS(CHAR(31), uid, COALESCE(sender_ip,''), COALESCE(from_addr,''), COALESCE(to_addr,''))
          FROM archive_index
          WHERE (learned_as='spam' OR (is_spam=1 AND (learned_as IS NULL OR learned_as='')))
          ORDER BY (learned_as='spam') DESC, uid DESC LIMIT $SPAM_N;"
sql_ham="SELECT CONCAT_WS(CHAR(31), uid, COALESCE(sender_ip,''), COALESCE(from_addr,''), COALESCE(to_addr,''))
         FROM archive_index
         WHERE is_spam=0 AND (learned_as IS NULL OR learned_as='')
         ORDER BY RAND() LIMIT $HAM_N;"

train_one() { # uid ip from rcpt class
  local uid="$1" ip="$2" from="$3" rcpt="$4" cls="$5" tmp rc
  tmp=$(mktemp) || return 1
  doveadm fetch -u "$ARCHIVE_USER" text mailbox INBOX uid "$uid" 2>/dev/null | sed '1d' > "$tmp"
  if [ ! -s "$tmp" ]; then rm -f "$tmp"; return 1; fi
  local -a hdr=(-H "ANN-Train: $cls")
  local fa ra
  fa=$(addr_only "$from"); ra=$(addr_only "$rcpt")
  [ -n "$ip" ] && hdr+=(-H "IP: $ip")
  [ -n "$fa" ] && hdr+=(-H "From: $fa")
  [ -n "$ra" ] && hdr+=(-H "Rcpt: $ra")
  # --fail: without it an HTTP 403/500 still exits 0 and the run counts a
  # refused scan as "trained", so a wholly failed bootstrap reports success.
  curl -s --fail --max-time 60 -X POST "$RSPAMD_URL" "${hdr[@]}" --data-binary "@$tmp" -o /dev/null
  rc=$?
  rm -f "$tmp"
  return $rc
}

run_class() { # class sql
  local cls="$1" sql="$2" n=0 ok=0 fail=0
  # Split on a NON-WHITESPACE separator, not tabs.
  #
  # Tab is IFS whitespace, so `IFS=$'\t' read` COLLAPSES a run of tabs: a row
  # whose sender_ip is empty (125 of 4056 rows in the reference archive)
  # shifted every field left, and the sender ADDRESS was then handed to rspamd
  # as the client IP while the recipient became the sender. Every IP, SPF,
  # DKIM-alignment and DMARC symbol in the resulting training vector was
  # computed against the wrong identities -- in the one tool whose entire
  # purpose is producing clean vectors. The SQL below emits \x1f (unit
  # separator) between columns, which read does not treat as whitespace.
  while IFS=$'\x1f' read -r uid ip from rcpt; do
    [ -n "${uid:-}" ] || continue
    n=$((n+1))
    if [ "$DRY" = 1 ]; then
      [ "$n" -le 3 ] && echo "  [dry-run] $cls uid=$uid ip=${ip:-none} from=${from:-none}"
      continue
    fi
    if train_one "$uid" "$ip" "$from" "$rcpt" "$cls"; then ok=$((ok+1)); else fail=$((fail+1)); fi
    [ $((n % 50)) -eq 0 ] && echo "  $cls: $n processed (ok=$ok fail=$fail)"
    sleep "$SLEEP"
  done < <(mysql -N "$DB" -e "$sql" 2>/dev/null)
  echo "$cls: $n selected, $ok trained, $fail unreadable"
}

vectors() { # every profile, newest-touched last -- do NOT guess "the current
  # one" by name: the digests are hashes, so sorting them alphabetically
  # happily reports an ORPHANED profile (one whose symbol set no longer
  # matches) and hides the fact that the live one is empty.
  local out=""
  for k in $(redis-cli --scan --pattern 'rn_*_set' 2>/dev/null | sort); do
    out="$out ${k##rn_}=$(redis-cli scard "$k" 2>/dev/null | head -1)"
  done
  printf '%s\n' "${out# }"
}

# archive_index.from_addr may carry a display name ("Foo Bar <a@b.c>"); the
# envelope header wants the address alone.
addr_only() {
  case "$1" in
    *"<"*">"*) printf '%s' "${1##*<}" | tr -d '>' ;;
    *)         printf '%s' "$1" ;;
  esac
}

# Largest spam-set cardinality across profiles. Used to measure how many
# DISTINCT vectors the spam pass actually produced, without needing to know
# which profile rspamd considers live.
max_spam_card() {
  local m=0 c
  for k in $(redis-cli --scan --pattern 'rn_*_spam_set' 2>/dev/null); do
    c=$(redis-cli scard "$k" 2>/dev/null | head -1)
    [[ "$c" =~ ^[0-9]+$ ]] && [ "$c" -gt "$m" ] && m=$c
  done
  echo "$m"
}

echo "archive user: $ARCHIVE_USER   target: ${SPAM_N} spam / up to ${HAM_N} ham   throttle: ${SLEEP}s"
echo "vectors before: $(vectors)"

spam_before=$(max_spam_card)
run_class spam "$sql_spam"
spam_after=$(max_spam_card)
gained=$((spam_after - spam_before))
[ "$gained" -lt 0 ] && gained=0

# CAP THE HAM PASS AGAINST WHAT THE SPAM PASS ACTUALLY YIELDED.
#
# This is not tidiness, it is the bug that bit on first use. Live scanning
# keeps the classes balanced by itself -- can_push_train_vector() skips the
# over-represented class probabilistically -- but the forced-learn path this
# tool uses BYPASSES that check entirely (neural.lua: `if manual_train or
# can_push_train_vector(...)`). So a naive run replays every message it is
# given: 341 spam messages deduplicated down to 148 distinct vectors while
# 600 ham messages stayed varied, and rspamd rejected the resulting model
# outright -- "degenerate model: constant or single-class output ... predicted
# spam=0 ham=746 of 746". Recovering meant trimming the ham set by hand.
#
# 1.5x the distinct spam gained keeps the larger class ahead (which the
# threshold requires) without reaching the ratio that collapses the model.
if [ "$gained" -gt 0 ]; then
  ham_cap=$(( gained * 3 / 2 ))
  [ "$ham_cap" -lt "$HAM_N" ] && {
    echo "spam pass yielded $gained DISTINCT vectors from $SPAM_N messages (campaigns collapse);"
    echo "capping the ham pass at $ham_cap to keep the classes trainable"
    HAM_N=$ham_cap
    # One rewrite, not two: the parameter-expansion form that used to sit here
    # searched for "LIMIT $((HAM_N * 2))" AFTER HAM_N had already been
    # reassigned on the line above, so its pattern could never match. The sed
    # below always did the work.
    sql_ham=$(printf '%s' "$sql_ham" | sed -E "s/LIMIT [0-9]+;/LIMIT $HAM_N;/")
  }
else
  echo "WARNING: the spam pass produced no new distinct vectors -- the archive"
  echo "is already represented in the training set. Skipping the ham pass, which"
  echo "would only unbalance it."
  HAM_N=0
fi

[ "$HAM_N" -gt 0 ] && run_class ham "$sql_ham"
echo "vectors after:  $(vectors)"
echo
echo "rspamd trains asynchronously once both classes pass the configured"
echo "thresholds (see local.d/neural.conf). Check with:"
echo "  redis-cli --scan --pattern 'rn_*' | grep -v _set"
echo "  /usr/local/sbin/qa-neural-snapshot.sh"
echo
echo "The weights stay at 0 until you have compared NEURAL_* against the rest"
echo "of the stack on LIVE mail -- see the neural group in local.d/groups.conf."
