#!/bin/bash
#
# main.cf parameter control: read/write a curated allowlist of postfix
# settings, safely.
#
# The ilexa Admin tab drives postfix config through this one script -- apache
# never runs postconf/postfix directly. Every write is check-then-reload:
# apply the change, run `postfix check`, and if that fails roll the value
# back before anything reaches the running daemon.
#
#   qa-postfix-config.sh get <key>          current value of an allowlisted key
#   qa-postfix-config.sh set <key> <value>  new value; check+reload, or rollback on failure
set -uo pipefail
# The caller's locale reaches here through sudo's env_keep (LC_*). Under a
# UTF-8 or Latin-1 locale [A-Za-z]/[0-9] match more than ASCII, so the guards
# below would judge a different language than PHP does.
export LC_ALL=C

die() { echo "qa-postfix-config: $*" >&2; exit 2; }

# key|validator_name
SCALAR_KEYS=(
  "mynetworks|net_list"
  "relay_domains|domain_list"
  "relayhost|relayhost"
  "message_size_limit|size_bytes"
  "smtpd_tls_security_level|smtpd_tls_level"
  "smtp_tls_security_level|smtp_tls_level"
  "smtpd_tls_mandatory_protocols|tls_protocols_preset"
  "smtp_tls_mandatory_protocols|tls_protocols_preset"
)

TLS_PROTOCOL_PRESETS=("!SSLv2,!SSLv3,!TLSv1,!TLSv1.1" "!SSLv2,!SSLv3,!TLSv1,!TLSv1.1,!TLSv1.2")

RESTRICTION_DIRS=(smtpd_client_restrictions smtpd_helo_restrictions
                   smtpd_recipient_restrictions smtpd_relay_restrictions)

SAFE_TOKENS=(permit_mynetworks permit_sasl_authenticated reject_unauth_destination
             reject_invalid_hostname reject_unknown_hostname reject_unauth_pipelining
             reject_non_fqdn_recipient reject_non_fqdn_sender permit warn_if_reject)

# Readable via `get`, never via `set` -- certbot owns the TLS cert files, and
# postscreen_dnsbl_sites is a curated list edited directly on the server (see
# the HRBL DNSBL sub-project, 2026-08-12) -- the console only displays these
# for visibility, never edits them.
#
# myhostname is here for the Dashboard's System card, which shows the server's
# FQDN. It is deliberately read-only: myhostname is the name in the SMTP banner
# and the TLS certificate, so editing it from a web console could break mail
# identity and certificate matching in one click. Display only.
READONLY_KEYS=(smtpd_tls_cert_file smtpd_tls_key_file postscreen_dnsbl_sites myhostname)

_validator_for() { # key -> prints validator name on stdout, or returns 1 if unknown
  local s k v
  for s in "${SCALAR_KEYS[@]}"; do
    IFS='|' read -r k v <<<"$s"
    [ "$k" = "$1" ] && { echo "$v"; return 0; }
  done
  return 1
}

_known_get_key() { # key -> 0 if readable via `get` (settable OR read-only)
  _validator_for "$1" >/dev/null 2>&1 && return 0
  _in_array "$1" "${READONLY_KEYS[@]}"
}

_in_array() { # needle "${array[@]}"
  local needle="$1"; shift
  local x
  for x in "$@"; do [ "$x" = "$needle" ] && return 0; done
  return 1
}

_valid_value() { # validator_name value -> 0 if valid
  local v="$1" val="$2"
  case "$v" in
    net_list|domain_list)
      # Per-entry syntax and breadth: _setting_guard, which also needs the
      # current value.
      [ -n "$val" ] || return 1
      ;;
    relayhost)
      [ -z "$val" ] && return 0
      [[ "$val" =~ ^(\[[a-zA-Z0-9.-]+\]|[a-zA-Z0-9.-]+)?(:[0-9]{1,5})?$ ]] || return 1
      ;;
    size_bytes)
      [[ "$val" =~ ^[0-9]+$ ]] || return 1
      [ "$val" -ge 1048576 ] || return 1
      [ "$val" -le 524288000 ] || return 1
      ;;
    smtpd_tls_level)
      _in_array "$val" none may encrypt || return 1
      ;;
    smtp_tls_level)
      _in_array "$val" none may encrypt dane dane-only || return 1
      ;;
    tls_protocols_preset)
      _in_array "$val" "${TLS_PROTOCOL_PRESETS[@]}" || return 1
      ;;
    *) return 1 ;;
  esac
  return 0
}

# ── Relay-control guard ──────────────────────────────────────────────────────
# Postfix 2.10+ accepts a recipient only if it passes BOTH
# smtpd_relay_restrictions and smtpd_recipient_restrictions, and smtpd will not
# start unless one of them holds a working reject_unauth_destination (or
# equivalent). `permit` is in SAFE_TOKENS, so without this guard set-restriction
# could write relay=`permit` next to a recipient chain lacking
# reject_unauth_destination: an open relay, or a mail outage at the next smtpd
# start -- and `postfix check` catches neither.
#
# postfix_relay_guard() in src/postfix.php applies the same rule for the UI
# message; THIS copy is authoritative, because this script is the privilege
# boundary. The functions below are pure (arguments in, verdict out, no
# postconf), and the script returns before its dispatch when sourced, so
# tools/check-postfix-relay-guard.php tests them without root or real config.
RELAY_CONTROLS=(reject_unauth_destination defer_unauth_destination reject defer)

_relay_partner() { # dir -> prints the partner directive; returns 1 for client/helo
  case "$1" in
    smtpd_relay_restrictions)     echo smtpd_recipient_restrictions ;;
    smtpd_recipient_restrictions) echo smtpd_relay_restrictions ;;
    *) return 1 ;;
  esac
}

_chain_words() { # entries... -> the chain as Postfix reads it, one word per line
  # Split on commas AND whitespace ("warn_if_reject reject_unknown_hostname" is
  # two words); every word of a "{ ... }" group prints as an opaque '{}', so
  # nothing inside check_policy_service { ... } can pass for a control.
  local e w o c depth=0
  local -a ws
  for e in "$@"; do
    IFS=$' \t\r\n,' read -ra ws <<< "$e"
    for w in "${ws[@]}"; do
      [ -n "$w" ] || continue
      o="${w//[^\{]/}"; c="${w//[^\}]/}"
      if [ "$depth" -gt 0 ] || [ -n "$o" ]; then
        depth=$(( depth + ${#o} - ${#c} ))
        [ "$depth" -ge 0 ] || depth=0
        printf '%s\n' '{}'
        continue
      fi
      printf '%s\n' "$w"
    done
  done
}

_chain_relay_safe() { # words... -> 0 if a relay control comes before any bare permit
  # A control right after warn_if_reject only logs, so it does not count
  # (Postfix's own startup check skips it the same way); permit always ends it.
  local w skip=0
  for w in "$@"; do
    [ "$w" = permit ] && return 1
    # warn_if_reject first: consecutive ones keep the warn flag set (Postfix),
    # so the control after "warn_if_reject warn_if_reject" still only logs.
    if [ "$w" = warn_if_reject ]; then skip=1; continue; fi
    if [ "$skip" = 1 ]; then skip=0; continue; fi
    _in_array "$w" "${RELAY_CONTROLS[@]}" && return 0
  done
  return 1
}

_restriction_guard() { # dir partner-current-value proposed-entries...
  # Prints the refusal reason and returns 1, or returns 0. The partner value is
  # ignored for client/helo; pass "" when it could not be read (fail closed).
  local dir="$1" partner_val="$2" i n
  shift 2
  local -a pw ow
  mapfile -t pw < <(_chain_words "$@")
  n="${#pw[@]}"
  for (( i = 0; i < n - 1; i++ )); do
    if [ "${pw[$i]}" = permit ]; then
      echo "a bare 'permit' must be the last restriction in $dir (everything after it is dead config)"
      return 1
    fi
  done
  _relay_partner "$dir" >/dev/null || return 0
  _chain_relay_safe "${pw[@]}" && return 0
  mapfile -t ow < <(_chain_words "$partner_val")
  _chain_relay_safe "${ow[@]}" && return 0
  echo "refused: neither smtpd_relay_restrictions nor smtpd_recipient_restrictions would keep a" \
       "reject_unauth_destination (or defer_unauth_destination, reject, defer) that is not preceded" \
       "by a bare 'permit' or directly by warn_if_reject -- that is an open relay, or an smtpd that" \
       "refuses to start"
  return 1
}

# ── Network-card guard (mynetworks, relay_domains) ──────────────────────────
# Both settings decide who may relay through this server, and the chain guard
# above cannot see either: permit_mynetworks lets every client in mynetworks
# send anywhere, and reject_unauth_destination passes every recipient domain
# relay_domains matches. So `mynetworks = 0.0.0.0/0` or
# `relay_domains = static:all` is an open relay with every chain intact, and
# `postfix check` accepts both.
#
# postfix_setting_guard() in src/postfix.php applies the same rules for the UI
# message; THIS copy is authoritative. Pure functions again (arguments in,
# verdict out), so tools/check-postfix-relay-guard.php tests them by sourcing.
#
# What syntax cannot judge: a specific domain. `relay_domains = gmail.com`
# relays to every gmail.com mailbox, but so would a legitimate backup-MX
# domain look; neither a transport entry nor a DNS MX check separates them
# without refusing real backup-MX setups.
LIST_MAX_ENTRIES=64
MYNET_MIN_PREFIX_V4=16
MYNET_MIN_PREFIX_V6=48
# Trusted at any size: none of these is reachable from the internet.
MYNET_PRIVATE=(127.0.0.0/8 10.0.0.0/8 172.16.0.0/12 192.168.0.0/16 169.254.0.0/16 100.64.0.0/10
               '[::1]/128' '[fc00::]/7' '[fe80::]/10')
# IPv6 ranges that carry an IPv4 client address in their last 32 bits
# (IPv4-mapped, NAT64): judged by the IPv4 rules, so [::ffff:0:0]/96 is
# 0.0.0.0/0 in disguise.
MYNET_V4_EMBEDDING=('[::ffff:0:0]/96' '[64:ff9b::]/96')
MYNET_PRIVATE_P=()
MYNET_V4_EMBEDDING_P=()

_list_tokens() { # value -> one entry per line, split on commas and/or whitespace like Postfix
  local w
  local -a ws=()
  IFS=$' \t\r\n,' read -r -d '' -a ws <<< "$1" || true
  for w in "${ws[@]}"; do [ -n "$w" ] && printf '%s\n' "$w"; done
  return 0
}

_ip4_bits() { # dotted quad -> 32 bits as a 0/1 string; returns 1 if invalid
  local x i bits="" re='^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$'
  local -a o
  [[ "$1" =~ $re ]] || return 1
  IFS=. read -ra o <<< "$1"
  for x in "${o[@]}"; do
    # inet_pton (and so Postfix) refuses a leading zero.
    [[ "$x" =~ ^(0|[1-9][0-9]*)$ ]] && [ "$x" -le 255 ] || return 1
    for (( i = 7; i >= 0; i-- )); do bits+=$(( (x >> i) & 1 )); done
  done
  printf '%s' "$bits"
}

_ip6_bits() { # IPv6 address -> 128 bits as a 0/1 string; returns 1 if invalid
  local a="$1" head tail g n i v4 bits="" re4='^(.*:)([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)$'
  local -a hg=() tg=() all=()
  if [[ "$a" == *.* ]]; then # a trailing dotted quad stands for the last two groups
    [[ "$a" =~ $re4 ]] || return 1
    a="${BASH_REMATCH[1]}"
    v4="$(_ip4_bits "${BASH_REMATCH[2]}")" || return 1
    a+="$(printf '%x:%x' "$(( 2#${v4:0:16} ))" "$(( 2#${v4:16:16} ))")"
  fi
  [[ "$a" =~ ^[0-9A-Fa-f:]+$ ]] || return 1
  [[ "$a" == *:::* ]] && return 1
  if [[ "$a" == *::* ]]; then
    head="${a%%::*}"; tail="${a#*::}"
    [[ "$tail" == *::* || "$head" == :* || "$tail" == *: ]] && return 1
    [ -z "$head" ] || IFS=: read -ra hg <<< "$head"
    [ -z "$tail" ] || IFS=: read -ra tg <<< "$tail"
    n=$(( ${#hg[@]} + ${#tg[@]} ))
    [ "$n" -le 7 ] || return 1
    all=("${hg[@]}")
    for (( i = n; i < 8; i++ )); do all+=(0); done
    all+=("${tg[@]}")
  else
    [[ "$a" == :* || "$a" == *: ]] && return 1
    IFS=: read -ra all <<< "$a"
    [ "${#all[@]}" -eq 8 ] || return 1
  fi
  for g in "${all[@]}"; do
    [[ "$g" =~ ^[0-9A-Fa-f]{1,4}$ ]] || return 1
    n=$(( 16#$g ))
    for (( i = 15; i >= 0; i-- )); do bits+=$(( (n >> i) & 1 )); done
  done
  printf '%s' "$bits"
}

_net_parse() { # mynetworks entry -> prints "bits prefix family"; or prints invalid|ipv6-brackets|table, returns 1
  # Every spelling Postfix's cidr_match_parse accepts: a.b.c.d[/n], [addr],
  # [addr]/n and [addr/n], for both families -- so no bracketed form of a
  # broad network can pass as "not an address".
  local t="$1" addr len max fam bits
  local reb1='^\[([0-9A-Fa-f:.]+)\](/([0-9]{1,3}))?$'
  local reb2='^\[([0-9A-Fa-f:.]+)/([0-9]{1,3})\]$'
  local re4='^([0-9]{1,3}(\.[0-9]{1,3}){3})(/([0-9]{1,3}))?$'
  # Postfix needs IPv6 in [], or it reads the colon as type:table.
  local re6bare='^[0-9A-Fa-f.]*:[0-9A-Fa-f:.]*(/[0-9]{1,3})?$'
  local retable='^[A-Za-z][A-Za-z0-9_-]*:'
  if [[ "$t" =~ $reb1 ]]; then addr="${BASH_REMATCH[1]}"; len="${BASH_REMATCH[3]}"
  elif [[ "$t" =~ $reb2 ]]; then addr="${BASH_REMATCH[1]}"; len="${BASH_REMATCH[2]}"
  elif [[ "$t" =~ $re4 ]]; then addr="${BASH_REMATCH[1]}"; len="${BASH_REMATCH[4]}"
  elif [[ "$t" =~ $re6bare ]]; then printf ipv6-brackets; return 1
  elif [[ "$t" == /* || "$t" == '!'* || "$t" =~ $retable ]]; then printf table; return 1
  else printf invalid; return 1
  fi
  if [[ "$addr" == *:* ]]; then
    max=128; fam=6; bits="$(_ip6_bits "$addr")" || { printf invalid; return 1; }
  else
    max=32; fam=4; bits="$(_ip4_bits "$addr")" || { printf invalid; return 1; }
  fi
  if [ -n "$len" ]; then len=$(( 10#$len )); else len=$max; fi
  [ "$len" -le "$max" ] || { printf invalid; return 1; }
  printf '%s %s %s' "$bits" "$len" "$fam"
}

_mynet_init() { # parse the fixed blocks once; $(...) subshells inherit the result
  local b
  [ "${#MYNET_PRIVATE_P[@]}" -gt 0 ] && return 0
  for b in "${MYNET_PRIVATE[@]}"; do MYNET_PRIVATE_P+=("$(_net_parse "$b")"); done
  for b in "${MYNET_V4_EMBEDDING[@]}"; do MYNET_V4_EMBEDDING_P+=("$(_net_parse "$b")"); done
}

_mynet_classify() { # entry -> prints a refusal code, or "private", or "public4 <units>" / "public6 <units>"
  # Refusal codes: invalid, ipv6-brackets, table, host-bits, too-broad, all-ipv4.
  # Units measure address space for the whole-value cap: IPv4 addresses, or
  # IPv6 /64s (a longer prefix counts as one).
  local p bits len fam blk bb bl bf n
  _mynet_init
  p="$(_net_parse "$1")" || { printf '%s' "$p"; return 0; }
  read -r bits len fam <<< "$p"
  # Postfix refuses "10.1.2.3/8" ("non-null host address bits").
  [[ "${bits:len}" == *1* ]] && { printf host-bits; return 0; }
  if [ "$fam" = 6 ]; then
    for blk in "${MYNET_V4_EMBEDDING_P[@]}"; do
      read -r bb bl bf <<< "$blk"
      n=$(( len < 96 ? len : 96 ))
      [ "${bits:0:n}" = "${bb:0:n}" ] || continue
      # Shorter than /96 and overlapping: it holds the whole block.
      if [ "$len" -lt 96 ]; then
        if [ "$len" -lt "$MYNET_MIN_PREFIX_V6" ]; then printf too-broad; else printf all-ipv4; fi
        return 0
      fi
      bits="${bits:96}"; len=$(( len - 96 )); fam=4
      break
    done
  fi
  for blk in "${MYNET_PRIVATE_P[@]}"; do
    read -r bb bl bf <<< "$blk"
    [ "$bf" = "$fam" ] && [ "$len" -ge "$bl" ] && [ "${bits:0:bl}" = "${bb:0:bl}" ] && { printf private; return 0; }
  done
  if [ "$fam" = 4 ]; then
    [ "$len" -ge "$MYNET_MIN_PREFIX_V4" ] || { printf too-broad; return 0; }
    printf 'public4 %s' "$(( 1 << (32 - len) ))"
  else
    [ "$len" -ge "$MYNET_MIN_PREFIX_V6" ] || { printf too-broad; return 0; }
    printf 'public6 %s' "$(( len >= 64 ? 1 : 1 << (64 - len) ))"
  fi
  return 0
}

_mynet_token_code() { # entry -> prints a refusal code, or nothing if the entry is allowed on its own
  local c
  c="$(_mynet_classify "$1")"
  case "$c" in private|public*) ;; *) printf '%s' "$c" ;; esac
  return 0
}

_relay_domain_code() { # entry -> prints a refusal code (tld, not-domain) or nothing
  # Two labels is as far as syntax can judge breadth: a public suffix such as
  # co.hu still passes. EL9 ships the public suffix list only as a binary DAFSA.
  local t="$1"
  local label='[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?' tld='[A-Za-z]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?'
  local re_dom="^\\.?($label\\.)+$tld\$" re_tld="^\\.?$tld\$"
  case "$t" in '$mydestination'|'${mydestination}'|'$(mydestination)') return 0 ;; esac
  [ "${#t}" -le 254 ] || { printf not-domain; return 0; }
  [[ "$t" =~ $re_dom ]] && return 0
  if [[ "$t" =~ $re_tld ]]; then printf tld; else printf not-domain; fi
  return 0
}

_setting_guard() { # key current-value proposed-value -> prints the refusal and returns 1, or returns 0
  # A lookup table, file or negation (mynetworks), or anything not a domain
  # (relay_domains), may stay only if it is already in the current value --
  # the restriction editor's rule. An address is always judged afresh, however
  # it is spelled. Pass "" for an unreadable current value (fail closed).
  local key="$1" cur="$2" val="$3" tok code c4=0 c6=0
  local cap4=$(( 1 << (32 - MYNET_MIN_PREFIX_V4) )) cap6=$(( 1 << (64 - MYNET_MIN_PREFIX_V6) ))
  local -a have toks
  case "$key" in mynetworks|relay_domains) ;; *) return 0 ;; esac
  if [[ "$val" =~ [[:cntrl:]] ]]; then
    echo "control characters (line breaks) are not allowed in $key"; return 1
  fi
  mapfile -t have < <(_list_tokens "$cur")
  mapfile -t toks < <(_list_tokens "$val")
  [ "${#toks[@]}" -gt 0 ] || { echo "invalid value for $key: no entries"; return 1; }
  [ "${#toks[@]}" -le "$LIST_MAX_ENTRIES" ] || { echo "too many entries in $key (at most $LIST_MAX_ENTRIES)"; return 1; }
  [ "$key" = mynetworks ] && _mynet_init
  for tok in "${toks[@]}"; do
    if [ "$key" = mynetworks ]; then code="$(_mynet_classify "$tok")"
    else code="$(_relay_domain_code "$tok")"; fi
    case "$code" in
      ''|private) continue ;;
      public4\ *) c4=$(( c4 + ${code#* } )); continue ;;
      public6\ *) c6=$(( c6 + ${code#* } )); continue ;;
      table|not-domain) _in_array "$tok" "${have[@]}" && continue ;;
    esac
    case "$code" in
      invalid)       echo "invalid network in mynetworks: $tok (use e.g. 192.0.2.0/24 or [2001:db8::]/48)" ;;
      ipv6-brackets) echo "IPv6 networks in mynetworks must be in brackets, e.g. [2001:db8::]/48 (Postfix reads a bare one as type:table): $tok" ;;
      table)         echo "not permitted in mynetworks: $tok (a new table, file or negation; one already present may stay)" ;;
      host-bits)     echo "host bits set in $tok -- give the network address, e.g. 192.168.1.0/24" ;;
      too-broad)     echo "refused: $tok is too broad for mynetworks -- every client in it may relay through this server;" \
                          "a public range needs at least /$MYNET_MIN_PREFIX_V4 (IPv4) or /$MYNET_MIN_PREFIX_V6 (IPv6)" ;;
      all-ipv4)      echo "refused: $tok covers every IPv4 client (IPv4-mapped range) -- an open relay" ;;
      tld)           echo "refused: $tok is a single-label name -- if it is a top-level domain, relaying for it is an open relay" ;;
      *)             echo "not permitted in relay_domains: $tok (a domain name or \$mydestination;" \
                          "a table, file or wildcard only if already present)" ;;
    esac
    return 1
  done
  # Each public range may pass on its own and still add up: the public entries
  # together may cover no more than one minimum-size range of each family.
  if [ "$c4" -gt "$cap4" ] || [ "$c6" -gt "$cap6" ]; then
    echo "refused: the public ranges in mynetworks together cover more than one /$MYNET_MIN_PREFIX_V4" \
         "(IPv6: one /$MYNET_MIN_PREFIX_V6) -- every client in them may relay through this server"
    return 1
  fi
  return 0
}

_apply_and_reload() { # key newvalue -> writes, checks, rolls back+dies on failure
  local key="$1" newval="$2" oldval chk
  oldval="$(postconf -h "$key" 2>/dev/null)"
  postconf -e "${key}=${newval}" || die "postconf -e failed to write ${key}"
  if ! chk="$(postfix check 2>&1)"; then
    postconf -e "${key}=${oldval}"
    die "postfix check failed, change rolled back: ${chk}"
  fi
  systemctl reload postfix || die "value accepted but 'systemctl reload postfix' failed"
  echo OK
}

# Sourced (tools/check-postfix-relay-guard.php): stop here, with the functions
# above defined and nothing run. sudo can only EXECUTE this file, where
# BASH_SOURCE[0] == $0, so this branch is unreachable through the sudoers grant;
# there is deliberately no env var or flag that changes what an executed run does.
[ "${BASH_SOURCE[0]}" = "$0" ] || return 0

op="${1:-}"; key="${2:-}"

case "$op" in
  get)
    _known_get_key "$key" || die "unknown key: $key"
    postconf -h "$key" 2>/dev/null
    ;;

  # Batch read. Same allowlist as `get`, applied to every key -- this adds no
  # reachable surface, only removes round trips.
  #
  # WHY: the console read these one key at a time, so rendering the Rendszer
  # page spawned this helper FIFTEEN times, each through its own sh + sudo.
  # That was ~900ms of the page's ~1.4s, measured with strace -c (53 execve
  # per render, 15 of them this script). postconf itself accepts several
  # parameter names in one invocation, so the whole batch costs one process.
  get-many)
    shift
    [ "$#" -gt 0 ]  || die "get-many needs at least one key"
    [ "$#" -le 64 ] || die "too many keys"
    for k in "$@"; do
      _known_get_key "$k" || die "unknown key: $k"
    done
    # Parse postconf's own LABELLED output ("name = value"), never by position.
    #
    # `postconf -h` prints values only, and for a parameter this Postfix build
    # does not know it prints NOTHING and still exits 0 -- verified here:
    # `postconf -h mynetworks no_such_param relayhost` emits two lines for
    # three names. Pairing by index therefore silently hands every later key
    # its neighbour's value, which on this page means an editable TLS enum
    # showing (and then saving) the wrong setting. The keys are fixed and
    # allowlisted today, but this toolkit targets EL9/EL10 and Ubuntu
    # 22/24/26, where a parameter can legitimately be absent.
    #
    # A key postconf did not return is simply OMITTED from the output rather
    # than guessed at, so the caller can tell the difference and fall back.
    postconf "$@" 2>/dev/null | while IFS= read -r _line; do
      case "$_line" in
        *' = '*) printf '%s=%s\n' "${_line%% = *}" "${_line#* = }" ;;
        *' ='|*'=') printf '%s=\n' "${_line%% =*}" ;;
      esac
    done
    ;;

  set)
    val="${3:-}"
    validator="$(_validator_for "$key")" || die "unknown key: $key"
    _valid_value "$validator" "$val" || die "invalid value for $key: $val"
    # Network-card guard (see _setting_guard). An unreadable current value is
    # passed as "" -- fail closed: nothing then counts as already present.
    case "$key" in
      mynetworks|relay_domains)
        current="$(postconf -h "$key" 2>/dev/null)" || current=""
        reason="$(_setting_guard "$key" "$current" "$val")" || die "$reason"
        ;;
    esac
    _apply_and_reload "$key" "$val"
    ;;

  get-restriction)
    _in_array "$key" "${RESTRICTION_DIRS[@]}" || die "unknown restriction directive: $key"
    current="$(postconf -h "$key" 2>/dev/null)"
    printf '['
    first=1
    IFS=',' read -ra toks <<< "$current"
    for t in "${toks[@]}"; do
      t="$(printf '%s' "$t" | sed -e 's/^[ \t]*//' -e 's/[ \t]*$//')"
      [ -n "$t" ] || continue
      [ $first -eq 1 ] && first=0 || printf ','
      esc="$(printf '%s' "$t" | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g')"
      printf '"%s"' "$esc"
    done
    printf ']'
    ;;

  set-restriction)
    dir="$key"
    _in_array "$dir" "${RESTRICTION_DIRS[@]}" || die "unknown restriction directive: $dir"
    # Serialise restriction writes: the relay guard below reads the PARTNER
    # chain, so two concurrent saves (relay and recipient) must not both pass
    # against each other's old value. Locks this script's own file -- no new
    # lock path to create or own.
    exec 9<"${BASH_SOURCE[0]}" || die "cannot open lock"
    flock -w 30 9 || die "another restriction change is in progress, try again"
    current="$(postconf -h "$dir" 2>/dev/null)"
    IFS=',' read -ra cur_toks <<< "$current"
    declare -a cur_trimmed=()
    for t in "${cur_toks[@]}"; do
      t="$(printf '%s' "$t" | sed -e 's/^[ \t]*//' -e 's/[ \t]*$//')"
      [ -n "$t" ] && cur_trimmed+=("$t")
    done

    declare -a new_toks=()
    while IFS= read -r line || [ -n "$line" ]; do
      line="$(printf '%s' "$line" | sed -e 's/^[ \t]*//' -e 's/[ \t]*$//')"
      [ -n "$line" ] && new_toks+=("$line")
    done
    [ "${#new_toks[@]}" -gt 0 ] || die "restriction list cannot be empty"

    for t in "${new_toks[@]}"; do
      _in_array "$t" "${SAFE_TOKENS[@]}" && continue
      _in_array "$t" "${cur_trimmed[@]}" && continue
      die "token not permitted (must already be present, or from the safe vocabulary): $t"
    done

    # Relay-control guard (see _restriction_guard). An unreadable partner is
    # passed as "" -- fail closed: the new chain must then be safe on its own.
    partner_val=""
    if partner="$(_relay_partner "$dir")"; then
      partner_val="$(postconf -h "$partner" 2>/dev/null)" || partner_val=""
    fi
    reason="$(_restriction_guard "$dir" "$partner_val" "${new_toks[@]}")" || die "$reason"

    joined=""
    for i in "${!new_toks[@]}"; do
      [ "$i" -gt 0 ] && joined+=", "
      joined+="${new_toks[$i]}"
    done
    _apply_and_reload "$dir" "$joined"
    ;;

  *) die "usage: get <key> | set <key> <value> | get-restriction <dir> | set-restriction <dir> (tokens on stdin)" ;;
esac
