#!/bin/bash
#
# main.cf parameter control: read/write a curated allowlist of postfix
# settings, safely.
#
# The ilexa Admin tab drives postfix config through this one script -- apache
# never runs postconf/postfix directly. Every write is check-then-reload:
# apply the change, run `postfix check`, and if that fails roll the value
# back before anything reaches the running daemon.
#
#   qa-postfix-config.sh get <key>          current value of an allowlisted key
#   qa-postfix-config.sh set <key> <value>  new value; check+reload, or rollback on failure
set -uo pipefail

die() { echo "qa-postfix-config: $*" >&2; exit 2; }

# key|validator_name
SCALAR_KEYS=(
  "mynetworks|cidr_list"
  "relay_domains|freetext"
  "relayhost|relayhost"
  "message_size_limit|size_bytes"
  "smtpd_tls_security_level|smtpd_tls_level"
  "smtp_tls_security_level|smtp_tls_level"
  "smtpd_tls_mandatory_protocols|tls_protocols_preset"
  "smtp_tls_mandatory_protocols|tls_protocols_preset"
)

TLS_PROTOCOL_PRESETS=("!SSLv2,!SSLv3,!TLSv1,!TLSv1.1" "!SSLv2,!SSLv3,!TLSv1,!TLSv1.1,!TLSv1.2")

RESTRICTION_DIRS=(smtpd_client_restrictions smtpd_helo_restrictions
                   smtpd_recipient_restrictions smtpd_relay_restrictions)

SAFE_TOKENS=(permit_mynetworks permit_sasl_authenticated reject_unauth_destination
             reject_invalid_hostname reject_unknown_hostname reject_unauth_pipelining
             reject_non_fqdn_recipient reject_non_fqdn_sender permit warn_if_reject)

# Readable via `get`, never via `set` -- certbot owns the TLS cert files, and
# postscreen_dnsbl_sites is a curated list edited directly on the server (see
# the HRBL DNSBL sub-project, 2026-08-12) -- the console only displays these
# for visibility, never edits them.
#
# myhostname is here for the Dashboard's System card, which shows the server's
# FQDN. It is deliberately read-only: myhostname is the name in the SMTP banner
# and the TLS certificate, so editing it from a web console could break mail
# identity and certificate matching in one click. Display only.
READONLY_KEYS=(smtpd_tls_cert_file smtpd_tls_key_file postscreen_dnsbl_sites myhostname)

_validator_for() { # key -> prints validator name on stdout, or returns 1 if unknown
  local s k v
  for s in "${SCALAR_KEYS[@]}"; do
    IFS='|' read -r k v <<<"$s"
    [ "$k" = "$1" ] && { echo "$v"; return 0; }
  done
  return 1
}

_known_get_key() { # key -> 0 if readable via `get` (settable OR read-only)
  _validator_for "$1" >/dev/null 2>&1 && return 0
  _in_array "$1" "${READONLY_KEYS[@]}"
}

_in_array() { # needle "${array[@]}"
  local needle="$1"; shift
  local x
  for x in "$@"; do [ "$x" = "$needle" ] && return 0; done
  return 1
}

_valid_value() { # validator_name value -> 0 if valid
  local v="$1" val="$2" tok
  case "$v" in
    cidr_list)
      [ -n "$val" ] || return 1
      for tok in $val; do
        [[ "$tok" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}(/[0-9]{1,2})?$ ]] && continue
        [[ "$tok" =~ ^[0-9a-fA-F:]+(/[0-9]{1,3})?$ ]] && continue
        return 1
      done
      ;;
    freetext)
      [ -n "$val" ] || return 1
      ;;
    relayhost)
      [ -z "$val" ] && return 0
      [[ "$val" =~ ^(\[[a-zA-Z0-9.-]+\]|[a-zA-Z0-9.-]+)?(:[0-9]{1,5})?$ ]] || return 1
      ;;
    size_bytes)
      [[ "$val" =~ ^[0-9]+$ ]] || return 1
      [ "$val" -ge 1048576 ] || return 1
      [ "$val" -le 524288000 ] || return 1
      ;;
    smtpd_tls_level)
      _in_array "$val" none may encrypt || return 1
      ;;
    smtp_tls_level)
      _in_array "$val" none may encrypt dane dane-only || return 1
      ;;
    tls_protocols_preset)
      _in_array "$val" "${TLS_PROTOCOL_PRESETS[@]}" || return 1
      ;;
    *) return 1 ;;
  esac
  return 0
}

# ── Relay-control guard ──────────────────────────────────────────────────────
# Postfix 2.10+ accepts a recipient only if it passes BOTH
# smtpd_relay_restrictions and smtpd_recipient_restrictions, and smtpd will not
# start unless one of them holds a working reject_unauth_destination (or
# equivalent). `permit` is in SAFE_TOKENS, so without this guard set-restriction
# could write relay=`permit` next to a recipient chain lacking
# reject_unauth_destination: an open relay, or a mail outage at the next smtpd
# start -- and `postfix check` catches neither.
#
# postfix_relay_guard() in src/postfix.php applies the same rule for the UI
# message; THIS copy is authoritative, because this script is the privilege
# boundary. The functions below are pure (arguments in, verdict out, no
# postconf), and the script returns before its dispatch when sourced, so
# tools/check-postfix-relay-guard.php tests them without root or real config.
RELAY_CONTROLS=(reject_unauth_destination defer_unauth_destination reject defer)

_relay_partner() { # dir -> prints the partner directive; returns 1 for client/helo
  case "$1" in
    smtpd_relay_restrictions)     echo smtpd_recipient_restrictions ;;
    smtpd_recipient_restrictions) echo smtpd_relay_restrictions ;;
    *) return 1 ;;
  esac
}

_chain_words() { # entries... -> the chain as Postfix reads it, one word per line
  # Split on commas AND whitespace ("warn_if_reject reject_unknown_hostname" is
  # two words); every word of a "{ ... }" group prints as an opaque '{}', so
  # nothing inside check_policy_service { ... } can pass for a control.
  local e w o c depth=0
  local -a ws
  for e in "$@"; do
    IFS=$' \t\r\n,' read -ra ws <<< "$e"
    for w in "${ws[@]}"; do
      [ -n "$w" ] || continue
      o="${w//[^\{]/}"; c="${w//[^\}]/}"
      if [ "$depth" -gt 0 ] || [ -n "$o" ]; then
        depth=$(( depth + ${#o} - ${#c} ))
        [ "$depth" -ge 0 ] || depth=0
        printf '%s\n' '{}'
        continue
      fi
      printf '%s\n' "$w"
    done
  done
}

_chain_relay_safe() { # words... -> 0 if a relay control comes before any bare permit
  # A control right after warn_if_reject only logs, so it does not count
  # (Postfix's own startup check skips it the same way); permit always ends it.
  local w skip=0
  for w in "$@"; do
    [ "$w" = permit ] && return 1
    # warn_if_reject first: consecutive ones keep the warn flag set (Postfix),
    # so the control after "warn_if_reject warn_if_reject" still only logs.
    if [ "$w" = warn_if_reject ]; then skip=1; continue; fi
    if [ "$skip" = 1 ]; then skip=0; continue; fi
    _in_array "$w" "${RELAY_CONTROLS[@]}" && return 0
  done
  return 1
}

_restriction_guard() { # dir partner-current-value proposed-entries...
  # Prints the refusal reason and returns 1, or returns 0. The partner value is
  # ignored for client/helo; pass "" when it could not be read (fail closed).
  local dir="$1" partner_val="$2" i n
  shift 2
  local -a pw ow
  mapfile -t pw < <(_chain_words "$@")
  n="${#pw[@]}"
  for (( i = 0; i < n - 1; i++ )); do
    if [ "${pw[$i]}" = permit ]; then
      echo "a bare 'permit' must be the last restriction in $dir (everything after it is dead config)"
      return 1
    fi
  done
  _relay_partner "$dir" >/dev/null || return 0
  _chain_relay_safe "${pw[@]}" && return 0
  mapfile -t ow < <(_chain_words "$partner_val")
  _chain_relay_safe "${ow[@]}" && return 0
  echo "refused: neither smtpd_relay_restrictions nor smtpd_recipient_restrictions would keep a" \
       "reject_unauth_destination (or defer_unauth_destination, reject, defer) that is not preceded" \
       "by a bare 'permit' or directly by warn_if_reject -- that is an open relay, or an smtpd that" \
       "refuses to start"
  return 1
}

_apply_and_reload() { # key newvalue -> writes, checks, rolls back+dies on failure
  local key="$1" newval="$2" oldval chk
  oldval="$(postconf -h "$key" 2>/dev/null)"
  postconf -e "${key}=${newval}" || die "postconf -e failed to write ${key}"
  if ! chk="$(postfix check 2>&1)"; then
    postconf -e "${key}=${oldval}"
    die "postfix check failed, change rolled back: ${chk}"
  fi
  systemctl reload postfix || die "value accepted but 'systemctl reload postfix' failed"
  echo OK
}

# Sourced (tools/check-postfix-relay-guard.php): stop here, with the functions
# above defined and nothing run. sudo can only EXECUTE this file, where
# BASH_SOURCE[0] == $0, so this branch is unreachable through the sudoers grant;
# there is deliberately no env var or flag that changes what an executed run does.
[ "${BASH_SOURCE[0]}" = "$0" ] || return 0

op="${1:-}"; key="${2:-}"

case "$op" in
  get)
    _known_get_key "$key" || die "unknown key: $key"
    postconf -h "$key" 2>/dev/null
    ;;

  # Batch read. Same allowlist as `get`, applied to every key -- this adds no
  # reachable surface, only removes round trips.
  #
  # WHY: the console read these one key at a time, so rendering the Rendszer
  # page spawned this helper FIFTEEN times, each through its own sh + sudo.
  # That was ~900ms of the page's ~1.4s, measured with strace -c (53 execve
  # per render, 15 of them this script). postconf itself accepts several
  # parameter names in one invocation, so the whole batch costs one process.
  get-many)
    shift
    [ "$#" -gt 0 ]  || die "get-many needs at least one key"
    [ "$#" -le 64 ] || die "too many keys"
    for k in "$@"; do
      _known_get_key "$k" || die "unknown key: $k"
    done
    # Parse postconf's own LABELLED output ("name = value"), never by position.
    #
    # `postconf -h` prints values only, and for a parameter this Postfix build
    # does not know it prints NOTHING and still exits 0 -- verified here:
    # `postconf -h mynetworks no_such_param relayhost` emits two lines for
    # three names. Pairing by index therefore silently hands every later key
    # its neighbour's value, which on this page means an editable TLS enum
    # showing (and then saving) the wrong setting. The keys are fixed and
    # allowlisted today, but this toolkit targets EL9/EL10 and Ubuntu
    # 22/24/26, where a parameter can legitimately be absent.
    #
    # A key postconf did not return is simply OMITTED from the output rather
    # than guessed at, so the caller can tell the difference and fall back.
    postconf "$@" 2>/dev/null | while IFS= read -r _line; do
      case "$_line" in
        *' = '*) printf '%s=%s\n' "${_line%% = *}" "${_line#* = }" ;;
        *' ='|*'=') printf '%s=\n' "${_line%% =*}" ;;
      esac
    done
    ;;

  set)
    val="${3:-}"
    validator="$(_validator_for "$key")" || die "unknown key: $key"
    _valid_value "$validator" "$val" || die "invalid value for $key: $val"
    _apply_and_reload "$key" "$val"
    ;;

  get-restriction)
    _in_array "$key" "${RESTRICTION_DIRS[@]}" || die "unknown restriction directive: $key"
    current="$(postconf -h "$key" 2>/dev/null)"
    printf '['
    first=1
    IFS=',' read -ra toks <<< "$current"
    for t in "${toks[@]}"; do
      t="$(printf '%s' "$t" | sed -e 's/^[ \t]*//' -e 's/[ \t]*$//')"
      [ -n "$t" ] || continue
      [ $first -eq 1 ] && first=0 || printf ','
      esc="$(printf '%s' "$t" | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g')"
      printf '"%s"' "$esc"
    done
    printf ']'
    ;;

  set-restriction)
    dir="$key"
    _in_array "$dir" "${RESTRICTION_DIRS[@]}" || die "unknown restriction directive: $dir"
    # Serialise restriction writes: the relay guard below reads the PARTNER
    # chain, so two concurrent saves (relay and recipient) must not both pass
    # against each other's old value. Locks this script's own file -- no new
    # lock path to create or own.
    exec 9<"${BASH_SOURCE[0]}" || die "cannot open lock"
    flock -w 30 9 || die "another restriction change is in progress, try again"
    current="$(postconf -h "$dir" 2>/dev/null)"
    IFS=',' read -ra cur_toks <<< "$current"
    declare -a cur_trimmed=()
    for t in "${cur_toks[@]}"; do
      t="$(printf '%s' "$t" | sed -e 's/^[ \t]*//' -e 's/[ \t]*$//')"
      [ -n "$t" ] && cur_trimmed+=("$t")
    done

    declare -a new_toks=()
    while IFS= read -r line || [ -n "$line" ]; do
      line="$(printf '%s' "$line" | sed -e 's/^[ \t]*//' -e 's/[ \t]*$//')"
      [ -n "$line" ] && new_toks+=("$line")
    done
    [ "${#new_toks[@]}" -gt 0 ] || die "restriction list cannot be empty"

    for t in "${new_toks[@]}"; do
      _in_array "$t" "${SAFE_TOKENS[@]}" && continue
      _in_array "$t" "${cur_trimmed[@]}" && continue
      die "token not permitted (must already be present, or from the safe vocabulary): $t"
    done

    # Relay-control guard (see _restriction_guard). An unreadable partner is
    # passed as "" -- fail closed: the new chain must then be safe on its own.
    partner_val=""
    if partner="$(_relay_partner "$dir")"; then
      partner_val="$(postconf -h "$partner" 2>/dev/null)" || partner_val=""
    fi
    reason="$(_restriction_guard "$dir" "$partner_val" "${new_toks[@]}")" || die "$reason"

    joined=""
    for i in "${!new_toks[@]}"; do
      [ "$i" -gt 0 ] && joined+=", "
      joined+="${new_toks[$i]}"
    done
    _apply_and_reload "$dir" "$joined"
    ;;

  *) die "usage: get <key> | set <key> <value> | get-restriction <dir> | set-restriction <dir> (tokens on stdin)" ;;
esac
