#!/usr/bin/php
<?php
/**
 * Password-expiry pre-notification sweep: emails a mailbox owner 7, 3 and 1
 * day(s) before their own password_expiry.
 *
 * Run from cron as root:   0 6 * * * root /usr/local/sbin/qa-password-expiry-notify.php
 * Dry run (prints, sends nothing):    /usr/local/sbin/qa-password-expiry-notify.php --dry-run
 *
 * Idempotent via a JSON state file keyed on username:interval, so a mid-day
 * re-run (or a cron misfire) never double-sends -- same discipline
 * check-breaches.py uses for its own daily-budget tracking, translated to
 * PHP. flock()-guarded so two overlapping runs can't race the state file.
 *
 * Deliberately sends regardless of email_other (recovery-address) coverage:
 * at 7/3/1 days out the mailbox itself is still fully reachable, so there is
 * no lockout risk yet to exempt anyone from -- that exemption belongs to a
 * later, harsher notice (after an account is actually blocked), not this one.
 */

$APP = '/var/www/html/quarantine-admin';
require $APP . '/src/bootstrap.php';

const PWX_STATE_FILE = '/var/cache/quarantine-admin/pwexpiry-notify.json';
const PWX_LOCK_FILE  = '/var/lock/qa-password-expiry-notify.lock';
const PWX_INTERVALS  = [7, 3, 1]; // days before expiry

$dry = in_array('--dry-run', $argv ?? [], true);

// Master switch (ilexa console, Admin -> Jelszó-lejárati kényszerítés; same
// flag the Roundcube password_expiry plugin checks). Checked before even
// taking the lock -- when off, there is nothing for this run to do at all.
if (!qa_password_expiry_enabled()) {
    if ($dry) fwrite(STDOUT, "password-expiry-notify: disabled (Admin -> Jelszó-lejárati kényszerítés) -- would do nothing\n");
    exit(0);
}

$lockFh = fopen(PWX_LOCK_FILE, 'c');
if (!$lockFh || !flock($lockFh, LOCK_EX | LOCK_NB)) {
    fwrite(STDERR, "Already running - another instance holds the lock.\n");
    exit(0);
}

$state = [];
if (is_readable(PWX_STATE_FILE)) {
    $decoded = json_decode((string) file_get_contents(PWX_STATE_FILE), true);
    if (is_array($decoded)) $state = $decoded;
}

$db = audit_db();
if (!$db) {
    fwrite(STDERR, "database unavailable - skipping this run\n");
    flock($lockFh, LOCK_UN);
    exit(0);
}

function pwx_send_notice(string $user, int $days, string $expiry, bool $dry): bool {
    $subject = $days === 1
        ? 'Your mail password expires tomorrow'
        : "Your mail password expires in $days days";
    // No MAIL_FQDN constant exists in this app; POSTMASTER_FROM (postmaster@
    // the mail domain, always defined) already carries the same identity.
    $body = "Hello,\n\n"
          . "The password for $user will expire on $expiry.\n"
          . "Please change it before then to avoid being locked out of email.\n\n"
          . "This is an automated message from " . POSTMASTER_FROM . ".\n";

    if ($dry) {
        printf("[dry-run] would send to %s: %s\n", $user, $subject);
        return true;
    }

    $h = popen(SENDMAIL . ' -i -f ' . escapeshellarg(POSTMASTER_FROM) . ' ' . escapeshellarg($user), 'w');
    if (!$h) return false;
    fwrite($h, 'From: ' . POSTMASTER_FROM . "\r\n");
    fwrite($h, "To: $user\r\n");
    fwrite($h, "Subject: $subject\r\n");
    fwrite($h, "Content-Type: text/plain; charset=utf-8\r\n\r\n");
    fwrite($h, $body);
    return pclose($h) === 0;
}

$sent = 0;
$st = $db->prepare(
    'SELECT username, password_expiry FROM mailbox
     WHERE active = 1
       AND password_expiry >= NOW() + INTERVAL :d0 DAY
       AND password_expiry <  NOW() + INTERVAL :d1 DAY'
);
foreach (PWX_INTERVALS as $days) {
    $st->execute(['d0' => $days, 'd1' => $days + 1]);
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $user = (string) $row['username'];
        // Defence in depth: qaudit_ro's own column-scoped grant already
        // bounds what this query can read, but a username reaching a raw
        // mail header (To:/Subject: built by hand below, not via a mail
        // library) must never be trusted on format alone -- reuse the
        // app's own strict validator rather than a one-off regex here.
        if (!valid_user($user)) {
            fwrite(STDERR, "skipping malformed username: " . json_encode($user) . "\n");
            continue;
        }

        $key = $user . ':' . $days;
        if (isset($state[$key])) continue; // already notified for this interval

        if (pwx_send_notice($user, $days, (string) $row['password_expiry'], $dry)) {
            if (!$dry) $state[$key] = time();
            $sent++;
        } else {
            fwrite(STDERR, "send failed: $user ($days days)\n");
        }
    }
}

if (!$dry) {
    file_put_contents(PWX_STATE_FILE, json_encode($state, JSON_PRETTY_PRINT));
}
flock($lockFh, LOCK_UN);
fclose($lockFh);

fwrite(STDOUT, "password-expiry-notify: sent $sent notice(s)\n");
