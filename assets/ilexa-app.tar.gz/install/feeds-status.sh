#!/bin/bash
# feeds-status.sh - output JSON status of all reputation/blocklist feeds
# Called via sudo by the quarantine-admin web UI. No network access - stat + grep only.
set -uo pipefail

now=$(date +%s)

_mtime() { stat -c %Y "$1" 2>/dev/null || echo 0; }
_age()   { local mt=$1; [ "$mt" -eq 0 ] && echo -1 || echo $(( now - mt )); }
_fmt()   { local mt=$1; [ "$mt" -eq 0 ] && echo "" || date -d "@$mt" '+%Y-%m-%d %H:%M'; }
# grep -c prints its count AND exits 1 when that count is zero, so the older
# `$(grep -c … || echo 0)` idiom appended a SECOND zero and produced "0\n0",
# which corrupted the emitted JSON for any feed file that existed but matched
# nothing. Take the first line only; an unreadable or missing file yields an
# empty result, which defaults to 0.
_grepc() { local n; n=$(grep "$@" 2>/dev/null | head -1); printf '%s' "${n:-0}"; }

# ── AlienVault OTX IP block (firewalld ipset XML) ────────────────────────────
otx_f=/etc/firewalld/ipsets/otx_block.xml
otx_n=$(_grepc -c '<entry' "$otx_f")
otx_mt=$(_mtime "$otx_f")

# ── OTX DNSBL zone (rbldnsd - same source, separate file) ───────────────────
dnsbl_f=/var/lib/rbldnsd/otx.rbl
dnsbl_mt=$(_mtime "$dnsbl_f")
dnsbl_svc=$(systemctl is-active rbldnsd-otx 2>/dev/null; true)

# ── OTX URI hosts (rspamd multimap flat list) — reconnected 2026-08-15, was ──
# SpamAssassin/OTX_URI.cf (dead since the rspamd cutover, this line pointed at
# it until now, so the dashboard showed stale/zero status the whole time).
uri_f=/etc/rspamd/local.d/maps.d/otx_uri_hosts.inc
uri_n=$(_grepc -vc '^\s*#\|^\s*$' "$uri_f")
uri_mt=$(_mtime "$uri_f")

# ── URLhaus hosts (rspamd multimap flat list) ─────────────────────────────────
uh_f=/etc/rspamd/local.d/maps.d/urlhaus_hosts.inc
uh_n=$(_grepc -vc '^\s*#\|^\s*$' "$uh_f")
uh_mt=$(_mtime "$uh_f")

# ── Spamhaus DROP (firewalld ipset XML) ───────────────────────────────────────
sp_f=/etc/firewalld/ipsets/spamhaus_drop.xml
sp_n=$(_grepc -c '<entry' "$sp_f")
sp_mt=$(_mtime "$sp_f")

# ── Abuse.ch C2 / ThreatFox + Feodo (firewalld ipset XML) ────────────────────
c2_f=/etc/firewalld/ipsets/abuse_c2_block.xml
c2_n=$(_grepc -c '<entry' "$c2_f")
c2_mt=$(_mtime "$c2_f")

# ── Geoblock (firewalld ipset XML) ────────────────────────────────────────────
geo_f=/etc/firewalld/ipsets/geoblock.xml
geo_n=$(_grepc -c '<entry' "$geo_f")
geo_mt=$(_mtime "$geo_f")

# ── rspamd multimap IP-reputation feeds (score-only) ─────────────────────────
fh_f=/etc/rspamd/local.d/maps.d/firehol.inc
fh_n=$(_grepc -vc '^\s*#\|^\s*$' "$fh_f");  fh_mt=$(_mtime "$fh_f")
ab_f=/etc/rspamd/local.d/maps.d/abuseipdb.inc
ab_n=$(_grepc -vc '^\s*#\|^\s*$' "$ab_f");  ab_mt=$(_mtime "$ab_f")
et_f=/etc/rspamd/local.d/maps.d/emergingthreats.inc
et_n=$(_grepc -vc '^\s*#\|^\s*$' "$et_f");  et_mt=$(_mtime "$et_f")

# ── rspamd community rules (curated multimap rule-set, category-file count) ──
rr_d=/etc/rspamd/local.d/community-rules.d
rr_n=$(find "$rr_d" -maxdepth 1 -name '*.conf' 2>/dev/null | wc -l)
rr_mt=$(_mtime "$rr_d")

# ── YARA Forge core pack (ClamAV .yar, rule count) ───────────────────────────
# Same expression update-yara-forge.sh uses to report "$count rules in pack"
# (grep -cE '^rule '), so the console and the updater's own log cannot
# disagree about how many rules are installed. Without this entry the feed had
# no age at all, so feed_health() graded it "unknown" forever -- a successful
# refresh still displayed "nincs adat".
yf_f=/var/lib/clamav/yara-forge-core.yar
yf_n=$(_grepc -cE '^rule ' "$yf_f")
yf_mt=$(_mtime "$yf_f")

printf '{\n'
printf '  "otx":      {"count":%s,"age":%s,"updated":"%s","cadence":21600},\n' \
    "$otx_n" "$(_age "$otx_mt")" "$(_fmt "$otx_mt")"
printf '  "otx_dnsbl":{"count":%s,"age":%s,"updated":"%s","cadence":21600,"svc":"%s"},\n' \
    "$otx_n" "$(_age "$dnsbl_mt")" "$(_fmt "$dnsbl_mt")" "$dnsbl_svc"
printf '  "otx_uri":  {"count":%s,"age":%s,"updated":"%s","cadence":86400},\n' \
    "$uri_n" "$(_age "$uri_mt")" "$(_fmt "$uri_mt")"
printf '  "urlhaus":  {"count":%s,"age":%s,"updated":"%s","cadence":86400},\n' \
    "$uh_n" "$(_age "$uh_mt")" "$(_fmt "$uh_mt")"
printf '  "spamhaus": {"count":%s,"age":%s,"updated":"%s","cadence":86400},\n' \
    "$sp_n" "$(_age "$sp_mt")" "$(_fmt "$sp_mt")"
printf '  "c2":       {"count":%s,"age":%s,"updated":"%s","cadence":86400},\n' \
    "$c2_n" "$(_age "$c2_mt")" "$(_fmt "$c2_mt")"
printf '  "geoblock": {"count":%s,"age":%s,"updated":"%s","cadence":604800},\n' \
    "$geo_n" "$(_age "$geo_mt")" "$(_fmt "$geo_mt")"
printf '  "firehol":  {"count":%s,"age":%s,"updated":"%s","cadence":86400},\n' \
    "$fh_n" "$(_age "$fh_mt")" "$(_fmt "$fh_mt")"
printf '  "abuseipdb":{"count":%s,"age":%s,"updated":"%s","cadence":86400},\n' \
    "$ab_n" "$(_age "$ab_mt")" "$(_fmt "$ab_mt")"
printf '  "et":       {"count":%s,"age":%s,"updated":"%s","cadence":86400},\n' \
    "$et_n" "$(_age "$et_mt")" "$(_fmt "$et_mt")"
printf '  "rspamd_rules":{"count":%s,"age":%s,"updated":"%s","cadence":86400},\n' \
    "$rr_n" "$(_age "$rr_mt")" "$(_fmt "$rr_mt")"
printf '  "yara_forge":{"count":%s,"age":%s,"updated":"%s","cadence":86400}\n' \
    "$yf_n" "$(_age "$yf_mt")" "$(_fmt "$yf_mt")"
printf '}\n'
