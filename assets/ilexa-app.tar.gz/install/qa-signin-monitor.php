#!/usr/bin/php
<?php
/**
 * Login-anomaly ingestion sweep: reads recent successful/failed mailbox
 * sign-ins (Dovecot + Roundcube logs, via mail_auth_successes()/
 * mail_auth_failures() -- src/signin.php), enriches with GeoIP (country,
 * city/lat-lon, ASN), and stores new events in logins.db. Also maintains
 * each user's "usual places" profile (signin_places) from successful
 * logins only.
 *
 * Ingest also scores every new successful login via signin_risk_score()
 * (Phase 3) and stores score/tier/reasons on its row. Notification (Phase
 * 4) is not wired in yet. See plans/zany-napping-sunrise.md for the full
 * design.
 *
 * Run from cron as apache (it owns logins.db, same reasoning as
 * qa-campaign-detect.php/qa-ioc-expire.php -- no root, no sudo needed for
 * the DB itself; the existing "/usr/local/sbin/qa-audit-log.sh *" sudoers
 * grant apache already has covers the new mail-auth-success subcommand):
 *   (every 5 minutes) apache /usr/local/sbin/qa-signin-monitor.php
 *
 * Dry run (prints what would be ingested and its score, writes nothing):
 *   /usr/local/sbin/qa-signin-monitor.php --dry-run
 *
 * Explain: prints the signal breakdown for a hypothetical login by <user>
 * from <ip> RIGHT NOW, scored against that user's current stored profile
 * -- for verifying signin_risk_score() by hand against a seeded profile,
 * without waiting for a real log line to appear. Read-only, no lock taken.
 *   /usr/local/sbin/qa-signin-monitor.php --explain <user> <ip>
 *
 * flock()-guarded so an overrunning 5-minute run can't overlap the next --
 * same discipline qa-password-expiry-notify.php uses. No master on/off
 * toggle here: ingestion and scoring always run (only Phase 4's outbound
 * notification email gets an admin opt-in switch, checked at send time).
 */

$APP = '/var/www/html/quarantine-admin';
require $APP . '/src/bootstrap.php';

$argv = $argv ?? [];
if (($k = array_search('--explain', $argv, true)) !== false) {
    $user = $argv[$k + 1] ?? ''; $ip = $argv[$k + 2] ?? '';
    if ($user === '' || $ip === '' || !filter_var($ip, FILTER_VALIDATE_IP)) {
        fwrite(STDERR, "usage: qa-signin-monitor.php --explain <user> <ip>\n");
        exit(2);
    }
    $db = _signin_db();
    $now = time();
    $geo = qa_ip_geo($ip);
    $asn = qa_ip_asn($ip);
    $profile = signin_user_profile($db, $user, $now, $ip, $geo['cc']);
    $scored = signin_risk_score(
        ['ts' => $now, 'ip' => $ip, 'cc' => $geo['cc'], 'asn' => $asn,
         'lat' => $geo['lat'], 'lon' => $geo['lon'], 'proto' => 'IMAP'],
        $profile
    );
    printf("score=%d tier=%s (prior_successes=%d, history_days=%s, recent_failures=%d)\n",
        $scored['score'], $scored['tier'], $profile['prior_successes'],
        $profile['earliest_first_seen'] !== null ? round(($now - $profile['earliest_first_seen']) / 86400, 1) : 'n/a',
        $profile['recent_failures']);
    foreach ($scored['reasons'] as $r) {
        printf("  %+4d  %-24s %s\n", $r['weight'], $r['code'], $r['label']);
    }
    exit(0);
}

// Not /var/lock: that directory is root:root and apache (this script's
// runtime user, same as qa-campaign-detect.php/qa-ioc-expire.php) cannot
// create a new file there -- confirmed live. /var/cache/quarantine-admin is
// already apache-owned (it holds logins.db itself), same fix qa-feed-
// sample's cron entry already applies to CRON_ALERT_STATE_DIR for the
// identical reason.
const SIGNIN_LOCK_FILE = '/var/cache/quarantine-admin/qa-signin-monitor.lock';

$dry = in_array('--dry-run', $argv ?? [], true);

$lockFh = fopen(SIGNIN_LOCK_FILE, 'c');
if (!$lockFh || !flock($lockFh, LOCK_EX | LOCK_NB)) {
    fwrite(STDERR, "Already running - another instance holds the lock.\n");
    exit(0);
}

try {
    $result = signin_ingest(500, $dry);
} catch (Throwable $e) {
    fwrite(STDERR, 'signin-monitor: ingest failed: ' . $e->getMessage() . "\n");
    flock($lockFh, LOCK_UN);
    exit(1);
}

if ($dry) {
    echo "[dry-run] would insert {$result['inserted']} new event(s) of {$result['seen']} seen; nothing written\n";
    foreach ($result['samples'] as $s) echo "  + $s\n";
    flock($lockFh, LOCK_UN);
    exit(0);
}

echo "ingested {$result['inserted']} new event(s) of {$result['seen']} seen\n";

try {
    $pruned = signin_prune();
    if ($pruned['events_deleted'] > 0 || $pruned['places_deleted'] > 0) {
        echo "pruned {$pruned['events_deleted']} event(s), {$pruned['places_deleted']} place(s)\n";
    }
} catch (Throwable $e) {
    fwrite(STDERR, 'signin-monitor: prune failed: ' . $e->getMessage() . "\n");
    flock($lockFh, LOCK_UN);
    exit(1);
}

flock($lockFh, LOCK_UN);
exit(0);
