#!/bin/bash
#
# On-demand IOC-lookup service control: enable/disable a lookup service and
# store its API key. Parallel in shape to qa-feeds-config.sh, but for
# on-demand lookups (VirusTotal, URLhaus from the IOC tab) rather than
# cron-refreshed blocklist feeds -- no cadence field, because there is no
# cron dispatch for these.
#
# Keys are root-only files (0600). The web user must never read them -- it
# only asks this helper to write one, and only ever learns whether a key is
# *present*. Keys arrive on STDIN, never as an argument, so they stay out of
# ps and the shell history.
#
#   qa-ioclookup-config.sh list                  JSON: per source enabled/needs_key/has_key
#                                                (custom DNSBL sources carry zone/types/weight/custom too)
#   qa-ioclookup-config.sh enable  <source>
#   qa-ioclookup-config.sh disable <source>
#   qa-ioclookup-config.sh set-key <source>      key on stdin; empty input clears it
#   qa-ioclookup-config.sh is-enabled <source>   exit 0 if enabled
#   qa-ioclookup-config.sh add-custom <name> <zone> <types> <weight>
#                                                operator-defined DNSBL/URIBL lookup; types = ip,domain
#   qa-ioclookup-config.sh remove-custom <name>
set -uo pipefail

CONF=/etc/ilexa/ioc_lookup.conf
# Operator-defined DNS-zone lookup services (the only kind addable without
# code: an API service needs query/parse logic, a DNSBL needs only a zone).
# Format: name|zone|types|weight  -- types comma-joined from {ip,domain}.
CUSTOM=/etc/ilexa/ioc_lookup_custom.conf
die() { echo "qa-ioclookup-config: $*" >&2; exit 2; }

# source|keyfile   (urlhaus's keyfile is owned by the feed side -- this
# script reads has_key from it but set-key refuses to write it)
SOURCES=(
  "virustotal|/etc/ilexa/secrets/vt_api_key"
  "urlhaus|/etc/ilexa/secrets/abuse_api_key"
  "otx|/etc/ilexa/secrets/otx_api_key"
  "hrbl|"
  "mailspike|"
  "urlvet|"
  "yaraify|/etc/ilexa/secrets/abuse_api_key"
  "threatfox|/etc/ilexa/secrets/abuse_api_key"
  "xposedornot|"
  "leakcheck|"
  "hudsonrock|"
)

_field() { # source field_index -> value
  local s want
  for s in "${SOURCES[@]}"; do
    IFS='|' read -r want kf <<<"$s"
    [ "$want" = "$1" ] || continue
    case "$2" in key) echo "$kf" ;; esac
    return 0
  done
  return 1
}
_custom_row() { # name -> the conf row, or fail
  [ -f "$CUSTOM" ] && grep -m1 -E "^$1\|" "$CUSTOM"
}
_known() { _field "$1" key >/dev/null 2>&1 || _custom_row "$1" >/dev/null 2>&1; }

_ensure_conf() {
  [ -d /etc/ilexa ] || { mkdir -p /etc/ilexa; chmod 755 /etc/ilexa; }
  [ -f "$CONF" ] || {
    printf '# ilexa IOC-lookup services. "<source>=yes|no". Managed by qa-ioclookup-config.sh.\n' > "$CONF"
    chmod 644 "$CONF"
  }
}

_enabled() { # source -> 0 if enabled
  [ -f "$CONF" ] || return 1
  grep -qE "^$1=yes$" "$CONF"
}

_set() { # source yes|no
  _ensure_conf
  if grep -qE "^$1=" "$CONF"; then
    sed -i "s|^$1=.*|$1=$2|" "$CONF"
  else
    printf '%s=%s\n' "$1" "$2" >> "$CONF"
  fi
}

op="${1:-}"; src="${2:-}"

case "$op" in
  list)
    printf '{'
    first=1
    for s in "${SOURCES[@]}"; do
      IFS='|' read -r name kf <<<"$s"
      en=false; _enabled "$name" && en=true
      needs_key=false; [ -n "$kf" ] && needs_key=true
      has=false; [ -n "$kf" ] && [ -s "$kf" ] && has=true
      [ $first -eq 1 ] && first=0 || printf ','
      printf '"%s":{"enabled":%s,"needs_key":%s,"has_key":%s}' "$name" "$en" "$needs_key" "$has"
    done
    if [ -f "$CUSTOM" ]; then
      while IFS='|' read -r cname czone ctypes cweight; do
        [ -n "$cname" ] || continue; case "$cname" in \#*) continue ;; esac
        en=false; _enabled "$cname" && en=true
        [ $first -eq 1 ] && first=0 || printf ','
        printf '"%s":{"enabled":%s,"needs_key":false,"has_key":false,"custom":true,"zone":"%s","types":"%s","weight":%s}' \
          "$cname" "$en" "$czone" "$ctypes" "$cweight"
      done < "$CUSTOM"
    fi
    printf '}'
    ;;

  add-custom)
    name="$src"; zone="${3:-}"; types="${4:-}"; weight="${5:-}"
    [[ "$name" =~ ^[a-z0-9][a-z0-9_-]{1,30}$ ]] || die "invalid name (lowercase slug, 2-31 chars)"
    _field "$name" key >/dev/null 2>&1 && die "'$name' collides with a built-in service"
    _custom_row "$name" >/dev/null 2>&1 && die "'$name' already exists — remove-custom first"
    [[ "$zone" =~ ^[a-z0-9]([a-z0-9._-]{0,251}[a-z0-9])?$ ]] || die "invalid zone"
    [[ "$types" =~ ^(ip|domain|ip,domain|domain,ip)$ ]] || die "invalid types (ip, domain, or ip,domain)"
    [[ "$weight" =~ ^[0-9]{1,2}$ ]] && [ "$weight" -ge 1 ] && [ "$weight" -le 40 ] || die "invalid weight (1..40)"
    _ensure_conf
    [ -f "$CUSTOM" ] || { printf '# Operator-defined DNSBL lookup services. name|zone|types|weight. Managed by qa-ioclookup-config.sh.\n' > "$CUSTOM"; chmod 644 "$CUSTOM"; }
    printf '%s|%s|%s|%s\n' "$name" "$zone" "$types" "$weight" >> "$CUSTOM"
    _set "$name" yes
    echo OK
    ;;

  remove-custom)
    _custom_row "$src" >/dev/null 2>&1 || die "unknown custom source: $src"
    sed -i "/^${src}|/d" "$CUSTOM"
    sed -i "/^${src}=/d" "$CONF" 2>/dev/null || true
    echo OK
    ;;

  enable)
    _known "$src" || die "unknown source: $src"
    # Unlike qa-feeds-config.sh, do NOT refuse when the key is missing: this
    # is an on-demand lookup, not a cron job that would silently no-op every
    # run. A missing VT key surfaces per-lookup instead (see src/ioc_lookup.php).
    _set "$src" yes; echo OK
    ;;

  disable)
    _known "$src" || die "unknown source: $src"
    _set "$src" no; echo OK
    ;;

  set-key)
    _known "$src" || die "unknown source: $src"
    # Without this, a custom name would fall through every builtin refusal
    # below to the empty-keyfile branch, whose "OK cleared" path silently
    # DISABLES the service while reporting success.
    _custom_row "$src" >/dev/null 2>&1 && die "custom DNSBL sources need no api key"
    [ "$src" != "urlhaus" ] || die "urlhaus's key is managed from the feed sources, not here"
    # yaraify authenticates with the SAME abuse.ch key as urlhaus, so it has no
    # key of its own to set here either -- setting one would write the shared
    # credential from two places.
    [ "$src" != "yaraify" ] || die "yaraify uses the abuse.ch key, managed from the feed sources"
    [ "$src" != "threatfox" ] || die "threatfox uses the abuse.ch key, managed from the feed sources"
    [ "$src" != "otx" ]     || die "otx's key is managed from the feed sources, not here"
    [ "$src" != "hrbl" ]      || die "hrbl requires no api key"
    [ "$src" != "mailspike" ] || die "mailspike requires no api key"
    # Without this, set-key urlvet reaches the code below with an empty
    # keyfile field: an empty key would take the "OK cleared" path and
    # SILENTLY DISABLE the service while reporting success. Reachable from
    # the Admin POST handler, which gates only on IOCLOOKUP_SOURCES.
    [ "$src" != "urlvet" ]    || die "urlvet requires no api key"
    # Same trap as urlvet's, one line up: xposedornot's free tier is keyless,
    # so without this refusal set-key would reach the empty-keyfile branch
    # below, take its "OK cleared" path, and SILENTLY DISABLE the service
    # while reporting success.
    [ "$src" != "xposedornot" ] || die "xposedornot's free tier requires no api key"
    # Same keyless-service trap as the three above.
    [ "$src" != "leakcheck" ]  || die "leakcheck's public API requires no api key"
    [ "$src" != "hudsonrock" ] || die "hudsonrock's free OSINT API requires no api key"
    kf="$(_field "$src" key)"
    key="$(cat)"                      # stdin only
    key="${key//[$'\r\n']/}"          # a trailing newline breaks header auth
    if [ -z "$key" ]; then
      rm -f "$kf"; _set "$src" no
      echo "OK cleared"               # no key means the source cannot work
    else
      umask 077; printf '%s' "$key" > "$kf"; chmod 600 "$kf"
      echo OK
    fi
    ;;

  is-enabled)
    _known "$src" || die "unknown source: $src"
    _enabled "$src"
    ;;

  *) die "usage: list | enable <src> | disable <src> | set-key <src> | is-enabled <src>" ;;
esac
