#!/usr/bin/php
<?php
/**
 * Community feed loader entry point for the Mail Security Operations
 * Console. Runs as root (writes to /etc/firewalld/ipsets/ and reloads
 * firewalld) -- daily via cron for all enabled slots, or on-demand for
 * one slot via qa-community-feed-refresh.sh (sudo-gated, triggered from
 * the Admin tab's Refresh button).
 *
 * Usage:
 *   qa-community-feed-loader.php                    refresh all enabled feeds
 *   qa-community-feed-loader.php <id>               refresh one feed only
 *   qa-community-feed-loader.php <id> provision     create ipset + drop rule
 *   qa-community-feed-loader.php <id> teardown      remove rule + ipset + status
 *   qa-community-feed-loader.php <id> flush         empty the ipset, keep plumbing
 */

require __DIR__ . '/qa-community-feed-lib.php';

$arg  = $argv[1] ?? null;
$mode = $argv[2] ?? 'refresh';

// Lifecycle modes act on exactly one id and exit immediately; they never fall
// through to a refresh. The id is re-validated inside each lib function too.
if (in_array($mode, ['provision', 'teardown', 'flush'], true)) {
    if (!_community_feed_valid_id($arg)) { fwrite(STDERR, "bad id\n"); exit(1); }
    $id = (int) $arg;
    $ok = $mode === 'provision' ? _community_feed_provision($id)
        : ($mode === 'teardown' ? _community_feed_teardown($id)
        :                          _community_feed_flush($id));
    exit($ok ? 0 : 1);
}

if ($arg !== null && _community_feed_valid_id($arg)) {
    $failures = _community_feed_run([(int) $arg]);
} else {
    $failures = _community_feed_run();
}
exit($failures > 0 ? 1 : 0);
