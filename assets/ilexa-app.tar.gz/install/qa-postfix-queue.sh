#!/bin/bash
#
# Mail queue and postfix service control.
#
# The ilexa Admin tab drives queue inspection/actions and service reload
# through this one script -- apache never runs postqueue/postsuper/systemctl
# directly.
#
#   qa-postfix-queue.sh list                 postqueue -j output as a JSON array
#   qa-postfix-queue.sh flush                postqueue -f
#   qa-postfix-queue.sh hold <qid>            postsuper -h <qid>
#   qa-postfix-queue.sh release <qid>         postsuper -H <qid>
#   qa-postfix-queue.sh delete <qid>          postsuper -d <qid>
#   qa-postfix-queue.sh delete-all <queue>    postsuper -d ALL <queue> (active|deferred|hold)
#   qa-postfix-queue.sh status                JSON {"active":bool,"state":str,"since":str}
#   qa-postfix-queue.sh reload                systemctl reload postfix
#   qa-postfix-queue.sh restart               systemctl restart postfix
set -uo pipefail

die() { echo "qa-postfix-queue: $*" >&2; exit 2; }

_json_escape() { printf '%s' "$1" | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g'; }

_valid_qid() { [[ "$1" =~ ^[0-9A-F]{6,20}$ ]]; }

op="${1:-}"; a2="${2:-}"

case "$op" in
  list)
    printf '['
    first=1
    while IFS= read -r line; do
      [ -n "$line" ] || continue
      [ $first -eq 1 ] && first=0 || printf ','
      printf '%s' "$line"
    done < <(postqueue -j 2>/dev/null)
    printf ']'
    ;;

  flush)
    if postqueue -f >/dev/null 2>&1; then
      echo OK
    else
      die "postqueue -f failed"
    fi
    ;;

  hold)
    _valid_qid "$a2" || die "invalid queue id: $a2"
    if out="$(postsuper -h "$a2" 2>&1)"; then
      echo OK
    else
      die "$out"
    fi
    ;;

  release)
    _valid_qid "$a2" || die "invalid queue id: $a2"
    if out="$(postsuper -H "$a2" 2>&1)"; then
      echo OK
    else
      die "$out"
    fi
    ;;

  delete)
    _valid_qid "$a2" || die "invalid queue id: $a2"
    if out="$(postsuper -d "$a2" 2>&1)"; then
      echo OK
    else
      die "$out"
    fi
    ;;

  delete-all)
    case "$a2" in
      active|deferred|hold) : ;;
      *) die "invalid queue name: $a2 (must be active|deferred|hold)" ;;
    esac
    if out="$(postsuper -d ALL "$a2" 2>&1)"; then
      echo OK
    else
      die "$out"
    fi
    ;;

  status)
    state="$(systemctl is-active postfix 2>/dev/null || true)"
    active=false; [ "$state" = "active" ] && active=true
    since="$(systemctl show postfix --property=ActiveEnterTimestamp --value 2>/dev/null)"
    printf '{"active":%s,"state":"%s","since":"%s"}' "$active" "$(_json_escape "$state")" "$(_json_escape "$since")"
    ;;

  reload)
    if systemctl reload postfix; then
      echo OK
    else
      die "reload failed"
    fi
    ;;

  restart)
    if systemctl restart postfix; then
      echo OK
    else
      die "restart failed"
    fi
    ;;

  *) die "usage: list | flush | hold <qid> | release <qid> | delete <qid> | delete-all <queue> | status | reload | restart" ;;
esac
