#!/bin/bash
#
# qa-verify-console.sh — post-install checks for the ilexa console.
#
# One implementation, two callers: ilexa-installer's modules/99-verify.sh and
# the app's own install-console.sh. They used to each carry their own copy, and
# had already diverged on the first day -- 99-verify checked the folder
# allowlist but not sudo reachability, install-console.sh the reverse. That is
# the same drift that silently cost the gateway its hdr.received field, so the
# checks live here and both callers just run this.
#
# Contract, so each caller can render results in its own style:
#   stdout   one line per check, pipe-delimited:
#              OK|<label>
#              FAIL|<label>|<remedy>
#              SKIP|<label>|<why>
#   exit 0   every check passed (or was skipped)
#   exit 1   at least one FAIL
#
# Deliberately not "exit the number of failures": callers count the FAIL lines
# themselves, which avoids both the >125 exit-code wraparound and any confusion
# with a shell that treats a non-zero exit as fatal.
#
#   qa-verify-console.sh [--config PATH] [--web-user USER] [--gateway PATH]
set -uo pipefail

CONFIG=/var/www/html/quarantine-admin/config.php
GATEWAY=/usr/local/sbin/qa-doveadm.sh
WEB_USER=""

while [ $# -gt 0 ]; do
  case "$1" in
    --config)   CONFIG="${2:?--config needs a path}"; shift 2 ;;
    --web-user) WEB_USER="${2:?--web-user needs a name}"; shift 2 ;;
    --gateway)  GATEWAY="${2:?--gateway needs a path}"; shift 2 ;;
    *) echo "FAIL|argument parsing|unknown argument: $1"; exit 1 ;;
  esac
done

if [ -z "$WEB_USER" ]; then
  if   id -u apache   >/dev/null 2>&1; then WEB_USER=apache
  elif id -u www-data >/dev/null 2>&1; then WEB_USER=www-data
  fi
fi

fails=0
pass() { printf 'OK|%s\n' "$1"; }
fail() { printf 'FAIL|%s|%s\n' "$1" "$2"; fails=$((fails + 1)); }
skip() { printf 'SKIP|%s|%s\n' "$1" "$2"; }

# Read one top-level key out of config.php without sourcing it into a shell.
cfg() { php -r '$c=require $argv[1]; $v=$c[$argv[2]] ?? ""; echo is_array($v) ? implode(" ", $v) : $v;' "$CONFIG" "$1" 2>/dev/null; }

# ---- 1. config.php is loadable ---------------------------------------------
if [ ! -r "$CONFIG" ]; then
  fail "config.php present" "$CONFIG is missing or unreadable — the console cannot start"
  printf 'FAIL|remaining checks|skipped: they all read %s\n' "$CONFIG"
  exit 1
fi
if php -l "$CONFIG" >/dev/null 2>&1; then
  pass "config.php parses"
else
  fail "config.php parses" "php -l $CONFIG reports a syntax error"
  printf 'FAIL|remaining checks|skipped: %s does not parse\n' "$CONFIG"
  exit 1
fi

# ---- 2/3. config.php and the gateway must agree ----------------------------
# They independently carry the archive mailbox and the folder allowlist. When
# they disagree the console looks fine and fails silently: the gateway refuses
# folders the UI offers.
if [ -r "$GATEWAY" ]; then
  cfg_arch=$(cfg archive_user)
  gw_arch=$(sed -n 's/^ARCHIVE_USER="\(.*\)"$/\1/p' "$GATEWAY")
  if [ "$cfg_arch" = "$gw_arch" ]; then
    pass "archive account agrees between config.php and the gateway"
  else
    fail "archive account agrees between config.php and the gateway" \
         "config.php='$cfg_arch' gateway='$gw_arch' — re-render both from install/*.tmpl"
  fi

  cfg_f=$(cfg quarantine_folders)
  gw_f=$(sed -n 's/^ALLOWED_FOLDERS=(\(.*\))$/\1/p' "$GATEWAY" | tr -d '"' | xargs)
  if [ "$cfg_f" = "$gw_f" ]; then
    pass "folder allowlist agrees ($cfg_f)"
  else
    fail "folder allowlist agrees" \
         "config.php='$cfg_f' gateway='$gw_f' — the gateway will refuse folders the UI offers"
  fi
else
  fail "doveadm gateway installed" "$GATEWAY is missing — no mail access at all"
  cfg_arch=""
fi

# ---- 4. the archive account must actually exist ----------------------------
# Agreement alone is not enough: if BOTH name a nonexistent account (e.g.
# archive@example.com from an unedited PRIMARY_DOMAIN) they agree perfectly
# while the gateway refuses every archive fetch and the console displays no
# content, with nothing pointing at the cause.
if [ -z "${cfg_arch:-}" ]; then
  skip "archive account resolves" "no archive account configured (Archive tab disabled)"
elif ! command -v doveadm >/dev/null 2>&1; then
  skip "archive account resolves" "doveadm not on PATH"
elif doveadm user "$cfg_arch" >/dev/null 2>&1; then
  pass "archive account '$cfg_arch' is a real mailbox"
else
  fail "archive account resolves" \
       "'$cfg_arch' is not a known mailbox — message viewing WILL fail; check PRIMARY_DOMAIN/ARCHIVE_USER"
fi

# ---- 5. the web user must be able to reach mail ----------------------------
if [ -z "$WEB_USER" ]; then
  skip "web user can reach the gateway" "could not determine the web user"
elif ! command -v runuser >/dev/null 2>&1; then
  skip "web user can reach the gateway" "runuser not available"
elif runuser -u "$WEB_USER" -- sudo -n "$GATEWAY" users >/dev/null 2>&1; then
  pass "$WEB_USER can reach mail through the sudo gateway"
else
  fail "web user can reach the gateway" \
       "$WEB_USER cannot run $GATEWAY via sudo — check /etc/sudoers.d/ilexa"
fi

# ---- 6. Audit > Logins needs the access log ------------------------------
# Test the file the CONSOLE reads (config.php's access_log_glob), not whatever
# access log happens to sit in that directory. EL ships web logs root:root 0644
# so only the directory ACL gates access; Debian ships them root:adm 0640. "Can
# any log be read" is therefore not a portable question -- only "can the
# configured one be read" is. Globbing the directory produced a confident FAIL
# on a host where Audit > Logins worked perfectly.
glob=$(cfg access_log_glob)
if [ -z "$glob" ]; then
  skip "web user can read the access log" "no access_log_glob configured"
elif [ -z "$WEB_USER" ] || ! command -v runuser >/dev/null 2>&1; then
  skip "web user can read the access log" "cannot test as the web user here"
else
  # shellcheck disable=SC2086  # $glob must stay unquoted: it is a shell glob
  lf=$(ls -1 $glob 2>/dev/null | head -1)
  if [ -z "$lf" ]; then
    fail "access log present" "nothing matches access_log_glob ($glob) — Audit > Logins will be empty"
  elif runuser -u "$WEB_USER" -- test -r "$lf" 2>/dev/null; then
    pass "$WEB_USER can read $lf (Audit > Logins works)"
  else
    fail "web user can read the access log" \
         "$WEB_USER cannot read $lf — setfacl -m u:${WEB_USER}:rx $(dirname "$lf") (an ACL mask of --- from a chmod is the usual cause; on Debian also check the file is not root:adm 0640)"
  fi
fi

[ "$fails" -eq 0 ] || exit 1
exit 0
