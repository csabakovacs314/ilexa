#!/usr/bin/php
<?php
declare(strict_types=1);
/**
 * External-API request-budget CLI.
 *
 *   qa-quota.php take   <provider> <batch|interactive>
 *   qa-quota.php status <provider>
 *   qa-quota.php ensure <provider>
 *
 * The window/limit logic lives in qa-quota-lib.php and is NOT reimplemented
 * here. Nothing in the normal request path uses this script: the only code
 * that SPENDS budget is qa-ioc-lookup.php, which requires the library
 * directly, and the console displays the ledger by reading its (0644) file.
 *
 * This exists for the two jobs that need a process boundary rather than a
 * function call:
 *
 *   ensure  seed an empty ledger at install time, so the Rendszer card has a
 *           budget to display before the first request is ever made
 *   status  answer "why did the breach sweep stop last night" from a shell,
 *           without reading JSON by eye
 *
 * 'take' is exposed for completeness and for testing a budget by hand. It
 * SPENDS a real slot -- it is not a dry run -- so it is not something to
 * loop over idly.
 *
 * Exactly one JSON object is printed on every path, to stdout, matching
 * qa-ioc-lookup.php's contract so callers never have to read stderr to find
 * out what happened:
 *
 *   take:   {"allowed":true,...}  exit 0     {"allowed":false,"reason":...} exit 1
 *   status: {"provider":...,...}  exit 0     {"error":...}                  exit 1
 *
 * Root-only: the ledger lives under /var/lib/ilexa. The console does NOT use
 * this script -- it reads the (0644) ledger file directly, because rendering
 * a counter should not need a sudo grant.
 */

$lib = __DIR__ . '/qa-quota-lib.php';
if (!is_readable($lib)) {
    // Fail inside the contract rather than outside it: a bare PHP fatal would
    // reach check-breaches.py as an empty stdout, which it would have to
    // guess about.
    printf("{\"allowed\":false,\"reason\":\"quota library not installed: %s\"}\n", $lib);
    exit(1);
}
require $lib;

ini_set('display_errors', 'stderr');

function qa_quota_emit(array $payload, int $code): void {
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), "\n";
    exit($code);
}

$argvv = $argv ?? [];
array_shift($argvv);
$op       = $argvv[0] ?? '';
$provider = $argvv[1] ?? '';

// Providers are keys of a compile-time table, but this still validates the
// shape before it is used to build a path -- qa_quota_path() concatenates it.
if ($provider !== '' && preg_match('/^[a-z0-9][a-z0-9_-]{0,30}$/', $provider) !== 1) {
    qa_quota_emit(['error' => 'invalid provider'], 1);
}

switch ($op) {
    case 'take':
        $caller = $argvv[2] ?? '';
        $r = qa_quota_take($provider, $caller);
        qa_quota_emit($r, !empty($r['allowed']) ? 0 : 1);

    case 'status':
        $r = qa_quota_status($provider);
        qa_quota_emit($r, isset($r['error']) ? 1 : 0);

    case 'ensure':
        $r = qa_quota_ensure($provider);
        qa_quota_emit($r, isset($r['error']) ? 1 : 0);

    default:
        qa_quota_emit(['error' => 'usage: qa-quota.php take <provider> <batch|interactive>'
                                . ' | status <provider> | ensure <provider>'], 2);
}
