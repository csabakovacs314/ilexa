#!/bin/bash
#
# Feed ONE human-classified message into rspamd's neural network.
#
# Message on stdin, class as the only argument:
#   qa-neural-teach.sh spam < message.eml
#   qa-neural-teach.sh ham  < message.eml
#
# WHY THIS EXISTS: rspamd's neural only ever learns from vectors captured
# during a SCAN. A controller learn (what the console's teach buttons do,
# `rspamc learn_spam`) does not run the filter pipeline, so it produces no
# vector -- teaching Bayes has always left the neural net untouched. This
# closes that gap using rspamd's own supported forced-learn path: a scan
# carrying an `ANN-Train: spam|ham` request header (plugins/neural.lua,
# manual_train), which bypasses the score thresholds and stores the vector
# exactly as a live scan would.
#
# These are the BEST training vectors available anywhere on the system: a
# human looked at the message and said what it is. Everything else -- the
# archive replay, live autolearn -- is labelled by the rule stack's own
# verdicts, so it can only teach the ANN to imitate what already exists.
#
# Deliberately quiet and non-fatal: the caller is a web request finishing a
# release/delete/re-classify action the operator cares about, and neural
# training is a background nicety. Any failure exits 0 with a note on stderr
# rather than turning a successful teach into a visible error.
#
# NOT for bulk actions. One message is one scan (DNS lookups included), so a
# 50-message bulk release must not fan out into 50 of these.
set -uo pipefail

CLS="${1:-}"
URL=http://127.0.0.1:11333/checkv2
MAX_BYTES=$((5 * 1024 * 1024))

case "$CLS" in
  spam|ham) ;;
  *) echo "usage: $0 spam|ham < message" >&2; exit 2 ;;
esac

tmp=$(mktemp) || { echo "neural-teach: mktemp failed" >&2; exit 0; }
trap 'rm -f "$tmp"' EXIT
head -c "$MAX_BYTES" > "$tmp"

if [ ! -s "$tmp" ]; then
  echo "neural-teach: empty message, nothing to train" >&2
  exit 0
fi

# --fail matters: without it curl exits 0 on ANY completed exchange, so a 403
# (neural disabled, manual_train refused) or a 500 was reported as "OK neural
# vector queued" into the learn log, forever, while no vector was ever stored.
# That is the same false-success shape as the 2026-08-11 teach-button bug,
# where rspamd denied the learn and the UI said it had worked.
if curl -s --fail --max-time 30 -X POST "$URL" -H "ANN-Train: $CLS" \
     --data-binary "@$tmp" -o /dev/null; then
  echo "OK neural vector queued ($CLS)"
else
  echo "neural-teach: rspamd did not accept the training scan (HTTP error or timeout)" >&2
fi
exit 0
