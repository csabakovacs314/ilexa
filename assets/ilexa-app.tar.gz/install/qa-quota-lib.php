<?php
// Persistent external-API request budgets. Pure/testable functions only --
// no top-level executable code. Two entry points require this file:
// qa-quota.php (the CLI, used by check-breaches.py) and qa-ioc-lookup.php
// (the on-demand lookup gateway).
//
// TWO BUG CLASSES THIS EXISTS FOR.
//
// 1. A BUDGET THAT LIVES IN A PROCESS. XposedOrNot's free tier was enforced
//    only by check-breaches.py's own DAILY_LIMIT constant -- a number in RAM,
//    not on disk. That works while the cron sweep is the ONLY caller. The
//    moment a second one exists (the IOC tab's on-demand email lookup), two
//    independent processes spend one shared budget with no idea of each other,
//    and "45 per run" stops meaning anything. A restart, a manual run, or an
//    operator clicking through a dozen addresses would each silently overshoot.
//
// 2. A BUDGET THAT MODELS ONE LIMIT WHEN THE PROVIDER PUBLISHES THREE. See
//    QA_QUOTA_DEFAULTS below: modelling only the daily cap cost 75% of the
//    available XposedOrNot budget, every night, invisibly.
//
// So the budget lives on disk, every request -- batch or interactive -- takes
// a slot before it may leave the host, and it must fit in EVERY window the
// provider publishes.
//
// WHY ROLLING WINDOWS AND NOT RESET-AT-MIDNIGHT COUNTERS. The limits are
// stated per rolling period, not per calendar day. A midnight-reset counter
// would permit 100 requests at 23:59 and another 100 at 00:01. Storing the
// individual request timestamps costs a few hundred bytes (the list is capped
// by the largest limit) and models the actual rule exactly, so a slot frees
// up exactly when it was spent plus the window.
//
// FAIL CLOSED. An unreadable or unparseable ledger DENIES the request. The
// alternative -- assuming an empty budget and proceeding -- risks the API
// access itself, and this project has already been bitten once by a helper
// that read a broken state as a clean one (the rbl.conf Abusix incident,
// where a DNS SERVFAIL was read as "not listed"). A stopped sweep is visible
// on the Rendszer card and costs nothing but freshness; an overshoot is not
// visible at all until access is withdrawn. An ABSENT ledger is a different
// case and is NOT a failure: that is simply the first request ever made.

// Defined conditionally so a test harness can point both at a temp tree by
// defining them before the require. Deliberately NOT an environment variable:
// this file decides whether real money-equivalent budget gets spent, and an
// env var would let anything that can set the environment of a sudo'd helper
// hand it a fresh, empty ledger. A caller that can define a PHP constant
// before the require is already inside the trust boundary.
if (!defined('QA_QUOTA_DIR'))  define('QA_QUOTA_DIR',  '/var/lib/ilexa/quota');
// Operator override, never written by any installer.
// Lines: <provider>|<window_name>|<limit>  or  <provider>|reserve|<n>
if (!defined('QA_QUOTA_CONF')) define('QA_QUOTA_CONF', '/etc/ilexa/quota.conf');

// LOCALLY CONFIGURED ESTIMATES, not provider-reported values. None of these
// providers returns rate-limit headers (checked live 2026-08-27: LeakCheck
// sends none at all), so nothing here can be reconciled against the provider
// at runtime -- which is exactly why the Rendszer card labels these as
// configured rather than authoritative. If a published free tier changes,
// this is the one place to change it.
//
// A provider has SEVERAL windows, and a request must fit in ALL of them.
//
// WHY MULTIPLE WINDOWS EXIST AT ALL -- this is not speculative generality.
// XposedOrNot publishes three limits (2/sec, 25/hour, 100/day) and the sweep
// modelled only the daily one. It fired 45 requests inside four minutes, hit
// the HOURLY cap at request 26, took the 429 to mean the daily quota was
// gone, and stopped. Every night, for months: 25 checks instead of the
// available 100, and a full pass over the mailboxes taking 5.7 days instead
// of 1.4. The failure was completely silent -- the log line said "daily quota
// exhausted" and looked like correct, healthy behaviour.
//
// So: model every published window, or the shortest one silently becomes the
// only one that matters.
//
//   windows  [window_seconds, limit] pairs, keyed by a name used in messages
//            and in the operator override file
//   reserve  slots at the bottom of the LONGEST window that only interactive
//            callers may spend. Without it the sweep would routinely leave an
//            analyst with an empty budget the next morning, and a lookup that
//            cannot run is a worse failure than a sweep finishing a day later
//            -- the sweep re-queues itself, the analyst just sees a dead
//            button. Meaningless (and 0) for a provider with no scarce
//            long-window budget.
//
// Per-second windows are expressed as a window of 1 second. Note that the
// prune rule below counts a hit whose age is EXACTLY the window, so
// ['second' => [1, 1]] permits one request roughly every two seconds rather
// than exactly one per second. That conservatism is deliberate and cheap: a
// 143-mailbox LeakCheck sweep takes ~5 minutes instead of ~2.5.
const QA_QUOTA_DEFAULTS = [
    // https://xposedornot.com/api_doc -- 2/sec, 25/hour, 100/day.
    // 22/hour, not 25: our counter and the provider's will not agree exactly
    // (clock skew, requests in flight, their window boundary is not ours), and
    // the whole point of this file is to stop one short of the line.
    'xposedornot' => [
        'windows' => ['second' => [1, 2], 'hour' => [3600, 22], 'day' => [86400, 100]],
        'budget'  => 'day',
        'reserve' => 20,
    ],
    // https://docs.leakcheck.io/overview -- public API, no key, 1 req/sec,
    // no daily cap documented or observed. Commercial use is permitted on
    // condition of a "Powered by LeakCheck" link, which views/dashboard.php
    // renders; that attribution is a LICENCE TERM, not decoration.
    'leakcheck' => [
        'windows' => ['second' => [1, 1]],
        // NO budget window. Every refusal from this provider is pacing --
        // "wait a second" -- never "you are done for the day". Inferring the
        // budget as "the longest window" instead of naming it here is a real
        // bug that shipped for about ten minutes: with only a per-second
        // window, that inference made a 1-second wait look like an exhausted
        // daily quota, which would have stopped the whole mailbox sweep for
        // the day the first time two lookups landed in one second.
        'budget'  => null,
        'reserve' => 0,
    ],
    // https://docs.hudsonrock.com/ -- free OSINT endpoints, no key,
    // 50 requests per 10 seconds. 40 for the same margin reason as above.
    'hudsonrock' => [
        'windows' => ['burst' => [10, 40]],
        'budget'  => null,   // pacing only, same as leakcheck
        'reserve' => 0,
    ],
];

const QA_QUOTA_CALLERS = ['batch', 'interactive'];

/**
 * Effective budget for one provider, defaults merged with the operator
 * override file. Returns null for a provider with no budget defined --
 * callers treat that as "unknown provider", never as "unlimited".
 *
 * Override lines (/etc/ilexa/quota.conf), one per value:
 *   <provider>|<window_name>|<limit>     e.g.  xposedornot|hour|18
 *   <provider>|reserve|<n>               e.g.  xposedornot|reserve|30
 * An unknown window name is ignored rather than added: the set of windows a
 * provider has is a property of the provider, not an operator preference.
 */
function qa_quota_config(string $provider): ?array {
    $cfg = QA_QUOTA_DEFAULTS[$provider] ?? null;
    if ($cfg === null) return null;

    $fh = @fopen(QA_QUOTA_CONF, 'r');
    if ($fh) {
        while (($line = fgets($fh)) !== false) {
            $line = trim($line);
            if ($line === '' || $line[0] === '#') continue;
            $f = array_map('trim', explode('|', $line));
            if (count($f) < 3 || $f[0] !== $provider) continue;
            $key = $f[1];
            $val = (int)$f[2];
            if ($key === 'reserve') {
                // Clamped below, once the long window's limit is known.
                if ($val >= 0) $cfg['reserve'] = $val;
                continue;
            }
            // Bounds are deliberate: a typo'd 100000 would defeat the entire
            // point of the file.
            if (isset($cfg['windows'][$key]) && $val >= 1 && $val <= 100000) {
                $cfg['windows'][$key][1] = $val;
            }
        }
        fclose($fh);
    }

    // A reserve at or above the budget window's limit would starve batch
    // callers completely, which is worse than having no reserve at all. A
    // provider with no budget window has nothing scarce to reserve.
    $budget = qa_quota_budget_window($cfg);
    if ($budget === null || $cfg['reserve'] >= $budget[2]) $cfg['reserve'] = 0;
    return $cfg;
}

/**
 * The provider's longest window as [name, seconds, limit]. Used for RETENTION
 * -- a hit older than this is dead to every window and can be discarded.
 * Says nothing about which window is the budget.
 */
function qa_quota_max_window(array $cfg): array {
    $best = null;
    foreach ($cfg['windows'] as $name => [$secs, $limit]) {
        if ($best === null || $secs > $best[1]) $best = [$name, $secs, $limit];
    }
    return $best ?? ['day', 86400, 0];
}

/**
 * The window that is the BUDGET, as [name, seconds, limit] -- or null when the
 * provider has none.
 *
 * Named in the config rather than inferred, because the two are genuinely
 * different ideas and the inference is wrong for a provider whose only limit
 * is a rate. Being refused by the budget window means "not today" and stops a
 * sweep; being refused by any other means "not yet" and it should come back.
 * A provider with no budget window can only ever say "not yet".
 */
function qa_quota_budget_window(array $cfg): ?array {
    $name = $cfg['budget'] ?? null;
    if ($name === null || !isset($cfg['windows'][$name])) return null;
    [$secs, $limit] = $cfg['windows'][$name];
    return [$name, $secs, $limit];
}

function qa_quota_path(string $provider): string {
    return QA_QUOTA_DIR . '/' . $provider . '.json';
}

/**
 * Drop timestamps that have aged out of the window.
 *
 * The comparison is >= rather than >, so a hit whose age is EXACTLY the
 * window is still counted and frees one second later. That one second is
 * deliberate: at the boundary the two readings differ by a single request,
 * and on a free-tier budget the direction to be wrong in is "spent one fewer
 * than allowed", never "one more".
 *
 * A timestamp from the future is dropped rather than trusted -- a clock step
 * backwards would otherwise pin a slot for up to a whole extra window. The
 * 60s of slack absorbs ordinary NTP correction without doing that.
 */
function qa_quota_prune(array $hits, int $now, int $window): array {
    $cut = $now - $window;
    $out = [];
    foreach ($hits as $t) {
        if (is_int($t) && $t >= $cut && $t <= $now + 60) $out[] = $t;
    }
    sort($out);
    return $out;
}

/**
 * Build the public status shape from a pruned hit list. Shared by take() and
 * status() so the two can never describe the same ledger differently -- this
 * project's recurring bug is two code paths disagreeing about one number.
 */
function qa_quota_shape(string $provider, array $cfg, array $hits, int $now): array {
    $budget   = qa_quota_budget_window($cfg);
    // With no budget window the headline falls back to the longest one purely
    // so the shape stays uniform; 'budget' => false tells the console it is
    // looking at a rate, not a daily allowance, so it can say so.
    $headName = $budget !== null ? $budget[0] : qa_quota_max_window($cfg)[0];

    $windows = [];
    foreach ($cfg['windows'] as $name => [$secs, $limit]) {
        $in   = qa_quota_prune($hits, $now, $secs);
        $used = count($in);
        $windows[$name] = [
            'name'      => $name,
            'window'    => $secs,
            'limit'     => $limit,
            'used'      => $used,
            'remaining' => max(0, $limit - $used),
            // When this window's next slot frees (its oldest hit + its span).
            'reset_at'  => $in ? $in[0] + $secs : null,
        ];
    }
    $head = $windows[$headName];

    return [
        'provider'    => $provider,
        // The headline figures describe the LONGEST window -- the budget in
        // the everyday sense, and what the Rendszer card shows. The shorter
        // windows are pacing: being refused by one means "not yet", being
        // refused by this one means "not today". Keeping these keys at the top
        // level also means the console keeps reading the number it always did.
        'used'        => $head['used'],
        'limit'       => $head['limit'],
        'remaining'   => $head['remaining'],
        'reserve'     => $cfg['reserve'],
        // What a BATCH caller may still spend: it must leave the reserve alone.
        'batch_remaining' => max(0, $head['remaining'] - $cfg['reserve']),
        'window'      => $head['window'],
        'reset_at'    => $head['reset_at'],
        // Is the headline an allowance, or merely the slowest rate limit?
        'budget'      => $budget !== null ? $budget[0] : null,
        'windows'     => $windows,
        'last_request'=> $hits ? $hits[count($hits) - 1] : null,
        'updated_at'  => $now,
    ];
}

/**
 * Read the ledger under a shared lock. Returns [array|null $hits, string $err]
 * -- $hits null means "do not proceed" (unparseable). An absent file is the
 * first-ever request: [[], ''].
 */
function qa_quota_read(string $provider): array {
    $path = qa_quota_path($provider);
    if (!file_exists($path)) return [[], ''];
    $fh = @fopen($path, 'r');
    if (!$fh) return [null, 'ledger unreadable'];
    @flock($fh, LOCK_SH);
    $body = stream_get_contents($fh);
    @flock($fh, LOCK_UN);
    fclose($fh);
    if ($body === false || trim((string)$body) === '') return [null, 'ledger unreadable'];
    $d = json_decode((string)$body, true);
    if (!is_array($d) || !isset($d['hits']) || !is_array($d['hits'])) {
        return [null, 'ledger corrupt'];
    }
    return [array_values(array_filter($d['hits'], 'is_int')), ''];
}

/** Read-only view of a provider's budget. Never records a request. */
function qa_quota_status(string $provider, ?int $now = null): array {
    $now = $now ?? time();
    $cfg = qa_quota_config($provider);
    if ($cfg === null) {
        return ['provider' => $provider, 'error' => 'unknown provider'];
    }
    [$hits, $err] = qa_quota_read($provider);
    [, $maxSecs, $maxLimit] = qa_quota_max_window($cfg);
    if ($hits === null) {
        return ['provider' => $provider, 'error' => $err, 'limit' => $maxLimit];
    }
    // Prune to the LONGEST window: a hit outside it is dead to every window,
    // and shape() re-prunes per window from this list.
    return qa_quota_shape($provider, $cfg, qa_quota_prune($hits, $now, $maxSecs), $now);
}

/**
 * Atomically claim one request slot. This is the only function that records a
 * request, and every outbound call to a budgeted provider must pass through
 * it BEFORE the request leaves the host -- not after, and not "roughly around
 * the same time". Returns the status shape plus:
 *
 *   allowed  bool
 *   reason   ok
 *            | rate_limited              a SHORT window is full -- "not yet",
 *                                        retry_at says when. Normal pacing,
 *                                        not a failure.
 *            | quota_exhausted           the LONG window is full -- "not
 *                                        today".
 *            | reserved_for_interactive  long window has slots left, but only
 *                                        the reserve, and this is a batch call
 *            | unknown_provider | unknown_caller | ledger unreadable/corrupt
 *            | ledger not writable
 *   blocked_window  which window said no
 *   retry_at        when that window's next slot frees
 *
 * Distinguishing rate_limited from quota_exhausted is the whole point of
 * having several windows: the sweep must end its run for either, but for the
 * first it should come straight back next hour, and for the second it must
 * not. Conflating them is what cost 75% of the XposedOrNot budget.
 *
 * A denied call records nothing, so the caller keeps its place in whatever
 * queue it is working through.
 *
 * The whole read-decide-write cycle happens under one exclusive flock on the
 * ledger itself, and the write truncates in place rather than doing the usual
 * tmp+rename: a rename would swap the inode out from under any process
 * already blocked on the lock, which is precisely the concurrency this is
 * supposed to serialise. The file is a few hundred bytes -- one page -- so an
 * in-place rewrite is not meaningfully exposed to tearing, and a torn read
 * fails closed anyway.
 */
function qa_quota_take(string $provider, string $caller, ?int $now = null): array {
    $now = $now ?? time();
    $deny = function (string $reason, array $extra = []) use ($provider): array {
        return array_merge(['provider' => $provider, 'allowed' => false,
                            'reason' => $reason], $extra);
    };

    $cfg = qa_quota_config($provider);
    if ($cfg === null)                             return $deny('unknown_provider');
    if (!in_array($caller, QA_QUOTA_CALLERS, true)) return $deny('unknown_caller');

    if (!is_dir(QA_QUOTA_DIR) && !@mkdir(QA_QUOTA_DIR, 0755, true) && !is_dir(QA_QUOTA_DIR)) {
        return $deny('ledger not writable');
    }

    $path = qa_quota_path($provider);
    // 'c+' creates without truncating, so an existing ledger survives the open
    // even if we go on to deny the request.
    $fh = @fopen($path, 'c+');
    if (!$fh) return $deny('ledger not writable');

    try {
        if (!flock($fh, LOCK_EX)) return $deny('ledger not writable');

        $body = stream_get_contents($fh);
        $hits = [];
        if (trim((string)$body) !== '') {
            $d = json_decode((string)$body, true);
            if (!is_array($d) || !isset($d['hits']) || !is_array($d['hits'])) {
                return $deny('ledger corrupt');
            }
            $hits = array_values(array_filter($d['hits'], 'is_int'));
        }
        $budget     = qa_quota_budget_window($cfg);
        $budgetName = $budget !== null ? $budget[0] : null;
        [, $maxSecs] = qa_quota_max_window($cfg);
        $hits  = qa_quota_prune($hits, $now, $maxSecs);
        $shape = qa_quota_shape($provider, $cfg, $hits, $now);

        // Check EVERY window; the request needs room in all of them. Shortest
        // first, so a denial names the most immediate blocker rather than a
        // distant one -- "the hour is full, retry in 12 minutes" is actionable
        // in a way that "the day has 60 left" is not.
        $byLength = $shape['windows'];
        uasort($byLength, fn(array $a, array $b): int => $a['window'] <=> $b['window']);

        foreach ($byLength as $name => $w) {
            $isBudget = ($budgetName !== null && $name === $budgetName);
            // The reserve guards the budget window only: every other window is
            // pacing and applies equally to both caller classes.
            $floor    = ($isBudget && $caller === 'batch') ? $cfg['reserve'] : 0;
            if ($w['remaining'] > $floor) continue;

            if (!$isBudget) {
                // "Not yet" -- a short window refilling is normal pacing, and
                // the caller should come back rather than treat this as the
                // budget being gone.
                $reason = 'rate_limited';
            } elseif ($caller === 'batch' && $w['remaining'] > 0) {
                $reason = 'reserved_for_interactive';
            } else {
                $reason = 'quota_exhausted';
            }
            return array_merge($shape, [
                'allowed'        => false,
                'reason'         => $reason,
                'blocked_window' => $name,
                'retry_at'       => $w['reset_at'],
                'caller'         => $caller,
            ]);
        }

        $hits[] = $now;
        $shape  = qa_quota_shape($provider, $cfg, $hits, $now);
        $out    = json_encode($shape + ['hits' => $hits],
                              JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

        rewind($fh);
        if (ftruncate($fh, 0) === false || fwrite($fh, $out . "\n") === false) {
            return $deny('ledger not writable');
        }
        fflush($fh);
        // The console reads this file directly rather than through a sudo
        // shim -- it holds counters and timestamps, no keys and no PII -- so
        // it has to stay world-readable. fopen honours the umask, which is
        // 077 in some cron contexts.
        @chmod($path, 0644);

        return array_merge($shape, ['allowed' => true, 'reason' => 'ok', 'caller' => $caller]);
    } finally {
        @flock($fh, LOCK_UN);
        fclose($fh);
    }
}

/**
 * Write the ledger out with no request recorded, so the console has something
 * to render before the first request is ever made. Root-only, best effort.
 */
function qa_quota_ensure(string $provider, ?int $now = null): array {
    $now = $now ?? time();
    $st  = qa_quota_status($provider, $now);
    if (isset($st['error'])) return $st;
    $path = qa_quota_path($provider);
    if (file_exists($path)) return $st;
    if (!is_dir(QA_QUOTA_DIR) && !@mkdir(QA_QUOTA_DIR, 0755, true) && !is_dir(QA_QUOTA_DIR)) {
        return $st;
    }
    if (@file_put_contents($path,
            json_encode($st + ['hits' => []],
                        JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n",
            LOCK_EX) !== false) {
        @chmod($path, 0644);
    }
    return $st;
}
