#!/bin/bash
# Reload firewalld, then re-assert Fail2Ban bans.
#
# "firewall-cmd --reload" discards every *runtime* rich rule, and Fail2Ban's
# bans are runtime rich rules. Fail2Ban keeps the ban in its own database, so
# it neither re-applies the rule nor notices it is gone: the host silently
# stops enforcing every active ban, and the eventual unban fails with
# "NOT_ENABLED ... not in 'public'".
#
# Restarting a jail makes Fail2Ban restore its bans from the database and
# re-run the ban action, which recreates the rules with their original expiry.
# Only jails that actually hold bans are restarted.
set -uo pipefail

firewall-cmd --reload || exit $?

command -v fail2ban-client >/dev/null 2>&1 || exit 0
systemctl is-active --quiet fail2ban 2>/dev/null || exit 0

jails=$(fail2ban-client status 2>/dev/null \
        | sed -n 's/.*Jail list:[[:space:]]*//p' | tr -d '[:blank:]' | tr ',' ' ')

for j in $jails; do
    [ -n "$j" ] || continue
    n=$(fail2ban-client status "$j" 2>/dev/null \
        | sed -n 's/.*Currently banned:[[:space:]]*//p' | tr -d '[:blank:]')
    case "$n" in
        ''|*[!0-9]*) continue ;;
    esac
    [ "$n" -gt 0 ] && fail2ban-client restart "$j" >/dev/null 2>&1
done

exit 0
