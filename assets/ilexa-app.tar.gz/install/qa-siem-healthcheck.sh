#!/bin/bash
#
# Health check for SIEM export forwarding (see qa-siem-config.sh). Meant to
# run periodically from cron via cron-alert.sh, so a config that "looks
# enabled" but has quietly stopped sending anything gets caught and reported
# -- instead of silently rotting until someone happens to check with
# tcpdump. That is exactly what happened in practice once: an intermediate
# unreachable-collector state (while testing) wedged the omfwd action into a
# resume/retry backoff that only a full `systemctl restart rsyslog` cleared.
# The config itself, and `rsyslogd -N1`, both looked completely fine the
# whole time; `strace`ing rsyslogd during a triggered test event was the
# only thing that showed zero network syscalls were happening.
#
# Reads qa-siem-config.sh's impstats output (module(load="impstats" ...),
# one JSON object per line, in $STATS_FILE) and checks two distinct failure
# shapes for the named forward action ("siemfwd"):
#
#   1. Actively suspended right now (suspended > 0) -- omfwd's own retry/
#      backoff state. The direct signal.
#   2. Messages are being handed to the action ("processed" climbing between
#      this run and the last) but nothing is actually leaving the box
#      ("messages.sent", the per-target omfwd counter, staying flat). Kept
#      as a second check because a single suspended=0 sample does not rule
#      out a stall between backoff windows.
#
# On either signal: auto-heals with `systemctl restart rsyslog` (confirmed
# safe -- momentary local-logging gap only, no mail-flow impact, and it is
# the exact fix that resolved the real incident this script exists because
# of), then exits non-zero so cron-alert.sh mails the admin. It always
# alerts even though the problem self-heals: silently auto-fixing a channel
# that is supposed to carry security-relevant Fail2Ban/audit/auth-failure
# events to an external collector would hide exactly the kind of gap an
# admin needs to know happened.
set -uo pipefail

SIEM_CONF=/etc/ilexa/siem.conf
STATS_FILE=/var/log/rsyslog-siem-stats.json
STATE_FILE=/var/lib/rsyslog/qa-siem-healthcheck.state
STALE_AFTER=180   # seconds; impstats interval is 60s, allow 2 missed ticks

heal_and_fail() {
    echo "$1"
    systemctl restart rsyslog
    echo "Ran: systemctl restart rsyslog"
    rm -f "$STATE_FILE"
    exit 1
}

enabled=no
host=
if [ -f "$SIEM_CONF" ]; then
    # shellcheck disable=SC1090
    source "$SIEM_CONF"
fi

if [ "$enabled" != yes ] || [ -z "$host" ]; then
    # Forwarding is off -- nothing to check. Drop any stale comparison state
    # so a future re-enable does not compare against ancient counters.
    rm -f "$STATE_FILE"
    exit 0
fi

if [ ! -f "$STATS_FILE" ]; then
    heal_and_fail "SIEM export is enabled (target $host) but $STATS_FILE does not exist -- impstats never wrote a sample. Likely cause: rsyslog was reloaded rather than restarted after the config last changed (module(load=...) needs a full restart to take effect, a HUP/reload is not enough)."
fi

now_ts="$(date +%s)"
mtime="$(stat -c %Y "$STATS_FILE" 2>/dev/null || echo 0)"
if [ "$mtime" -eq 0 ] || [ $(( now_ts - mtime )) -gt "$STALE_AFTER" ]; then
    heal_and_fail "SIEM export is enabled (target $host) but $STATS_FILE has not been updated in over ${STALE_AFTER}s. rsyslog may be down or stuck."
fi

siem_line="$(tail -n 50 "$STATS_FILE" | grep '"name": "siemfwd", "origin": "core.action"' | tail -1)"
omfwd_line="$(tail -n 50 "$STATS_FILE" | grep '"origin": "omfwd"' | tail -1)"

if [ -z "$siem_line" ]; then
    heal_and_fail "SIEM export is enabled (target $host) but no 'siemfwd' action stats were found in the last 50 lines of $STATS_FILE -- the config may not have been fully reloaded (module/action changes need a full 'systemctl restart rsyslog', not just reload)."
fi

suspended="$(grep -oP '"suspended":\s*\K[0-9]+' <<< "$siem_line")"
processed="$(grep -oP '"processed":\s*\K[0-9]+' <<< "$siem_line")"
sent="$(grep -oP '"messages\.sent":\s*\K[0-9]+' <<< "$omfwd_line")"

if [ "${suspended:-0}" -gt 0 ]; then
    heal_and_fail "SIEM forward action 'siemfwd' is currently suspended (retry/backoff) -- suspended=$suspended, processed=$processed, target=$host."
fi

# Compare against the previous run. First run ever (no state file) has
# nothing to compare against yet -- just record a baseline.
if [ -f "$STATE_FILE" ]; then
    prev_processed=0
    prev_sent=0
    # shellcheck disable=SC1090
    source "$STATE_FILE"
    if [ "${processed:-0}" -gt "$prev_processed" ] && [ "${sent:-0}" -le "$prev_sent" ]; then
        heal_and_fail "SIEM forward action 'siemfwd' processed ${processed} messages (was ${prev_processed} last check) but messages.sent to $host stayed at ${sent} -- messages are being accepted but nothing is reaching the collector."
    fi
fi

{
    echo "prev_processed=${processed:-0}"
    echo "prev_sent=${sent:-0}"
} > "$STATE_FILE.tmp" && mv -f "$STATE_FILE.tmp" "$STATE_FILE"

exit 0
