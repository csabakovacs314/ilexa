#!/bin/bash
#
# Feed source control: enable/disable a reputation feed and store its API key.
#
# Both the installer and the ilexa Admin tab drive feeds through this one script,
# so there is a single place that knows where keys live and which sources need one.
#
# Keys are root-only files (0600). The web user must never read them - it only
# asks this helper to write one, and only ever learns whether a key is *present*.
# Keys arrive on STDIN, never as an argument, so they stay out of ps and the
# shell history.
#
#   qa-feeds-config.sh list                  JSON: per source enabled/needs_key/has_key
#   qa-feeds-config.sh enable  <source>
#   qa-feeds-config.sh disable <source>
#   qa-feeds-config.sh set-key <source>      key on stdin; empty input clears it
#   qa-feeds-config.sh is-enabled <source>   exit 0 if enabled
set -uo pipefail

CONF=/etc/ilexa/feeds.conf
die() { echo "qa-feeds-config: $*" >&2; exit 2; }

# source|keyfile|cadence_seconds   (empty keyfile = no key required)
SOURCES=(
  "otx|/etc/ilexa/secrets/otx_api_key|21600"
  "otx_uri|/etc/ilexa/secrets/otx_api_key|86400"
  "urlhaus|/etc/ilexa/secrets/abuse_api_key|86400"
  "c2|/etc/ilexa/secrets/abuse_api_key|86400"
  "abuseipdb|/etc/ilexa/secrets/abuseipdb_key|86400"
  "spamhaus||86400"
  "firehol||86400"
  "et||86400"
  "geoblock||604800"
  "rspamd_rules||86400"
  "yara_forge||86400"
)

_field() { # source field_index -> value
  local s want
  for s in "${SOURCES[@]}"; do
    IFS='|' read -r want kf cad <<<"$s"
    [ "$want" = "$1" ] || continue
    case "$2" in key) echo "$kf" ;; cadence) echo "$cad" ;; esac
    return 0
  done
  return 1
}
_known() { _field "$1" key >/dev/null 2>&1; }

_ensure_conf() {
  [ -d /etc/ilexa ] || { mkdir -p /etc/ilexa; chmod 755 /etc/ilexa; }
  [ -f "$CONF" ] || {
    printf '# ilexa feed sources. "<source>=yes|no". Managed by qa-feeds-config.sh.\n' > "$CONF"
    chmod 644 "$CONF"
  }
}

_enabled() { # source -> 0 if enabled
  [ -f "$CONF" ] || return 1
  grep -qE "^$1=yes$" "$CONF"
}

_set() { # source yes|no
  _ensure_conf
  if grep -qE "^$1=" "$CONF"; then
    sed -i "s|^$1=.*|$1=$2|" "$CONF"
  else
    printf '%s=%s\n' "$1" "$2" >> "$CONF"
  fi
}

op="${1:-}"; src="${2:-}"

case "$op" in
  list)
    printf '{'
    first=1
    for s in "${SOURCES[@]}"; do
      IFS='|' read -r name kf cad <<<"$s"
      en=false; _enabled "$name" && en=true
      needs=false; [ -n "$kf" ] && needs=true
      has=false;   [ -n "$kf" ] && [ -s "$kf" ] && has=true
      [ $first -eq 1 ] && first=0 || printf ','
      printf '"%s":{"enabled":%s,"needs_key":%s,"has_key":%s,"cadence":%s}' \
             "$name" "$en" "$needs" "$has" "$cad"
    done
    printf '}'
    ;;

  enable)
    _known "$src" || die "unknown source: $src"
    kf="$(_field "$src" key)"
    # Refuse rather than enable a source that can only fail: without its key the
    # updater exits without doing anything and the panel shows a stale feed.
    if [ -n "$kf" ] && [ ! -s "$kf" ]; then
      die "$src needs an API key first ($kf is missing or empty)"
    fi
    _set "$src" yes; echo OK
    ;;

  disable)
    _known "$src" || die "unknown source: $src"
    _set "$src" no; echo OK
    ;;

  set-key)
    _known "$src" || die "unknown source: $src"
    kf="$(_field "$src" key)"
    [ -n "$kf" ] || die "$src does not use an API key"
    key="$(cat)"                      # stdin only
    key="${key//[$'\r\n']/}"          # a trailing newline breaks header auth
    if [ -z "$key" ]; then
      rm -f "$kf"; _set "$src" no
      echo "OK cleared"               # no key means the source cannot work
    else
      umask 077; printf '%s' "$key" > "$kf"; chmod 600 "$kf"
      echo OK
    fi
    ;;

  is-enabled)
    _known "$src" || die "unknown source: $src"
    _enabled "$src"
    ;;

  *) die "usage: list | enable <src> | disable <src> | set-key <src> | is-enabled <src>" ;;
esac
