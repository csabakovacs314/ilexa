#!/usr/bin/php
<?php
// Hourly feed-count sampler. Runs as the WEB USER (apache), not root: it calls
// sudo feeds-status.sh -- a grant apache already holds -- and writes iocs.db,
// which apache must be able to read afterwards. A root-owned database or
// journal file that the web user cannot open has broken this app twice.
//
// Exits non-zero on a failed or unparseable status read, and the cron.d entry
// runs this through cron-alert.sh so that exit actually mails someone -- no
// qa-* cron.d job routes through it otherwise. It records NOTHING in the
// failure case: a fabricated zero would poison the median baseline and
// manufacture a false collapse on the next render.

// App root is overridable so this can be exercised against the worktree (or a
// scratch copy) BEFORE it is deployed -- without it, the first test run would
// load the deployed tree, which does not yet contain feed_health.php, and die
// on an undefined function. Production passes nothing and gets the real path.
$root = getenv('QA_APP_ROOT') ?: '/var/www/html/quarantine-admin';
require "$root/config.php";
require "$root/src/bootstrap.php";

$raw = shell_exec(SUDO . ' /usr/local/sbin/feeds-status.sh 2>/dev/null');
if (!is_string($raw) || trim($raw) === '') {
    fwrite(STDERR, "feeds-status.sh produced no output\n");
    exit(1);
}
$data = json_decode(trim($raw), true);
// is_array()/!$data alone cannot tell a JSON object from a JSON array --
// PHP represents both as an array. A top-level array (e.g. "[1,2,3]") must
// fail the same as any other unparseable input, not silently write rows
// keyed "0", "1", ...
if (!is_array($data) || !$data || array_is_list($data)) {
    fwrite(STDERR, "feeds-status.sh output was not a JSON object\n");
    exit(1);
}

$written = 0; $skipped = 0;
foreach ($data as $feed => $st) {
    // A feed missing from this run gets no row: absence is not a zero count.
    // Same for a non-numeric count ("N/A", ""): (int) casts either to 0, and
    // a fabricated zero would poison the median baseline just as badly as a
    // missing one, so it is skipped rather than recorded.
    if (!is_array($st) || !isset($st['count']) || !is_numeric($st['count'])) { $skipped++; continue; }
    // A non-numeric age is stored as -1 (unknown), the same as a missing age,
    // rather than letting (int) silently fabricate 0 (i.e. "just refreshed").
    $age = (isset($st['age']) && is_numeric($st['age'])) ? (int) $st['age'] : -1;
    if (feed_sample_record((string) $feed, (int) $st['count'], $age)) $written++;
    else $skipped++;
}
$pruned = feed_samples_prune();
fwrite(STDOUT, "feeds sampled=$written skipped=$skipped pruned=$pruned\n");
exit($written > 0 ? 0 : 1);
