#!/bin/bash
#
# Geo-blocking country-list control: read/write the ISO country codes that
# feed /usr/local/sbin/load-countries.sh's firewalld 'geoblock' ipset build.
#
# The ilexa Admin tab drives this through the one script, matching
# qa-feeds-config.sh's pattern -- the web user never touches the config file
# directly, only asks this helper to read or replace it.
#
#   qa-geoblock-config.sh get    prints the current codes, space-separated
#   qa-geoblock-config.sh set    new codes on stdin, space-separated;
#                                 validates, writes the file; rejects an
#                                 empty result (use the geoblock feed's
#                                 enable/disable toggle to turn blocking off
#                                 entirely instead)
set -uo pipefail

CONF=/etc/ilexa/geoblock.conf
die() { echo "qa-geoblock-config: $*" >&2; exit 2; }

op="${1:-}"

case "$op" in
  get)
    [ -f "$CONF" ] || { echo; exit 0; }
    grep -v '^#' "$CONF" | tr -s ' \t\r\n' ' ' | sed -e 's/^ *//' -e 's/ *$//'
    echo
    ;;

  set)
    raw="$(cat)"                      # stdin only
    codes="$(printf '%s' "$raw" | tr 'A-Z' 'a-z' | tr -s ' \t\r\n' ' ')"
    valid=()
    for c in $codes; do
      case "$c" in
        [a-z][a-z])
          dup=0
          for existing in "${valid[@]}"; do [ "$existing" = "$c" ] && dup=1 && break; done
          [ "$dup" -eq 0 ] && valid+=("$c")
          ;;
        *) die "invalid country code: '$c' (must be exactly 2 letters)" ;;
      esac
    done
    [ "${#valid[@]}" -gt 0 ] || die "no countries given (use the Geoblock enable/disable toggle to turn blocking off entirely)"
    mkdir -p /etc/ilexa
    {
      printf '# ilexa geoblock country list. ISO 3166-1 alpha-2, space-separated. Managed by qa-geoblock-config.sh.\n'
      printf '%s\n' "${valid[*]}"
    } > "$CONF"
    chmod 644 "$CONF"
    echo "OK ${valid[*]}"
    ;;

  *) die "usage: get | set (codes on stdin)" ;;
esac
