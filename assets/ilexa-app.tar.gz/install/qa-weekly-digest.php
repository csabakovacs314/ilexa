#!/usr/bin/php
<?php
/**
 * Weekly digest for the Mail Security Operations Console.
 *
 * Emails the administrator a summary of the week so routine health checking
 * does not require opening the console: mail volume and spam share, the top
 * spam senders, the state of every reputation feed, ClamAV, and how the breach
 * sweep is progressing.
 *
 * Run from cron as root:   0 7 * * 1  root  /usr/local/sbin/qa-weekly-digest.php
 * Dry run (prints, sends nothing):    /usr/local/sbin/qa-weekly-digest.php --dry-run
 */

$APP = '/var/www/html/quarantine-admin';
require $APP . '/src/bootstrap.php';

$dry = in_array('--dry-run', $argv ?? [], true);
$to  = getenv('QA_DIGEST_TO') ?: POSTMASTER_FROM;

// ── Volume, spam share and top senders, straight from the archive index ──────
$vol = ['total' => 0, 'spam' => 0];
$top = [];
$db  = audit_db();
if ($db) {
    $since = strtotime('-7 days');
    try {
        $st = $db->prepare("SELECT COUNT(*) c, COALESCE(SUM(is_spam),0) s FROM archive_index WHERE ts >= ?");
        $st->execute([$since]);
        $r   = $st->fetch(PDO::FETCH_ASSOC);
        $vol = ['total' => (int)$r['c'], 'spam' => (int)$r['s']];

        $st = $db->prepare("SELECT from_addr, COUNT(*) c FROM archive_index
                            WHERE ts >= ? AND is_spam = 1
                            GROUP BY from_addr ORDER BY c DESC LIMIT 10");
        $st->execute([$since]);
        $top = $st->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        // A digest is not worth failing over; the section simply reports nothing.
    }
}

$feeds  = admin_feeds_status();
$clam   = admin_clamav_status();
$breach = admin_breach_status();
$sys    = admin_system_info();

$pct  = $vol['total'] ? round($vol['spam'] * 100 / $vol['total']) : 0;
$age  = fn(int $s) => $s < 0 ? 'n/a' : ($s < 86400 ? intdiv($s, 3600) . ' h' : intdiv($s, 86400) . ' d');
$L    = [];
$L[]  = 'Mail Security Operations Console - weekly digest';
$L[]  = str_repeat('=', 52);
$L[]  = 'Host:   ' . SITE_SUBTITLE;
$L[]  = 'Period: ' . date('Y-m-d', strtotime('-7 days')) . ' .. ' . date('Y-m-d');
$L[]  = '';
$L[]  = 'MAIL VOLUME (7 days)';
$L[]  = sprintf('  archived: %s    spam: %s (%d%%)', number_format($vol['total']), number_format($vol['spam']), $pct);
$L[]  = '';

$L[] = 'TOP SPAM SENDERS';
if ($top) { foreach ($top as $t) $L[] = sprintf('  %5d  %s', $t['c'], $t['from_addr']); }
else      { $L[] = '  (no data)'; }
$L[] = '';

$L[] = 'DANGEROUS ATTACHMENTS (flagged, delivered)';
// Counted from rspamd's own log, NOT the postfix log and NOT the archive index.
//
// Both alternatives are blind to this by construction. qa-blocked-stats.sh
// parses postfix for rejections, and these messages are deliberately NOT
// rejected -- they are scored heavily, tagged and delivered so a false
// positive stays recoverable from the archive. archive_index stores the score
// but not the symbols, so it cannot say WHY a message scored what it did.
// rspamd's log is the only place the symbol name appears.
//
// A hit is worth an admin's attention precisely because nothing was blocked:
// the message reached a mailbox with an executable attachment attached.
$att = ['count' => 0, 'senders' => []];
foreach (glob('/var/log/rspamd/rspamd.log*') ?: [] as $lf) {
    if (!is_readable($lf)) continue;
    $cmd = (substr($lf, -3) === '.gz' ? 'zgrep' : 'grep')
         . ' -h ' . escapeshellarg('DANGEROUS_ATTACHMENT_EXT') . ' ' . escapeshellarg($lf) . ' 2>/dev/null';
    $out = shell_exec($cmd);
    foreach (explode("\n", (string)$out) as $line) {
        // Only real message verdicts carry "from: <...>". Config-load lines
        // ("add_augmentation", "set default score") mention the symbol too, and
        // counting those reports rule reloads as if they were blocked mail --
        // a mistake made once already while reading these very logs.
        if (!preg_match('/from: <([^>]*)>/', $line, $m)) continue;
        if (strpos($line, 'rspamd_task_write_log') === false) continue;
        $att['count']++;
        $dom = strstr((string)$m[1], '@') ?: (string)$m[1];
        $att['senders'][$dom] = ($att['senders'][$dom] ?? 0) + 1;
    }
}
if ($att['count'] > 0) {
    $L[] = sprintf('  %d message(s) carried an executable/script attachment', $att['count']);
    $L[] = '  they were TAGGED AND DELIVERED, not blocked - recoverable from the archive';
    arsort($att['senders']);
    foreach (array_slice($att['senders'], 0, 5, true) as $d => $c) $L[] = sprintf('  %5d  %s', $c, $d);
} else {
    $L[] = '  none';
}
$L[] = '';

$L[] = 'REPUTATION FEEDS';
$stale = 0;
$collapsed = 0;
// Collapse verdicts come from feed_health(), which opens iocs.db -- and this
// script runs as root. Delegated to a helper run as apache (see
// qa-feed-health.php) rather than requiring feed_health.php in-process here,
// for the same reason qa-feed-sample.php runs as apache and not root: a
// root-owned iocs.db journal in apache's 0700 cache dir has broken this app
// twice. A failed/unparseable helper run degrades to no collapse detection
// this week, not a broken digest -- STALE reporting below is unaffected.
$health = json_decode((string) shell_exec('runuser -u apache -- /usr/local/sbin/qa-feed-health.php 2>/dev/null'), true);
if (!is_array($health)) $health = [];
foreach ($feeds as $k => $f) {
    $cad = (int)($f['cadence'] ?? 86400);
    $a   = (int)($f['age'] ?? -1);
    $flag = ($a < 0 || $a > $cad * 3) ? ' <-- STALE' : '';
    if ($flag) $stale++;
    if (($health[$k]['state'] ?? '') === 'collapsed') {
        $flag .= sprintf(' <-- COLLAPSED (baseline %s, now %d%%)',
            number_format((int)($health[$k]['baseline'] ?? 0)), (int)($health[$k]['pct'] ?? 0));
        $collapsed++;
    }
    $L[] = sprintf('  %-12s %8s entries   updated %s ago%s', $k, number_format((int)($f['count'] ?? 0)), $age($a), $flag);
}
if (($feeds['otx_dnsbl']['svc'] ?? 'active') !== 'active') $L[] = '  rbldnsd service is NOT running';
$L[] = '';

$L[] = 'CLAMAV';
if ($clam) {
    $L[] = sprintf('  daemon: %s   engine %s   db %s (%s signatures)',
        !empty($clam['daemon_active']) ? 'running' : 'STOPPED',
        $clam['clam_version'] ?? '?', $clam['db_version'] ?? '?', number_format((int)($clam['db_sigs'] ?? 0)));
    $L[] = sprintf('  signatures updated %s ago', $age((int)($clam['daily_age'] ?? -1)));
} else { $L[] = '  (status unavailable)'; }
$L[] = '';

$L[] = 'DATA BREACHES';
if ($breach) {
    $L[] = sprintf('  %d exposed of %d checked (%d mailboxes total)',
        (int)($breach['exposed_count'] ?? 0), (int)($breach['checked_count'] ?? 0), (int)($breach['total_users'] ?? 0));
    foreach (array_slice($breach['exposed'] ?? [], 0, 10) as $e) {
        $L[] = sprintf('    %-38s %d breaches', $e['email'] ?? '?', count($e['breaches'] ?? []));
    }
} else { $L[] = '  (no data yet)'; }
$L[] = '';

$L[] = 'SYSTEM';
if (!empty($sys['disk'])) $L[] = sprintf('  disk %d%% used, %s free', $sys['disk']['pct'], admin_fmt_bytes($sys['disk']['avail']));
if (!empty($sys['mem']))  $L[] = sprintf('  memory %d%% used', $sys['mem']['pct']);
$L[] = '';
$L[] = 'Console: https://' . SITE_SUBTITLE . COOKIE_PATH;

$body    = implode("\n", $L) . "\n";
$subject = sprintf('[MSOC] Weekly digest - %s spam of %s mail%s%s',
    number_format($vol['spam']), number_format($vol['total']),
    $stale ? sprintf(', %d stale feed(s)', $stale) : '',
    $collapsed ? sprintf(', %d COLLAPSED feed(s)', $collapsed) : '');

if ($dry) { echo "To: $to\nSubject: $subject\n\n$body"; exit(0); }

$h = popen(SENDMAIL . ' -i -f ' . escapeshellarg(POSTMASTER_FROM) . ' ' . escapeshellarg($to), 'w');
if (!$h) { fwrite(STDERR, "digest: cannot start sendmail\n"); exit(1); }
fwrite($h, "To: $to\nSubject: $subject\nContent-Type: text/plain; charset=utf-8\n\n$body");
$rc = pclose($h);
if ($rc !== 0) { fwrite(STDERR, "digest: sendmail exited $rc\n"); exit(1); }
echo "digest sent to $to\n";
