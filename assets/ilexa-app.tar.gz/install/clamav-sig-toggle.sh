#!/bin/bash
# Toggle clamav-unofficial-sigs source rating in user.conf.
# Usage: clamav-sig-toggle.sh <source|yara> <DISABLE|ENABLE|LOW|MEDIUM|HIGH|on|off>
# Run via sudo as root.

USER_CONF="/etc/clamav-unofficial-sigs/user.conf"
VALID_SOURCES=(sanesecurity securiteinfo interserver linuxmalwaredetect malwareexpert malwarepatrol urlhaus ditekshen twinclams)
VALID_RATINGS=(LOW MEDIUM HIGH DISABLE ENABLE)

src="$1"
val="${2^^}"  # uppercase

if [ -z "$src" ] || [ -z "$val" ]; then
    echo "Usage: $0 <source|yara> <DISABLE|ENABLE|LOW|MEDIUM|HIGH>" >&2
    exit 1
fi

# Every path below edits $USER_CONF, which belongs to clamav-unofficial-sigs --
# a THIRD-PARTY tool that is not installed by default on either platform. When
# it is absent, sed failed on a missing file but the script still printed "OK"
# and exited 0, so any caller that trusted the exit status was told the toggle
# had been applied when nothing had changed. Fail here instead, with the reason
# and what to do about it.
if [ ! -f "$USER_CONF" ]; then
    # Do NOT tell the admin to "install it and retry": on current Debian and
    # Ubuntu that is impossible advice -- the package is gone from noble and
    # from Debian trixie onward, and the 3.7.2 build still in jammy/bookworm is
    # a different upstream that uses /etc/clamav-unofficial-sigs.conf, not the
    # master.conf/user.conf pair this script edits. Say where it IS available
    # and leave it at that. The console hides these controls when the package
    # is absent, so reaching this message means a direct POST, not a UI click.
    echo "clamav-unofficial-sigs is not installed on this host ($USER_CONF missing)." >&2
    echo "The ClamAV signature-source and YARA controls need it. On RHEL/Rocky/Alma it" >&2
    echo "comes from EPEL (dnf install clamav-unofficial-sigs); current Debian and Ubuntu" >&2
    echo "releases do not package it, so these controls are unavailable there." >&2
    exit 1
fi

# --- YARA toggle ---
if [ "$src" = "yara" ]; then
    [ "$val" = "ON" ] || [ "$val" = "ENABLE" ] && new_val="yes" || new_val="no"
    # update or add enable_yararules line (before the last line)
    if grep -qE '^(#?)enable_yararules=' "$USER_CONF" 2>/dev/null; then
        sed -i "s|^#\?enable_yararules=.*|enable_yararules=\"$new_val\"|" "$USER_CONF"
    else
        # insert before last line
        sed -i "\$i enable_yararules=\"$new_val\"" "$USER_CONF"
    fi
    echo "OK"
    exit 0
fi

# --- validate source ---
valid=false
for s in "${VALID_SOURCES[@]}"; do [ "$src" = "$s" ] && valid=true && break; done
if [ "$valid" != "true" ]; then
    echo "Unknown source: $src" >&2
    exit 1
fi

# --- validate rating ---
if [ "$val" = "ENABLE" ]; then
    # ENABLE = remove the user override (fall back to default_dbs_rating)
    sed -i "/^${src}_dbs_rating=/d" "$USER_CONF"
    # also remove commented version that we may have added
    echo "OK"
    exit 0
fi

valid_r=false
for r in "${VALID_RATINGS[@]}"; do [ "$val" = "$r" ] && valid_r=true && break; done
if [ "$valid_r" != "true" ]; then
    echo "Invalid rating: $val" >&2
    exit 1
fi

key="${src}_dbs_rating"
new_line="${key}=\"${val}\""

if grep -qE "^(#?)${key}=" "$USER_CONF" 2>/dev/null; then
    # replace existing line (commented or not)
    sed -i "s|^#\?${key}=.*|${new_line}|" "$USER_CONF"
else
    # append before the last line (before the trailing comment)
    sed -i "\$i ${new_line}" "$USER_CONF"
fi

echo "OK"
