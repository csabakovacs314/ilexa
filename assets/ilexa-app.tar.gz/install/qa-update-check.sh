#!/bin/bash
# qa-update-check.sh -- fetch RELEASES.json from the public release repo,
# verify it, compare against the installed VERSION, cache the result.
#
# Runs unprivileged, as the web user, both from cron (--cron) and from the
# dashboard's "Ellenőrzés most" button (--now, via plain shell_exec, no
# sudo). NO sudoers entry exists for this script and none should ever be
# added: it fetches one public URL and writes one apache-owned cache file --
# nothing it does needs root, and running it as root would be strictly worse
# for no benefit. Classified `cron list` in install/helpers.list.
#
# --cron honours the admin toggle (skips if update_check.disabled exists);
# --now always runs -- a human pressing the button IS the human action the
# design requires apply to always go through; the toggle governs only the
# unattended SCHEDULE, never a human-initiated check.
#
# Always exits 0. Prints exactly one status token, matching every other
# root/web helper in this app (feeds-refresh.sh etc.) so a caller doing
# shell_exec() never has to distinguish "tool failed" from "tool reported a
# failure" -- both look the same on the exit code, and the token says which.
set -uo pipefail
export LC_ALL=C

CACHE_DIR="${QA_CACHE_DIR:-/var/cache/quarantine-admin}"
CACHE_FILE="$CACHE_DIR/update-status.cache.json"
DISABLED_FLAG="$CACHE_DIR/update_check.disabled"
PUBKEY_FILE="${QA_UPDATE_PUBKEY:-/etc/ilexa/update-release.pub}"
VERSION_FILE="${QA_VERSION_FILE:-/var/www/html/quarantine-admin/VERSION}"
MANIFEST_URL="${QA_UPDATE_MANIFEST_URL:-https://raw.githubusercontent.com/csabakovacs314/ilexa/main/RELEASES.json}"
SIG_URL="${QA_UPDATE_SIG_URL:-${MANIFEST_URL}.sig}"

mode="${1:---cron}"
case "$mode" in
    --cron|--now) ;;
    *) echo "ERR_BAD_MODE"; exit 0 ;;
esac

if [ "$mode" = "--cron" ] && [ -f "$DISABLED_FLAG" ]; then
    echo "SKIPPED_DISABLED"; exit 0
fi

if ! [ -r "$PUBKEY_FILE" ]; then
    echo "ERR_NO_PUBKEY"; exit 0
fi
if ! [ -r "$VERSION_FILE" ]; then
    echo "ERR_NO_VERSION_FILE"; exit 0
fi
installed_version="$(tr -d '[:space:]' < "$VERSION_FILE" 2>/dev/null)"

tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT

# Conditional GET: reuse the etag from the last successful fetch so a
# no-change day costs the CDN a 304, not a full body.
prev_etag=""
if [ -r "$CACHE_FILE" ]; then
    prev_etag="$(php -r '
        $c = @json_decode(file_get_contents($argv[1]), true);
        echo is_array($c) ? ($c["etag"] ?? "") : "";
    ' "$CACHE_FILE" 2>/dev/null)"
fi
etag_hdr=()
[ -n "$prev_etag" ] && etag_hdr=(-H "If-None-Match: $prev_etag")

http_code="$(curl -fsS --proto '=https' --tlsv1.2 --max-time 20 --retry 2 \
    --max-filesize 262144 "${etag_hdr[@]}" \
    -D "$tmp/headers" -o "$tmp/manifest.json" -w '%{http_code}' \
    "$MANIFEST_URL" 2>"$tmp/curl.err")"
rc=$?
if [ "$rc" != 0 ] && [ "$rc" != 22 ]; then
    # curl -f makes a 304 exit non-zero (22) even though it's the success
    # case for us -- handled explicitly below by checking $http_code, not $rc.
    echo "ERR_FETCH"; exit 0
fi

if [ "$http_code" = "304" ]; then
    # A 304 says the MANIFEST is unchanged. It does NOT say the local state is
    # unchanged -- and the installed version is exactly what changes underneath
    # this cache. Merely touching the file (the earlier bug) left a stale
    # "installed" inside it, so right after a successful update to X the tile
    # kept advertising X as still available: the post-apply refresh got a 304,
    # touched the mtime, and the cached installed version stayed at the OLD
    # one. The same staleness would persist indefinitely on any host upgraded
    # by the installer rather than by one-click, since nothing would rewrite
    # the cache until the manifest itself changed.
    #
    # So recompute the two locally-derived fields from the CURRENT VERSION
    # file. No network, no re-verification needed: every value being reused
    # here came from a manifest this script already fetched and
    # signature-verified when it wrote the cache.
    php -r '
        $cacheFile = $argv[1]; $installed = $argv[2];
        $d = @json_decode(@file_get_contents($cacheFile), true);
        if (!is_array($d) || empty($d["latest"]["version"])) { exit(1); }
        $d["checked_at"] = time();
        $d["installed"] = ["version" => $installed];
        $d["update_available"] = version_compare($d["latest"]["version"], $installed, ">");
        $t = $cacheFile . ".tmp." . getmypid();
        if (file_put_contents($t, json_encode($d, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)) === false) { exit(1); }
        @chmod($t, 0640);
        rename($t, $cacheFile);
    ' "$CACHE_FILE" "$installed_version" 2>/dev/null || touch "$CACHE_FILE" 2>/dev/null
    echo "OK_NOTMODIFIED"; exit 0
fi
if [ "$http_code" != "200" ]; then
    echo "ERR_FETCH"; exit 0
fi

if ! curl -fsS --proto '=https' --tlsv1.2 --max-time 20 --retry 2 --max-filesize 4096 \
    -o "$tmp/manifest.json.sig" "$SIG_URL" 2>"$tmp/curl2.err"; then
    echo "ERR_FETCH_SIG"; exit 0
fi

# Verify against EITHER pinned key (primary or cold spare) -- see
# assets/ilexa/update-release.pub's own header for why two.
awk -v d="$tmp" '
    /-----BEGIN PUBLIC KEY-----/ { n++; f = d "/key" n ".pem" }
    n>0 { print > f }
' "$PUBKEY_FILE"
sig_ok=1
for k in "$tmp"/key*.pem; do
    [ -s "$k" ] || continue
    if openssl pkeyutl -verify -pubin -inkey "$k" -rawin -in "$tmp/manifest.json" -sigfile "$tmp/manifest.json.sig" >/dev/null 2>&1; then
        sig_ok=0; break
    fi
done
# A signature mismatch here is usually NOT tampering: raw.githubusercontent.com
# caches RELEASES.json and RELEASES.json.sig independently (max-age=300), so for
# a few minutes after a release is published the two can be fetched from
# different edge states and simply not match each other. Retry the pair before
# reporting failure.
#
# --cron ONLY. --now is invoked with a synchronous shell_exec() straight from
# the dashboard POST handler (src/admin.php), so sleeping here would stall the
# admin's HTTP request and risk the FPM/max_execution_time limit; the button is
# cheap to press again. The scheduled run has nobody waiting on it, and its
# alternative is a stale tile until tomorrow, so it is the one that benefits.
#
# SECURITY: identical to the apply path -- each attempt re-fetches BOTH files
# and re-runs the full verification. There is no accumulated trust and no
# accept-after-N-attempts; a genuinely bad signature fails every attempt.
if [ "$sig_ok" != 0 ] && [ "$mode" = "--cron" ]; then
    for _d in 20 45 90; do
        sleep "$_d"
        # Unconditional re-fetch: no If-None-Match, or a 304 would hand back
        # the very manifest that just failed to verify.
        curl -fsS --proto '=https' --tlsv1.2 --max-time 20 --retry 2 --max-filesize 262144 \
            -D "$tmp/headers" -o "$tmp/manifest.json" "$MANIFEST_URL" 2>/dev/null || continue
        curl -fsS --proto '=https' --tlsv1.2 --max-time 20 --retry 2 --max-filesize 4096 \
            -o "$tmp/manifest.json.sig" "$SIG_URL" 2>/dev/null || continue
        for k in "$tmp"/key*.pem; do
            [ -s "$k" ] || continue
            if openssl pkeyutl -verify -pubin -inkey "$k" -rawin -in "$tmp/manifest.json" -sigfile "$tmp/manifest.json.sig" >/dev/null 2>&1; then
                sig_ok=0; break
            fi
        done
        [ "$sig_ok" = 0 ] && break
    done
fi
if [ "$sig_ok" != 0 ]; then
    echo "ERR_SIG"; exit 0
fi

new_etag="$(grep -i '^etag:' "$tmp/headers" | tail -1 | sed -E 's/^[Ee][Tt][Aa][Gg]:\s*//; s/[\r\n]//g')"

# Everything from here is pure computation over an already-verified file --
# hand off to PHP for the JSON/semver work rather than reimplementing both
# in shell, and let it do the atomic cache write in one place.
php -r '
$manifestPath = $argv[1]; $cacheFile = $argv[2]; $installed = $argv[3]; $newEtag = $argv[4];
$m = json_decode(file_get_contents($manifestPath), true);
if (!is_array($m) || !isset($m["serial"], $m["latest"], $m["releases"])) { echo "ERR_MANIFEST_SHAPE\n"; exit(0); }

$prevSerial = 0;
if (is_readable($cacheFile)) {
    $prev = @json_decode(file_get_contents($cacheFile), true);
    if (is_array($prev)) $prevSerial = (int)($prev["serial"] ?? 0);
}
if ((int)$m["serial"] < $prevSerial) { echo "ERR_SERIAL\n"; exit(0); }

$latestEntry = null;
foreach ($m["releases"] as $r) { if (($r["version"] ?? "") === $m["latest"]) { $latestEntry = $r; break; } }
if (!$latestEntry) { echo "ERR_MANIFEST_SHAPE\n"; exit(0); }

$updateAvailable = version_compare($m["latest"], $installed, ">");
$out = [
    "checked_at" => time(), "ok" => true, "error" => "",
    "etag" => $newEtag, "serial" => (int)$m["serial"],
    "installed" => ["version" => $installed],
    "latest" => [
        "version" => $latestEntry["version"], "codename" => $latestEntry["codename"] ?? "",
        "severity" => $latestEntry["severity"] ?? "feature",
        "released_at" => $latestEntry["released_at"] ?? "",
        "requires_installer" => (bool)($latestEntry["requires_installer"] ?? false),
        "min_upgrade_from" => $latestEntry["min_upgrade_from"] ?? "",
        "notes_hu" => $latestEntry["notes_hu"] ?? "", "notes_en" => $latestEntry["notes_en"] ?? "",
    ],
    "update_available" => $updateAvailable,
];
$tmp = $cacheFile . ".tmp." . getmypid();
file_put_contents($tmp, json_encode($out, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
rename($tmp, $cacheFile);
@chmod($cacheFile, 0640);
echo "OK\n";
' "$tmp/manifest.json" "$CACHE_FILE" "$installed_version" "$new_etag"
