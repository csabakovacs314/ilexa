#!/bin/bash
# qa-update-check.sh -- fetch RELEASES.json from the public release repo,
# verify it, compare against the installed VERSION, cache the result.
#
# Runs unprivileged, as the web user, both from cron (--cron) and from the
# dashboard's "Ellenőrzés most" button (--now, via plain shell_exec, no
# sudo). NO sudoers entry exists for this script and none should ever be
# added: it fetches one public URL and writes one apache-owned cache file --
# nothing it does needs root, and running it as root would be strictly worse
# for no benefit. Classified `cron list` in install/helpers.list.
#
# --cron honours the admin toggle (skips if update_check.disabled exists);
# --now always runs -- a human pressing the button IS the human action the
# design requires apply to always go through; the toggle governs only the
# unattended SCHEDULE, never a human-initiated check.
#
# Always exits 0. Prints exactly one status token, matching every other
# root/web helper in this app (feeds-refresh.sh etc.) so a caller doing
# shell_exec() never has to distinguish "tool failed" from "tool reported a
# failure" -- both look the same on the exit code, and the token says which.
set -uo pipefail
export LC_ALL=C

CACHE_DIR="${QA_CACHE_DIR:-/var/cache/quarantine-admin}"
CACHE_FILE="$CACHE_DIR/update-status.cache.json"
DISABLED_FLAG="$CACHE_DIR/update_check.disabled"
PUBKEY_FILE="${QA_UPDATE_PUBKEY:-/etc/ilexa/update-release.pub}"
VERSION_FILE="${QA_VERSION_FILE:-/var/www/html/quarantine-admin/VERSION}"
MANIFEST_URL="${QA_UPDATE_MANIFEST_URL:-https://raw.githubusercontent.com/csabakovacs314/ilexa/main/RELEASES.json}"
SIG_URL="${QA_UPDATE_SIG_URL:-${MANIFEST_URL}.sig}"

mode="${1:---cron}"
case "$mode" in
    --cron|--now) ;;
    *) echo "ERR_BAD_MODE"; exit 0 ;;
esac

if [ "$mode" = "--cron" ] && [ -f "$DISABLED_FLAG" ]; then
    echo "SKIPPED_DISABLED"; exit 0
fi

if ! [ -r "$PUBKEY_FILE" ]; then
    echo "ERR_NO_PUBKEY"; exit 0
fi
if ! [ -r "$VERSION_FILE" ]; then
    echo "ERR_NO_VERSION_FILE"; exit 0
fi
installed_version="$(tr -d '[:space:]' < "$VERSION_FILE" 2>/dev/null)"

# ── Security-release notification ─────────────────────────────────────────────
# Fires ONCE per version, only for severity=security, only when that release is
# actually newer than what is installed. Everything else stays silent: the
# dashboard tile is the surface for ordinary releases, and a checker that mails
# about every feature release trains the operator to filter it out, which costs
# more than it gains.
#
# Deliberately AFTER the status token has been decided and printed by the block
# above -- src/admin.php treats the output as a contract and tests it for
# exactly "OK" or "OK_NOTMODIFIED", so nothing here may add to stdout.
#
# The send logic mirrors cron-alert.sh rather than calling it: that wrapper only
# mails when a wrapped command FAILS, which is not this. Kept self-contained per
# the install/ convention (see helpers.list's header on why no shared lib).
notify_security_release() {
    [ -r "$CACHE_FILE" ] || return 0

    local sev ver avail
    sev=$(php -r '$d=@json_decode(@file_get_contents($argv[1]),true); echo $d["latest"]["severity"] ?? "";' "$CACHE_FILE" 2>/dev/null)
    ver=$(php -r '$d=@json_decode(@file_get_contents($argv[1]),true); echo $d["latest"]["version"] ?? "";' "$CACHE_FILE" 2>/dev/null)
    avail=$(php -r '$d=@json_decode(@file_get_contents($argv[1]),true); echo !empty($d["update_available"]) ? "1" : "0";' "$CACHE_FILE" 2>/dev/null)

    [ "$sev" = "security" ] || return 0
    [ "$avail" = "1" ]      || return 0
    [ -n "$ver" ]           || return 0

    # One notification per version. The latch is the version itself, not a
    # boolean, so a LATER security release still notifies.
    local state="$CACHE_DIR/update-security-notified"
    [ -r "$state" ] && [ "$(cat "$state" 2>/dev/null)" = "$ver" ] && return 0

    # Same recipient resolution as cron-alert.sh: environment, then the file the
    # console's Admin tab manages, then nothing. Silence is the default -- an
    # address must be configured before anything is sent.
    local to="${MAILTO:-}"
    [ -z "$to" ] && [ -r /etc/ilexa/alerts.conf ] \
        && to="$(grep -vE '^\s*#|^\s*$' /etc/ilexa/alerts.conf | head -1 | tr -d '[:space:]')"
    if [ -z "$to" ]; then
        # Deliberately NOT latched. Latching here would mean an operator who
        # configures an address AFTER a security release was first seen never
        # receives the notice for it -- the worst possible moment to go quiet.
        # The cost is one journal line per check until an address exists.
        logger -t ilexa-update-check "security release $ver available — no alert recipient configured, journal only (set one in the console Admin tab)"
        return 0
    fi

    local host body
    host=$(hostname -f 2>/dev/null || hostname)
    body=$(mktemp) || return 0
    {
        printf 'A SECURITY release of ilexa is available.\n\n'
        printf '  installed : %s\n' "$installed_version"
        printf '  available : %s\n' "$ver"
        printf '  host      : %s\n\n' "$host"
        php -r '$d=@json_decode(@file_get_contents($argv[1]),true);
                $n=$d["latest"]["notes_en"] ?? ""; if ($n !== "") echo "  ", $n, "\n\n";' "$CACHE_FILE" 2>/dev/null
        printf 'Install it from the console: https://%s/ — the version row on the\n' "$host"
        printf 'dashboard shows it in red and applies it in one click.\n\n'
        printf 'Applying an update is always a human action; this message is only a notice.\n'
    } > "$body"

    if command -v mail >/dev/null 2>&1; then
        mail -s "[ilexa] SECURITY update available: $ver (on $host)" "$to" < "$body"
    elif command -v sendmail >/dev/null 2>&1; then
        { printf 'To: %s\n' "$to"
          printf 'Subject: [ilexa] SECURITY update available: %s (on %s)\n' "$ver" "$host"
          printf 'Auto-Submitted: auto-generated\n'
          printf 'X-Ilexa-Alert: update-security\n\n'
          cat "$body"
        } | sendmail -t -f "root@${host}"
    else
        logger -t ilexa-update-check "security release $ver available but neither mail(1) nor sendmail(8) found"
        rm -f "$body"; return 0
    fi

    rm -f "$body"
    # Latch only after a send was attempted, so a host that cannot send retries
    # on the next run rather than going quiet about a security release forever.
    printf '%s' "$ver" > "$state" 2>/dev/null
    logger -t ilexa-update-check "security release $ver — notified $to"
}


# Reconcile the two LOCALLY-DERIVED cache fields before any network work, so
# that every early exit below is correct by construction rather than by
# remembering to patch each one.
#
# "installed" and "update_available" depend only on the VERSION file and the
# already-cached "latest" -- no network, no re-verification (the cached latest
# came from a manifest this script fetched and signature-verified when it
# wrote the cache). But they were only ever recomputed on the full-rewrite
# path, so ANY early exit left a stale installed version behind. Both known
# instances were the same bug wearing different error codes:
#   - 304 (manifest unchanged): the post-apply refresh touched the mtime and
#     left installed at the OLD version, so the tile advertised an update it
#     had just installed.
#   - ERR_SERIAL: seen live right after 1.0.8 published -- the CDN served a
#     stale manifest whose serial was lower than the cached one, the
#     anti-rollback guard correctly refused it, and the cache kept
#     installed=1.0.7 while the host was already on 1.0.8.
# ERR_FETCH, ERR_FETCH_SIG and ERR_SIG all have the identical shape.
if [ -n "$installed_version" ] && [ -r "$CACHE_FILE" ]; then
    php -r '
        $f = $argv[1]; $installed = $argv[2];
        $d = @json_decode(@file_get_contents($f), true);
        if (!is_array($d) || empty($d["latest"]["version"])) { exit(0); }
        if (($d["installed"]["version"] ?? null) === $installed) { exit(0); }  // nothing to do
        $d["installed"] = ["version" => $installed];
        $d["update_available"] = version_compare($d["latest"]["version"], $installed, ">");
        $t = $f . ".tmp." . getmypid();
        if (file_put_contents($t, json_encode($d, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)) === false) { exit(0); }
        @chmod($t, 0640);
        rename($t, $f);
    ' "$CACHE_FILE" "$installed_version" 2>/dev/null || true
fi

tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT

# Conditional GET: reuse the etag from the last successful fetch so a
# no-change day costs the CDN a 304, not a full body.
prev_etag=""
if [ -r "$CACHE_FILE" ]; then
    prev_etag="$(php -r '
        $c = @json_decode(file_get_contents($argv[1]), true);
        echo is_array($c) ? ($c["etag"] ?? "") : "";
    ' "$CACHE_FILE" 2>/dev/null)"
fi
etag_hdr=()
[ -n "$prev_etag" ] && etag_hdr=(-H "If-None-Match: $prev_etag")

http_code="$(curl -fsS --proto '=https' --tlsv1.2 --max-time 20 --retry 2 \
    --max-filesize 262144 "${etag_hdr[@]}" \
    -D "$tmp/headers" -o "$tmp/manifest.json" -w '%{http_code}' \
    "$MANIFEST_URL" 2>"$tmp/curl.err")"
rc=$?
if [ "$rc" != 0 ] && [ "$rc" != 22 ]; then
    # curl -f makes a 304 exit non-zero (22) even though it's the success
    # case for us -- handled explicitly below by checking $http_code, not $rc.
    echo "ERR_FETCH"; exit 0
fi

if [ "$http_code" = "304" ]; then
    # installed/update_available were already reconciled above, so this only
    # needs to refresh the mtime that update_status() ages the cache by.
    touch "$CACHE_FILE" 2>/dev/null
    # A 304 means the MANIFEST did not change -- it says nothing about whether a
    # pending security release was ever successfully notified. Without this, a
    # release first seen while no recipient was configured would stay unannounced
    # forever: every later check is a 304 and would never reach the notifier.
    notify_security_release
    echo "OK_NOTMODIFIED"; exit 0
fi
if [ "$http_code" != "200" ]; then
    echo "ERR_FETCH"; exit 0
fi

if ! curl -fsS --proto '=https' --tlsv1.2 --max-time 20 --retry 2 --max-filesize 4096 \
    -o "$tmp/manifest.json.sig" "$SIG_URL" 2>"$tmp/curl2.err"; then
    echo "ERR_FETCH_SIG"; exit 0
fi

# Verify against EITHER pinned key (primary or cold spare) -- see
# assets/ilexa/update-release.pub's own header for why two.
awk -v d="$tmp" '
    /-----BEGIN PUBLIC KEY-----/ { n++; f = d "/key" n ".pem" }
    n>0 { print > f }
' "$PUBKEY_FILE"
sig_ok=1
for k in "$tmp"/key*.pem; do
    [ -s "$k" ] || continue
    if openssl pkeyutl -verify -pubin -inkey "$k" -rawin -in "$tmp/manifest.json" -sigfile "$tmp/manifest.json.sig" >/dev/null 2>&1; then
        sig_ok=0; break
    fi
done
# A signature mismatch here is usually NOT tampering: raw.githubusercontent.com
# caches RELEASES.json and RELEASES.json.sig independently (max-age=300), so for
# a few minutes after a release is published the two can be fetched from
# different edge states and simply not match each other. Retry the pair before
# reporting failure.
#
# --cron ONLY. --now is invoked with a synchronous shell_exec() straight from
# the dashboard POST handler (src/admin.php), so sleeping here would stall the
# admin's HTTP request and risk the FPM/max_execution_time limit; the button is
# cheap to press again. The scheduled run has nobody waiting on it, and its
# alternative is a stale tile until tomorrow, so it is the one that benefits.
#
# SECURITY: identical to the apply path -- each attempt re-fetches BOTH files
# and re-runs the full verification. There is no accumulated trust and no
# accept-after-N-attempts; a genuinely bad signature fails every attempt.
if [ "$sig_ok" != 0 ] && [ "$mode" = "--cron" ]; then
    for _d in 20 45 90; do
        sleep "$_d"
        # Unconditional re-fetch: no If-None-Match, or a 304 would hand back
        # the very manifest that just failed to verify.
        curl -fsS --proto '=https' --tlsv1.2 --max-time 20 --retry 2 --max-filesize 262144 \
            -D "$tmp/headers" -o "$tmp/manifest.json" "$MANIFEST_URL" 2>/dev/null || continue
        curl -fsS --proto '=https' --tlsv1.2 --max-time 20 --retry 2 --max-filesize 4096 \
            -o "$tmp/manifest.json.sig" "$SIG_URL" 2>/dev/null || continue
        for k in "$tmp"/key*.pem; do
            [ -s "$k" ] || continue
            if openssl pkeyutl -verify -pubin -inkey "$k" -rawin -in "$tmp/manifest.json" -sigfile "$tmp/manifest.json.sig" >/dev/null 2>&1; then
                sig_ok=0; break
            fi
        done
        [ "$sig_ok" = 0 ] && break
    done
fi
if [ "$sig_ok" != 0 ]; then
    echo "ERR_SIG"; exit 0
fi

new_etag="$(grep -i '^etag:' "$tmp/headers" | tail -1 | sed -E 's/^[Ee][Tt][Aa][Gg]:\s*//; s/[\r\n]//g')"

# Everything from here is pure computation over an already-verified file --
# hand off to PHP for the JSON/semver work rather than reimplementing both
# in shell, and let it do the atomic cache write in one place.
php -r '
$manifestPath = $argv[1]; $cacheFile = $argv[2]; $installed = $argv[3]; $newEtag = $argv[4];
$m = json_decode(file_get_contents($manifestPath), true);
if (!is_array($m) || !isset($m["serial"], $m["latest"], $m["releases"])) { echo "ERR_MANIFEST_SHAPE\n"; exit(0); }

$prevSerial = 0;
if (is_readable($cacheFile)) {
    $prev = @json_decode(file_get_contents($cacheFile), true);
    if (is_array($prev)) $prevSerial = (int)($prev["serial"] ?? 0);
}
if ((int)$m["serial"] < $prevSerial) { echo "ERR_SERIAL\n"; exit(0); }

$latestEntry = null;
foreach ($m["releases"] as $r) { if (($r["version"] ?? "") === $m["latest"]) { $latestEntry = $r; break; } }
if (!$latestEntry) { echo "ERR_MANIFEST_SHAPE\n"; exit(0); }

$updateAvailable = version_compare($m["latest"], $installed, ">");
$out = [
    "checked_at" => time(), "ok" => true, "error" => "",
    "etag" => $newEtag, "serial" => (int)$m["serial"],
    "installed" => ["version" => $installed],
    "latest" => [
        "version" => $latestEntry["version"], "codename" => $latestEntry["codename"] ?? "",
        "severity" => $latestEntry["severity"] ?? "feature",
        "released_at" => $latestEntry["released_at"] ?? "",
        "requires_installer" => (bool)($latestEntry["requires_installer"] ?? false),
        "min_upgrade_from" => $latestEntry["min_upgrade_from"] ?? "",
        "notes_hu" => $latestEntry["notes_hu"] ?? "", "notes_en" => $latestEntry["notes_en"] ?? "",
    ],
    "update_available" => $updateAvailable,
];
$tmp = $cacheFile . ".tmp." . getmypid();
file_put_contents($tmp, json_encode($out, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
rename($tmp, $cacheFile);
@chmod($cacheFile, 0640);
echo "OK\n";
' "$tmp/manifest.json" "$CACHE_FILE" "$installed_version" "$new_etag"


notify_security_release