#!/bin/bash
#
# Enumerate rspamd scanning modules and turn them on/off from the console.
#
# STATE MODEL. rspamd loads a module unless something sets enabled = false, so
# there are three states and only two are stored: "off" is an explicit
# enabled = false in local.d/<module>.conf, "on" is either an explicit true or
# nothing at all. `rspamadm configdump <module>` is the authority -- it reports
# the merged result of every config layer, which is what rspamd actually runs.
#
# WRITE DISCIPLINE. Several of these modules have real configuration in their
# local.d file (multimap, antivirus, rbl, fuzzy_check ...). This script owns
# exactly ONE key in that file, the `enabled` line, and rewrites nothing else --
# the same rule the DQS and Abusix key scripts follow, and for the same reason:
# on 2026-08-16 a script that assumed it owned a whole rspamd config file
# destroyed a live feed for hours.
#
# PROTECTED MODULES. Some are load-bearing and disabling them breaks the system
# in ways that do not look like "a module was switched off":
#   milter_headers  X-Spamd-Result disappears -> the archive indexer records no
#                   score for any message and the Archivum score column empties
#   settings        the authenticated/localhost exemptions live here; without
#                   them the server starts scoring and rejecting its own
#                   submissions and re-injected archive mail
#   force_actions   the forced CLAM_VIRUS reject -- virus mail becomes deliverable
#   multimap        every block/allow list, the IOC promotions and the dangerous
#                   attachment rule
#   antivirus       ClamAV itself
#   history_redis   the console's message history
# They are listed so the operator can see their state, and refused for writes.
set -uo pipefail

LOCALD=/etc/rspamd/local.d
PROTECTED="milter_headers settings force_actions multimap antivirus history_redis"

# Modules offered in the console. Deliberately a curated list of SCANNING
# behaviour rather than every plugin rspamd ships: the point is the handful an
# operator has a reason to switch, not sixty entries most of which are inert.
MODULES="antivirus arc asn bayes_expiry dkim_signing dmarc emails force_actions
fuzzy_check greylist hfilter history_redis known_senders maillist milter_headers
mid mime_types multimap mx_check neural once_received phishing ratelimit rbl
replies reputation settings spf trie url_redirector whitelist"

# Collapse to a single space-separated line. MODULES above is written across
# several lines for readability, which left every module at the start of a line
# preceded by a NEWLINE rather than a space -- so the `case " $MODULES " in
# *" $mod "*` membership test rejected them as unknown. milter_headers, the
# first entry on its line, was refused as "unknown module" while sitting in the
# list. Found by testing the protected-module refusal and getting the wrong
# refusal reason.
MODULES=$(echo $MODULES)

die() { echo "qa-rspamd-modules: $*" >&2; exit 2; }

_is_protected() { case " $PROTECTED " in *" $1 "*) return 0 ;; *) return 1 ;; esac; }

# on | off | default(=on).  configdump reports the merged, effective value.
_state() {
    local v
    # Same top-level-only rule as the list path above.
    v=$(rspamadm configdump "$1" 2>/dev/null \
        | grep -oE '^    enabled[[:space:]]*=[[:space:]]*(true|false)' \
        | head -1 | grep -oE 'true|false')
    case "$v" in
        false) echo off ;;
        true)  echo on ;;
        *)     echo default ;;
    esac
}

case "${1:-}" in
  list)
    # ONE configdump for the whole list, not one per module.
    #
    # The first version called _state() -- i.e. `rspamadm configdump <module>` --
    # once per module. Each call re-parses rspamd's entire configuration and
    # costs ~0.6s, so 31 modules took 17.9 SECONDS and the Rendszer page hung
    # for that long on every load. A single full dump costs 0.71s and yields
    # byte-identical values for every module (checked against the per-module
    # calls for greylist/mx_check/neural before switching).
    dump=$(rspamadm configdump 2>/dev/null)
    printf '['
    first=1
    for m in $MODULES; do
        # Section for this module, then the first `enabled` inside it. Stops at
        # the section's closing brace so a later module's value cannot leak in.
        st=$(printf '%s\n' "$dump" | awk -v m="$m" '
                # An EMPTY section is printed as "name {}" on ONE line, so the
                # closing-brace guard below never fires for it and the scan
                # would run on into the NEXT module and read its enabled value.
                # dmarc {} and bayes_expiry {} were both reported "off" that
                # way, having inherited elastic'"'"'s enabled = false. Match the
                # empty form first and stop.
                $0 ~ "^"m" \\{\\}" { exit }
                $0 ~ "^"m" \\{" { f=1; next }
                # TOP-LEVEL enabled only: exactly one indent level (4 spaces).
                # A module section contains nested blocks carrying their own
                # enabled keys (rbl holds one per RBL and several ship
                # disabled), so matching any indentation let a module inherit a
                # nested value: rbl was reported OFF while it had 57 symbols
                # registered and was plainly running.
                f && /^    enabled[[:space:]]*=/ { gsub(/[;[:space:]]/,"",$3); print $3; exit }
                f && /^\}/ { exit }')
        case "$st" in
            false) st=off ;;
            true)  st=on ;;
            *)     st=default ;;
        esac
        en=true; [ "$st" = off ] && en=false
        prot=false; _is_protected "$m" && prot=true
        conf=false; [ -f "$LOCALD/$m.conf" ] && conf=true
        [ "$first" = 1 ] || printf ','
        first=0
        printf '{"name":"%s","enabled":%s,"explicit":%s,"protected":%s,"has_conf":%s}' \
               "$m" "$en" "$([ "$st" = default ] && echo false || echo true)" "$prot" "$conf"
    done
    printf ']\n'
    ;;

  set)
    mod="${2:-}"; want="${3:-}"
    case " $MODULES " in *" $mod "*) : ;; *) die "unknown module: $mod" ;; esac
    case "$want" in on|off) : ;; *) die "expected on|off" ;; esac
    if [ "$want" = off ] && _is_protected "$mod"; then
        die "$mod is protected: disabling it breaks mail flow or the console in ways that do not look like a disabled module. Refusing."
    fi

    f="$LOCALD/$mod.conf"
    val=$([ "$want" = on ] && echo true || echo false)
    backup=""
    if [ -f "$f" ]; then
        backup="$(mktemp)"; cp -p "$f" "$backup"
    fi

    umask 022
    if [ -f "$f" ] && grep -qE '^[[:space:]]*enabled[[:space:]]*=' "$f"; then
        sed -i -E "s|^[[:space:]]*enabled[[:space:]]*=.*|enabled = ${val};|" "$f"
    elif [ -f "$f" ]; then
        printf '\n# Set by the ilexa console.\nenabled = %s;\n' "$val" >> "$f"
    else
        printf '# Created by the ilexa console: module on/off only.\nenabled = %s;\n' "$val" > "$f"
        chmod 0644 "$f"
    fi

    # Never leave rspamd unable to start. configtest before reload; restore the
    # previous file (or remove one we created) if the change does not parse.
    if ! out=$(rspamadm configtest 2>&1); then
        if [ -n "$backup" ]; then cp -p "$backup" "$f"; else rm -f "$f"; fi
        [ -n "$backup" ] && rm -f "$backup"
        die "configtest failed, change reverted: $(printf '%s' "$out" | tail -1)"
    fi
    [ -n "$backup" ] && rm -f "$backup"

    if systemctl is-active --quiet rspamd; then
        systemctl reload rspamd || die "reload failed after enabling/disabling $mod"
    fi
    echo "OK: $mod set to $want"
    ;;

  *) die "usage: list | set <module> on|off" ;;
esac
