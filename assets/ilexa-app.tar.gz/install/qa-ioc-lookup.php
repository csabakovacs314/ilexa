#!/usr/bin/php
<?php
declare(strict_types=1);
/**
 * On-demand reputation and exposure lookups for the IOC store
 * (VirusTotal, URLhaus, YARAify, ThreatFox, OTX, HRBL, Mailspike, url.vet,
 *  XposedOrNot, LeakCheck, Hudson Rock, plus operator-defined DNS zones).
 *
 * PHP port of qa-ioc-lookup.sh, same CLI contract, same JSON contract:
 *
 *   qa-ioc-lookup.php <service> <type> <value> [timeout_seconds] [caller]
 *     service: virustotal | urlhaus | otx | hrbl | mailspike | urlvet
 *            | yaraify | threatfox | xposedornot | leakcheck | hudsonrock
 *            | <operator-defined zone>
 *     type:    ip | domain | url | hash | email
 *              (hrbl: ip/domain; mailspike: ip only; urlvet: url/domain;
 *               xposedornot/leakcheck/hudsonrock: email only;
 *               ip IPv4-only for the DNS-zone services)
 *
 * THE THREE EMAIL SERVICES DO NOT ANSWER THE SAME QUESTION. xposedornot and
 * leakcheck both report breach-corpus membership and corroborate each other.
 * hudsonrock reports INFOSTEALER INFECTIONS -- a live condition meaning
 * credentials may be in circulation now -- and never fills 'breaches'. The
 * raw payload keeps them in separate keys for that reason.
 *     caller:  interactive (default) | batch -- budget class, see qa-quota-lib.php
 *
 * This is the ONLY place that talks to any of these APIs. check-breaches.py's
 * nightly sweep goes through it too (as caller=batch) rather than keeping its
 * own copy of the XposedOrNot request and response parser: one API, one
 * parser, one budget gate. Two readers of one API drifting apart is this
 * project's most reliable source of bugs.
 *
 * Exactly one JSON object is printed on every path, to stdout, so the caller
 * never has to distinguish stdout from stderr to get an error message:
 *
 *   success: {"verdict":..., "detail":..., "raw":...}   exit 0
 *   failure: {"error":...}                              exit 1
 *
 * apache has no read access to any API key -- this script does the external
 * call itself, as root, via sudo (install/helpers.list).
 *
 * Why PHP and not Bash: the shell version needed jq for every parse and a
 * forked curl/dig per lookup, and built one JSON body by hand. Here the
 * untrusted IOC value never reaches a shell at all -- no command is
 * constructed, so there is nothing to quote wrong -- and the response is
 * parsed by json_decode instead of eight jq invocations.
 *
 * Deliberate differences from the shell version, all in the same direction
 * (an ambiguous result is reported rather than silently read as "clean"):
 *
 *   - A DNS SERVFAIL/REFUSED is an ERROR, not "not listed". dig +short exits
 *     0 with empty output for those, so the shell version called a broken
 *     zone (or a rejected DQS key -- see the Abusix incident) clean.
 *   - A response body that is not valid JSON is reported as
 *     "<service>: invalid response" instead of the shell's empty message.
 *   - POST/GET parameters are properly URL-encoded; the shell interpolated
 *     the raw value into "field=value", which mangles any URL containing &.
 */

const VT_KEY_FILE    = '/etc/ilexa/secrets/vt_api_key';
const ABUSE_KEY_FILE = '/etc/ilexa/secrets/abuse_api_key';
const OTX_KEY_FILE   = '/etc/ilexa/secrets/otx_api_key';
const CUSTOM_CONF    = '/etc/ilexa/ioc_lookup_custom.conf';

// Shared external-API request budget, covering the three keyless email
// services. They are budgeted and the key-authenticated services are not,
// because these free tiers are shared counts spent by TWO callers -- this
// gateway and check-breaches.py's mailbox sweep -- rather than a per-key
// allowance one process is the only spender of.
//
// Required defensively: absence is fatal only for a budgeted service, so
// every other lookup keeps working on a host where the library has not
// landed yet (helpers arrive in helpers.list order during an update).
const QUOTA_LIB = __DIR__ . '/qa-quota-lib.php';
if (is_readable(QUOTA_LIB)) require QUOTA_LIB;

$TIMEOUT = 15;
// api.url.vet is public (no key). This is LONGER than the shared TIMEOUT
// because a non-resolving domain takes urlvet ~31s to give up on, and it
// does NOT cache incomplete analyses -- measured 2026-08-15 on
// paypal-secure-login.tk: 31.4s direct, then error at a 12s timeout, then
// error again on an immediate retry. A shorter timeout therefore makes dead
// phishing infrastructure -- the commonest thing in an IOC store --
// permanently uncheckable rather than merely slow. PHP's execution ceiling
// is lifted at the call site (_ioc_lookup_call) instead of capping this.
$URLVET_TIMEOUT = 35;
// The resolver budget, deliberately shorter than TIMEOUT: a DNSBL zone
// either answers fast or is not going to. Kept separate so the shared
// TIMEOUT can change without silently tripling every DNS wait.
$DIG_TIMEOUT = 5;

const USER_AGENT = 'ilexa-ioc-lookup/1.0';

// stdout carries the JSON contract and nothing else: a stray PHP notice in
// front of the object would reach the caller as "could not reach the
// service". Warnings still go to stderr, where sudo/cron can log them.
ini_set('display_errors', 'stderr');

// Same reason, for the one case that would otherwise print nothing at all.
set_exception_handler(function (Throwable $e): void {
    emit_error('internal error: ' . $e->getMessage());
});

// ---------------------------------------------------------------- output --

function emit_error(string $msg): void {
    echo json_encode(['error' => $msg],
        JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), "\n";
    exit(1);
}

function emit_result(string $verdict, string $detail, $raw): void {
    echo json_encode(['verdict' => $verdict, 'detail' => $detail, 'raw' => $raw],
        JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), "\n";
    exit(0);
}

// jq -r prints 87 for 87 and 87.5 for 87.5; PHP would print 87 as "87" only
// if it is an int. Keep whole floats whole so details read the same.
function num_str($n): string {
    if (is_int($n)) return (string)$n;
    if (is_float($n)) return (float)$n == floor((float)$n)
        ? (string)(int)$n : rtrim(rtrim(sprintf('%.6F', $n), '0'), '.');
    return (string)$n;
}

function read_key(string $file): string {
    if (!is_readable($file)) emit_error('no api key configured');
    $k = @file_get_contents($file);
    if ($k === false) emit_error('no api key configured');
    $k = trim($k);
    if ($k === '') emit_error('no api key configured');
    return $k;
}

// ------------------------------------------------------------------ HTTP --

/**
 * Returns the response BODY regardless of HTTP status -- VirusTotal answers
 * 404 with the JSON error the caller wants to see, exactly as `curl -s` gave
 * it to the shell version. Null means transport failure or an empty body.
 * Redirects are not followed (curl's default, and these are all APIs).
 */
function http_body(string $url, array $headers, ?string $post, int $timeout): ?string {
    $ch = curl_init($url);
    if ($ch === false) return null;
    $opts = [
        CURLOPT_RETURNTRANSFER  => true,
        CURLOPT_TIMEOUT         => $timeout,
        CURLOPT_CONNECTTIMEOUT  => $timeout,
        CURLOPT_FOLLOWLOCATION  => false,
        CURLOPT_USERAGENT       => USER_AGENT,
        CURLOPT_HTTPHEADER      => $headers,
    ];
    // CURLOPT_PROTOCOLS is deprecated from PHP 8.4; the _STR form replaces it.
    if (defined('CURLOPT_PROTOCOLS_STR')) $opts[CURLOPT_PROTOCOLS_STR] = 'https';
    else                                  $opts[CURLOPT_PROTOCOLS]     = CURLPROTO_HTTPS;
    if ($post !== null) {
        $opts[CURLOPT_POST]       = true;
        $opts[CURLOPT_POSTFIELDS] = $post;
    }
    curl_setopt_array($ch, $opts);
    $body = curl_exec($ch);
    curl_close($ch);
    if (!is_string($body) || $body === '') return null;
    return $body;
}

// Decodes a response body, or ends the run with "<service>: invalid response".
function decode_or_die(string $service, string $body) {
    $d = json_decode($body, true);
    if ($d === null && strtolower(trim($body)) !== 'null') {
        emit_error("$service: invalid response");
    }
    return $d;
}

// ---------------------------------------------------------------- budget --

/**
 * Claim one request slot for a budgeted provider, or end the run with an
 * error that says exactly why. Returns only when the request may proceed.
 *
 * Shared by every budgeted service so the refusal vocabulary cannot drift
 * between them -- check-breaches.py classifies these strings to decide
 * whether to come back next hour or stop for the day, and three copies of
 * this wording would eventually disagree.
 *
 * A refusal is always an ERROR, never a verdict. "We did not ask" and "we
 * asked and found nothing" are different facts, and collapsing the first into
 * the second puts a clean tick on an address nobody checked.
 */
function quota_gate(string $service, string $callerClass): void {
    if (!function_exists('qa_quota_take')) {
        emit_error("quota ledger not installed: " . QUOTA_LIB);
    }
    $q = qa_quota_take($service, $callerClass);
    if (!empty($q['allowed'])) return;

    // retry_at is the blocking window's own reset; reset_at is the long
    // window's. Prefer the specific one.
    $at   = $q['retry_at'] ?? ($q['reset_at'] ?? null);
    $when = $at ? ' — retry after ' . gmdate('Y-m-d H:i:s', (int)$at) . 'Z' : '';
    $win  = (string)($q['blocked_window'] ?? '');

    switch ((string)($q['reason'] ?? '')) {
        case 'rate_limited':
            // A SHORT window is full. This is pacing, not exhaustion: the
            // caller should come back, not give up for the day. The wording
            // must stay distinguishable from the quota case below.
            emit_error("$service: rate limited by the local $win window"
                     . ' (' . (int)($q['windows'][$win]['used'] ?? 0) . '/'
                     . (int)($q['windows'][$win]['limit'] ?? 0) . ')' . $when);
        case 'quota_exhausted':
            emit_error("$service: free-tier budget spent ("
                     . (int)($q['used'] ?? 0) . '/' . (int)($q['limit'] ?? 0) . ')' . $when);
        case 'reserved_for_interactive':
            emit_error("$service: remaining budget is reserved for interactive"
                     . ' lookups (' . (int)($q['remaining'] ?? 0) . ' left, reserve '
                     . (int)($q['reserve'] ?? 0) . ')' . $when);
        default:
            emit_error("$service: lookup not permitted ("
                     . (string)($q['reason'] ?? 'denied') . ')');
    }
}

// ------------------------------------------------------------- leakcheck --

/**
 * Pull the breach list out of a LeakCheck public-API response.
 * Returns [array $breaches, int $latestYear, int $records, array $dataClasses].
 *
 * Shapes, captured live 2026-08-27:
 *   found      {"success":true,"found":1366,"fields":[...],
 *               "sources":[{"name":"Mathway.com","date":"2020-01"}, ...]}
 *   not found  {"success":false,"error":"Not found"}
 *
 * Two things this API does that the caller must not misread:
 *
 *  - "found" is a RECORD count (1366 for a well-known test address with 213
 *    distinct sources). It is NOT a breach count and must never be rendered
 *    as one.
 *  - "fields" is a GLOBAL union of the exposed field types across every
 *    source, not a per-breach list. It is kept at payload level for that
 *    reason: "password appears somewhere in these 213 breaches" is a real
 *    decision input (force a reset, or merely inform), but pinning it to an
 *    individual breach would be inventing an attribution the API never made.
 *  - A malformed address also returns "Not found", so it cannot be
 *    distinguished here. Our own validation rejects those long before this.
 */
function leakcheck_parse($d): array {
    if (!is_array($d) || empty($d['success'])) return [[], 0, 0, []];

    $records = (isset($d['found']) && is_numeric($d['found'])) ? (int)$d['found'] : 0;

    $classes = [];
    foreach ((array)($d['fields'] ?? []) as $f) {
        if (!is_string($f) || $f === '') continue;
        $classes[] = mb_substr($f, 0, 40);
        if (count($classes) >= 30) break;
    }

    $breaches = [];
    $latest   = 0;
    foreach ((array)($d['sources'] ?? []) as $srcRow) {
        if (!is_array($srcRow)) continue;
        $name = (isset($srcRow['name']) && is_string($srcRow['name'])) ? $srcRow['name'] : '';
        if ($name === '') continue;
        // "YYYY-MM", or empty when the source's date is unknown. Take the year
        // and nothing else -- the merged view compares years.
        $year = 0;
        if (isset($srcRow['date']) && is_string($srcRow['date'])
            && preg_match('/^(\d{4})/', $srcRow['date'], $m) === 1) {
            $year = (int)$m[1];
        }
        $breaches[] = ['name' => mb_substr($name, 0, 80), 'year' => $year, 'data' => ''];
        if ($year > $latest) $latest = $year;
        // 213 sources came back for one address, so this cap is load-bearing,
        // not theoretical.
        if (count($breaches) >= 60) break;
    }
    return [$breaches, $latest, $records, $classes];
}

// ------------------------------------------------------------ hudsonrock --

/**
 * Pull infostealer infection detail out of a Hudson Rock search-by-email
 * response. Returns null when the address is in no stealer log.
 *
 * Shapes, captured live 2026-08-27:
 *   infected      {"message":"This email address is associated with a computer
 *                  that was infected...","stealers":[{...}],
 *                  "total_corporate_services":699,"total_user_services":32482}
 *   not infected  {"message":"...is not associated...","stealers":[],
 *                  "total_corporate_services":0,"total_user_services":0}
 *
 * WHAT IS DELIBERATELY DISCARDED. Each stealer record also carries
 * top_passwords, top_logins and ip. The free tier already returns those
 * partially masked ("M***************d", "45.243.***.***"), but masked
 * credential material is still credential material and we have no use for it:
 * the operator's action is "force a password reset on this mailbox", which
 * needs none of it. Storing it would put fragments of a real person's
 * passwords into a cache file to no purpose. They are dropped here, at the
 * boundary, so nothing downstream can start depending on them.
 *
 * What is kept is what makes the finding actionable and credible to the user
 * being told about it: when, which machine, which OS.
 */
function hudsonrock_parse($d): ?array {
    if (!is_array($d)) return null;
    $rows = $d['stealers'] ?? null;
    if (!is_array($rows) || !$rows) return null;

    $infections = [];
    $latest     = '';
    foreach ($rows as $r) {
        if (!is_array($r)) continue;
        $str = function (string $k) use ($r): string {
            $v = $r[$k] ?? '';
            // The API writes the literal string "Not Found" for absent values;
            // carrying that through would render as if it were data.
            if (!is_string($v) || $v === '' || strcasecmp($v, 'Not Found') === 0) return '';
            return mb_substr($v, 0, 100);
        };
        $date = $str('date_compromised');
        $av   = [];
        foreach ((array)($r['antiviruses'] ?? []) as $a) {
            if (is_string($a) && $a !== '') $av[] = mb_substr($a, 0, 40);
            if (count($av) >= 8) break;
        }
        $infections[] = [
            'date'      => $date,
            'computer'  => $str('computer_name'),
            'os'        => $str('operating_system'),
            'antivirus' => $av,
        ];
        if ($date > $latest) $latest = $date;   // ISO-8601, so string compare is date order
        if (count($infections) >= 20) break;
    }
    if (!$infections) return null;

    $num = function (string $k) use ($d): int {
        return (isset($d[$k]) && is_numeric($d[$k])) ? (int)$d[$k] : 0;
    };
    return [
        'infected'           => true,
        'infections'         => $infections,
        'latest'             => $latest,
        'corporate_services' => $num('total_corporate_services'),
        'user_services'      => $num('total_user_services'),
    ];
}

// ----------------------------------------------------------- xposedornot --

/**
 * Pull the breach list out of an XposedOrNot breach-analytics response.
 * Returns [array $breaches, int $latestYear]; an empty list means the address
 * is in no breach this API knows about.
 *
 * Pure and separately callable so tools/check-xon-parse.php can exercise it
 * against fixtures. That matters more here than for the other services: this
 * API has THREE response shapes in the wild (the current ExposedBreaches one,
 * an older BreachMetrics one, and a bare name list), the differences are
 * invisible until one is hit, and every live call to find out costs one of
 * 100 requests a day that the mailbox sweep also needs.
 *
 * Everything in $d is provider-controlled and is treated as such: types are
 * checked before use, strings are length-bounded, and the list itself is
 * capped so a hostile or broken response cannot turn into an unbounded row
 * count on the IOC page.
 */
function xon_parse_breaches($d): array {
    // An 'Error' member or an explicit "Not found" status is this API's way of
    // saying the address is in no breach it knows about -- a real negative
    // answer, not a failure. Transport and rate-limit failures never reach
    // here; they are handled by the caller before this is called.
    if (!is_array($d)
        || (isset($d['Error']) && $d['Error'] !== '')
        || (isset($d['status']) && $d['status'] === 'Not found')) {
        return [[], 0];
    }

    $breaches = [];
    $latest   = 0;

    // Current API shape first, older one second, then the plain check-email
    // style.
    $details = $d['ExposedBreaches']['breaches_details'] ?? null;
    if (!is_array($details) || !$details) {
        $details = $d['BreachMetrics']['breaches_details'] ?? null;
    }

    if (is_array($details) && $details) {
        foreach ($details as $b) {
            if (!is_array($b)) continue;
            $name = '';
            foreach (['breach', 'name'] as $k) {
                if (isset($b[$k]) && is_string($b[$k]) && $b[$k] !== '') { $name = $b[$k]; break; }
            }
            if ($name === '') continue;
            $year = 0;
            foreach (['xposed_date', 'year', 'YearOfBreach'] as $k) {
                if (isset($b[$k]) && is_scalar($b[$k]) && (int)$b[$k] > 0) {
                    $year = (int)$b[$k];
                    break;
                }
            }
            $classes = '';
            foreach (['xposed_data', 'details', 'DataClasses'] as $k) {
                if (isset($b[$k]) && is_string($b[$k]) && $b[$k] !== '') { $classes = $b[$k]; break; }
            }
            // Field names are 'name'/'year'/'data' because that is the shape
            // check-breaches.py's cache file already has and the dashboard's
            // breach_names() already reads. This payload feeds BOTH, so it
            // uses their vocabulary rather than a tidier one nothing speaks.
            $breaches[] = [
                'name' => mb_substr($name, 0, 80),
                'year' => $year,
                'data' => mb_substr($classes, 0, 200),
            ];
            if ($year > $latest) $latest = $year;
            if (count($breaches) >= 60) break;
        }
        return [$breaches, $latest];
    }

    // {"breaches":[["Adobe","LinkedIn"]]} -- names only, no dates.
    $raw   = $d['breaches'] ?? [];
    $names = (is_array($raw) && isset($raw[0]) && is_array($raw[0])) ? $raw[0]
           : (is_array($raw) ? $raw : []);
    foreach ($names as $n) {
        if (!is_string($n) || $n === '') continue;
        $breaches[] = ['name' => mb_substr($n, 0, 80), 'year' => 0, 'data' => ''];
        if (count($breaches) >= 60) break;
    }
    return [$breaches, $latest];
}

// ------------------------------------------------------------------- DNS --
//
// A minimal stub resolver rather than dns_get_record(), for two reasons:
// dns_get_record() has no timeout knob (a wedged zone would blow past the
// 6s quarantine-surface budget), and it cannot tell NXDOMAIN from SERVFAIL,
// which is the difference between "not listed" and "this zone is broken".

const DNS_RCODE_NOERROR  = 0;
const DNS_RCODE_NXDOMAIN = 3;

function dns_servers(): array {
    // Test seam: lets the timeout path be exercised against a black hole
    // (QA_DNS_SERVERS=192.0.2.1). sudo runs with env_reset and this name is
    // not in env_keep, so the web user cannot reach it -- see
    // install/sudoers.example.
    $override = getenv('QA_DNS_SERVERS');
    if (is_string($override) && $override !== '') {
        $list = array_values(array_filter(array_map('trim', explode(',', $override)), 'strlen'));
        if ($list) return array_slice($list, 0, 3);
    }
    $out = [];
    $txt = @file_get_contents('/etc/resolv.conf');
    if (is_string($txt)) {
        foreach (explode("\n", $txt) as $line) {
            if (preg_match('/^\s*nameserver\s+(\S+)/', $line, $m)) $out[] = $m[1];
        }
    }
    if (!$out) $out[] = '127.0.0.1';
    return array_slice($out, 0, 3);
}

function dns_encode_name(string $name): ?string {
    $out = '';
    foreach (explode('.', rtrim($name, '.')) as $label) {
        if ($label === '') continue;
        $len = strlen($label);
        if ($len > 63) return null;
        $out .= chr($len) . $label;
    }
    if (strlen($out) > 254) return null;
    return $out . "\0";
}

function dns_skip_name(string $buf, int &$off): bool {
    $n = strlen($buf);
    while (true) {
        if ($off >= $n) return false;
        $len = ord($buf[$off]);
        if ($len === 0) { $off++; return true; }
        if (($len & 0xC0) === 0xC0) { $off += 2; return $off <= $n; }
        $off += 1 + $len;
        if ($off > $n) return false;
    }
}

/** ['rcode'=>int, 'records'=>string[], 'truncated'=>bool] or null on a malformed packet. */
function dns_parse(string $buf, int $id, int $qtype): ?array {
    if (strlen($buf) < 12) return null;
    $hdr = unpack('nid/nflags/nqd/nan/nns/nar', substr($buf, 0, 12));
    if ($hdr['id'] !== $id) return null;
    $rcode = $hdr['flags'] & 0x0F;
    $tc    = ($hdr['flags'] & 0x0200) !== 0;
    $off   = 12;
    for ($i = 0; $i < $hdr['qd']; $i++) {
        if (!dns_skip_name($buf, $off)) return null;
        $off += 4;
    }
    $records = [];
    for ($i = 0; $i < $hdr['an']; $i++) {
        if (!dns_skip_name($buf, $off)) return null;
        if ($off + 10 > strlen($buf)) return null;
        $rr = unpack('ntype/nclass/Nttl/nlen', substr($buf, $off, 10));
        $off += 10;
        if ($off + $rr['len'] > strlen($buf)) return null;
        $rdata = substr($buf, $off, $rr['len']);
        $off  += $rr['len'];
        if ($rr['type'] !== $qtype) continue;          // CNAMEs in the chain, etc.
        if ($qtype === 1 && strlen($rdata) === 4) {
            $records[] = inet_ntop($rdata);
        } elseif ($qtype === 16) {
            // One TXT RR is a sequence of length-prefixed character strings.
            $s = ''; $p = 0;
            while ($p < strlen($rdata)) {
                $l = ord($rdata[$p]); $p++;
                $s .= substr($rdata, $p, $l);
                $p += $l;
            }
            $records[] = $s;
        }
    }
    return ['rcode' => $rcode, 'records' => $records, 'truncated' => $tc];
}

function dns_exchange_tcp(string $host, string $pkt, int $id, int $qtype, float $remain): ?array {
    $errno = 0; $errstr = '';
    $sock = @stream_socket_client("tcp://$host:53", $errno, $errstr, $remain);
    if (!$sock) return null;
    stream_set_timeout($sock, (int)$remain, (int)(fmod($remain, 1) * 1e6));
    @fwrite($sock, pack('n', strlen($pkt)) . $pkt);
    $lenb = @fread($sock, 2);
    if (!is_string($lenb) || strlen($lenb) < 2) { fclose($sock); return null; }
    $need = unpack('n', $lenb)[1];
    $buf  = '';
    while (strlen($buf) < $need) {
        $chunk = @fread($sock, $need - strlen($buf));
        if ($chunk === false || $chunk === '') break;
        $buf .= $chunk;
    }
    fclose($sock);
    if (strlen($buf) < $need) return null;
    return dns_parse($buf, $id, $qtype);
}

/**
 * ['rcode'=>int, 'records'=>string[]] on an answer, or ['error'=>string].
 * $timeout is the WHOLE budget across every configured nameserver.
 */
function dns_lookup(string $name, int $qtype, int $timeout): array {
    $qname = dns_encode_name($name);
    if ($qname === null) return ['error' => 'bad query name'];
    $id   = random_int(0, 0xFFFF);
    $pkt  = pack('nnnnnn', $id, 0x0100, 1, 0, 0, 0) . $qname . pack('nn', $qtype, 1);
    $deadline = microtime(true) + $timeout;

    foreach (dns_servers() as $ns) {
        $remain = $deadline - microtime(true);
        if ($remain <= 0) break;
        $host  = strpos($ns, ':') !== false ? "[$ns]" : $ns;
        $errno = 0; $errstr = '';
        $sock  = @stream_socket_client("udp://$host:53", $errno, $errstr, min($remain, 2.0));
        if (!$sock) continue;
        if (@fwrite($sock, $pkt) === false) { fclose($sock); continue; }
        $r = [$sock]; $w = null; $e = null;
        $remain = max(0.0, $deadline - microtime(true));
        $sel = @stream_select($r, $w, $e, (int)$remain, (int)(fmod($remain, 1) * 1e6));
        if ($sel > 0) {
            $buf = @fread($sock, 65535);
            fclose($sock);
            if (is_string($buf)) {
                $ans = dns_parse($buf, $id, $qtype);
                if ($ans !== null) {
                    if (!empty($ans['truncated'])) {
                        $tcp = dns_exchange_tcp($host, $pkt, $id, $qtype,
                            max(0.5, $deadline - microtime(true)));
                        if ($tcp !== null) return $tcp;
                    }
                    return $ans;
                }
            }
            continue;
        }
        fclose($sock);
    }
    return ['error' => 'timeout'];
}

/**
 * The shared DNSBL body: reverse the IPv4 octets under $zone (or append the
 * zone to a domain), and turn the A records into a verdict via $classify.
 * $classify(array $a_records) returns [verdict, detail, txt_mode], where
 * txt_mode is 'none' (detail stands alone), 'append' (detail — TXT) or
 * 'replace' (the TXT record IS the detail, falling back to detail).
 */
function dnsbl_lookup(string $service, string $type, string $value, string $zone,
                      int $digTimeout, callable $classify): void {
    if ($type === 'ip') {
        if (strpos($value, ':') !== false) emit_error("$service: ipv6 not supported");
        $o = explode('.', $value);
        $query = "$o[3].$o[2].$o[1].$o[0].$zone";
    } else {
        $query = "$value.$zone";
    }

    $ans = dns_lookup($query, 1, $digTimeout);
    if (isset($ans['error'])) {
        emit_error("$service: dns lookup failed (" . $ans['error'] . ")");
    }
    if ($ans['rcode'] !== DNS_RCODE_NOERROR && $ans['rcode'] !== DNS_RCODE_NXDOMAIN) {
        emit_error("$service: dns lookup failed (rcode " . $ans['rcode'] . ")");
    }

    $a = $ans['records'];
    if (!$a) {
        emit_result('clean', 'not listed', ['query' => $query, 'a_record' => '']);
    }

    [$verdict, $detail, $txtMode] = $classify($a);
    if ($txtMode !== 'none') {
        $txtAns = dns_lookup($query, 16, $digTimeout);
        $txt = '';
        if (!isset($txtAns['error']) && $txtAns['records']) {
            $txt = substr(str_replace('"', '', implode("\n", $txtAns['records'])), 0, 200);
        }
        if ($txt !== '') $detail = $txtMode === 'replace' ? $txt : "$detail — $txt";
    }
    emit_result($verdict, $detail, ['query' => $query, 'a_record' => implode("\n", $a)]);
}

// Include-without-dispatch seam for tools/check-xon-parse.php. Everything
// above this line is pure functions; everything below reads argv and performs
// the lookup. A test defines this constant, requires the file, and calls the
// parsers directly.
//
// Deliberately a CONSTANT and not an environment variable: this file runs as
// root via sudo, and anything env-driven here would be one env_keep away from
// letting the web user steer a privileged script.
if (defined('QA_IOC_LOOKUP_LIB_ONLY')) return;

// ------------------------------------------------------------ arguments ---

$argvv = $argv ?? [];
array_shift($argvv);
if (count($argvv) < 3 || count($argvv) > 5) {
    emit_error('usage: qa-ioc-lookup.php <service> <type> <value> [timeout_seconds] [caller]');
}
[$service, $type, $value] = $argvv;
$timeoutOverride = $argvv[3] ?? '';

// Which budget class this request belongs to, for services that have a
// budget (today: xposedornot). 'interactive' is the default because that is
// what every caller through sudo is -- an operator waiting on a page. Only
// check-breaches.py's nightly sweep passes 'batch', which is the class that
// must leave the interactive reserve alone.
//
// Nothing is granted by naming a class: 'batch' can only ever be REFUSED
// earlier than 'interactive', so the web user passing it through the sudo
// wildcard restricts itself and gains nothing.
$callerClass = $argvv[4] ?? 'interactive';
if ($callerClass !== 'batch' && $callerClass !== 'interactive') {
    emit_error('invalid caller: must be batch or interactive');
}

// An optional per-surface timeout (see IOC_LOOKUP_SERVICE_TIMEOUTS in
// src/ioc_lookup.php). Rejected rather than ignored when malformed: a caller
// that asked for a 6s budget must never silently get a 35s one, because the
// whole point is bounding a page that has a 60s proxy ceiling. 60 is that
// ceiling, so a larger value could only ever be cut off by the proxy anyway.
if ($timeoutOverride !== '') {
    if (preg_match('/^[0-9]+$/', $timeoutOverride) !== 1) {
        emit_error('invalid timeout: must be digits only');
    }
    $t = (int)$timeoutOverride;
    if ($t < 1 || $t > 60) emit_error('invalid timeout: must be between 1 and 60 seconds');
}

$CUSTOM_ZONE = null;
switch ($service) {
    case 'virustotal': $supported = ['ip', 'domain', 'url', 'hash']; break;
    case 'urlhaus':    $supported = ['domain', 'url', 'hash'];       break;
    case 'otx':        $supported = ['ip', 'domain', 'url', 'hash']; break;
    case 'hrbl':       $supported = ['ip', 'domain'];                break;
    case 'mailspike':  $supported = ['ip'];                          break;
    case 'urlvet':     $supported = ['url', 'domain'];               break;
    case 'yaraify':    $supported = ['hash'];                        break;
    case 'threatfox':  $supported = ['ip', 'domain', 'url', 'hash']; break;
    case 'xposedornot': $supported = ['email'];                      break;
    case 'leakcheck':   $supported = ['email'];                      break;
    case 'hudsonrock':  $supported = ['email'];                      break;
    default:
        // Operator-defined DNS-zone service (qa-ioclookup-config.sh
        // add-custom). The row is root-written and slug/zone-validated at
        // add time; re-validated here anyway because this file must never
        // trust its inputs.
        $row = null;
        $fh  = @fopen(CUSTOM_CONF, 'r');
        if ($fh) {
            while (($line = fgets($fh)) !== false) {
                if (strncmp($line, $service . '|', strlen($service) + 1) === 0) {
                    $row = rtrim($line, "\r\n");
                    break;
                }
            }
            fclose($fh);
        }
        if ($row === null) emit_error("unknown service: $service");
        $f = explode('|', $row);
        $CUSTOM_ZONE   = $f[1] ?? '';
        $customTypes   = $f[2] ?? '';
        if (preg_match('/^[a-z0-9]([a-z0-9._-]{0,251}[a-z0-9])?$/', $CUSTOM_ZONE) !== 1) {
            emit_error("bad zone for $service");
        }
        $supported = array_values(array_filter(explode(',', $customTypes), 'strlen'));
        break;
}
if (!in_array($type, $supported, true)) {
    emit_error("service $service does not support type $type");
}

switch ($type) {
    case 'ip':
        if (preg_match('/^[0-9]{1,3}(\.[0-9]{1,3}){3}$/', $value) === 1) break;
        if (strpos($value, ':') !== false && preg_match('/^[0-9a-fA-F:]+$/', $value) === 1) break;
        emit_error('invalid ip');
    case 'domain':
        if (preg_match('/^[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?(\.[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?)+$/', $value) !== 1) {
            emit_error('invalid domain');
        }
        break;
    case 'url':
        if (preg_match('#^https?://[^[:space:]]+$#', $value) !== 1) emit_error('invalid url');
        break;
    case 'hash':
        if (preg_match('/^[A-Fa-f0-9]{32}$/', $value) !== 1
            && preg_match('/^[A-Fa-f0-9]{40}$/', $value) !== 1
            && preg_match('/^[A-Fa-f0-9]{64}$/', $value) !== 1) {
            emit_error('invalid hash');
        }
        break;
    case 'email':
        if (filter_var($value, FILTER_VALIDATE_EMAIL) === false) emit_error('invalid email');
        // Normalise the DOMAIN only. Domains are case-insensitive by
        // definition, so lowercasing one cannot change which mailbox is meant
        // and stops "User@Example.COM" and "user@example.com" being asked
        // about separately -- two requests out of a budget of 100.
        //
        // The local part is left EXACTLY as given. It is case-sensitive per
        // RFC 5321, and the tempting further "normalisations" are all wrong
        // in the general case: stripping dots or +tags is a Gmail-specific
        // convention, and applying it here would silently ask about a
        // different person's mailbox than the operator typed.
        $at = strrpos($value, '@');
        if ($at === false) emit_error('invalid email');
        $value = substr($value, 0, $at) . '@' . strtolower(substr($value, $at + 1));
        if (strlen($value) > 254) emit_error('invalid email');
        break;
}

// Applies to whichever service the caller selected: TIMEOUT covers the API
// services, URLVET_TIMEOUT covers urlvet, and DIG_TIMEOUT covers DNS zones.
if ($timeoutOverride !== '') {
    $TIMEOUT = $URLVET_TIMEOUT = $DIG_TIMEOUT = (int)$timeoutOverride;
}

// -------------------------------------------------------------- services --

if ($service === 'virustotal') {
    $key = read_key(VT_KEY_FILE);
    switch ($type) {
        case 'ip':     $endpoint = "ip_addresses/$value"; break;
        case 'domain': $endpoint = "domains/$value";      break;
        case 'hash':   $endpoint = "files/$value";        break;
        default:
            $id = rtrim(strtr(base64_encode($value), '/+', '_-'), '=');
            $endpoint = "urls/$id";
    }
    $body = http_body("https://www.virustotal.com/api/v3/$endpoint",
        ["x-apikey: $key"], null, $TIMEOUT);
    if ($body === null) emit_error('no response from virustotal');
    $d = decode_or_die('virustotal', $body);

    $stats = (is_array($d) && isset($d['data']['attributes']['last_analysis_stats'])
              && is_array($d['data']['attributes']['last_analysis_stats']))
             ? $d['data']['attributes']['last_analysis_stats'] : null;
    if ($stats === null) {
        $msg = (is_array($d) && isset($d['error']['message']) && is_string($d['error']['message']))
               ? $d['error']['message'] : 'not found';
        emit_error("virustotal: $msg");
    }

    $malicious  = (int)($stats['malicious']  ?? 0);
    $suspicious = (int)($stats['suspicious'] ?? 0);
    $harmless   = (int)($stats['harmless']   ?? 0);
    $undetected = (int)($stats['undetected'] ?? 0);
    $total      = $malicious + $suspicious + $harmless + $undetected;

    if      ($malicious  > 0) $verdict = 'malicious';
    elseif  ($suspicious > 0) $verdict = 'suspicious';
    elseif  ($total      > 0) $verdict = 'clean';
    else                      $verdict = 'unknown';

    emit_result($verdict, "$malicious/$total engines flagged", $d);
}

if ($service === 'urlhaus') {
    $key = read_key(ABUSE_KEY_FILE);
    switch ($type) {
        case 'domain': $url = 'https://urlhaus-api.abuse.ch/v1/host/';    $field = 'host'; break;
        case 'url':    $url = 'https://urlhaus-api.abuse.ch/v1/url/';     $field = 'url';  break;
        default:       $url = 'https://urlhaus-api.abuse.ch/v1/payload/'; $field = 'sha256_hash';
    }
    $body = http_body($url, ["Auth-Key: $key"],
        http_build_query([$field => $value]), $TIMEOUT);
    if ($body === null) emit_error('no response from urlhaus');
    $d = decode_or_die('urlhaus', $body);

    $status = (is_array($d) && isset($d['query_status']) && is_string($d['query_status']))
              ? $d['query_status'] : 'error';
    if ($status === 'ok') {
        $sub = $d['url_status'] ?? $d['signature'] ?? 'listed';
        if (!is_string($sub) || $sub === '') $sub = 'listed';
        emit_result('malicious', "listed ($sub)", $d);
    } elseif ($status === 'no_results') {
        emit_result('clean', 'not listed', $d);
    }
    emit_error("urlhaus: $status");
}

if ($service === 'yaraify') {
    // abuse.ch YARAify: which YARA rules match a known sample. Shares the
    // abuse.ch Auth-Key with urlhaus -- one credential, two services.
    //
    // Hash only, by design. YARAify also exposes a file-SCANNING endpoint,
    // which is deliberately not used here: its own documentation says
    // submitted files are shared by default, and uploading customers' mail
    // attachments to a public malware-sharing platform is not something a
    // mail server should do on an operator's behalf.
    $key  = read_key(ABUSE_KEY_FILE);
    $body = http_body('https://yaraify-api.abuse.ch/api/v1/',
        ["Auth-Key: $key", 'Content-Type: application/json'],
        json_encode(['query' => 'lookup_hash', 'search_term' => $value]), $TIMEOUT);
    if ($body === null) emit_error('no response from yaraify');
    $d = decode_or_die('yaraify', $body);

    $status = (is_array($d) && isset($d['query_status']) && is_string($d['query_status']))
              ? $d['query_status'] : 'error';
    if ($status === 'ok') {
        // Count the matching YARA rules across every scan task, and name the
        // first few: "which rules matched" is far more actionable than a bare
        // verdict, and it is what an analyst wants next.
        $names = [];
        $tasks = $d['data']['tasks'] ?? null;
        if (is_array($tasks)) {
            foreach ($tasks as $task) {
                $res = is_array($task) ? ($task['static_results'] ?? null) : null;
                if (!is_array($res)) continue;
                foreach ($res as $r) {
                    if (is_array($r) && isset($r['rule_name']) && is_string($r['rule_name'])) {
                        $names[] = $r['rule_name'];
                    }
                }
            }
        }
        $hits = count($names);
        if ($hits > 0) {
            $uniq = array_values(array_unique($names));
            sort($uniq, SORT_STRING);               // jq's unique sorts, too
            emit_result('malicious',
                "$hits YARA rule(s): " . implode(', ', array_slice($uniq, 0, 3)), $d);
        }
        // Known to YARAify but nothing matched: seen, not condemned.
        emit_result('unknown', 'known sample, no YARA rule matched', $d);
    } elseif ($status === 'no_results') {
        emit_result('clean', 'not known to YARAify', $d);
    }
    emit_error("yaraify: $status");
}

if ($service === 'threatfox') {
    // abuse.ch ThreatFox: shares the same Auth-Key as urlhaus/yaraify.
    // Unlike the abuse_c2_block ipset (load-abuse-c2.sh), which only pulls
    // the "recent" IP:port export, search_ioc queries ThreatFox's FULL
    // indicator database live -- ip/domain/url/hash all included -- so this
    // can hit on an indicator the ipset feed never saw.
    //
    // ThreatFox indexes IP IOCs as "ip:port" but its own search matches a
    // bare IP against those entries (confirmed empirically 2026-08-21
    // against a live abuse_c2_block entry) -- no port-stripping needed here.
    $key  = read_key(ABUSE_KEY_FILE);
    $body = http_body('https://threatfox-api.abuse.ch/api/v1/',
        ["Auth-Key: $key", 'Content-Type: application/json'],
        json_encode(['query' => 'search_ioc', 'search_term' => $value]), $TIMEOUT);
    if ($body === null) emit_error('no response from threatfox');
    $d = decode_or_die('threatfox', $body);

    $status = (is_array($d) && isset($d['query_status']) && is_string($d['query_status']))
              ? $d['query_status'] : 'error';
    if ($status === 'ok') {
        $rows = (is_array($d) && isset($d['data']) && is_array($d['data'])) ? $d['data'] : null;
        if ($rows === null) emit_error('threatfox: unexpected response');
        // Multiple IOCs can share one indicator (re-used C&C infra across
        // campaigns) -- take the highest-confidence submission, same
        // "worst-known-verdict wins" idea as VT's malicious-count check.
        // Ties go to the LAST row, matching jq's max_by.
        $top = null; $best = null;
        foreach ($rows as $r) {
            if (!is_array($r)) continue;
            $c = isset($r['confidence_level']) && is_numeric($r['confidence_level'])
                 ? (int)$r['confidence_level'] : 0;
            if ($best === null || $c >= $best) { $best = $c; $top = $r; }
        }
        $conf    = $best ?? 0;
        $malware = 'unknown malware';
        $threat  = 'ioc';
        if ($top !== null) {
            foreach (['malware_printable', 'malware'] as $k) {
                if (isset($top[$k]) && is_string($top[$k]) && $top[$k] !== '') {
                    $malware = $top[$k];
                    break;
                }
            }
            if (isset($top['threat_type']) && is_string($top['threat_type']) && $top['threat_type'] !== '') {
                $threat = $top['threat_type'];
            }
        }
        // 50 matches TF_MIN_CONF in load-abuse-c2.sh (the ipset feed's own
        // trust floor) -- a lookup result below that line is "known to
        // ThreatFox" but not confident enough to call malicious outright.
        emit_result($conf >= 50 ? 'malicious' : 'suspicious',
            "$malware ($threat, confidence $conf)", $d);
    } elseif ($status === 'no_result') {
        emit_result('clean', 'not listed', $d);
    }
    $msg = (is_array($d) && isset($d['data']) && is_string($d['data'])) ? $d['data'] : $status;
    emit_error("threatfox: $msg");
}

if ($service === 'otx') {
    $key = read_key(OTX_KEY_FILE);
    switch ($type) {
        case 'ip':     $otxType = strpos($value, ':') !== false ? 'IPv6' : 'IPv4'; break;
        case 'domain': $otxType = 'domain'; break;
        case 'url':    $otxType = 'url'; $value = rawurlencode($value); break;
        default:       $otxType = 'file';
    }
    $body = http_body("https://otx.alienvault.com/api/v1/indicators/$otxType/$value/general",
        ["X-OTX-API-KEY: $key"], null, $TIMEOUT);
    if ($body === null) emit_error('no response from otx');
    $d = decode_or_die('otx', $body);

    $count = (is_array($d) && isset($d['pulse_info']['count']) && is_numeric($d['pulse_info']['count']))
             ? (int)$d['pulse_info']['count'] : null;
    if ($count === null) {
        $msg = 'not found';
        foreach (['detail', 'error'] as $k) {
            if (is_array($d) && isset($d[$k]) && is_string($d[$k]) && $d[$k] !== '') {
                $msg = $d[$k];
                break;
            }
        }
        emit_error("otx: $msg");
    }
    if      ($count >= 3) $verdict = 'malicious';
    elseif  ($count >= 1) $verdict = 'suspicious';
    else                  $verdict = 'clean';
    emit_result($verdict,
        $count > 0 ? "referenced in $count OTX pulses" : 'not referenced in any OTX pulses',
        $d);
}

if ($CUSTOM_ZONE !== null) {
    dnsbl_lookup($service, $type, $value, $CUSTOM_ZONE, $DIG_TIMEOUT,
        function (array $a): array {
            foreach ($a as $rec) {
                if (strncmp($rec, '127.0.0.', 8) === 0) {
                    return ['malicious', 'listed (' . implode(' ', $a) . ')', 'append'];
                }
            }
            return ['unknown', 'unexpected response: ' . implode(' ', $a), 'none'];
        });
}

if ($service === 'hrbl') {
    $zone = $type === 'ip' ? 'bl.hrbl.hu' : 'uribl.hrbl.hu';
    dnsbl_lookup('hrbl', $type, $value, $zone, $DIG_TIMEOUT,
        function (array $a): array {
            if (in_array('127.0.0.2', $a, true)) return ['malicious', 'listed on HRBL', 'replace'];
            return ['unknown', 'unexpected response: ' . implode("\n", $a), 'none'];
        });
}

if ($service === 'mailspike') {
    // rep.mailspike.net encodes a reputation LEVEL in the last octet, from
    // L5 (worst) through H5 (best); anything else is not a rating we know.
    $levels = [
        '127.0.0.10' => ['malicious',  'L5 (worst possible reputation)'],
        '127.0.0.11' => ['malicious',  'L4 (very bad reputation)'],
        '127.0.0.12' => ['malicious',  'L3 (bad reputation)'],
        '127.0.0.13' => ['suspicious', 'L2 (suspicious behavior)'],
        '127.0.0.14' => ['suspicious', 'L1 (neutral, probably spam)'],
        '127.0.0.15' => ['unknown',    'LHO (neutral)'],
        '127.0.0.16' => ['unknown',    'H1 (neutral, probably legitimate)'],
        '127.0.0.17' => ['clean',      'H2 (possible legitimate sender)'],
        '127.0.0.18' => ['clean',      'H3 (good reputation)'],
        '127.0.0.19' => ['clean',      'H4 (very good reputation)'],
        '127.0.0.20' => ['clean',      'H5 (excellent reputation)'],
    ];
    dnsbl_lookup('mailspike', $type, $value, 'rep.mailspike.net', $DIG_TIMEOUT,
        function (array $a) use ($levels): array {
            foreach ($levels as $ip => $lv) {
                if (in_array($ip, $a, true)) return [$lv[0], $lv[1], 'none'];
            }
            return ['unknown', 'unexpected response: ' . implode("\n", $a), 'none'];
        });
}

if ($service === 'urlvet') {
    $body = http_body('https://api.url.vet/api/v1/analyze?url=' . rawurlencode($value),
        [], null, $URLVET_TIMEOUT);
    if ($body === null) {
        emit_error("urlvet: no response within {$URLVET_TIMEOUT}s "
                 . '(the host may not resolve -- url.vet needs ~31s for those)');
    }
    $d = decode_or_die('urlvet', $body);

    $raw = (is_array($d) && isset($d['result']['verdict']) && is_string($d['result']['verdict']))
           ? $d['result']['verdict'] : '';
    if ($raw === '') {
        $msg = (is_array($d) && isset($d['error']) && is_string($d['error']) && $d['error'] !== '')
               ? $d['error']
               : 'unexpected response: ' . substr(str_replace(["\r", "\n"], '', $body), 0, 120);
        emit_error("urlvet: $msg");
    }
    $score      = isset($d['result']['final_score']) && is_numeric($d['result']['final_score'])
                  ? num_str($d['result']['final_score']) : '0';
    $incomplete = !empty($d['incomplete']);

    switch ($raw) {
        case 'Risky':      $verdict = 'malicious';  break;
        case 'Suspicious': $verdict = 'suspicious'; break;
        case 'Safe':       $verdict = $incomplete ? 'unknown' : 'clean'; break;
        default:           $verdict = 'unknown';
    }
    $bad = $d['result']['reasons']['bad_reasons'] ?? null;
    $detail = (is_array($bad) && $bad) ? implode('; ', array_map('strval', $bad))
                                       : "$raw ($score/100)";
    if ($incomplete) $detail .= ' [partial analysis]';
    emit_result($verdict, $detail, $d);
}

if ($service === 'xposedornot') {
    // Email breach exposure. The SAME provider and the SAME free-tier budget
    // that check-breaches.py spends on its nightly sweep of every mailbox --
    // which is the entire reason the budget had to move out of that script
    // and onto disk. See qa-quota-lib.php.
    //
    // An 'interactive' caller may spend into the reserve the 'batch' sweep is
    // not allowed to touch, because an operator clicking a button and getting
    // nothing is a worse outcome than tonight's sweep covering a few
    // addresses fewer. See $callerClass at the argument parsing above.
    quota_gate('xposedornot', $callerClass);

    $body = http_body('https://api.xposedornot.com/v1/breach-analytics?email='
                      . rawurlencode($value),
        ['Accept: application/json'], null, $TIMEOUT);
    if ($body === null) emit_error('no response from xposedornot');
    $d = decode_or_die('xposedornot', $body);

    // A 429 arrives as a body, not a transport failure. Our own ledger should
    // have prevented it -- if it did not, the local budget disagrees with the
    // provider's, so say exactly that rather than reporting a clean address.
    if (is_array($d) && isset($d['Error']) && is_string($d['Error'])
        && stripos($d['Error'], 'rate') !== false) {
        emit_error('xposedornot: provider rate-limited us despite the local budget'
                 . ' — the configured limit is too high');
    }

    [$breaches, $latest] = xon_parse_breaches($d);

    // Only the fields the console actually renders are kept. The full
    // breach-analytics blob carries risk scores and per-breach descriptive
    // text we do not display, and storing a provider's whole answer about a
    // real person's mailbox because it happened to be in the response is
    // exactly the data we should not be accumulating.
    $raw = [
        'query'         => $value,
        'exposed'       => (bool)$breaches,
        'breaches'      => $breaches,
        'latest_breach' => $latest ?: '',
    ];

    if (!$breaches) {
        emit_result('clean', 'no known breach', $raw);
    }

    // VERDICT SEMANTICS, and why this is 'suspicious' and not 'malicious'.
    // Appearing in a breach says the ACCOUNT was exposed in someone else's
    // incident. It says nothing about whether the address is hostile, and
    // calling it malicious would be inventing a finding the provider never
    // reported. 'suspicious' carries the right operational meaning for an
    // address in the IOC store -- a plausibly credential-stuffed sender worth
    // a second look -- without overstating it.
    //
    // The matching half of this decision is in src/ioc_lookup.php: the
    // service is weighted 0, so this verdict is displayed but never moves the
    // maliciousness confidence score. Changing one without the other makes
    // the score dishonest.
    $names  = array_map(fn(array $b) => $b['name'], $breaches);
    $detail = count($breaches) . ' breach' . (count($breaches) === 1 ? '' : 'es')
            . ($latest ? " (latest $latest)" : '') . ': ' . implode(', ', $names);
    emit_result('suspicious', $detail, $raw);
}

if ($service === 'leakcheck') {
    quota_gate('leakcheck', $callerClass);

    $body = http_body('https://leakcheck.io/api/public?check=' . rawurlencode($value),
        ['Accept: application/json'], null, $TIMEOUT);
    if ($body === null) emit_error('no response from leakcheck');
    $d = decode_or_die('leakcheck', $body);

    // "Not found" is this API's negative answer and arrives as success:false.
    // Any OTHER error string is a genuine failure and must NOT be read as a
    // clean address -- that distinction is the whole reason this branch does
    // not simply treat !success as "no breaches".
    if (is_array($d) && empty($d['success'])) {
        $err = (isset($d['error']) && is_string($d['error'])) ? $d['error'] : '';
        if ($err !== '' && stripos($err, 'not found') === false) {
            emit_error('leakcheck: ' . mb_substr($err, 0, 120));
        }
    }

    [$breaches, $latest, $records, $classes] = leakcheck_parse($d);

    $raw = [
        'query'         => $value,
        'exposed'       => (bool)$breaches,
        'breaches'      => $breaches,
        'latest_breach' => $latest ?: '',
        // Named 'records', never 'found', so nothing downstream can mistake a
        // record count for a breach count.
        'records'       => $records,
        'data_classes'  => $classes,
        'stealer'       => null,
    ];

    if (!$breaches) emit_result('clean', 'no known breach', $raw);

    // 'suspicious' with weight 0, for the same reason as xposedornot: breach
    // exposure is a fact about the account, not evidence the address is
    // hostile. See IOC_CONFIDENCE_WEIGHTS in src/ioc_lookup.php.
    $names  = array_map(fn(array $b) => $b['name'], $breaches);
    $detail = count($breaches) . ' breach' . (count($breaches) === 1 ? '' : 'es')
            . ($latest ? " (latest $latest)" : '') . ': ' . implode(', ', $names);
    emit_result('suspicious', $detail, $raw);
}

if ($service === 'hudsonrock') {
    quota_gate('hudsonrock', $callerClass);

    $body = http_body('https://cavalier.hudsonrock.com/api/json/v2/osint-tools/'
                      . 'search-by-email?email=' . rawurlencode($value),
        ['Accept: application/json'], null, $TIMEOUT);
    if ($body === null) emit_error('no response from hudsonrock');
    $d = decode_or_die('hudsonrock', $body);

    // The negative answer is a message plus an EMPTY stealers list. A response
    // carrying neither is not an answer at all, and must not be read as clean.
    if (!is_array($d) || !array_key_exists('stealers', $d)) {
        emit_error('hudsonrock: unexpected response');
    }

    $stealer = hudsonrock_parse($d);
    $raw = [
        'query'         => $value,
        // This provider answers a DIFFERENT question from the breach ones, so
        // it never sets 'exposed' and never fills 'breaches'. An infostealer
        // infection is not breach-corpus membership, and merging the two would
        // make both numbers meaningless.
        'exposed'       => false,
        'breaches'      => [],
        'latest_breach' => '',
        'stealer'       => $stealer,
    ];

    if ($stealer === null) emit_result('clean', 'no infostealer record', $raw);

    $n      = count($stealer['infections']);
    $when   = $stealer['latest'] !== '' ? substr($stealer['latest'], 0, 10) : 'unknown date';
    $detail = $n . ' infostealer infection' . ($n === 1 ? '' : 's') . " (latest $when)";
    emit_result('suspicious', $detail, $raw);
}

emit_error("unknown service: $service");
