#!/usr/bin/php
<?php
/**
 * Nightly IOC expiry sweep for the Mail Security Operations Console.
 *
 * Marks every active indicator whose expires_at has passed as inactive
 * (soft-delete -- expired rows are kept for audit history, never deleted).
 * Runs as the apache user (the SQLite file's owner) -- no root, no sudo
 * helper needed, unlike the postfix admin scripts.
 *
 * Run from cron as apache:  0 3 * * *  apache  /usr/local/sbin/qa-ioc-expire.php
 * Dry run (counts, writes nothing):    /usr/local/sbin/qa-ioc-expire.php --dry-run
 */

$APP = '/var/www/html/quarantine-admin';
require $APP . '/src/bootstrap.php';

$dry = in_array('--dry-run', $argv ?? [], true);
$n   = ioc_expire_sweep($dry);

echo ($dry ? "[dry-run] would expire: " : "expired: ") . $n . "\n";
