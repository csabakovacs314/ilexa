#!/bin/bash
#
# GeoIP database refresh — feeds the sender-country flags on the Archívum
# page, the login-IP flags on Audit, archive-indexer.php's sender_cc column,
# and (city/asn tiers) login-anomaly scoring's impossible-travel distance and
# "usual network" signals (see plans/zany-napping-sunrise.md).
#
# Source: db-ip.com's Lite series — CC-BY, keyless, republished monthly.
# Chosen over the distro packages because EL's geolite2-country is a
# snapshot frozen at the 2019 MaxMind license change and Ubuntu ships no
# GeoLite2 mmdb at all: both families get the same fresh data this way.
#
# Files keep MaxMind's traditional names/paths because every consumer
# (helpers.php, archive-indexer.php) reads exactly those; db-ip uses the same
# mmdb format and the same lookup keys MaxMind's own equivalents use
# (verified live: country/iso_code, city/names/en, location/latitude,
# location/longitude, autonomous_system_number/organization).
#
# Each of the three tiers is refreshed independently and fail-closed: a
# candidate is downloaded to a temp file and must answer a known sanity
# lookup before it replaces anything; a failure on ONE tier leaves that
# tier's last-good database in place and does not block the other two. The
# marker file per tier records that WE manage that database — an operator's
# own file (no marker) is never overwritten. Exits 75 (EX_TEMPFAIL) if any
# tier failed, so a cron-alert wrapper can soft-fail; 0 only if all
# requested tiers succeeded (or were left alone as unmanaged).
set -uo pipefail

MARKER_DIR=/var/lib/ilexa
TIMEOUT=120
any_failed=0

log() { echo "qa-geoipdb-refresh: $*" >&2; }

refresh_tier() {  # slug db_path marker_name expected_value query_args...
    local slug="$1" db="$2" marker="$MARKER_DIR/$3" expected="$4"; shift 4
    local query=("$@")

    command -v mmdblookup >/dev/null 2>&1 || { log "mmdblookup not installed"; any_failed=1; return; }

    if [ -e "$db" ] && [ ! -e "$marker" ]; then
        log "$db exists but is not managed by this script (no $marker) — leaving it alone. Touch the marker to adopt it."
        return
    fi

    local tmp; tmp=$(mktemp) || { log "$slug: mktemp failed"; any_failed=1; return; }
    trap 'rm -f "$tmp" "$tmp.gz"' RETURN

    fetch_month() { # YYYY-MM
        curl -fsSL --max-time "$TIMEOUT" \
            "https://download.db-ip.com/free/dbip-$slug-$1.mmdb.gz" -o "$tmp.gz"
    }
    # The current month's file appears around the 1st; on a miss (or right
    # at the month boundary) fall back to the previous month.
    if ! fetch_month "$(date +%Y-%m)"; then
        if ! fetch_month "$(date -d '1 month ago' +%Y-%m 2>/dev/null || date -v-1m +%Y-%m)"; then
            log "$slug: download failed for current and previous month"; any_failed=1; return
        fi
    fi

    gunzip -c "$tmp.gz" > "$tmp" 2>/dev/null || { log "$slug: gunzip failed"; any_failed=1; return; }

    local got
    got=$(mmdblookup --file "$tmp" --ip 8.8.8.8 "${query[@]}" 2>/dev/null \
          | grep -oE '"[^"]*"|[0-9]+(\.[0-9]+)?' | head -1 | tr -d '"')
    if [ "$got" != "$expected" ]; then
        log "$slug: candidate database failed the sanity lookup (got '${got:-nothing}', expected '$expected' for 8.8.8.8)"
        any_failed=1; return
    fi

    install -d -m 755 /usr/share/GeoIP "$MARKER_DIR"
    install -m 644 "$tmp" "$db"
    : > "$marker"
    log "$slug: OK — $(stat -c %s "$db") bytes installed"
}

refresh_tier country-lite /usr/share/GeoIP/GeoLite2-Country.mmdb geoipdb.managed \
    US country iso_code

refresh_tier city-lite /usr/share/GeoIP/GeoLite2-City.mmdb geoipdb-city.managed \
    'Mountain View' city names en

refresh_tier asn-lite /usr/share/GeoIP/GeoLite2-ASN.mmdb geoipdb-asn.managed \
    15169 autonomous_system_number

[ "$any_failed" -eq 0 ] || exit 75
exit 0
