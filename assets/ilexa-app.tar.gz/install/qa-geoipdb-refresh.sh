#!/bin/bash
#
# GeoIP country database refresh — feeds the sender-country flags on the
# Archívum page, the login-IP flags on Audit, and archive-indexer.php's
# sender_cc column (all via mmdblookup on the file below).
#
# Source: db-ip.com "IP to Country Lite" — CC-BY, keyless, republished
# monthly. Chosen over the distro packages because EL's geolite2-country is
# a snapshot frozen at the 2019 MaxMind license change and Ubuntu ships no
# GeoLite2 mmdb at all: both families get the same fresh data this way.
#
# The file keeps MaxMind's traditional name/path because every consumer
# (helpers.php, archive-indexer.php) reads exactly that; db-ip uses the same
# mmdb format and the same country/iso_code lookup keys (verified live).
#
# Fail-closed: the candidate is downloaded to a temp file and must answer a
# known test lookup (8.8.8.8 -> US) before it replaces anything; any failure
# leaves the last-good database in place and exits 75 (EX_TEMPFAIL) so a
# cron-alert wrapper can soft-fail. The marker file records that WE manage
# the database — an operator's own file (no marker) is never overwritten.
set -uo pipefail

DB=/usr/share/GeoIP/GeoLite2-Country.mmdb
MARKER=/var/lib/ilexa/geoipdb.managed
TIMEOUT=120

die_soft() { echo "qa-geoipdb-refresh: $*" >&2; exit 75; }

command -v mmdblookup >/dev/null 2>&1 || die_soft "mmdblookup not installed"

if [ -e "$DB" ] && [ ! -e "$MARKER" ]; then
  echo "qa-geoipdb-refresh: $DB exists but is not managed by this script (no $MARKER) — leaving it alone. Touch the marker to adopt it." >&2
  exit 0
fi

tmp=$(mktemp) || die_soft "mktemp failed"
trap 'rm -f "$tmp" "$tmp.gz"' EXIT

fetch_month() { # YYYY-MM
  curl -fsSL --max-time "$TIMEOUT" \
    "https://download.db-ip.com/free/dbip-country-lite-$1.mmdb.gz" -o "$tmp.gz"
}
# The current month's file appears around the 1st; on a miss (or right at
# the month boundary) fall back to the previous month rather than failing.
fetch_month "$(date +%Y-%m)" || fetch_month "$(date -d '1 month ago' +%Y-%m 2>/dev/null || date -v-1m +%Y-%m)" \
  || die_soft "download failed for current and previous month"

gunzip -c "$tmp.gz" > "$tmp" 2>/dev/null || die_soft "gunzip failed"

cc=$(mmdblookup --file "$tmp" --ip 8.8.8.8 country iso_code 2>/dev/null | grep -oE '"[A-Z]{2}"' | tr -d '"')
[ "$cc" = "US" ] || die_soft "candidate database failed the sanity lookup (got '${cc:-nothing}' for 8.8.8.8)"

install -d -m 755 /usr/share/GeoIP /var/lib/ilexa
install -m 644 "$tmp" "$DB"
: > "$MARKER"
echo "qa-geoipdb-refresh: OK — $(stat -c %s "$DB") bytes installed"
