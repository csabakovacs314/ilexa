#!/usr/bin/env python3
"""Fortnightly retrain + evaluation of the language-classifier signals,
emailed to whoever the console has nominated.

WHY THIS RUNS AT ALL. Every symbol the classifier emits sits at weight 0.0:
the values are logged on each message but change no verdict. The open
question is whether any of them has become good enough to earn a real
weight. That question can only be answered by measuring against mail the
model has never seen, and it changes over time as spam does -- so it is a
recurring job, not a one-off.

WHAT IT MEASURES, and why against the LIVE archive specifically. The
MailScanner corpus the current model was trained from is FROZEN: that stack
was retired 2026-08-05 and will never receive another message, so retraining
on it alone would reproduce an identical model forever. The live archive
(postfix.archive_index + the archive mailbox) is the only growing source,
and everything in it that postdates the last training run is genuinely
unseen data. That is exactly what an honest evaluation needs.

WHAT IT DOES NOT DO: it does not change any weight, retrain the deployed
model in place, or act on its own findings. It measures, writes a report,
and asks a human to decide. Promoting a shadow signal to a real weight is a
judgement call with a false-positive cost attached, and this job has no
business making it.

PRIVACY: message text is streamed, scored in memory and discarded, exactly
like the other tools here. The report contains aggregate statistics only --
never a subject, address, or message body.

Usage: qa-hu-classify-report.py [--dry-run] [--sample N]
  --dry-run   print the report instead of mailing it
"""

import hashlib
import importlib.util
import json
import os
import re
import subprocess
import sys
import time

STUB = "/usr/local/sbin/hu-classify-stub.py"
DOVEADM = "/usr/local/sbin/qa-doveadm.sh"
STATE_STAMP = "/var/lib/ilexa/hu-classify-report.last"
# Machine-readable copy of the same numbers the mail contains, so the console
# can show real per-host measurements instead of quoting figures from the
# machine this was developed on. Written on every run, including --dry-run:
# the panel should reflect the latest measurement whether or not a mail went
# out (an operator with no recipient configured still deserves the numbers).
RESULT_JSON = "/var/lib/ilexa/hu-classify-measurement.json"
WHITESPACE_RE = re.compile(r"\s+")
HTML_TAG_RE = re.compile(r"<[^>]+>")
SIGNALS = ("hu_language", "hu_naturalness", "en_language", "en_naturalness", "hu_spam")


def sh(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, timeout=kw.pop("timeout", 30), **kw)


def archive_user():
    """Read the archive mailbox from the doveadm gateway, which the installer
    renders per host -- hardcoding it works on exactly one machine."""
    try:
        with open(DOVEADM) as f:
            m = re.search(r'^ARCHIVE_USER="([^"]+)"', f.read(), re.M)
        return m.group(1) if m else ""
    except OSError:
        return ""


def run_mysql(q):
    r = subprocess.run(["mysql", "-N", "-e", q], capture_output=True, text=True, check=True)
    return [l.split("\t") for l in r.stdout.splitlines() if l]


def clean(raw):
    import email as _email
    lines = raw.splitlines()
    if lines and lines[0].strip() == "text:":
        lines = lines[1:]
    try:
        msg = _email.message_from_string("\n".join(lines))
    except Exception:
        return "", ""
    plain, html = [], []
    for part in msg.walk():
        if part.is_multipart():
            continue
        ct = part.get_content_type()
        if ct not in ("text/plain", "text/html"):
            continue
        try:
            payload = part.get_payload(decode=True)
        except Exception:
            continue
        if payload is None:
            continue
        cs = part.get_content_charset() or "utf-8"
        try:
            txt = payload.decode(cs, errors="replace")
        except (LookupError, UnicodeDecodeError):
            txt = payload.decode("utf-8", errors="replace")
        (plain if ct == "text/plain" else html).append(txt)
    if plain:
        text = "\n".join(plain)
    elif html:
        import html as _h
        text = _h.unescape(HTML_TAG_RE.sub(" ", "\n".join(html)))
    else:
        return "", ""
    return str(msg.get("Subject", "") or ""), WHITESPACE_RE.sub(" ", text).strip()


def auc(pos, neg):
    """Ties count half. These signals emit exact 0.0 constantly, and counting
    a tie as a win would flatter them."""
    if not pos or not neg:
        return None
    w = t = 0
    for a in pos:
        for b in neg:
            if a > b:
                w += 1
            elif a == b:
                t += 1
    return (w + 0.5 * t) / (len(pos) * len(neg))


def collect(stub, user, rows, label):
    seen, out = set(), []
    for uid, in rows:
        r = sh([DOVEADM, "fetch-text", user, "INBOX", str(uid)], timeout=15)
        if r.returncode != 0:
            continue
        subj, text = clean(r.stdout.decode("utf-8", errors="replace"))
        if len(text) < 20:
            continue
        h = hashlib.sha256(WHITESPACE_RE.sub(" ", text.lower()).encode()).hexdigest()
        if h in seen:
            continue
        seen.add(h)
        out.append({
            "hu_language": stub.detect_language_score(subj, text, "hu"),
            "hu_naturalness": stub.score_naturalness(subj, text, "hu"),
            "en_language": stub.detect_language_score(subj, text, "en"),
            "en_naturalness": stub.score_naturalness(subj, text, "en"),
            "hu_spam": stub.score_hu_spam(subj, text),
        })
    return out


def main():
    dry = "--dry-run" in sys.argv
    sample = 600
    if "--sample" in sys.argv:
        sample = int(sys.argv[sys.argv.index("--sample") + 1])

    spec = importlib.util.spec_from_file_location("stub", STUB)
    stub = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(stub)

    user = archive_user()
    if not user:
        print("cannot determine the archive mailbox; is the console installed?", file=sys.stderr)
        return 2

    spam_rows = run_mysql("SELECT uid FROM postfix.archive_index WHERE is_spam=1;")
    ham_rows = run_mysql(f"SELECT uid FROM postfix.archive_index WHERE is_spam=0 "
                         f"ORDER BY RAND() LIMIT {sample};")

    spam = collect(stub, user, spam_rows, "spam")
    ham = collect(stub, user, ham_rows, "ham")

    L = []
    L.append("ilexa — language-classifier signal review")
    L.append("=" * 46)
    L.append("")
    L.append(f"host: {os.uname().nodename}    generated: {time.strftime('%Y-%m-%d %H:%M %Z')}")
    L.append("")
    L.append("This is the scheduled fortnightly check on the experimental")
    L.append("language signals. They currently carry weight 0.0 -- they are")
    L.append("logged on every message and change no verdict. The question")
    L.append("below is whether that should change.")
    L.append("")
    L.append(f"Measured against {len(spam)} distinct spam / {len(ham)} distinct")
    L.append("legitimate messages from the live archive, deduplicated by content.")
    L.append("")

    results = {}
    if not spam or not ham:
        L.append("NOT ENOUGH DATA to judge anything this cycle -- too few distinct")
        L.append("messages in the archive. Nothing to do; the next run will retry.")
    else:
        # The TRUE archive base rate, not the sample's. The sample takes every
        # spam but only a capped slice of ham, so its own ratio is a sampling
        # artefact (~40%) and printing that would badly misrepresent the
        # false-positive maths below, which depends entirely on how rare spam
        # really is.
        try:
            r = run_mysql("SELECT ROUND(SUM(is_spam=1)/COUNT(*),4) FROM postfix.archive_index;")
            base = float(r[0][0]) if r and r[0][0] not in (None, "NULL") else 0.0
        except Exception:
            base = 0.0
        L.append("AUC = probability a random spam scores above a random good")
        L.append("message. 0.50 is no information at all; distance from 0.50 in")
        L.append("either direction is what matters.")
        L.append("")
        L.append(f"  {'signal':16s} {'AUC':>6s}   verdict")
        promising = []
        for s in SIGNALS:
            vals_s = [d[s] for d in spam]
            vals_h = [d[s] for d in ham]
            a = auc(vals_s, vals_h)
            if a is None:
                continue
            dist = abs(a - 0.5)
            if dist < 0.05:
                v, tier = "no signal", "none"
            elif dist < 0.10:
                v, tier = "marginal", "marginal"
            elif dist < 0.20:
                v, tier = "real, weak", "weak"
            else:
                v, tier = "STRONG — worth reviewing", "strong"
                promising.append((s, a))
            # Direction matters for what a weight would even mean: below 0.5
            # the signal is HAM-leaning, so any weight would have to be
            # negative. Recording it stops the console implying otherwise.
            results[s] = {
                "auc": round(a, 4),
                "tier": tier,
                "direction": "spam" if a >= 0.5 else "ham",
                "spam_median": round(sorted(vals_s)[len(vals_s)//2], 4),
                "ham_median": round(sorted(vals_h)[len(vals_h)//2], 4),
            }
            L.append(f"  {s:16s} {a:6.3f}   {v}")

        L.append("")
        L.append(f"Real spam rate across the whole archive: {base*100:.0f}%")
        L.append("(the sample above deliberately over-weights spam so there is")
        L.append("enough of it to measure; the rate here is the real one, and it")
        L.append("is the rate the false-positive maths below depends on).")
        L.append("")
        if promising:
            L.append("WHAT TO DO: one or more signals separate spam from good mail")
            L.append("well enough to be worth a look:")
            for s, a in promising:
                L.append(f"  - {s} (AUC {a:.3f})")
            L.append("")
            L.append("Before giving any of them a score, check the FALSE-POSITIVE")
            L.append("cost at the real spam rate, not the headline number. A")
            L.append("classifier that looks strong on a balanced test can still")
            L.append("flag mostly legitimate mail once ~90% of traffic is good --")
            L.append("that is exactly what happened to hu_spam, which scored 81%")
            L.append("accuracy and would still have mis-flagged ~46 good messages")
            L.append("per 1000. Run recalibrate.py / measure_signal_value.py and")
            L.append("look at the projected precision first.")
        else:
            L.append("WHAT TO DO: nothing. No signal is strong enough to justify a")
            L.append("weight. This is a normal outcome and worth recording -- the")
            L.append("next run will check again against newer mail.")

    L.append("")
    L.append("Tools, all of which store aggregates only and never message text:")
    L.append("  /opt/hu-classify/measure_signal_value.py   re-measure on demand")
    L.append("  /opt/hu-classify/recalibrate.py            preprocessing/calibration")
    L.append("  /opt/hu-classify/mw_train_spam_router.py   retrain the spam router")
    L.append("")
    L.append("Turn these signals off entirely, or change who receives this")
    L.append("report, on the console's Rendszer page.")
    body = "\n".join(L)

    # Persist the measurement for the console. Written before the mail is
    # attempted so a mail failure cannot cost us the numbers.
    try:
        os.makedirs(os.path.dirname(RESULT_JSON), exist_ok=True)
        with open(RESULT_JSON, "w", encoding="utf-8") as f:
            json.dump({
                "measured_at": int(time.time()),
                "n_spam": len(spam),
                "n_ham": len(ham),
                "spam_base_rate": round(base, 4) if spam and ham else None,
                "signals": results,
            }, f)
        os.chmod(RESULT_JSON, 0o644)
    except OSError as e:
        print(f"could not write {RESULT_JSON}: {e}", file=sys.stderr)

    if dry:
        print(body)
        return 0

    rcpt = sh(["/usr/local/sbin/qa-hu-classify.sh", "report-email", "get"]).stdout.decode().strip()
    if not rcpt:
        for conf in ("/etc/ilexa/alerts.conf",):
            try:
                with open(conf) as f:
                    for line in f:
                        line = line.strip()
                        if line and not line.startswith("#"):
                            rcpt = line
                            break
            except OSError:
                pass
    if not rcpt:
        # Same rule as cron-alert.sh: no address configured means silence, not
        # a guess. A mail server that mails an operator who never asked for it
        # is noise at best.
        print("no report recipient configured — nothing sent", file=sys.stderr)
        return 0

    host = os.uname().nodename
    # ASCII-only subject: a non-ASCII character forces MIME encoded-word
    # encoding of the whole header, which mail clients then fold awkwardly
    # ("=?utf-8?B?4oCU?=" mid-subject). The body is free to use whatever it
    # likes; the subject is not worth the encoding.
    p = subprocess.run(["mail", "-s", f"[ilexa] language-classifier review - {host}", rcpt],
                       input=body.encode(), capture_output=True)
    if p.returncode != 0:
        print(f"mail failed: {p.stderr.decode()[:200]}", file=sys.stderr)
        return 1

    os.makedirs(os.path.dirname(STATE_STAMP), exist_ok=True)
    with open(STATE_STAMP, "w") as f:
        f.write(time.strftime("%Y-%m-%d %H:%M"))
    print(f"report sent to {rcpt}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
