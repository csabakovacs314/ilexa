#!/bin/bash
#
# Postscreen DNSBL standing config: which DNS blocklists postscreen scores
# inbound port-25 clients against, each list's weight, and the reject
# threshold. The console's Rendszer card edits it; the installer seeds it.
#
# Single source of truth: /etc/ilexa/postscreen_dnsbl.conf
#   threshold=3
#   zen.spamhaus.org*3
#   bl.hrbl.hu*2
#   ...
# `apply` composes postscreen_dnsbl_sites/_threshold from that file and
# writes them with postconf -e -- ALWAYS the full explicit value, never a
# read-modify-paste (a postconf read pasted back once doubled a key into its
# own value and crash-looped postscreen for 7 minutes on the reference
# host). A failed `postfix check` rolls the two keys back to their previous
# values and exits non-zero; nothing else in main.cf is ever touched.
#
#   qa-postscreen-dnsbl.sh list                    JSON: threshold + sites[]
#   qa-postscreen-dnsbl.sh init                    seed the conf from live postconf (only if absent)
#   qa-postscreen-dnsbl.sh add <site> <weight>     add a list + apply
#   qa-postscreen-dnsbl.sh set-weight <site> <w>   change a weight + apply
#   qa-postscreen-dnsbl.sh remove <site>           remove a list + apply (refuses the last one)
#   qa-postscreen-dnsbl.sh set-threshold <n>       change the reject threshold + apply
#   qa-postscreen-dnsbl.sh apply                   re-render postconf from the conf
set -uo pipefail

CONF=/etc/ilexa/postscreen_dnsbl.conf
die() { echo "qa-postscreen-dnsbl: $*" >&2; exit 2; }

# Weights are small signed integers: positive scores toward the reject
# threshold, negative expresses a whitelist zone. Bounds are sanity rails,
# not policy.
valid_site()   { [[ "$1" =~ ^[a-z0-9]([a-z0-9._-]{0,251}[a-z0-9])?$ ]]; }
valid_weight() { [[ "$1" =~ ^-?[0-9]{1,2}$ ]] && [ "$1" -ge -10 ] && [ "$1" -le 10 ] && [ "$1" != 0 ]; }

_ensure_dir() { [ -d /etc/ilexa ] || { mkdir -p /etc/ilexa; chmod 755 /etc/ilexa; }; }

# Parse the live postconf value ("site*3 site2*2 site3") into conf lines.
_import_live() {
  local sites thr s
  sites=$(postconf -h postscreen_dnsbl_sites 2>/dev/null)
  thr=$(postconf -h postscreen_dnsbl_threshold 2>/dev/null)
  [[ "$thr" =~ ^[0-9]+$ ]] || thr=3
  echo "threshold=$thr"
  for s in $sites; do echo "${s%,}"; done
}

init_conf() {
  [ -f "$CONF" ] && { echo "already initialised"; return 0; }
  _ensure_dir
  { echo "# postscreen DNSBL sites + weights. Managed by qa-postscreen-dnsbl.sh"
    echo "# (Rendszer card in the ilexa console). Format: threshold=N, then one"
    echo "# site[*weight] per line. Edit + 'apply', or use the console."
    _import_live
  } > "$CONF"
  chmod 644 "$CONF"
  echo "OK initialised from live postconf"
}

_threshold() { grep -m1 -oE '^threshold=[0-9]+' "$CONF" 2>/dev/null | cut -d= -f2; }
_sites()     { grep -vE '^\s*(#|threshold=|$)' "$CONF" 2>/dev/null; }

_apply() {
  [ -s "$CONF" ] || die "no config at $CONF — run 'init' first"
  local thr sites prev_sites prev_thr
  thr=$(_threshold); [[ "$thr" =~ ^[0-9]+$ ]] || die "bad threshold in $CONF"
  sites=$(_sites | tr '\n' ' ' | sed 's/ $//')
  [ -n "$sites" ] || die "refusing to apply an empty site list"
  prev_sites=$(postconf -h postscreen_dnsbl_sites)
  prev_thr=$(postconf -h postscreen_dnsbl_threshold)
  # ONE -e, multiple assignments: -e is postconf's edit MODE, not a
  # per-assignment flag -- a second -e is parsed as an attribute name and
  # fails with "missing '=' after attribute name" (caught on first run).
  postconf -e "postscreen_dnsbl_sites = $sites" "postscreen_dnsbl_threshold = $thr" \
    || die "postconf write failed"
  if ! postfix check >/dev/null 2>&1; then
    postconf -e "postscreen_dnsbl_sites = $prev_sites" "postscreen_dnsbl_threshold = $prev_thr" || true
    die "postfix check failed — previous values restored, nothing reloaded"
  fi
  systemctl reload postfix >/dev/null 2>&1 || postfix reload >/dev/null 2>&1
  echo "OK applied: threshold=$thr sites=$(printf '%s' "$sites" | wc -w)"
}

_edit() { # mode site [weight]
  local mode="$1" site="$2" weight="${3:-}" entry tmp
  valid_site "$site" || die "invalid site: $site"
  [ "$mode" = remove ] || { valid_weight "$weight" || die "invalid weight: ${weight:-<none>} (allowed -10..10, not 0)"; }
  [ -s "$CONF" ] || init_conf >/dev/null
  entry="$site"; [ "${weight:-1}" != 1 ] && entry="$site*$weight"
  tmp=$(mktemp) || die "mktemp failed"
  grep -vE "^${site//./\\.}(\*|-[0-9]|$)" "$CONF" > "$tmp"
  case "$mode" in
    add|set-weight)
      # add refuses duplicates so a typo'd weight change must use set-weight,
      # and set-weight refuses unknown sites so a typo'd add is not silently
      # created -- the two errors are different mistakes.
      if [ "$mode" = add ] && grep -qE "^${site//./\\.}(\*|$)" "$CONF"; then rm -f "$tmp"; die "$site is already listed — use set-weight"; fi
      if [ "$mode" = set-weight ] && ! grep -qE "^${site//./\\.}(\*|$)" "$CONF"; then rm -f "$tmp"; die "$site is not listed — use add"; fi
      echo "$entry" >> "$tmp" ;;
    remove)
      grep -qE "^${site//./\\.}(\*|$)" "$CONF" || { rm -f "$tmp"; die "$site is not listed"; }
      if ! grep -vE '^\s*(#|threshold=|$)' "$tmp" | grep -q .; then
        rm -f "$tmp"; die "refusing to remove the last DNSBL — postscreen would score nothing"
      fi ;;
  esac
  cp -a "$CONF" "$CONF.bak" 2>/dev/null || true
  cat "$tmp" > "$CONF"; rm -f "$tmp"
  _apply
}

case "${1:-}" in
  list)
    [ -s "$CONF" ] || init_conf >/dev/null
    printf '{"threshold":%s,"sites":[' "$(_threshold)"
    first=1
    while IFS= read -r s; do
      site="${s%%\**}"; w="${s#*\*}"; [ "$w" = "$s" ] && w=1
      [ $first -eq 1 ] && first=0 || printf ','
      printf '{"site":"%s","weight":%s}' "$site" "$w"
    done < <(_sites)
    printf ']}\n' ;;
  init)          init_conf ;;
  add)           _edit add "${2:?site}" "${3:?weight}" ;;
  set-weight)    _edit set-weight "${2:?site}" "${3:?weight}" ;;
  remove)        _edit remove "${2:?site}" ;;
  set-threshold)
    t="${2:?threshold}"
    if ! [[ "$t" =~ ^[0-9]{1,2}$ ]] || [ "$t" -lt 1 ] || [ "$t" -gt 20 ]; then die "invalid threshold: $t (1..20)"; fi
    [ -s "$CONF" ] || init_conf >/dev/null
    cp -a "$CONF" "$CONF.bak" 2>/dev/null || true
    sed -i "s/^threshold=.*/threshold=$t/" "$CONF"
    grep -q '^threshold=' "$CONF" || sed -i "1i threshold=$t" "$CONF"
    _apply ;;
  apply)         _apply ;;
  *) die "usage: list | init | add <site> <weight> | set-weight <site> <weight> | remove <site> | set-threshold <n> | apply" ;;
esac
