#!/usr/bin/php
<?php
// qa-db-migrate.php - apply/inspect ilexa's DB migrations. Root-run, NEVER
// sudoers-reachable from the web layer: only qa-update-apply.sh (already
// root) and 55-ilexa.sh invoke this. Classified `cron` in helpers.list, not
// `sudo` -- keeping it off sudoers is the actual point, not an oversight.
//
// Requires the DEPLOYED webroot's src/migrate.php for the parsing/apply
// logic (not a private copy) so migration LOGIC and migration FILES always
// travel together in the same app tarball/update -- deliberate, not an
// accident: after a Phase-4 rsync during an update, this always requires
// the newest deployed copy, matched to the newest migration files.
//
// Usage:
//   qa-db-migrate.php --status [--json]
//   qa-db-migrate.php --plan   [--store=mysql|iocs|logins] [--json]
//   qa-db-migrate.php --apply  [--store=mysql|iocs|logins] [--dry-run] [--json]
//
// Always exits 0 with a JSON/text summary on stdout, matching this
// project's "never hang the caller" convention for root-run helpers -- a
// failure is reported in the summary's ok:false, not via a non-zero exit
// that a naive caller might not check.
declare(strict_types=1);

if (PHP_SAPI !== 'cli') { fwrite(STDERR, "cli only\n"); exit(2); }
if (posix_geteuid() !== 0) { fwrite(STDERR, "must run as root\n"); exit(2); }

$WEBROOT   = getenv('QA_WEBROOT') ?: '/var/www/html/quarantine-admin';
$SETTINGS  = getenv('QA_SETTINGS_DIR') ?: '/var/cache/quarantine-admin';
$MIG_CRED  = getenv('QA_MIG_CRED') ?: '/etc/ilexa/secrets/db-migrate.php';

$migrateFile = $WEBROOT . '/src/migrate.php';
if (!is_readable($migrateFile)) {
    fwrite(STDERR, "cannot read $migrateFile -- is the console deployed?\n");
    exit(2);
}
require $migrateFile;

$opts = getopt('', ['status', 'plan', 'apply', 'dry-run', 'store:', 'dir:', 'json']);
$json = isset($opts['json']);
$dir  = $opts['dir'] ?? MIGRATIONS_DIR;
$onlyStore = $opts['store'] ?? null;
if ($onlyStore !== null && !in_array($onlyStore, MIGRATION_STORES, true)) {
    fwrite(STDERR, "bad --store: $onlyStore\n");
    exit(2);
}
$mode = isset($opts['apply']) ? 'apply' : (isset($opts['plan']) ? 'plan' : 'status');
$dryRun = isset($opts['dry-run']) || $mode !== 'apply';

function qa_mig_connect(string $store, string $settingsDir, string $migCred): ?PDO {
    try {
        if ($store === 'mysql') {
            if (!is_readable($migCred)) return null;
            $c = @include $migCred;
            if (!is_array($c)) return null;
            $dsn = 'mysql:unix_socket=' . $c['socket'] . ';dbname=' . $c['db'] . ';charset=utf8mb4';
            return new PDO($dsn, $c['user'], $c['pass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        }
        $path = $settingsDir . '/' . $store . '.db'; // iocs.db, logins.db
        $db = new PDO('sqlite:' . $path, null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        $db->exec('PRAGMA busy_timeout = 5000');
        return $db;
    } catch (Throwable $e) {
        fwrite(STDERR, "connect($store): " . $e->getMessage() . "\n");
        return null;
    }
}

$files = migration_files($dir);
$badFiles = array_filter($files, fn($f) => !empty($f['error']));
if ($badFiles) {
    foreach ($badFiles as $id => $f) fwrite(STDERR, "malformed migration $id (" . $f['path'] . "): " . $f['error'] . "\n");
}

$stores = $onlyStore ? [$onlyStore] : MIGRATION_STORES;
$summary = ['mode' => $mode, 'dry_run' => $dryRun, 'stores' => []];
$overallOk = true;

foreach ($stores as $store) {
    $db = qa_mig_connect($store, $SETTINGS, $MIG_CRED);
    if (!$db) {
        $summary['stores'][$store] = ['ok' => false, 'reason' => 'no_connection'];
        $overallOk = false;
        continue;
    }
    migration_ensure_ledger_table($db, $store === 'mysql' ? 'mysql' : 'sqlite');
    $ledger  = migration_ledger($db);
    $pending = migration_pending($store, $files, $ledger);
    $drift   = migration_checksum_drift(
        array_filter($files, fn($f) => ($f['header']['store'] ?? '') === $store), $ledger
    );
    if ($drift) {
        $overallOk = false;
        $summary['stores'][$store] = ['ok' => false, 'reason' => 'checksum_drift', 'drift' => $drift];
        continue;
    }
    if ($mode === 'status' || $mode === 'plan') {
        $summary['stores'][$store] = [
            'ok' => true, 'applied' => count($ledger), 'pending' => array_keys($pending),
        ];
        continue;
    }
    // apply (or --dry-run, which still goes through migration_apply_one's own dryRun path)
    $results = migration_apply_pending($db, $store, $pending, $dryRun);
    $storeOk = true;
    foreach ($results as $r) { if (!$r['ok']) { $storeOk = false; $overallOk = false; break; } }
    $summary['stores'][$store] = ['ok' => $storeOk, 'applied_ids' => array_keys($pending), 'results' => $results];
}

$summary['ok'] = $overallOk;

if ($json) {
    echo json_encode($summary, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), "\n";
} else {
    foreach ($summary['stores'] as $store => $s) {
        if (!($s['ok'] ?? false)) {
            printf("%-8s FAIL (%s)\n", $store, $s['reason'] ?? 'see results');
            continue;
        }
        if ($mode === 'apply') {
            printf("%-8s OK  applied=%s\n", $store, implode(',', $s['applied_ids']) ?: '(none pending)');
        } else {
            printf("%-8s OK  ledger=%d pending=%s\n", $store, $s['applied'], implode(',', $s['pending']) ?: '(none)');
        }
    }
}

exit(0);
