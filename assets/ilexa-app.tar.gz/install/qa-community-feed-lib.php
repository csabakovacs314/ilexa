<?php
// Community feed loader library (docs/superpowers/specs/2026-08-11-
// community-feed-management-design.md). Pure/testable functions only --
// no top-level executable code. The entry point (qa-community-feed-
// loader.php) requires this file and does the actual dispatch.

const COMMUNITY_FEED_CONFIG      = '/var/cache/quarantine-admin/community_feeds.json';
const COMMUNITY_FEED_STATUS      = '/var/cache/quarantine-admin/community_feeds_status.json';
const COMMUNITY_FEED_IPSET_DIR   = '/etc/firewalld/ipsets';
const COMMUNITY_FEED_MIN_ENTRIES = 5;
// This is the id ceiling, not the live-feed cap (that cap -- 25 concurrent
// feeds -- is enforced only in the PHP web layer, against count($feeds), and
// has no representation here at all: this lib never counts feeds, it only
// validates and dispatches on a single id). ids are app-assigned, strictly
// increasing, and never reused, so a ceiling tied to the live-feed cap would
// make every id fail validation -- and therefore make every lifecycle
// operation on every existing feed fail too, not just new creates -- once
// enough lifetime creations had happened. Keep in sync with
// COMMUNITY_FEED_MAX_ID in src/admin.php and the length/numeric bounds in
// qa-community-feed-refresh.sh's shell guard.
const COMMUNITY_FEED_MAX_ID      = 9999;

// An ipset name is ALWAYS community_<id> with an app-assigned integer id --
// never anything derived from the admin-supplied label. This is the single
// choke point that keeps admin text out of firewall-cmd arguments, and it is
// deliberately re-checked here (root side) rather than trusting the caller:
// the web layer validates too, but this must hold even if that layer is
// compromised. Rejects '', '0', '01', '-1', '1.5', '1e3', '1 2', '1;x',
// and anything above the ceiling.
function _community_feed_valid_id(mixed $id): bool {
    if (is_int($id)) return $id >= 1 && $id <= COMMUNITY_FEED_MAX_ID;
    if (!is_string($id)) return false;
    if (preg_match('/^[1-9][0-9]*\z/', $id) !== 1) return false;
    return (int) $id <= COMMUNITY_FEED_MAX_ID;
}

// Native PHP curl, not a shelled-out curl binary -- see Global
// Constraints for why this script stays shell-free for fetch and parse.
// Returns null on any transport error or non-2xx response.
function _community_feed_fetch(string $url): ?string {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS      => 3,
        CURLOPT_USERAGENT      => 'ilexa-community-feed-loader/1.0',
        CURLOPT_PROTOCOLS      => CURLPROTO_HTTP | CURLPROTO_HTTPS,
        CURLOPT_REDIR_PROTOCOLS=> CURLPROTO_HTTP | CURLPROTO_HTTPS,
        CURLOPT_MAXFILESIZE    => 10 * 1024 * 1024,
    ]);
    $body = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);
    if ($body === false || $err !== '' || $code < 200 || $code >= 300) {
        return null;
    }
    return $body;
}

// Pure function: no I/O. Extracts a value from a decoded JSON row via a
// dot-notation field path (e.g. "data.ip" -> $row['data']['ip']).
// Returns null if any segment is missing or the leaf isn't a string --
// never throws, since a malformed admin-supplied field path against a
// real feed's actual shape is an expected, not exceptional, case.
function _community_feed_field(array $row, string $fieldPath): ?string {
    $cur = $row;
    foreach (explode('.', $fieldPath) as $seg) {
        if (!is_array($cur) || !array_key_exists($seg, $cur)) return null;
        $cur = $cur[$seg];
    }
    return is_string($cur) ? $cur : null;
}

// Pure function: no I/O. $format is one of 'plain'/'json'/'jsonl'.
// Malformed input at any stage yields no value for that row, never an
// exception -- one bad row (or a field path that never resolves) must
// never take the whole parse down.
function _community_feed_parse(string $raw, string $format, string $fieldPath): array {
    $out = [];
    if ($format === 'plain') {
        foreach (preg_split('/\r?\n/', $raw) as $line) {
            $line = trim($line);
            if ($line !== '' && $line[0] !== '#') $out[] = $line;
        }
        return $out;
    }
    if ($format === 'json') {
        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) return [];
        foreach ($decoded as $row) {
            if (!is_array($row)) continue;
            $v = _community_feed_field($row, $fieldPath);
            if ($v !== null) $out[] = $v;
        }
        return $out;
    }
    if ($format === 'jsonl') {
        foreach (preg_split('/\r?\n/', $raw) as $line) {
            $line = trim($line);
            if ($line === '') continue;
            $row = json_decode($line, true);
            if (!is_array($row)) continue;
            $v = _community_feed_field($row, $fieldPath);
            if ($v !== null) $out[] = $v;
        }
        return $out;
    }
    return [];
}

// Pure function: no I/O. Trims, dedupes, validates each entry as an IPv4
// address or CIDR (this app's community-feed ipsets are IPv4-only
// hash:net, so IPv6 entries are rejected here rather than written into
// an ipset that can't hold them), drops private/reserved ranges (the
// same FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE combination
// ioc_extract_candidates() already uses in src/ioc.php) and any of
// $ownIps. $ownIps is a parameter, not read from the host inside this
// function, specifically so this stays testable without touching real
// network interfaces.
function _community_feed_clean(array $raw, array $ownIps = []): array {
    $seen = [];
    $out = [];
    foreach ($raw as $entry) {
        $entry = trim((string) $entry);
        if ($entry === '' || isset($seen[$entry])) continue;
        $seen[$entry] = true;

        $parts = explode('/', $entry);
        if (count($parts) > 2) continue;
        $addrPart = $parts[0];
        if (filter_var($addrPart, FILTER_VALIDATE_IP,
                FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false) {
            continue;
        }
        if (isset($parts[1])) {
            if (!ctype_digit($parts[1])) continue;
            $prefix = (int) $parts[1];
            if ($prefix > 32) continue;
        }
        if (in_array($addrPart, $ownIps, true)) continue;

        $out[] = $entry;
    }
    return $out;
}

// Atomic tempfile-then-rename write of the ipset XML, same hash:net
// shape /usr/local/sbin/load-spamhaus-drop.sh already produces. Refuses to write
// (returns false, existing file untouched) if $entries is below
// COMMUNITY_FEED_MIN_ENTRIES, or if the new content is byte-identical to
// what's already on disk (a no-op refresh shouldn't force a
// firewall-cmd --reload -- the caller uses this return value to decide
// whether a reload is needed at all).
// Returns true if it wrote a changed file, false if it declined to write
// (too few entries, or content byte-identical to what's already on disk
// -- neither is an error), or null if an actual I/O failure occurred
// (tempnam/file_put_contents/rename). Callers must treat null as a real
// failure distinct from false -- conflating them was the residual gap a
// final review found: a genuine filesystem failure was being recorded
// as a successful refresh.
function _community_feed_write_ipset(string $slot, array $entries, string $label): ?bool {
    if (count($entries) < COMMUNITY_FEED_MIN_ENTRIES) return false;

    $lines = [
        '<?xml version="1.0" encoding="utf-8"?>',
        '<ipset type="hash:net">',
        '  <short>' . htmlspecialchars($label, ENT_XML1) . '</short>',
        '  <description>Community feed, rebuilt by qa-community-feed-loader.php. Applied as an all-ports source drop.</description>',
        '  <option name="hashsize" value="4096"/>',
        '  <option name="maxelem" value="65536"/>',
    ];
    foreach ($entries as $e) $lines[] = '  <entry>' . htmlspecialchars($e, ENT_XML1) . '</entry>';
    $lines[] = '</ipset>';
    $xml = implode("\n", $lines) . "\n";

    $path = COMMUNITY_FEED_IPSET_DIR . "/{$slot}.xml";
    if (is_file($path) && @file_get_contents($path) === $xml) return false;

    $tmp = tempnam(COMMUNITY_FEED_IPSET_DIR, '.community-');
    if ($tmp === false) return null;
    if (file_put_contents($tmp, $xml) === false) { @unlink($tmp); return null; }
    @chmod($tmp, 0644);
    return rename($tmp, $path) ? true : null;
}

// ── Firewall object lifecycle ────────────────────────────────────────────────
// These are the only functions in this codebase that CREATE or DESTROY a
// firewall object; everything else only rewrites ipset contents. Each one
// re-validates the id before building any command, and each is idempotent so a
// retried or half-finished operation converges instead of failing.
//
// ORDERING IS A CORRECTNESS REQUIREMENT: firewalld refuses a rich rule that
// names a nonexistent ipset (observed live during the 2026-08-11 rollout:
// "ERROR: INVALID_IPSET: Zone 'public': 'community_1' not among existing
// ipsets"). So create ipset->rule, and tear down rule->ipset.

function _community_feed_rich_rule(int $id): string {
    return 'rule family="ipv4" source ipset="community_' . $id . '" drop';
}

function _community_feed_provision(int $id): bool {
    if (!_community_feed_valid_id($id)) { echo "provision: bad id\n"; return false; }

    // New ipset, matching the five provisioned at rollout exactly.
    exec('firewall-cmd --permanent --new-ipset=community_' . $id
        . ' --type=hash:net --option=hashsize=4096 --option=maxelem=65536 2>&1', $o1, $rc1);
    // "NAME_CONFLICT" means it already exists -- idempotent, not an error. Any
    // other failure here means there is no ipset to name, so the rich rule
    // below must not be attempted -- that would either fail on a nonexistent
    // ipset or, worse, half-succeed into a rule/ipset mismatch.
    if ($rc1 !== 0 && stripos(implode(' ', $o1), 'NAME_CONFLICT') === false) {
        echo "provision: new-ipset failed: " . implode(' ', $o1) . "\n"; return false;
    }

    // Label it, matching the five provisioned at rollout (e.g. "Community
    // feed slot 2"): --new-ipset itself sets no <short>, so without this a
    // slot that's provisioned but never refreshed/flushed would render
    // unlabeled. Cosmetic only -- a failure here must never fail the
    // provision.
    exec('firewall-cmd --permanent --ipset=community_' . $id
        . ' --set-short=' . escapeshellarg('Community feed slot ' . $id) . ' 2>&1', $oS, $rcS);
    if ($rcS !== 0) { echo "provision: set-short failed: " . implode(' ', $oS) . "\n"; }

    $ok = true;

    exec('firewall-cmd --permanent --add-rich-rule=' . escapeshellarg(_community_feed_rich_rule($id)) . ' 2>&1', $o2, $rc2);
    if ($rc2 !== 0 && stripos(implode(' ', $o2), 'ALREADY_ENABLED') === false) {
        echo "provision: add-rich-rule failed: " . implode(' ', $o2) . "\n"; $ok = false;
    }

    exec('firewall-cmd --reload 2>&1', $o3, $rc3);
    if ($rc3 !== 0) { echo "provision: reload failed: " . implode(' ', $o3) . "\n"; $ok = false; }
    return $ok;
}

function _community_feed_teardown(int $id): bool {
    if (!_community_feed_valid_id($id)) { echo "teardown: bad id\n"; return false; }
    $ok = true;

    // Rule FIRST -- deleting the ipset while a rule still names it is what
    // produces INVALID_IPSET on the next reload. "NOT_ENABLED" means the
    // rule is already gone -- idempotent, not an error. Any other failure
    // means the rule may still be there, so deleting the ipset below must
    // not be attempted -- that's exactly the rule-with-no-ipset state this
    // ordering exists to prevent.
    exec('firewall-cmd --permanent --remove-rich-rule=' . escapeshellarg(_community_feed_rich_rule($id)) . ' 2>&1', $o1, $rc1);
    if ($rc1 !== 0 && stripos(implode(' ', $o1), 'NOT_ENABLED') === false) {
        echo "teardown: remove-rich-rule failed: " . implode(' ', $o1) . "\n"; return false;
    }

    exec('firewall-cmd --permanent --delete-ipset=community_' . $id . ' 2>&1', $o2, $rc2);
    if ($rc2 !== 0 && stripos(implode(' ', $o2), 'INVALID_IPSET') === false) {
        echo "teardown: delete-ipset failed: " . implode(' ', $o2) . "\n"; $ok = false;
    }

    exec('firewall-cmd --reload 2>&1', $o3, $rc3);
    if ($rc3 !== 0) { echo "teardown: reload failed: " . implode(' ', $o3) . "\n"; $ok = false; }

    _community_feed_clear_status($id);
    return $ok;
}

// Empties the ipset but leaves the ipset and its rule in place, so re-enabling
// a feed needs no firewall object creation. NOTE: this deliberately does not
// reuse _community_feed_write_ipset(), which refuses to write fewer than
// COMMUNITY_FEED_MIN_ENTRIES entries -- an intentional guard against a
// truncated feed wiping a live blocklist, and exactly the wrong behaviour here.
function _community_feed_flush(int $id): bool {
    if (!_community_feed_valid_id($id)) { echo "flush: bad id\n"; return false; }

    $xml = implode("\n", [
        '<?xml version="1.0" encoding="utf-8"?>',
        '<ipset type="hash:net">',
        '  <short>community_' . $id . '</short>',
        '  <description>Community feed, emptied by qa-community-feed-loader.php (feed disabled).</description>',
        '  <option name="hashsize" value="4096"/>',
        '  <option name="maxelem" value="65536"/>',
        '</ipset>',
    ]) . "\n";

    $path = COMMUNITY_FEED_IPSET_DIR . "/community_{$id}.xml";
    $tmp  = tempnam(COMMUNITY_FEED_IPSET_DIR, '.community-');
    if ($tmp === false) { echo "flush: tempnam failed\n"; return false; }
    if (file_put_contents($tmp, $xml) === false) { @unlink($tmp); echo "flush: write failed\n"; return false; }
    @chmod($tmp, 0644);
    if (!rename($tmp, $path)) { @unlink($tmp); echo "flush: rename failed\n"; return false; }

    exec('firewall-cmd --reload 2>&1', $o, $rc);
    if ($rc !== 0) { echo "flush: reload failed: " . implode(' ', $o) . "\n"; return false; }

    _community_feed_write_status("community_$id", 0, true, '');
    return true;
}

// Drops one feed's entry from the root-written status file, so a deleted feed
// leaves no stale "last refreshed / N entries" behind -- the exact residue that
// made a cleared slot still show 16102 entries in the Admin tab.
function _community_feed_clear_status(int $id): void {
    $status = is_file(COMMUNITY_FEED_STATUS)
        ? (json_decode((string) @file_get_contents(COMMUNITY_FEED_STATUS), true) ?: [])
        : [];
    unset($status["community_$id"]);
    $tmp = tempnam(dirname(COMMUNITY_FEED_STATUS), '.community-status-');
    if ($tmp === false) return;
    if (file_put_contents($tmp, json_encode($status, JSON_PRETTY_PRINT)) === false) { @unlink($tmp); return; }
    @chmod($tmp, 0644);
    rename($tmp, COMMUNITY_FEED_STATUS);
}

// Fixed, never-interpolated command -- carries zero admin-supplied data,
// unlike the field-path extraction above. See Global Constraints.
function _community_feed_own_ips(): array {
    $out = @shell_exec('hostname -I 2>/dev/null');
    if (!is_string($out)) return [];
    return array_values(array_filter(array_map('trim', explode(' ', trim($out)))));
}

// Fail-closed: an absent/unreadable/malformed config means no slots are
// configured, never "refresh everything with empty settings".
function _community_feed_load_config(): array {
    if (!is_file(COMMUNITY_FEED_CONFIG)) return [];
    $raw = json_decode((string) @file_get_contents(COMMUNITY_FEED_CONFIG), true);
    return is_array($raw) ? $raw : [];
}

// Root-written status file, deliberately separate from the apache-
// writable config file (see Global Constraints) so a web-triggered
// config save and this write can never race on the same file.
// $errorCode is a short machine code (not translated text -- this
// script has no access to the web app's t()/lang files), one of
// 'fetch_failed' | 'too_few_entries' | '' (empty means success). The
// Admin-tab view maps the code to a translated message.
function _community_feed_write_status(string $slot, int $count, bool $ok, string $errorCode = ''): void {
    $status = is_file(COMMUNITY_FEED_STATUS)
        ? (json_decode((string) @file_get_contents(COMMUNITY_FEED_STATUS), true) ?: [])
        : [];
    if (!is_array($status)) $status = [];
    $status[$slot] = [
        'last_refresh_at' => time(),
        'last_count'      => $count,
        'last_ok'         => $ok,
        'last_error'      => $errorCode,
    ];
    $tmp = tempnam(dirname(COMMUNITY_FEED_STATUS), '.community-status-');
    if ($tmp === false) return;
    if (file_put_contents($tmp, json_encode($status, JSON_PRETTY_PRINT)) === false) { @unlink($tmp); return; }
    @chmod($tmp, 0644);
    rename($tmp, COMMUNITY_FEED_STATUS);
}

// Top-level driver. $onlySlots lets the entry point refresh just one
// slot (the manual-Refresh path) or all enabled slots (the cron path).
// Returns the number of slots that failed (fetch failure, too-few-
// entries guard trip, or a failed firewall-cmd --reload) -- the entry
// point uses this to set its exit code, since a cron job that always
// exits 0 gives an operator no signal that something needs attention.
// $onlySlots === null means "every configured feed"; an array restricts to
// those ids. The fixed 1-5 pool is gone -- the config is now the source of
// truth for which feeds exist.
function _community_feed_run(?array $onlySlots = null): int {
    $config = _community_feed_config_feeds(_community_feed_load_config());
    $ownIps = _community_feed_own_ips();
    $changed = false;
    $failures = 0;

    $ids = $onlySlots === null ? array_keys($config) : $onlySlots;
    foreach ($ids as $n) {
        $slot = "community_$n";
        $cfg = $config[$n] ?? null;
        if (!$cfg || empty($cfg['enabled'])) continue;

        $raw = _community_feed_fetch((string) ($cfg['url'] ?? ''));
        if ($raw === null) {
            echo "$slot: fetch failed\n";
            _community_feed_write_status($slot, 0, false, 'fetch_failed');
            $failures++;
            continue;
        }
        $parsed  = _community_feed_parse($raw, (string) ($cfg['format'] ?? 'plain'), (string) ($cfg['field_path'] ?? ''));
        $cleaned = _community_feed_clean($parsed, $ownIps);

        if (count($cleaned) < COMMUNITY_FEED_MIN_ENTRIES) {
            echo "$slot: too few entries (" . count($cleaned) . ")\n";
            _community_feed_write_status($slot, count($cleaned), false, 'too_few_entries');
            $failures++;
            continue;
        }

        $wrote = _community_feed_write_ipset($slot, $cleaned, (string) ($cfg['label'] ?? $slot));
        if ($wrote === null) {
            echo "$slot: write failed\n";
            _community_feed_write_status($slot, count($cleaned), false, 'write_failed');
            $failures++;
            continue;
        }
        if ($wrote) {
            $changed = true;
            echo "$slot: wrote " . count($cleaned) . " entries\n";
        } else {
            echo "$slot: no change (" . count($cleaned) . " entries)\n";
        }
        _community_feed_write_status($slot, count($cleaned), true, '');
    }

    if ($changed) {
        // Exit status, not output content, is the correct success signal --
        // this firewalld build prints "success" to stdout on a clean reload
        // (confirmed live during rollout), so treating non-empty output as
        // a failure was itself a bug caught only by a real end-to-end run.
        exec('firewall-cmd --reload 2>&1', $reloadOut, $reloadRc);
        if ($reloadRc === 0) {
            echo "firewall-cmd --reload: ok\n";
        } else {
            echo "firewall-cmd --reload FAILED (exit $reloadRc): " . implode(' ', $reloadOut) . "\n";
            $failures++;
        }
    }

    return $failures;
}

// Accepts BOTH the legacy flat shape ({"community_1": {...}}) and the current
// one ({"next_id": N, "feeds": {"1": {...}}}), returning id => cfg either way.
// The web app owns migration (it is the only writer, and this file is mode 750
// so apache cannot share this code); this side stays read-only tolerant so a
// cron run either side of that migration behaves identically.
function _community_feed_config_feeds(array $raw): array {
    $out = [];
    if (isset($raw['feeds']) && is_array($raw['feeds'])) {
        foreach ($raw['feeds'] as $id => $cfg) {
            if (_community_feed_valid_id((string) $id) && is_array($cfg)) $out[(int) $id] = $cfg;
        }
        return $out;
    }
    foreach ($raw as $key => $cfg) {
        if (!is_array($cfg)) continue;
        if (preg_match('/^community_([1-9][0-9]*)$/', (string) $key, $m) !== 1) continue;
        if (_community_feed_valid_id($m[1])) $out[(int) $m[1]] = $cfg;
    }
    return $out;
}
