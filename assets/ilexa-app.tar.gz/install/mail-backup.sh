#!/usr/bin/env bash
# mail-backup — nightly verified DB dumps, kept locally and shipped off-host
# when BACKUP_TARGET is configured in /etc/mail-backup.conf.
#
# Deliberately NOT inert without a target: the local verified dump is the part
# that saves you from a bad migration or a dropped table, and it costs under a
# megabyte. BACKUP_TARGET adds survival of losing the host, which the local copy
# cannot give you -- they are different failures, so both layers exist.
#
# NO set -e: a failure on one database must still be reported, and the local
# copy must still be kept even if shipping off-host fails.
set -uo pipefail
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
CONF=/etc/mail-backup.conf
# The directive must sit alone, directly above the source line: on a compound
# line it binds to the assignment instead, and trailing prose on the directive
# line makes shellcheck discard it (SC1125). Both cost a round to learn.
# shellcheck source=/dev/null
[ -r "$CONF" ] && . "$CONF"
: "${BACKUP_TARGET:=}"; : "${MAIL_STORE:=/data/mail}"
: "${BACKUP_DBS:=postfix roundcube}"; : "${BACKUP_LOCAL_DIR:=/var/backups/ilexa-db}"
: "${BACKUP_KEEP_DAYS:=30}"
ts=$(date +%F-%H%M%S); rc=0

# 0700 / 0600 throughout: these dumps contain mailbox password HASHES and users'
# address books. A readable path must never exist, even briefly.
install -d -m 0700 -o root -g root "$BACKUP_LOCAL_DIR" || {
  logger -t mail-backup "cannot create $BACKUP_LOCAL_DIR"; exit 2; }
work=$(mktemp -d); chmod 0700 "$work"
trap 'rm -rf "$work"' EXIT

for db in $BACKUP_DBS; do
  f="$work/${db}-${ts}.sql.gz"
  if ! mysqldump --single-transaction --quick --routines --triggers \
                 --default-character-set=utf8mb4 --databases "$db" 2>"$f.err" | gzip -c >"$f"; then
    logger -t mail-backup "FAILED $db: mysqldump -- $(tr -d '\n' <"$f.err" | cut -c1-120)"
    rm -f "$f" "$f.err"; rc=1; continue
  fi
  rm -f "$f.err"

  # --- verify by CONTENT. gzip -t alone accepts a truncated dump. ---
  if ! gzip -t "$f" 2>/dev/null; then
    logger -t mail-backup "FAILED $db: gzip integrity"; rm -f "$f"; rc=1; continue
  fi
  if ! zcat "$f" | tail -5 | grep -q '^-- Dump completed'; then
    logger -t mail-backup "FAILED $db: truncated (no '-- Dump completed' marker)"
    rm -f "$f"; rc=1; continue
  fi
  live_t=$(mysql -N -e "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='$db';" 2>/dev/null)
  dump_t=$(zcat "$f" | grep -c '^CREATE TABLE')
  if [ -z "$live_t" ] || [ "$dump_t" -lt "$live_t" ]; then
    logger -t mail-backup "FAILED $db: $dump_t tables dumped, $live_t live"
    rm -f "$f"; rc=1; continue
  fi
  if [ "$db" = postfix ]; then
    live_mb=$(mysql -N -e "SELECT COUNT(*) FROM postfix.mailbox;" 2>/dev/null)
    dump_mb=$(zcat "$f" | sed -n "/INSERT INTO \`mailbox\`/,/;\$/p" | grep -o "),(" | wc -l)
    dump_mb=$(( dump_mb > 0 ? dump_mb + 1 : 0 ))
    if [ "$dump_mb" -lt "$live_mb" ]; then
      logger -t mail-backup "FAILED postfix: ~$dump_mb mailbox rows dumped, $live_mb live"
      rm -f "$f"; rc=1; continue
    fi
  fi

  # Keep the verified local copy BEFORE any encryption or shipping, so a broken
  # target or a missing gpg can never cost you the backup itself.
  install -m 0600 -o root -g root "$f" "$BACKUP_LOCAL_DIR/$(basename "$f")" \
    && logger -t mail-backup "ok $db: $(du -h "$f" | cut -f1), $dump_t tables (local)"
done

# --- retention. Never prune the newest copy of a database, whatever its age. --
for db in $BACKUP_DBS; do
  newest=$(ls -1t "$BACKUP_LOCAL_DIR"/"$db"-*.sql.gz 2>/dev/null | head -1)
  while IFS= read -r old; do
    [ "$old" = "$newest" ] && continue
    rm -f -- "$old"
  done < <(find "$BACKUP_LOCAL_DIR" -maxdepth 1 -name "$db-*.sql.gz" -mtime +"$BACKUP_KEEP_DAYS" 2>/dev/null)
done

# --- off-host, only if asked -------------------------------------------------
if [ -z "$BACKUP_TARGET" ]; then
  logger -t mail-backup "local copy kept in $BACKUP_LOCAL_DIR; no BACKUP_TARGET set, nothing shipped"
  exit "$rc"
fi
if [ -n "${BACKUP_PASSPHRASE:-}" ]; then
  for f in "$work"/*.sql.gz; do
    [ -e "$f" ] || continue
    gpg --batch --yes --passphrase "$BACKUP_PASSPHRASE" -c "$f" && rm -f "$f"
  done
else
  logger -t mail-backup "WARNING: BACKUP_PASSPHRASE unset — DB dumps ship UNENCRYPTED"
fi
# rsync-style target example; adapt to restic/borg/S3 as needed.
if rsync -a "$work"/ "$BACKUP_TARGET/db/" && rsync -a "$MAIL_STORE"/ "$BACKUP_TARGET/mail/"; then
  logger -t mail-backup "shipped to $BACKUP_TARGET ($ts)"
else
  logger -t mail-backup "FAILED: shipping to $BACKUP_TARGET (local copy is intact)"; rc=1
fi
exit "$rc"
