#!/bin/bash
#
# Toggle the Hungarian spam-classifier module (hu-classify-stub.service +
# the rspamd Lua postfilter's own gate) from the console. Called by apache
# via sudo.
#
# STATE MODEL. This is NOT rspamd's own local.d/<module>.conf `enabled`
# convention (see qa-rspamd-modules.sh for that one) -- the Lua module
# (lua.local.d/hu_classify.lua) re-reads STATE_FILE fresh on every message,
# so flipping it takes effect immediately with no rspamd reload at all.
# Absent file == disabled, which is the fail-safe default on a fresh
# install: the module is present but inert until an admin turns it on here.
#
# WRITE DISCIPLINE. This script owns STATE_FILE outright (it is not a real
# rspamd config key rspamd itself reads, just a flag this module's Lua
# checks) and the hu-classify-stub.service unit's enabled/active state.
# It touches nothing else.
#
# Usage: qa-hu-classify.sh status
#        qa-hu-classify.sh set on|off

set -uo pipefail

STATE_FILE=/etc/rspamd/local.d/hu_classify.state
# Recipient for the fortnightly retrain/evaluation report. Its OWN file rather
# than reusing /etc/ilexa/alerts.conf directly: alerts.conf is the
# "something broke" address, this is a periodic informational report someone
# may well want sent elsewhere (or nowhere). Unset falls back to alerts.conf,
# so a host that already configured alerts needs no second setting.
REPORT_CONF=/etc/ilexa/hu-classify-report.conf
WEIGHTS_FILE=/etc/rspamd/local.d/hu_classify.weights
MEASURE_JSON=/var/lib/ilexa/hu-classify-measurement.json
REPORT_BIN=/usr/local/sbin/qa-hu-classify-report.py
# Only these may ever be given a weight. The two *_LANGUAGE symbols are
# deliberately absent: language identity is not evidence of spam however
# well it correlates, and scoring it would penalise an entire language.
WEIGHTABLE="HU_NATURALNESS EN_NATURALNESS HU_SPAM"
ALERTS_CONF=/etc/ilexa/alerts.conf
ENABLED_SINCE_FILE=/etc/rspamd/local.d/hu_classify.enabled_since
SERVICE=hu-classify-stub.service
STUB_BIN=/usr/local/sbin/hu-classify-stub.py

action="${1:-}"

case "$action" in
    status)
        installed=false
        [ -x "$STUB_BIN" ] && installed=true

        en=false
        if [ -r "$STATE_FILE" ] && [ "$(tr -d '[:space:]' < "$STATE_FILE" 2>/dev/null)" = enabled ]; then
            en=true
        fi

        svc_active=false
        systemctl is-active --quiet "$SERVICE" 2>/dev/null && svc_active=true
        svc_enabled=false
        systemctl is-enabled --quiet "$SERVICE" 2>/dev/null && svc_enabled=true

        # All symbols run in shadow mode (score=0.0) for a while after being
        # turned on -- enough real traffic has to pass through before it
        # makes sense to judge whether any of them deserve a real weight.
        # This is the one clock for that, independent of the console's own
        # session: a plain epoch timestamp on disk, not anything Claude-side.
        since=""
        days=""
        if [ -r "$ENABLED_SINCE_FILE" ]; then
            since=$(tr -d '[:space:]' < "$ENABLED_SINCE_FILE" 2>/dev/null)
            if [ -n "$since" ] && [ "$since" -eq "$since" ] 2>/dev/null; then
                days=$(( ( $(date +%s) - since ) / 86400 ))
            else
                since=""
            fi
        fi

        # Effective recipient: explicit setting, else the alerts address, else
        # none. "inherited" lets the console show WHERE the address came from
        # instead of implying the operator typed it here.
        rcpt=""; rsrc="none"
        if [ -r "$REPORT_CONF" ]; then
            rcpt=$(grep -vE '^\s*#|^\s*$' "$REPORT_CONF" 2>/dev/null | head -1 | tr -d '[:space:]')
            [ -n "$rcpt" ] && rsrc="explicit"
        fi
        if [ -z "$rcpt" ] && [ -r "$ALERTS_CONF" ]; then
            rcpt=$(grep -vE '^\s*#|^\s*$' "$ALERTS_CONF" 2>/dev/null | head -1 | tr -d '[:space:]')
            [ -n "$rcpt" ] && rsrc="inherited"
        fi

        last_report=""
        [ -r /var/lib/ilexa/hu-classify-report.last ] && \
            last_report=$(tr -d '\n' < /var/lib/ilexa/hu-classify-report.last | cut -c1-40)

        printf '{"installed":%s,"enabled":%s,"service_active":%s,"service_enabled":%s,"enabled_since":%s,"days_enabled":%s,"report_email":"%s","report_email_source":"%s","last_report":"%s"}\n' \
            "$installed" "$en" "$svc_active" "$svc_enabled" "${since:-null}" "${days:-null}" \
            "$rcpt" "$rsrc" "$last_report"
        ;;
    set)
        want="${2:-}"
        if [ ! -x "$STUB_BIN" ]; then
            echo "ERROR: hu-classify-stub.py not installed on this host"
            exit 1
        fi
        case "$want" in
            on)
                # Only stamp a fresh enabled_since on an actual off->on
                # transition -- pressing "on" while already on must not
                # reset an in-progress observation window.
                was_enabled=false
                if [ -r "$STATE_FILE" ] && [ "$(tr -d '[:space:]' < "$STATE_FILE" 2>/dev/null)" = enabled ]; then
                    was_enabled=true
                fi
                # systemctl's own "Created symlink ..." chatter must not land
                # on this script's stdout: the console checks the reply with
                # str_starts_with($out, 'OK'), so any line ahead of "OK: ..."
                # -- even from a SUCCESSFUL enable --now -- makes a working
                # toggle look like a failure. Capture it into a variable and
                # only surface it if the command actually failed.
                if ! svc_out=$(systemctl enable --now "$SERVICE" 2>&1); then
                    echo "ERROR: failed to start $SERVICE: $svc_out"
                    exit 1
                fi
                printf 'enabled\n' > "$STATE_FILE"
                chmod 644 "$STATE_FILE"
                if [ "$was_enabled" = false ]; then
                    date +%s > "$ENABLED_SINCE_FILE"
                    chmod 644 "$ENABLED_SINCE_FILE"
                fi
                echo "OK: Hungarian classifier enabled"
                ;;
            off)
                # Flip the Lua-side gate first so no message hits a service
                # that's about to disappear mid-request, then reclaim the RAM.
                printf 'disabled\n' > "$STATE_FILE"
                chmod 644 "$STATE_FILE"
                # Turning it off ends the observation window, not pauses it --
                # re-enabling later starts a fresh one rather than resuming a
                # count that skipped a gap of unmeasured time.
                rm -f "$ENABLED_SINCE_FILE"
                systemctl disable --now "$SERVICE" >/dev/null 2>&1
                echo "OK: Hungarian classifier disabled"
                ;;
            *)
                echo "ERROR: expected on|off"
                exit 1
                ;;
        esac
        ;;
    weights)
        # Current weights as JSON, for the console panel.
        first=1; printf '{'
        for sym in $WEIGHTABLE; do
            v=0
            [ -r "$WEIGHTS_FILE" ] && v=$(grep -E "^\s*${sym}\s*=" "$WEIGHTS_FILE" 2>/dev/null | tail -1 | sed 's/.*=//' | tr -d '[:space:]')
            [ -n "$v" ] || v=0
            [ $first -eq 1 ] || printf ','
            printf '"%s":%s' "$sym" "$v"; first=0
        done
        printf '}\n'
        ;;
    weight)
        # set <SYMBOL> <value>. Rewrites the whole file from the known symbol
        # list rather than editing in place: this script owns the file
        # outright, so regenerating it cannot lose or corrupt another
        # writer's content -- there is no other writer.
        sub="${2:-}"; sym="${3:-}"; val="${4:-}"
        [ "$sub" = set ] || { echo "ERROR: expected 'weight set <SYMBOL> <value>'"; exit 1; }
        case " $WEIGHTABLE " in
            *" $sym "*) ;;
            *) echo "ERROR: $sym is not a weightable symbol"; exit 1 ;;
        esac
        # Range cap: this writes a live spam score. rspamd rejects at 15, so
        # anything approaching that from one experimental signal could reject
        # mail on its own. Bounded well below, both directions.
        if ! printf '%s' "$val" | grep -qE '^-?([0-4](\.[0-9]+)?|5(\.0+)?)$'; then
            echo "ERROR: weight must be a number between -5 and 5"
            exit 1
        fi
        install -d -m 0755 "$(dirname "$WEIGHTS_FILE")"
        tmp=$(mktemp)
        { echo "# Per-symbol weights for lua.local.d/hu_classify.lua."
          echo "# Managed from the console's Rendszer page; nothing else writes here."
          echo "# 0 = shadow mode (logged, no effect on the verdict)."
          for w in $WEIGHTABLE; do
              cur=0
              [ -r "$WEIGHTS_FILE" ] && cur=$(grep -E "^\s*${w}\s*=" "$WEIGHTS_FILE" 2>/dev/null | tail -1 | sed 's/.*=//' | tr -d '[:space:]')
              [ -n "$cur" ] || cur=0
              [ "$w" = "$sym" ] && cur="$val"
              printf '%s=%s\n' "$w" "$cur"
          done; } > "$tmp"
        install -m 0644 "$tmp" "$WEIGHTS_FILE"; rm -f "$tmp"
        # The score is fixed when rspamd registers the symbol, so unlike the
        # on/off switch this genuinely needs a restart -- and a restart, not
        # a reload, per the reload-doesn't-respawn-every-worker finding.
        if ! rspamadm configtest >/dev/null 2>&1; then
            echo "ERROR: rspamd configtest failed after writing $WEIGHTS_FILE"
            exit 1
        fi
        systemctl restart rspamd >/dev/null 2>&1
        echo "OK: $sym weight set to $val"
        ;;
    measure)
        # Re-measure in the background: it reads thousands of messages
        # through the doveadm gateway and takes minutes, far past any web
        # request. Same pattern the feed refresh already uses -- start it,
        # tell the operator to come back, never block the page.
        [ -x "$REPORT_BIN" ] || { echo "ERROR: $REPORT_BIN not installed"; exit 1; }
        if pgrep -f "qa-hu-classify-report.py" >/dev/null 2>&1; then
            echo "OK: already running"
            exit 0
        fi
        nohup nice -n 15 ionice -c3 /opt/hu-classify/venv/bin/python3 "$REPORT_BIN" --dry-run \
            >> /var/log/quarantine-admin/hu-classify-report.log 2>&1 &
        echo "OK: measurement started"
        ;;
    report-email)
        # get | set <address> | clear. Validation mirrors qa-alerts-config.sh:
        # this address is handed to `mail`, so it must never be operator prose.
        sub="${2:-}"
        case "$sub" in
            get)
                [ -r "$REPORT_CONF" ] || exit 0
                grep -vE '^\s*#|^\s*$' "$REPORT_CONF" | head -1 | tr -d '[:space:]'
                ;;
            set)
                addr="${3:-}"
                if ! printf '%s' "$addr" | grep -qE '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'; then
                    echo "ERROR: not a valid email address"
                    exit 1
                fi
                mkdir -p "$(dirname "$REPORT_CONF")"
                { echo "# Recipient for the ilexa language-classifier retrain report."
                  echo "# Managed from the console's Rendszer page (qa-hu-classify.sh report-email)."
                  echo "# Remove this file to fall back to /etc/ilexa/alerts.conf."
                  printf '%s\n' "$addr"; } > "$REPORT_CONF"
                chmod 644 "$REPORT_CONF"
                echo "OK: report recipient set"
                ;;
            clear)
                rm -f "$REPORT_CONF"
                echo "OK: report recipient cleared (falls back to the alert address)"
                ;;
            *)
                echo "ERROR: expected get|set|clear"
                exit 1
                ;;
        esac
        ;;
    *)
        echo "ERROR: unknown action: ${action}"
        exit 1
        ;;
esac
