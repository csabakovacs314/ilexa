#!/bin/bash
#
# Daily brand-guard review: which senders the BRAND_* symbols scored, and
# which of them look like false positives.
#
# WHY THIS EXISTS: the guard ships with deliberately strict scoring (a lure
# phrase alongside any brand signal reaches the spam tag), so the thing that
# needs watching is not "did it fire" but "did it fire on legitimate mail".
# Doing that by hand means reconstructing the same arithmetic every time, and
# the first manual pass got it wrong twice -- see the two notes below.
#
# THE TWO TRAPS THIS ENCODES:
#
# 1. COUNT VERDICTS, NOT LINES. `grep -c BRAND_ rspamd.log` counts the
#    module-registration chatter rspamd logs on every start ("set default
#    score 0 for multimap rule ..."), which after a few restarts dwarfs the
#    real hits. Only rspamd_task_write_log lines are messages.
#
# 2. HEADROOM DECIDES RISK, NOT BRAND POINTS. A sender's non-brand baseline
#    (total score minus the brand symbols) is what says whether it is near the
#    tag threshold. Measured 2026-08-22: szakmaieloadas.hu carried 6.5 brand
#    points and was never at risk (baseline -7.96), while hvg.hu's newsletter
#    carried only 3.0 and was one point from tagging (baseline +0.32). Judging
#    by brand points alone would have whitelisted the wrong senders.
#
# Exit codes are the notification channel (cron-alert.sh mails only non-zero):
#   0   nothing worth a look
#   10  at least one sender was TAGGED ONLY BECAUSE of the brand guard, i.e.
#       its own score was below the threshold and the brand points carried it
#       over. Those are the ones worth a human look; everything else was
#       either spam anyway or safely absorbed.
#   1   the log could not be read
set -uo pipefail

# WHICH LOGS: the newest rotated file PLUS the current one.
#
# rspamd's log rotates at MIDNIGHT (logrotate.timer, daily), so a morning run
# reading only rspamd.log would see a few hours of the new day and miss the
# entire day it is meant to review. The newest .gz holds yesterday; the live
# file holds today so far. An explicit argument overrides both.
if [ $# -ge 1 ]; then
  LOGS=("$@")
else
  LOGS=()
  newest_gz=$(ls -1t /var/log/rspamd/rspamd.log-*.gz 2>/dev/null | head -1)
  [ -n "$newest_gz" ] && LOGS+=("$newest_gz")
  [ -r /var/log/rspamd/rspamd.log ] && LOGS+=(/var/log/rspamd/rspamd.log)
fi
[ ${#LOGS[@]} -gt 0 ] || { echo "qa-brand-review: no rspamd log found" >&2; exit 1; }
TAG_THRESHOLD=$(grep -oE '^[[:space:]]*add_header[[:space:]]*=[[:space:]]*[0-9.]+' \
  /etc/rspamd/local.d/actions.conf 2>/dev/null | grep -oE '[0-9.]+$' | head -1)
TAG_THRESHOLD=${TAG_THRESHOLD:-4}

python3 - "$TAG_THRESHOLD" "${LOGS[@]}" <<'PYEOF'
import re, sys, collections

tag, logs = float(sys.argv[1]), sys.argv[2:]
BRAND = re.compile(r'((?:HU_)?BRAND_[A-Z_]+)\(([-0-9.]+)\)')
VERDICT = re.compile(r'\(default: [A-Z] \(([^)]*)\): \[([-0-9.]+)/')
FROM = re.compile(r'from: <([^>]*)>')
MID = re.compile(r'id: <([^>]*)>')
AUTH = re.compile(r'(R_DKIM_ALLOW|DMARC_POLICY_ALLOW|R_SPF_ALLOW)\(')

def lines(paths):
    import gzip
    for p in paths:
        op = gzip.open if p.endswith('.gz') else open
        try:
            with op(p, 'rt', errors='replace') as fh:
                yield from fh
        except OSError as e:
            print(f"  (skipping {p}: {e})", file=sys.stderr)

rows = []
for line in lines(logs):
    if 'rspamd_task_write_log' not in line or 'BRAND_' not in line:
        continue
    v, f = VERDICT.search(line), FROM.search(line)
    if not v:
        continue
    mid = MID.search(line)
    # Locally injected probes (rspamc tests) are not real traffic.
    if mid and re.search(r'@(example\.com|x\.com|example\.org)>?$', mid.group(1)):
        continue
    syms = BRAND.findall(line)
    brand = sum(float(x) for _, x in syms)
    total = float(v.group(2))
    rows.append({
        'from': f.group(1) if f else '(none)',
        'action': v.group(1), 'total': total, 'brand': brand,
        'base': total - brand, 'auth': bool(AUTH.search(line)),
        'syms': sorted({s for s, _ in syms}),
    })

if not rows:
    print("brand guard: no message scored a BRAND_ symbol in this log.")
    sys.exit(0)

by_sender = collections.defaultdict(list)
for r in rows:
    by_sender[r['from']].append(r)

# What actually matters: did the BRAND GUARD change this message's outcome?
#
#   base >= tag              -> spam on its own merits; brand points are extra
#   base + brand <  tag      -> safe; its own credit absorbs the brand points
#   base < tag <= base+brand -> THE BRAND GUARD DECIDED IT  <- review these
#
# The first version of this script asked "is the sender authenticated and
# carrying brand points", which flagged real phishing: an impersonator signs
# DKIM for its OWN throwaway domain quite happily, and passing DKIM for
# drjeffcunningham.com says nothing about impersonating Granit Bank. It
# reported that rejected phish as a false-positive candidate while burying the
# genuine one. Authentication is still shown, because a brand-decided sender
# that also authenticates is the likeliest true false positive -- but it is
# context, not the test.
decided, spam_anyway, safe = [], 0, 0
for s, rs in by_sender.items():
    worst = max(rs, key=lambda r: r['brand'])
    if worst['base'] >= tag:
        spam_anyway += 1
    elif worst['base'] + worst['brand'] >= tag:
        decided.append((tag - worst['base'], s, len(rs), worst))
    else:
        safe += 1
suspects = decided

blocked = [r for r in rows if r['action'] in ('reject', 'rewrite subject', 'add header')]
print(f"brand guard over {len(logs)} log file(s): {len(rows)} scored message(s) "
      f"from {len(by_sender)} sender(s); {len(blocked)} tagged or rejected. "
      f"tag threshold {tag}")

print(f"  {spam_anyway} sender(s) were over the tag line without any brand points; "
      f"{safe} had enough credit of their own to absorb theirs.")

if suspects:
    print("\nSENDERS THE BRAND GUARD DECIDED (tagged only because of it) -- review:")
    print(f"  {'needed':>7}  {'brand':>5}  {'n':>3}  {'auth':>4}  sender")
    for head, s, n, w in sorted(suspects, key=lambda x: -x[3]['brand']):
        print(f"  {head:>7.1f}  {w['brand']:>5.1f}  {n:>3}  {'yes' if w['auth'] else 'no':>4}  {s}")
        print(f"           {' '.join(w['syms'])}")
    print("\n  needed = how many points the brand guard had to supply to tag it.")
    print("  auth=yes means the sender passes DKIM/SPF/DMARC for its OWN domain,")
    print("  which makes a false positive more likely -- but an impersonator can")
    print("  authenticate for its own throwaway domain too, so read the symbols:")
    print("  a real brand's own mail should be scoring nothing at all here.")

print("\nRejected or tagged with brand points (expected: real impersonation):")
for r in sorted(blocked, key=lambda r: -r['brand'])[:10]:
    print(f"  {r['brand']:>5.1f} brand  {r['action']:<16} {r['total']:>7.2f}  {r['from'][:46]}")

sys.exit(10 if suspects else 0)
PYEOF
