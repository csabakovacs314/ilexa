#!/usr/bin/env python3
"""Feed overlap analysis -- on-demand report of redundancy between the
blocklist/reputation feeds tracked by quarantine-admin's feed-quality
dashboard. Run manually: python3 /root/analyze-feed-overlap.py
Self-test: python3 /root/analyze-feed-overlap.py --selftest

Design: docs/superpowers/specs/2026-08-15-feed-overlap-design.md (quarantine-admin repo).
No sudo needed -- every source file below is world-readable (644 root:root).
"""
import ipaddress
import itertools
import os
import re
import sys
from datetime import datetime, timezone

IP_FEEDS = {
    'otx':         '/etc/firewalld/ipsets/otx_block.xml',
    'c2':          '/etc/firewalld/ipsets/abuse_c2_block.xml',
    'abuseipdb':   '/etc/rspamd/local.d/maps.d/abuseipdb.inc',
    'et':          '/etc/rspamd/local.d/maps.d/emergingthreats.inc',
    'spamhaus':    '/etc/firewalld/ipsets/spamhaus_drop.xml',
    'firehol':     '/etc/rspamd/local.d/maps.d/firehol.inc',
    'dshield':     '/etc/rspamd/local.d/maps.d/dshield.inc',
    'blocklistde': '/etc/rspamd/local.d/maps.d/blocklistde.inc',
}

# Enforcement layer per IP feed -- what a coverage number in the report actually
# means depends on this. A firewall feed drops packets; an rspamd feed only nudges
# a mail score and can be skipped entirely for authenticated/local senders. Mixing
# these without saying so turns "100% covered" into a substitution claim it isn't --
# see the fix-1 brief / design spec for the spamhaus/firehol case this caught.
ENFORCEMENT = {
    'otx':         'firewall (per-service, no port 25)',
    'c2':          'firewall (per-service, no port 25)',
    'spamhaus':    'firewall (all ports)',
    'abuseipdb':   'rspamd score-only (mail traffic, auth/local exempt)',
    'et':          'rspamd score-only (mail traffic, auth/local exempt)',
    'firehol':     'rspamd score-only (mail traffic, auth/local exempt)',
    'dshield':     'rspamd score-only (mail traffic, auth/local exempt)',
    'blocklistde': 'rspamd score-only (mail traffic, auth/local exempt)',
}
HOST_FEEDS = {
    'urlhaus': '/etc/rspamd/local.d/maps.d/urlhaus_hosts.inc',
    'otx_uri': '/etc/rspamd/local.d/maps.d/otx_uri_hosts.inc',
}
# Excluded from pairwise comparison -- see Global Constraints for why each.
GEOBLOCK_PATH  = '/etc/firewalld/ipsets/geoblock.xml'
OTX_DNSBL_PATH = '/var/lib/rbldnsd/otx.rbl'


def _read(path):
    """Returns (text, None) on success, (None, error_str) on any failure.
    Centralises the missing/unreadable/empty checks so both loaders below
    share one error-shape."""
    if not os.path.isfile(path):
        return None, f'{path}: not found'
    try:
        with open(path, 'r', errors='replace') as f:
            raw = f.read()
    except OSError as e:
        return None, f'{path}: {e}'
    if not raw.strip():
        return None, f'{path}: empty'
    return raw, None


def load_ip_feed(path):
    """Parses a firewalld ipset XML (<entry>IP-or-CIDR</entry> per line) or
    an rspamd .inc plain list (one IP/CIDR per line, '#'-comment and blank
    lines skipped -- same filtering feeds-status.sh's _grepc() already
    applies to these exact files). A bare IP becomes a /32 (or /128)
    network so networks_overlap() below can treat every case uniformly.
    Never raises -- returns {'ok': False, 'error': ...} instead."""
    raw, err = _read(path)
    if err:
        return {'ok': False, 'error': err}

    if path.endswith('.xml'):
        lines = re.findall(r'<entry>([^<]+)</entry>', raw)
    else:
        lines = [ln.strip() for ln in raw.splitlines()
                 if ln.strip() and not ln.strip().startswith('#')]

    networks = []
    malformed = 0
    for ln in lines:
        ln = ln.strip()
        if not ln:
            continue
        try:
            networks.append(ipaddress.ip_network(ln, strict=False))
        except ValueError:
            malformed += 1

    if not networks:
        return {'ok': False, 'error': f'{path}: no valid entries parsed ({malformed} malformed lines)'}
    return {'ok': True, 'networks': networks, 'malformed': malformed}


def load_host_feed(path):
    """Plain hostname list, one per line, '#'-comment/blank lines skipped
    (matches the shape /usr/local/sbin/load-urlhaus.sh and /usr/local/sbin/load-otx-uri.sh
    both write). Never raises."""
    raw, err = _read(path)
    if err:
        return {'ok': False, 'error': err}
    hosts = {ln.strip().lower() for ln in raw.splitlines()
             if ln.strip() and not ln.strip().startswith('#')}
    if not hosts:
        return {'ok': False, 'error': f'{path}: no hostnames parsed'}
    return {'ok': True, 'hosts': hosts}


def networks_overlap(a, b):
    """True if two ipaddress networks share any address. Every entry from
    load_ip_feed() is already a network object (a bare IP as /32 or /128),
    so this single predicate covers all three matching cases the design
    calls for: CIDR-vs-CIDR range overlap, IP-vs-CIDR containment, and
    IP-vs-IP exact equality -- the last is just two /32s overlapping only
    each other. IPv4/IPv6 pairs are guarded defensively (ipaddress raises
    TypeError comparing across families); none of today's feeds are IPv6,
    so this branch is not expected to fire, but a crash on unexpected input
    is worse than reporting no overlap for that one pair."""
    if a.version != b.version:
        return False
    return a.overlaps(b)


# Public suffixes that must never be treated as a valid "parent" domain for
# containment purposes -- otherwise any two unrelated hosts sharing one (e.g.
# evil.co.uk and other.co.uk) would wrongly count as covered by each other.
# Mirrors /usr/local/sbin/load-otx-uri.sh's own PUBLIC_SUFFIXES list verbatim -- keep
# these two lists identical if either is ever updated.
PUBLIC_SUFFIXES = {
    "co.uk","org.uk","gov.uk","ac.uk","com.au","net.au","org.au","co.jp","or.jp",
    "co.nz","co.za","com.br","com.cn","com.mx","com.tr","com.ar","co.in","co.kr",
    "com.sg","com.hk","com.tw","co.il","com.ua","com.pl","co.id",
}


def hosts_covered(host, other_set):
    """True if host is exactly present in other_set, or is a subdomain of
    some entry in other_set. Mirrors /usr/local/sbin/load-otx-uri.sh's own parent-
    domain redundancy rule (www.evil.com is covered if evil.com is
    listed). Deliberately asymmetric: a parent domain is NOT considered
    covered just because one of its subdomains is listed."""
    if host in other_set:
        return True
    parts = host.split('.')
    for i in range(1, len(parts) - 1):
        candidate = '.'.join(parts[i:])
        if candidate in PUBLIC_SUFFIXES:
            continue
        if candidate in other_set:
            return True
    return False


def ip_pair_overlap(a_nets, b_nets):
    """Directional coverage in both directions -- see Global Constraints
    for why a single symmetric percentage isn't enough. O(len(a)*len(b));
    the worst real pair here is ~46M checks, measured at 129s (design doc,
    Performance section) -- several minutes for a full 15-pair run is
    accepted as fine for a script run occasionally by hand, so no indexing
    structure is built."""
    a_covered = sum(1 for na in a_nets if any(networks_overlap(na, nb) for nb in b_nets))
    b_covered = sum(1 for nb in b_nets if any(networks_overlap(na, nb) for na in a_nets))
    return {'a_covered': a_covered, 'a_total': len(a_nets),
            'b_covered': b_covered, 'b_total': len(b_nets)}


def host_pair_overlap(a_hosts, b_hosts):
    a_covered = sum(1 for h in a_hosts if hosts_covered(h, b_hosts))
    b_covered = sum(1 for h in b_hosts if hosts_covered(h, a_hosts))
    return {'a_covered': a_covered, 'a_total': len(a_hosts),
            'b_covered': b_covered, 'b_total': len(b_hosts)}


def run_selftest():
    failures = []

    def check(label, got, want):
        if got != want:
            failures.append(f'{label}: got {got!r}, want {want!r}')

    net = lambda s: ipaddress.ip_network(s, strict=False)

    # IP vs IP
    check('exact IP match', networks_overlap(net('1.2.3.4'), net('1.2.3.4')), True)
    check('distinct IPs', networks_overlap(net('1.2.3.4'), net('1.2.3.5')), False)
    # IP vs CIDR
    check('IP inside CIDR', networks_overlap(net('10.0.0.5'), net('10.0.0.0/24')), True)
    check('IP outside CIDR', networks_overlap(net('10.0.1.5'), net('10.0.0.0/24')), False)
    # CIDR vs CIDR
    check('CIDR subset overlap', networks_overlap(net('10.0.0.0/24'), net('10.0.0.128/25')), True)
    check('adjacent CIDRs no overlap', networks_overlap(net('10.0.0.0/24'), net('10.0.1.0/24')), False)
    # Cross-family guard
    check('IPv4 vs IPv6 no overlap', networks_overlap(net('1.2.3.4'), net('::1')), False)

    # Host containment
    check('exact host match', hosts_covered('evil.com', {'evil.com'}), True)
    check('subdomain covered by parent', hosts_covered('www.evil.com', {'evil.com'}), True)
    check('parent NOT covered by subdomain', hosts_covered('evil.com', {'www.evil.com'}), False)
    check('unrelated host', hosts_covered('good.com', {'evil.com'}), False)
    check('public-suffix parent NOT treated as covering', hosts_covered('other.co.uk', {'evil.co.uk'}), False)

    # Loaders: failure paths
    check('missing file', load_ip_feed('/tmp/does-not-exist-analyze-feed-overlap-selftest')['ok'], False)
    check('missing host file', load_host_feed('/tmp/does-not-exist-analyze-feed-overlap-selftest')['ok'], False)

    # Loaders: malformed-line counting, against a real temp file
    import tempfile
    with tempfile.NamedTemporaryFile('w', suffix='.inc', delete=False) as f:
        f.write('# comment\nnot-an-ip\n1.2.3.4\n10.0.0.0/24\n\n')
        tmp_path = f.name
    try:
        result = load_ip_feed(tmp_path)
        check('malformed-line loader ok', result['ok'], True)
        check('malformed-line count', result.get('malformed'), 1)
        check('malformed-line valid count', len(result.get('networks', [])), 2)
    finally:
        os.unlink(tmp_path)

    # Pair overlap directionality: a small set fully inside a larger one
    a = [net('10.0.0.5'), net('10.0.0.6')]
    b = [net('10.0.0.0/24')]
    result = ip_pair_overlap(a, b)
    check('small-in-large a_covered', result['a_covered'], 2)
    check('small-in-large a_total', result['a_total'], 2)
    check('small-in-large b_covered', result['b_covered'], 1)
    check('small-in-large b_total', result['b_total'], 1)

    if failures:
        print(f'SELFTEST FAILED ({len(failures)}):', file=sys.stderr)
        for f in failures:
            print(f'  - {f}', file=sys.stderr)
        return False
    print(f'SELFTEST OK', file=sys.stderr)
    return True


def _skip_note(key, error):
    """otx_uri's file doesn't exist yet because a separate, already-planned
    project produces it and hasn't finished deploying -- this is expected
    today, not an error. Append a clarifying note for that one known-pending
    case only; every other feed's raw loader error is left as-is."""
    if key == 'otx_uri' and 'not found' in error:
        return f'{error} (pending a separate reconnect project, not yet deployed)'
    return error


def build_report():
    lines = []
    now = datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')
    lines.append(f'Feed overlap analysis -- {now}')
    lines.append('=' * (25 + len(now)))
    lines.append('')

    # --- Load every IP feed up front; report load failures once, clearly ---
    loaded = {}
    lines.append('IP feeds:')
    for key, path in IP_FEEDS.items():
        result = load_ip_feed(path)
        loaded[key] = result
        if result['ok']:
            note = f" ({result['malformed']} malformed lines skipped)" if result['malformed'] else ''
            lines.append(f'  {key:<12} {len(result["networks"]):>7,} entries{note}  [{ENFORCEMENT[key]}]')
        else:
            lines.append(f'  {key:<12} SKIPPED -- {result["error"]}')
    lines.append('')

    # --- Pairwise IP overlap, all 21 combinations ---
    lines.append('Pairwise overlap (share of that feed\'s entries also covered by the other):')
    lines.append('')
    for a_key, b_key in itertools.combinations(IP_FEEDS.keys(), 2):
        a, b = loaded[a_key], loaded[b_key]
        if not a['ok'] or not b['ok']:
            reason = a['error'] if not a['ok'] else b['error']
            lines.append(f'  {a_key} <-> {b_key}: SKIPPED -- {reason}')
            continue
        r = ip_pair_overlap(a['networks'], b['networks'])
        a_pct = 100 * r['a_covered'] / r['a_total'] if r['a_total'] else 0
        b_pct = 100 * r['b_covered'] / r['b_total'] if r['b_total'] else 0
        a_layer = ENFORCEMENT[a_key].split(' (')[0]
        b_layer = ENFORCEMENT[b_key].split(' (')[0]
        lines.append(f'  {a_key} <-> {b_key}')
        lines.append(f'    {a_key}: {r["a_covered"]:,}/{r["a_total"]:,} ({a_pct:.1f}%) also covered by {b_key}')
        lines.append(f'    {b_key}: {r["b_covered"]:,}/{r["b_total"]:,} ({b_pct:.1f}%) also covered by {a_key}')
        if a_layer != b_layer:
            lines.append(f'    NOTE: cross-layer comparison ({ENFORCEMENT[a_key]} vs {ENFORCEMENT[b_key]}) '
                          f'-- high coverage here is NOT a substitution claim')
    lines.append('')

    # --- Host overlap: urlhaus vs otx_uri ---
    lines.append('Host feeds:')
    host_loaded = {key: load_host_feed(path) for key, path in HOST_FEEDS.items()}
    for key, result in host_loaded.items():
        if result['ok']:
            lines.append(f'  {key:<12} {len(result["hosts"]):>7,} hosts')
        else:
            lines.append(f'  {key:<12} SKIPPED -- {_skip_note(key, result["error"])}')
    u, o = host_loaded['urlhaus'], host_loaded['otx_uri']
    if u['ok'] and o['ok']:
        r = host_pair_overlap(u['hosts'], o['hosts'])
        u_pct = 100 * r['a_covered'] / r['a_total'] if r['a_total'] else 0
        o_pct = 100 * r['b_covered'] / r['b_total'] if r['b_total'] else 0
        lines.append(f'  urlhaus <-> otx_uri')
        lines.append(f'    urlhaus: {r["a_covered"]:,}/{r["a_total"]:,} ({u_pct:.1f}%) also covered by otx_uri')
        lines.append(f'    otx_uri: {r["b_covered"]:,}/{r["b_total"]:,} ({o_pct:.1f}%) also covered by urlhaus')
    else:
        reason_key, reason = ('urlhaus', u['error']) if not u['ok'] else ('otx_uri', o['error'])
        lines.append(f'  urlhaus <-> otx_uri: SKIPPED -- {_skip_note(reason_key, reason)}')
    lines.append('')

    # --- Explicitly excluded, reported with reasons rather than silently omitted ---
    lines.append('Excluded from pairwise comparison:')
    geo = load_ip_feed(GEOBLOCK_PATH)
    if geo['ok']:
        lines.append(f'  geoblock     {len(geo["networks"]):>7,} entries -- country-level CIDR; '
                      f'pairwise containment against it would mostly measure geography, not '
                      f'threat-intel redundancy (design spec, Scope)')
    else:
        lines.append(f'  geoblock     SKIPPED -- {geo["error"]}')

    dnsbl_raw, dnsbl_err = _read(OTX_DNSBL_PATH)
    otx_result = loaded.get('otx')
    if dnsbl_err:
        lines.append(f'  otx_dnsbl    SKIPPED -- {dnsbl_err}')
    else:
        dnsbl_entry_lines = [ln for ln in dnsbl_raw.splitlines()
                              if ln and not ln.startswith('$') and not ln.startswith(':')]
        otx_n = len(otx_result['networks']) if otx_result and otx_result['ok'] else '?'
        lines.append(f'  otx_dnsbl    {len(dnsbl_entry_lines):>7,} entries -- same AlienVault OTX '
                      f'source as otx ({otx_n} entries), re-exported as a DNSBL zone; not an '
                      f'independent redundancy signal (design spec, Scope)')

    return '\n'.join(lines)


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if run_selftest() else 1)
    print(build_report())
