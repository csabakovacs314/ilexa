#!/bin/bash
#
# Spamhaus DQS (Data Query Service) key control: enable/replace/clear the
# account key that routes Spamhaus RBL + ZRD lookups through rspamd.
#
# Unlike qa-feeds-config.sh's keyed sources, there is no separate keyfile:
# the key is embedded directly in the DNS zone hostnames rspamd queries, so
# it lives in the config file itself.
#
# That file is rbl.d/10-spamhaus-dqs.conf -- NOT rbl.conf. rbl.conf is a
# shared wrapper whose rbls{} block glob-includes rbl.d/*.conf, so each
# feature owns exactly one slice and cannot touch another's. This layout
# exists because the previous one assumed rbl.conf was owned outright by this
# script: on 2026-08-16 a set-key silently destroyed a live Abusix Mail
# Intelligence config (3 rules, its own secret key) and re-enabled a
# deliberately-disabled URIBL_MULTI block, undetected for ~4.5 hours.
#
# Everything here writes/reads/deletes ONLY the slice. rbl.conf is created if
# missing and otherwise never modified, and never deleted.
#
# The slice content below must be kept in sync with the installer's initial
# write in ilexa-installer/modules/40-rspamd.sh -- that one seeds it once at
# install time (matching the OTX_API_KEY convention: modules seed secrets
# directly), this one is the sole writer for every change after install.
#
#   qa-spamhaus-dqs.sh status            JSON: {"has_key":bool,
#                                        "reachable":true|false|null,"state":...}
#                                        Runs the same live probe as `test`, so
#                                        the console can show the source as
#                                        working rather than merely configured.
#   qa-spamhaus-dqs.sh set-key           key on stdin; empty input clears
#                                        (reverts to rspamd's public zones)
#   qa-spamhaus-dqs.sh test              JSON: {"ok":true|false,"detail":"..."}
#                                        live DNS probe against Spamhaus's own
#                                        documented test IP (127.0.0.2 in the
#                                        ZEN zone -- see docs.spamhaus.com,
#                                        "Testing DQS"). Reads the key from
#                                        the slice itself -- never takes it as
#                                        an argument or prints it, matching
#                                        the "web user only learns presence"
#                                        rule the rest of this script follows.
set -uo pipefail

LOCALD=/etc/rspamd/local.d
RBL_CONF="$LOCALD/rbl.conf"          # shared wrapper: created if absent, never edited
RBL_D="$LOCALD/rbl.d"
DQS_CONF="$RBL_D/10-spamhaus-dqs.conf"   # this script's slice -- the only file it writes
# shellcheck disable=SC2016  # $LOCAL_CONFDIR is rspamd's own variable, must stay literal
RBL_GLOB='.include(glob=true,try=true,priority=1,duplicate=merge) "$LOCAL_CONFDIR/local.d/rbl.d/*.conf"'
die() { echo "qa-spamhaus-dqs: $*" >&2; exit 2; }

_reload_rspamd() {
    systemctl is-active --quiet rspamd || return 0
    if rspamadm configtest >/dev/null 2>&1; then
        systemctl reload rspamd
    else
        die "rspamd configtest failed after this change -- reload skipped, check $DQS_CONF"
    fi
}

_ensure_split_layout() {
    # Guarantees the rbl.d/ slice directory exists and rbl.conf glob-includes
    # it, so a slice we write is actually read. Replaces the earlier
    # "refuse if rbl.conf holds foreign content" stopgap, which after the
    # split would grep a wrapper that never contains foreign rules again and
    # so would quietly become dead code that still reads like protection.
    #
    # The failure this guards against now: a host still carrying the old
    # monolithic rbl.conf. There, writing a slice would be a silent no-op --
    # the directory is never included, the new key never takes effect, and
    # the old key stays live with nothing to indicate it. Fail closed.
    mkdir -p "$RBL_D" || die "cannot create $RBL_D"
    chown root:_rspamd "$RBL_D" 2>/dev/null || chown root:root "$RBL_D"
    chmod 0750 "$RBL_D"

    if [ ! -s "$RBL_CONF" ]; then
        umask 027
        printf '%s\n' \
          '# Shared wrapper. Every rbls{} rule lives in its own file under' \
          '# rbl.d/, one per owner, so no feature can overwrite another'"'"'s.' \
          '# Do not add rules here -- add rbl.d/<NN>-<owner>.conf instead.' \
          'rbls {' \
          "  $RBL_GLOB" \
          '}' > "$RBL_CONF" || die "cannot create $RBL_CONF"
        chown root:_rspamd "$RBL_CONF" 2>/dev/null || chown root:root "$RBL_CONF"
        chmod 0640 "$RBL_CONF"
        return 0
    fi

    grep -qF 'local.d/rbl.d/*.conf' "$RBL_CONF" && return 0
    die "$RBL_CONF does not glob-include rbl.d/ -- this host still has the old monolithic layout, so writing a slice would silently have no effect. Migrate it first: move each rbls{} sub-block into its own $RBL_D/<NN>-<owner>.conf and leave rbl.conf containing only the include."
}

_ensure_zrd_weights() {
    touch "$LOCALD/groups.conf"
    grep -q '"SPAMHAUS_ZRD_VERY_FRESH_DOMAIN"' "$LOCALD/groups.conf" && return 0
    cat >> "$LOCALD/groups.conf" <<'EOF'

group "rbl" {
  symbols {
    "SPAMHAUS_ZRD_VERY_FRESH_DOMAIN" {
      weight = 3.0;
      description = "URL/email domain first seen in the last few hours (Spamhaus ZRD)";
    }
    "SPAMHAUS_ZRD_FRESH_DOMAIN" {
      weight = 1.5;
      description = "URL/email domain first seen in the last 24h (Spamhaus ZRD)";
    }
  }
}
EOF
}

_slice_key() {
    [ -s "$DQS_CONF" ] || return 1
    grep -oP 'rbl = "\K[^.]+(?=\.zen\.dq\.spamhaus\.net)' "$DQS_CONF" | head -1
}

# Same three-state probe as qa-abusix.sh's, and for the same reason: "a key is
# configured" is not "the feed works", and the console used to paint the first
# as if it were the second. See that script's _probe for the full rationale --
# in particular why the fallback control query matches the SHAPE of an NS answer
# instead of testing for non-empty output (`dig +short` prints its timeout
# message to stdout and still exits 0, so a dead resolver otherwise looks like a
# successful control and the key gets blamed for a DNS fault).
_probe() {
    local key="$1" name attempt ans
    name="2.0.0.127.${key}.zen.dq.spamhaus.net"
    PROBE_ANS=''; PROBE_STATE=unreachable
    for attempt in 1 2; do
        ans="$(dig +short +time=3 +tries=1 A "$name" 2>/dev/null)"
        if printf '%s' "$ans" | grep -q '^127\.0\.0\.'; then
            PROBE_ANS="$(printf '%s' "$ans" | tr '\n' ' ' | sed 's/ $//')"
            PROBE_STATE=answered
            return 0
        fi
    done
    # The control must name a zone that actually HAS an NS record. dq.spamhaus.net
    # does not -- it answers NOERROR with an empty answer section, which the
    # shape test correctly rejects, so every refused key was being reported as
    # "resolver cannot reach Spamhaus". The zone cut is one label lower.
    if dig +short +time=3 +tries=1 NS zen.dq.spamhaus.net 2>/dev/null \
         | grep -qE '^[a-z0-9][a-z0-9.-]*\.$'; then
        PROBE_STATE=rejected
    else
        PROBE_STATE=unreachable
    fi
    return 1
}

op="${1:-}"

case "$op" in
  status)
    # Keyed on the slice, NOT rbl.conf: after the split rbl.conf always
    # exists (it holds the include), so testing it would report has_key=true
    # even with no key set and the console's panel would lie.
    key="$(_slice_key)" || { printf '{"has_key":false,"reachable":null,"state":"nokey"}\n'; exit 0; }
    if [ -z "$key" ]; then
      printf '{"has_key":true,"reachable":false,"state":"unreadable"}\n'; exit 0
    fi
    if _probe "$key"; then
      printf '{"has_key":true,"reachable":true,"state":"answered"}\n'
    else
      printf '{"has_key":true,"reachable":false,"state":"%s"}\n' "$PROBE_STATE"
    fi
    ;;

  set-key)
    _ensure_split_layout
    key="$(cat)"                      # stdin only - never an argument
    key="${key//[$'\r\n']/}"          # a trailing newline breaks the DNS hostname
    if [ -z "$key" ]; then
        # Delete ONLY our slice. Removing rbl.conf here would take every
        # other owner's rules down with it -- the original incident in
        # mirror image.
        rm -f "$DQS_CONF"
        _reload_rspamd
        echo "OK cleared"
        exit 0
    fi
    umask 027
    tmp="$(mktemp "$RBL_D/.10-spamhaus-dqs.conf.XXXXXX")" || die "mktemp failed"
    # NOTE: no `rbls {` wrapper here. This file is glob-included from INSIDE
    # rbl.conf's own rbls{} block, so the rules sit at top level; wrapping
    # them again would nest an rbls{} inside rbls{} and they would never
    # register (configtest still says "syntax OK" -- see the header).
    cat > "$tmp" <<EOF
# Spamhaus DQS (Data Query Service) -- account key embedded in the zone
# hostname below. local.d MERGES with modules.d/rbl.conf, so only the \`rbl\`
# zone is overridden here; existing symbol/check definitions still apply.
# CONTAINS A SECRET KEY -> kept at 0640 root:_rspamd.
# Managed by qa-spamhaus-dqs.sh -- do not hand-edit, changes are overwritten.
spamhaus {
  rbl = "${key}.zen.dq.spamhaus.net";
}
DBL {
  rbl = "${key}.dbl.dq.spamhaus.net";
}

# Spamhaus ZRD: domain first-seen (registered/reactivated) recently, a
# phishing signal. no_ip + domain-only checks; ignore_defaults so only the
# ZRD symbols fire. Return codes per Spamhaus: 127.0.2.2-4 = very fresh
# (last few hours); 127.0.2.5-24 = fresh (last 24h).
SPAMHAUS_ZRD {
  rbl = "${key}.zrd.dq.spamhaus.net";
  no_ip = true;
  emails_domainonly = true;
  ignore_defaults = true;
  checks = ["urls", "content_urls", "emails", "dkim"];
  returncodes {
    SPAMHAUS_ZRD_VERY_FRESH_DOMAIN = ["127.0.2.2", "127.0.2.3", "127.0.2.4"];
    SPAMHAUS_ZRD_FRESH_DOMAIN = ["127.0.2.5", "127.0.2.6", "127.0.2.7", "127.0.2.8", "127.0.2.9", "127.0.2.10", "127.0.2.11", "127.0.2.12", "127.0.2.13", "127.0.2.14", "127.0.2.15", "127.0.2.16", "127.0.2.17", "127.0.2.18", "127.0.2.19", "127.0.2.20", "127.0.2.21", "127.0.2.22", "127.0.2.23", "127.0.2.24"];
  }
}
EOF
    chown root:_rspamd "$tmp" 2>/dev/null || chown root:root "$tmp"
    chmod 0640 "$tmp"
    mv -f "$tmp" "$DQS_CONF"
    _ensure_zrd_weights
    _reload_rspamd
    echo OK
    ;;

  test)
    # Reads the slice, not rbl.conf -- the key lives in rbl.d/ now, so
    # grepping the wrapper would always come back empty and report a working
    # key as unreadable.
    if [ ! -s "$DQS_CONF" ]; then
      printf '{"ok":false,"detail":"nincs beallitva kulcs"}\n'
      exit 0
    fi
    key="$(_slice_key)"
    if [ -z "$key" ]; then
      printf '{"ok":false,"detail":"a kulcs nem olvashato ki a rbl.d/10-spamhaus-dqs.conf-bol"}\n'
      exit 0
    fi
    # Spamhaus's own documented test: every ZEN-member zone lists 127.0.0.2
    # for exactly this purpose. dig's ANY query type is refused (NOTIMP) by
    # many local resolvers per RFC 8482 -- use A, which is what rspamd itself
    # queries. +time=3 +tries=1 keeps a bad/rate-limited key from hanging the
    # web request for long.
    if _probe "$key"; then
      printf '{"ok":true,"detail":"zen zona valaszolt: %s"}\n' "$PROBE_ANS"
    elif [ "$PROBE_STATE" = rejected ]; then
      printf '{"ok":false,"detail":"a Spamhaus elerheto, de ezt a kulcsot nem szolgalja ki - ervenytelen, korlatozott, vagy lejart"}\n'
    else
      printf '{"ok":false,"detail":"a Spamhaus nevszerverei nem valaszoltak ket probalkozasra sem - a DNS-feloldo nem eri el oket"}\n'
    fi
    ;;

  *) die "usage: status | set-key | test" ;;
esac
