#!/bin/bash
#
# rspamd neural network: status for the console, and the shadow/promote
# switch for its two symbol weights.
#
# WHY A STATUS VIEW EXISTS AT ALL: this module fails silently. An untrained
# ANN and a healthy quiet one look identical from the outside -- NEURAL_*
# simply never fires -- and the reference host sat untrained for two weeks
# without a single sign. Two causes were found 2026-08-22 (balanced-class
# deadlock, and training vectors resetting on any symbol-set change); see the
# header of /etc/rspamd/local.d/neural.conf. Making the counts visible is the
# actual fix; a "train now" button would not have helped.
#
# PROFILE CHURN, made visible on purpose: training vectors are keyed by a
# digest of the SYMBOL LIST, so shipping a new rule starts a fresh empty set
# and orphans the old one. The status output therefore lists EVERY profile and
# marks which one rspamd is currently writing to (detected by growth; see the
# status function for why idle time cannot be used), so
# "the counter went back to zero" reads as an expected consequence rather than
# a bug.
#
# VECTORS ARE DISTINCT, NOT MESSAGES: redis stores them in a SET, so two
# messages that produce the same symbol combination count once. Spam campaigns
# collapse heavily -- 341 archived spam messages yielded 148 distinct vectors
# on the reference host. The status reports what actually counts toward the
# threshold.
#
#   qa-neural-config.sh status              JSON: profiles, vectors, threshold, ANN, weights
#   qa-neural-config.sh promote             restore upstream weights (3.0 / -2.0) + reload
#   qa-neural-config.sh shadow              zero both weights (fire + log, change nothing) + reload
set -uo pipefail

GROUPS_CONF=/etc/rspamd/local.d/groups.conf
NEURAL_CONF=/etc/rspamd/local.d/neural.conf
STAMP=/var/lib/ilexa/neural-trained.stamp
STATE=/var/lib/ilexa/neural-profiles.state
SPAM_W=3.0
HAM_W=-2.0

die() { echo "qa-neural-config: $*" >&2; exit 2; }
command -v redis-cli >/dev/null || die "redis-cli not found"

json_escape() { printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'; }

_weights_shadowed() {
  grep -qE '"NEURAL_SPAM"[^}]*weight[[:space:]]*=[[:space:]]*0(\.0)?[[:space:]]*;' "$GROUPS_CONF" 2>/dev/null
}

_threshold() {
  local mt bias
  mt=$(grep -oE '^[[:space:]]*max_trains[[:space:]]*=[[:space:]]*[0-9]+' "$NEURAL_CONF" 2>/dev/null | grep -oE '[0-9]+$' | head -1)
  bias=$(grep -oE '^[[:space:]]*classes_bias[[:space:]]*=[[:space:]]*[0-9.]+' "$NEURAL_CONF" 2>/dev/null | grep -oE '[0-9.]+$' | head -1)
  echo "${mt:-1000} ${bias:-0}"
}

status() {
  local mt bias minor first_seen ann_keys
  read -r mt bias <<<"$(_threshold)"
  # Smaller class must reach max_trains * (1 - classes_bias); the larger must
  # reach max_trains. Same arithmetic rspamd applies in balanced learn mode.
  minor=$(awk -v m="$mt" -v b="$bias" 'BEGIN{printf "%d", m*(1-b)}')

  # ONE keyspace sweep, not two. redis-cli --scan walks the WHOLE keyspace,
  # and this host's redis holds ~335k Bayes token keys, so a single sweep costs
  # 1.5-4s. Doing one for the ANN keys and another for the training sets made
  # this helper 4.3s and turned the Rendszer page into a 7.7s load. redis-cli's
  # --count flag would reduce the round trips but is broken in this version
  # (it silently returns no keys), so the fix is to sweep once and classify the
  # names locally, plus the cache below.
  local all_keys
  all_keys=$(discover_keys)
  ann_keys=$(printf '%s\n' "$all_keys" | grep -vE '_set$' | grep -E '^rn_' | head -5)
  first_seen=$(cat "$STAMP" 2>/dev/null)

  printf '{"max_trains":%s,"classes_bias":%s,"min_per_class":%s,' "$mt" "$bias" "$minor"
  printf '"trained":%s,' "$([ -n "$ann_keys" ] && echo true || echo false)"
  printf '"first_trained":"%s",' "$(json_escape "${first_seen:-}")"
  printf '"shadow":%s,' "$(_weights_shadowed && echo true || echo false)"
  printf '"profiles":['

  # WHICH PROFILE IS LIVE: rspamd keeps no pointer we can read, and redis
  # OBJECT IDLETIME is useless here because reading a key to measure it resets
  # the idle clock -- every profile then reports 0. So detect the live one by
  # the only thing that distinguishes it: rspamd writes ONLY to the current
  # profile, so it is the one whose counts GROW. Previous counts are kept in a
  # state file and the verdict is sticky, so a quiet hour does not un-identify
  # it. Unknown until something grows, which is honest rather than a guess --
  # and getting this wrong matters: an orphaned profile can show 568/1001 and
  # look finished while the live one sits at 148.
  local first=1
  local -A spam ham
  for k in $(printf '%s\n' "$all_keys" | grep -E '_set$' | sort); do
    local prof card
    prof=$(printf '%s' "$k" | sed -E 's/^rn_(.*)_(spam|ham)_set$/\1/')
    card=$(redis-cli scard "$k" 2>/dev/null | head -1)
    [[ "$card" =~ ^[0-9]+$ ]] || card=0
    case "$k" in *_spam_set) spam["$prof"]=$card ;; *_ham_set) ham["$prof"]=$card ;; esac
  done

  local active=""
  [ -r "$STATE" ] && active=$(grep -m1 '^active=' "$STATE" 2>/dev/null | cut -d= -f2)

  # A remembered profile that no longer exists is not "still active", it is
  # gone. This happens on EVERY successful training round: rspamd stores the
  # model, DELETES the version-N training sets and starts version N+1. Without
  # this the sticky pointer kept naming a deleted profile, no row matched, and
  # the card labelled every set -- including the live one -- as superseded.
  if [ -n "$active" ] && [ -z "${spam[$active]:-}${ham[$active]:-}" ]; then
    active=""
  fi

  for prof in "${!spam[@]}" "${!ham[@]}"; do
    local prev_s prev_h
    prev_s=$(grep -m1 "^${prof}=" "$STATE" 2>/dev/null | cut -d= -f2 | cut -d, -f1)
    prev_h=$(grep -m1 "^${prof}=" "$STATE" 2>/dev/null | cut -d= -f2 | cut -d, -f2)
    if [ -z "${prev_s:-}" ]; then
      # Never seen before. rspamd only creates a training set when it writes
      # to it, so a set that just appeared IS the live one -- no need to wait
      # for a second sample to prove it by growth.
      active=$prof
    elif [ "${spam[$prof]:-0}" -gt "${prev_s:-0}" ] || [ "${ham[$prof]:-0}" -gt "${prev_h:-0}" ]; then
      active=$prof
    fi
  done

  if [ -w "$(dirname "$STATE")" ] 2>/dev/null || mkdir -p "$(dirname "$STATE")" 2>/dev/null; then
    { [ -n "$active" ] && echo "active=$active"
      for prof in "${!spam[@]}"; do echo "${prof}=${spam[$prof]:-0},${ham[$prof]:-0}"; done
    } > "$STATE" 2>/dev/null || true
  fi

  for prof in "${!spam[@]}"; do
    [ $first -eq 1 ] && first=0 || printf ','
    printf '{"profile":"%s","spam":%s,"ham":%s,"current":%s}' \
      "$(json_escape "$prof")" "${spam[$prof]:-0}" "${ham[$prof]:-0}" \
      "$([ "$prof" = "$active" ] && echo true || echo false)"
  done
  printf ']}\n'
}

set_weights() { # spam_weight ham_weight label
  [ -s "$GROUPS_CONF" ] || die "no $GROUPS_CONF"
  grep -q '"NEURAL_SPAM"' "$GROUPS_CONF" || die "no neural symbol block in $GROUPS_CONF"
  cp -a "$GROUPS_CONF" "$GROUPS_CONF.bak" 2>/dev/null || true
  # Rewrite only the two weight numbers, leaving every surrounding comment
  # (which carries the promotion criteria) intact.
  sed -i -E "s/(\"NEURAL_SPAM\"[^}]*weight[[:space:]]*=[[:space:]]*)-?[0-9]+(\.[0-9]+)?/\1$1/; \
             s/(\"NEURAL_HAM\"[^}]*weight[[:space:]]*=[[:space:]]*)-?[0-9]+(\.[0-9]+)?/\1$2/" "$GROUPS_CONF"
  if ! rspamadm configtest >/dev/null 2>&1; then
    mv -f "$GROUPS_CONF.bak" "$GROUPS_CONF" 2>/dev/null
    die "rspamadm configtest failed — weights rolled back, nothing reloaded"
  fi
  systemctl reload rspamd >/dev/null 2>&1 || die "rspamd reload failed"
  rm -f "$STATE_KEYS" 2>/dev/null || true  # force re-discovery after a change
  echo "OK neural weights set to $3 (NEURAL_SPAM=$1 NEURAL_HAM=$2)"
}

# Only DISCOVERY is expensive, so only discovery is cached.
#
# redis-cli --scan walks the entire keyspace, and this host's redis holds
# ~335k Bayes token keys, so one sweep costs 1.5-4s. Doing it on every page
# render made the Rendszer page a 7.7s load. But the sweep only answers "which
# training sets exist"; the numbers themselves are SCARD lookups at ~5ms each.
# So the key NAMES are remembered and re-swept only every DISCOVER_TTL, while
# the counters stay live on every call.
#
# A vanished set forces an immediate re-sweep, which is exactly the case that
# matters: after each training round rspamd deletes the version-N sets and
# creates N+1, so the new generation is picked up at once rather than up to
# DISCOVER_TTL later. A brand-new symbol digest (a rule added or removed) is
# picked up on the next timed sweep.
STATE_KEYS=/var/lib/ilexa/neural-keys.state
DISCOVER_TTL=900

discover_keys() {   # prints one rn_* key per line, sweeping only when needed
  local now age cached stale=0
  now=$(date +%s)
  if [ -s "$STATE_KEYS" ]; then
    age=$(( now - $(stat -c %Y "$STATE_KEYS" 2>/dev/null || echo 0) ))
    [ "$age" -ge "$DISCOVER_TTL" ] && stale=1
    cached=$(grep -E '^rn_' "$STATE_KEYS" 2>/dev/null)
    # Cheap existence check: any remembered key that disappeared means the
    # picture changed underneath us.
    if [ "$stale" = 0 ] && [ -n "$cached" ]; then
      local k
      for k in $cached; do
        [ "$(redis-cli exists "$k" 2>/dev/null | head -1)" = "1" ] || { stale=1; break; }
      done
    fi
    if [ "$stale" = 0 ] && [ -n "$cached" ]; then printf '%s\n' "$cached"; return 0; fi
  fi
  local found
  found=$(redis-cli --scan --pattern 'rn_*' 2>/dev/null)
  mkdir -p "$(dirname "$STATE_KEYS")" 2>/dev/null || true
  printf '%s\n' "$found" > "$STATE_KEYS" 2>/dev/null || true
  printf '%s\n' "$found"
}

case "${1:-}" in
  status)   status ;;
  promote)  set_weights "$SPAM_W" "$HAM_W" promoted ;;
  shadow)   set_weights "0.0" "0.0" shadow ;;
  *) die "usage: status | promote | shadow" ;;
esac
