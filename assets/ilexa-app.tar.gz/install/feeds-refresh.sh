#!/bin/bash
# feeds-refresh.sh - trigger a background feed refresh
# Usage: feeds-refresh.sh <feed_name>
# Always exits 0; prints OK, ALREADY_RUNNING, or ERR_*.

feed="${1:-}"

case "$feed" in
    otx)      script=/usr/bin/update-otx.sh ;;
    otx_uri)  script=/usr/bin/update-otx-uri.sh ;;
    urlhaus)  script=/usr/local/sbin/load-urlhaus.sh ;;
    spamhaus) script=/usr/bin/update-spamhaus-drop.sh ;;
    c2)        script=/usr/bin/update-abuse-c2.sh ;;
    geoblock)  script=/usr/bin/update-geoip.sh ;;
    firehol)   script=/usr/local/sbin/update-firehol.sh ;;
    abuseipdb) script=/usr/local/sbin/update-abuseipdb.sh ;;
    et)        script=/usr/local/sbin/update-et.sh ;;
    rspamd_rules) script=/usr/local/sbin/update-rspamd-community-rules.sh ;;
    yara_forge)  script=/usr/local/sbin/update-yara-forge.sh ;;
    *)        echo "ERR_UNKNOWN_FEED"; exit 0 ;;
esac

# The toggle in /etc/ilexa/feeds.conf previously only affected the UI and the
# `enable` guard (can't enable without a key) -- a disabled source's script
# still ran here, from both the manual Refresh button and every cron entry
# that calls its update-*.sh directly. Refuse here so at least the manual
# path (and anything else that calls this script) is honored; the cron
# entries still bypass this file entirely and are not fixed by this change.
if ! /usr/local/sbin/qa-feeds-config.sh is-enabled "$feed" >/dev/null 2>&1; then
    echo "ERR_DISABLED"
    exit 0
fi

lockfile=/var/lock/feeds-refresh-${feed}.lock
logfile=/var/log/feeds-refresh-${feed}.log

# Non-blocking check: is a previous run still alive?
if [ -f "$lockfile" ]; then
    pid=$(cat "$lockfile" 2>/dev/null)
    if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
        echo "ALREADY_RUNNING"
        exit 0
    fi
    rm -f "$lockfile"
fi

# setsid: new session so it survives FPM worker death / SIGHUP
# nohup: ignore SIGHUP in case parent's session leader exits
# The subshell writes its own PID to lockfile and removes it on exit.
setsid nohup bash -c "
    echo \$\$ > '$lockfile'
    '$script' >> '$logfile' 2>&1
    rm -f '$lockfile'
" </dev/null >>/dev/null 2>&1 &

echo "OK"
