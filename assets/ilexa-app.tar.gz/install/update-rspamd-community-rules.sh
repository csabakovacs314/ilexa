#!/bin/bash
# update-rspamd-community-rules.sh - sync the martinschaible/rspamd-rules
# curated multimap rule-set into rspamd, or empty it when disabled.
#
# Only ever manages /etc/rspamd/local.d/community-rules.d/ -- never touches
# the existing hand-built /etc/rspamd/local.d/multimap.conf's content. That
# file gets exactly one glob-include line added to it, once, at rollout
# (docs/superpowers/plans/2026-08-11-community-rspamd-rules.md Task 3),
# which picks up whatever *.conf files this script places in the
# subdirectory. The upstream repo's own local.d/multimap.conf (its
# orchestration file) is always excluded when staging -- see Step 4.
#
# Usage:
#   update-rspamd-community-rules.sh              real sync/disable
#   update-rspamd-community-rules.sh --dry-run     fetch+stage+report only;
#                                                   never touches LIVE_DIR
#                                                   or reloads, but does
#                                                   create+remove its own
#                                                   staging directory under
#                                                   /etc/rspamd/local.d/ --
#                                                   see the flock below,
#                                                   which serializes this
#                                                   against a concurrent
#                                                   real run
set -uo pipefail

REPO_TARBALL="https://github.com/martinschaible/rspamd-rules/archive/refs/heads/main.tar.gz"
LIVE_DIR=/etc/rspamd/local.d/community-rules.d
OLD_DIR=/etc/rspamd/local.d/community-rules.d.old
NEW_DIR=/etc/rspamd/local.d/community-rules.d.new
LOG=/var/log/feeds-refresh-rspamd_rules.log
SCORE_CAP=5.0

dry_run=0
[ "${1:-}" = "--dry-run" ] && dry_run=1

log() { echo "[$(date '+%F %T')] $*" >>"$LOG"; }

# Sorted "filename sha256" lines for a directory of *.conf files -- empty
# output for an absent or empty directory. Used to detect a genuine no-op
# sync before touching the live directory at all (matches the byte-identical
# no-op check the IP-feed loader established as this app's convention).
_manifest() {
  [ -d "$1" ] || return 0
  find "$1" -maxdepth 1 -name '*.conf' -type f -printf '%f\n' 2>/dev/null | sort | \
    while read -r f; do sha256sum "$1/$f" | awk -v f="$f" '{print f, $1}'; done
}

_reload_rspamd() {
  systemctl reload rspamd
  rc=$?
  if [ "$rc" -ne 0 ]; then
    log "systemctl reload rspamd FAILED (exit $rc)"
    return 1
  fi
  log "rspamd reloaded"
  return 0
}

_has_conf_files() { # dir -> 0 if it contains at least one *.conf file
  [ -d "$1" ] && [ -n "$(find "$1" -maxdepth 1 -name '*.conf' -print -quit 2>/dev/null)" ]
}

# Clamp any positive score above SCORE_CAP down to SCORE_CAP, in place.
# Never touches negative scores (whitelist rules use e.g. -5.0/-1.0/-0.5
# and those reductions are intentional, not something this cap concerns
# itself with). Logs every clamp. Verified against the real upstream
# rule-set: this correctly catches the 4 symbols at 18.0 and 356 at 12.0
# that would otherwise exceed this host's deliberately calibrated
# reject=15 threshold.
_clamp_scores() { # file
    local f="$1" label
    label=$(basename "$f")
    SCORE_CAP="$SCORE_CAP" LABEL="$label" perl -i -pe '
        if (/(score\s*=\s*)(-?[0-9]+\.?[0-9]*)(;)/) {
            my ($pre, $val, $post) = ($1, $2, $3);
            my $cap = $ENV{SCORE_CAP};
            if ($val > $cap) {
                print STDERR "CLAMP $ENV{LABEL}: $val -> $cap\n";
                s/(score\s*=\s*)(-?[0-9]+\.?[0-9]*)(;)/${pre}${cap}${post}/;
            }
        }
    ' "$f" 2>>"$LOG"
}

# Move $1 to $2, refusing if $2 already exists (mv would silently NEST $1
# inside $2 rather than fail or replace -- its own exit status can't
# detect this, since mv returns 0 in that case too) and verifying
# afterward that the move actually landed where expected. Logs CRITICAL
# and returns 1 on any violation; callers must check the return value.
_safe_mv() {
    local src="$1" dst="$2"
    if [ -e "$dst" ]; then
        log "CRITICAL: _safe_mv refused -- $dst already exists (would nest, not replace)"
        return 1
    fi
    if ! mv "$src" "$dst"; then
        log "CRITICAL: mv $src -> $dst failed"
        return 1
    fi
    if [ ! -e "$dst" ] || [ -e "$src" ]; then
        log "CRITICAL: mv $src -> $dst did not land as expected"
        return 1
    fi
    return 0
}

# ── Disabled: empty the directory if it has anything, reload if it changed ──
if ! /usr/local/sbin/qa-feeds-config.sh is-enabled rspamd_rules >/dev/null 2>&1; then
    if _has_conf_files "$LIVE_DIR"; then
        if [ "$dry_run" -eq 1 ]; then
            log "[dry-run] disabled -- would empty $LIVE_DIR"
            exit 0
        fi
        rm -f "$LIVE_DIR"/*.conf
        if rspamadm configtest >/dev/null 2>>"$LOG"; then
            log "emptied $LIVE_DIR (source disabled)"
            _reload_rspamd
            exit $?
        else
            log "configtest failed after emptying $LIVE_DIR -- leaving as-is, NOT reloading"
            exit 1
        fi
    else
        log "disabled, nothing to do"
        exit 0
    fi
fi

# ── Enabled: fetch, extract, sanity-check ───────────────────────────────────
# flock serializes this against any concurrent invocation (a manual
# --dry-run or refresh racing the daily cron) so two runs can never
# collide on the shared $NEW_DIR staging path.
exec 9>/var/lock/update-rspamd-community-rules.lock
flock -n 9 || { log "another run is already in progress -- exiting"; exit 0; }

scratch=$(mktemp -d /tmp/rspamd-community-rules.XXXXXX) || { log "mktemp failed"; exit 1; }
trap 'rm -rf "$scratch"' EXIT

tarball="$scratch/repo.tar.gz"
if ! curl -sfL --max-time 60 -o "$tarball" "$REPO_TARBALL"; then
    log "fetch failed: $REPO_TARBALL"
    exit 1
fi

extract_dir="$scratch/extract"
mkdir -p "$extract_dir"
if ! tar -xzf "$tarball" -C "$extract_dir" 2>>"$LOG"; then
    log "tar extract failed"
    exit 1
fi

# The tarball's top-level entry name includes the branch (e.g.
# "rspamd-rules-main/"), not something to hardcode -- find local.d/ under
# whatever that name turns out to be.
src_local_d=$(find "$extract_dir" -maxdepth 2 -type d -name 'local.d' | head -1)
if [ -z "$src_local_d" ] || ! _has_conf_files "$src_local_d"; then
    log "extracted tarball has no local.d/*.conf files -- aborting, nothing touched"
    exit 1
fi

# ── Stage: only actual multimap rule-definition files ───────────────────────
# Allow-list, not deny-list: upstream's local.d/ also ships non-multimap
# files (e.g. asn.conf, the ASN module's own config) that must never be
# merged into the multimap module by this glob-include. Only files
# matching the rule-definition naming convention are staged; everything
# else (including the upstream's own multimap.conf orchestration file) is
# skipped and logged, so a future upstream restructure is visible in the
# log instead of silently merged into the wrong place.
rm -rf "$NEW_DIR"
mkdir -p "$NEW_DIR"
count=0
skipped=0
for f in "$src_local_d"/*.conf; do
    base=$(basename "$f")
    case "$base" in
        multimap.conf)
            skipped=$((skipped + 1))
            ;;
        multimap.*.conf|_multimap*.conf)
            cp "$f" "$NEW_DIR/$base"
            _clamp_scores "$NEW_DIR/$base"
            count=$((count + 1))
            ;;
        *)
            log "skipped non-multimap file: $base"
            skipped=$((skipped + 1))
            ;;
    esac
done
log "staged $count rule-definition file(s), skipped $skipped non-rule file(s)"

# Defense in depth: confirm the clamp actually worked (belt-and-suspenders
# against a future upstream format change the regex doesn't match).
max_score=$(command grep -rhoP 'score\s*=\s*\K-?[0-9]+\.?[0-9]*' "$NEW_DIR"/*.conf 2>/dev/null | sort -n | tail -1)
if [ -n "$max_score" ] && awk -v m="$max_score" -v c="$SCORE_CAP" 'BEGIN{exit !(m>c)}'; then
    log "ABORT: post-clamp sanity check found a score ($max_score) still above cap ($SCORE_CAP) -- not touching live"
    rm -rf "$NEW_DIR"
    exit 1
fi

if [ "$dry_run" -eq 1 ]; then
    log "[dry-run] would sync $count file(s) into $LIVE_DIR"
    if [ -f "$NEW_DIR/multimap.conf" ]; then
        log "[dry-run] WARNING: multimap.conf exclusion did not work as expected"
    fi
    rm -rf "$NEW_DIR"
    exit 0
fi

# ── No-op check: byte-identical to what's already live? ────────────────────
if [ "$(_manifest "$NEW_DIR")" = "$(_manifest "$LIVE_DIR")" ]; then
    log "no change ($count file(s), content identical to live)"
    touch "$LIVE_DIR"
    rm -rf "$NEW_DIR"
    exit 0
fi

# ── Swap: two-step rename via _safe_mv (a single rename over a non-empty
# dir fails on Linux, and a plain unchecked mv can silently nest instead
# of erroring -- see _safe_mv's comment) ────────────────────────────────
rm -rf "$OLD_DIR"
if [ -d "$LIVE_DIR" ]; then
    _safe_mv "$LIVE_DIR" "$OLD_DIR" || exit 1
fi
_safe_mv "$NEW_DIR" "$LIVE_DIR" || exit 1

if rspamadm configtest >/dev/null 2>>"$LOG"; then
    rm -rf "$OLD_DIR"
    log "synced $count file(s), configtest OK"
    _reload_rspamd
    exit $?
else
    log "configtest FAILED after sync -- rolling back"
    rm -rf "$LIVE_DIR"
    if [ -d "$OLD_DIR" ]; then
        if ! _safe_mv "$OLD_DIR" "$LIVE_DIR"; then
            log "CRITICAL: rollback mv failed -- manual intervention needed, live directory may be missing or inconsistent"
            exit 1
        fi
    else
        mkdir -p "$LIVE_DIR"
    fi
    if rspamadm configtest >/dev/null 2>>"$LOG"; then
        log "rollback verified valid"
        _reload_rspamd
    else
        log "CRITICAL: rollback itself failed configtest -- manual intervention needed"
    fi
    exit 1
fi
