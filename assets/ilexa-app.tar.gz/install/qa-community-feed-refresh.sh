#!/bin/bash
# qa-community-feed-refresh.sh - trigger a background community-feed slot
# refresh. Usage: qa-community-feed-refresh.sh <id> [refresh|provision|teardown|flush]
# Always exits 0; prints OK, ALREADY_RUNNING, ERR_BAD_SLOT, ERR_BAD_MODE, or ERR_MODE_FAILED.

# Byte-wise, locale-independent matching. Without this, [[ =~ ]]'s [1-9]
# collates non-ASCII digits (e.g. Arabic-Indic U+0667) as matches under a
# UTF-8 locale, and the guard below then falls through when the numeric
# comparison errors on them.
export LC_ALL=C
#
# Unlike feeds-refresh.sh, this does NOT pre-check whether the slot is
# enabled: the Admin tab only ever shows a Refresh button for a slot that
# is already both configured and enabled (matching the existing feeds
# panel's own guard), and qa-community-feed-loader.php itself silently
# no-ops a disabled/unconfigured slot -- duplicating that check here in
# shell against the same JSON config file would just be a second place
# for the same logic to drift, for a path the UI doesn't expose anyway.

slot="${1:-}"
mode="${2:-refresh}"

# Independent id validation -- this must hold even if the web layer is
# compromised, since $slot reaches a firewall-cmd argument downstream.
# ^[1-9][0-9]*$ rejects '', '0', '01', '-1', '1.5', '1e3', and anything
# containing whitespace or shell metacharacters; the numeric compare then
# enforces the ceiling. Keep this in sync with COMMUNITY_FEED_MAX_ID in the
# lib (id ceiling, not the separate live-feed cap -- see that constant's
# comment in qa-community-feed-lib.php).
# Length check FIRST: [ -gt ] errors (exit 2, i.e. falsy) on a numeral too
# large to parse, which would make this whole condition fall through instead
# of rejecting. Four digits is the widest a valid id can be (ceiling 9999).
if ! [[ "$slot" =~ ^[1-9][0-9]*$ ]] || [ "${#slot}" -gt 4 ] || [ "$slot" -gt 9999 ]; then
    echo "ERR_BAD_SLOT"; exit 0
fi

case "$mode" in
    refresh|provision|teardown|flush) ;;
    *) echo "ERR_BAD_MODE"; exit 0 ;;
esac

# Lifecycle modes are fast and must complete before the caller redirects, so
# they run synchronously -- unlike a refresh, which fetches over the network
# and is backgrounded below.
if [ "$mode" != "refresh" ]; then
    if /usr/local/sbin/qa-community-feed-loader.php "$slot" "$mode" >>"/var/log/community-feed-refresh-${slot}.log" 2>&1; then
        echo "OK"
    else
        echo "ERR_MODE_FAILED"
    fi
    exit 0
fi

lockfile="/var/lock/community-feed-refresh-${slot}.lock"
logfile="/var/log/community-feed-refresh-${slot}.log"

if [ -f "$lockfile" ]; then
    pid=$(cat "$lockfile" 2>/dev/null)
    if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
        echo "ALREADY_RUNNING"
        exit 0
    fi
    rm -f "$lockfile"
fi

setsid nohup bash -c "
    echo \$\$ > '$lockfile'
    /usr/local/sbin/qa-community-feed-loader.php '$slot' >> '$logfile' 2>&1
    rm -f '$lockfile'
" </dev/null >>/dev/null 2>&1 &

echo "OK"
