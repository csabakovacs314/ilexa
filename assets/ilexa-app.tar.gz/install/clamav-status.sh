#!/bin/bash
# ClamAV status JSON for quarantine-admin web UI.
# Run via sudo as root from apache.

DB_DIR="/var/lib/clamav"
USER_CONF="/etc/clamav-unofficial-sigs/user.conf"
MASTER_CONF="/etc/clamav-unofficial-sigs/master.conf"
NOW=$(date +%s)

# ── is clamav-unofficial-sigs present at all? ────────────────────────────────
# It is an EPEL package on EL and is NOT available on current Debian/Ubuntu
# (see 35-clamav.sh in the installer for why), so on those hosts neither conf
# file exists. Every "unofficial sigs" field below is derived from those two
# files with a built-in fallback -- default_dbs_rating falls back to MEDIUM and
# each source's *_enabled falls back to yes -- so on a host WITHOUT the package
# this script used to report nine third-party signature sources active at
# MEDIUM when in fact not one third-party signature was installed. That is a
# false security-posture claim, so report the absence explicitly and emit empty
# values for everything that would otherwise be invented.
UNOFFICIAL_INSTALLED=false
if [ -f "$MASTER_CONF" ] || [ -f "$USER_CONF" ]; then
    UNOFFICIAL_INSTALLED=true
fi

jbool() { [ "$1" = "yes" ] || [ "$1" = "true" ] || [ "$1" = "1" ] && echo "true" || echo "false"; }
jstr()  { printf '"%s"' "$(echo "$1" | sed 's/\\/\\\\/g;s/"/\\"/g')"; }
jint()  { printf '%d' "${1:-0}" 2>/dev/null || echo 0; }

# ── daemon ───────────────────────────────────────────────────────────────────
# The unit name is NOT the same on every platform: EL packages the daemon as
# the templated clamd@scan, Debian/Ubuntu as clamav-daemon. Checking only the
# EL name made the console report ClamAV as down on Debian while it was
# running perfectly -- verified on both a live EL host (clamd@scan active,
# clamav-daemon inactive) and a live Ubuntu 24.04 host (the exact reverse).
DAEMON_ACTIVE=false
for _unit in clamd@scan clamav-daemon clamd; do
    if systemctl -q is-active "$_unit" 2>/dev/null; then DAEMON_ACTIVE=true; break; fi
done

CLAM_VERSION=""
if v=$(clamdscan --version 2>/dev/null | head -1); then
    CLAM_VERSION=$(echo "$v" | awk '{print $2}' | cut -d/ -f1)
fi

# ── official DB (daily.cld or daily.cvd) ─────────────────────────────────────
# freshclam ships the full database as daily.cvd and writes daily.cld once it
# starts applying incremental diffs, so WHICH ONE EXISTS depends on how the
# host has updated so far -- a fresh install has only .cvd. Looking solely for
# .cld reported "no database" (version blank, age -1) on any freshly-installed
# host even with a perfectly current 25MB daily.cvd sitting right there.
# Prefer .cld when both exist: that is the one freshclam is keeping current.
DB_VERSION=""; DB_SIGS=""; DB_BUILD=""
DAILY_AGE=-1; DAILY_UPDATED=""
DAILY_DB=""
for _db in "$DB_DIR/daily.cld" "$DB_DIR/daily.cvd"; do
    [ -f "$_db" ] && { DAILY_DB="$_db"; break; }
done
if [ -n "$DAILY_DB" ]; then
    if info=$(sigtool --info "$DAILY_DB" 2>/dev/null); then
        DB_VERSION=$(echo "$info" | grep "^Version:" | awk '{print $2}')
        DB_SIGS=$(echo "$info" | grep "^Signatures:" | awk '{print $2}')
        DB_BUILD=$(echo "$info" | grep "^Build time:" | cut -d: -f2- | xargs)
    fi
    MT=$(stat -c %Y "$DAILY_DB")
    DAILY_AGE=$((NOW - MT))
    DAILY_UPDATED=$(date -d "@$MT" "+%Y-%m-%d %H:%M" 2>/dev/null)
fi

# ── unofficial sigs: last run (newest mtime across junk.ndb / porcupine.ndb) ─
UNOFFICIAL_AGE=-1; UNOFFICIAL_UPDATED=""
for f in "$DB_DIR/junk.ndb" "$DB_DIR/porcupine.ndb" "$DB_DIR/blurl.ndb"; do
    [ -f "$f" ] || continue
    MT=$(stat -c %Y "$f")
    if [ $UNOFFICIAL_AGE -lt 0 ] || [ $MT -gt $((NOW - UNOFFICIAL_AGE)) ]; then
        UNOFFICIAL_AGE=$((NOW - MT))
        UNOFFICIAL_UPDATED=$(date -d "@$MT" "+%Y-%m-%d %H:%M" 2>/dev/null)
    fi
done

# ── parse a key=value conf (last definition wins, strips quotes) ──────────────
get_conf() {
    local file="$1" key="$2"
    grep -E "^${key}=" "$file" 2>/dev/null | tail -1 | \
        sed 's/[^=]*=//;s/#.*//' | tr -d '"'"'" | xargs 2>/dev/null
}

# ── effective rating: user.conf overrides master.conf ────────────────────────
DEFAULT_RATING=""
if [ "$UNOFFICIAL_INSTALLED" = true ]; then
    DEFAULT_RATING=$(get_conf "$MASTER_CONF" "default_dbs_rating")
    [ -z "$DEFAULT_RATING" ] && DEFAULT_RATING="MEDIUM"
    U=$(get_conf "$USER_CONF" "default_dbs_rating")
    [ -n "$U" ] && DEFAULT_RATING="$U"
fi

YARA_ENABLED=false
YR=$(get_conf "$USER_CONF" "enable_yararules")
[ -z "$YR" ] && YR=$(get_conf "$MASTER_CONF" "enable_yararules")
[ "$YR" = "yes" ] && YARA_ENABLED=true

# ── per-source ratings ────────────────────────────────────────────────────────
src_rating() {
    local src="$1"
    local u m
    u=$(get_conf "$USER_CONF" "${src}_dbs_rating")
    [ -n "$u" ] && echo "$u" && return
    m=$(get_conf "$MASTER_CONF" "${src}_dbs_rating")
    [ -n "$m" ] && echo "$m" && return
    echo "$DEFAULT_RATING"
}
src_master_enabled() {
    local v; v=$(get_conf "$MASTER_CONF" "${1}_enabled")
    [ -z "$v" ] && v="yes"
    jbool "$v"
}
src_user_override() {
    local u; u=$(get_conf "$USER_CONF" "${1}_dbs_rating")
    [ -n "$u" ] && echo "true" || echo "false"
}

# sources: key|label
SOURCES=(
    "sanesecurity|Sanesecurity"
    "securiteinfo|SecuriteInfo"
    "interserver|InterServer"
    "linuxmalwaredetect|Linux Malware Detect"
    "malwareexpert|Malware Expert"
    "malwarepatrol|Malware Patrol"
    "urlhaus|URLhaus"
    "ditekshen|Ditekshen"
    "twinclams|TwinClams"
)

printf '{'
printf '"daemon_active":%s,' "$DAEMON_ACTIVE"
printf '"clam_version":%s,' "$(jstr "$CLAM_VERSION")"
printf '"db_version":%s,' "$(jstr "$DB_VERSION")"
printf '"db_sigs":%s,' "$(jint "$DB_SIGS")"
printf '"db_build":%s,' "$(jstr "$DB_BUILD")"
printf '"daily_age":%s,' "$(jint "$DAILY_AGE")"
printf '"daily_updated":%s,' "$(jstr "$DAILY_UPDATED")"
printf '"unofficial_age":%s,' "$(jint "$UNOFFICIAL_AGE")"
printf '"unofficial_updated":%s,' "$(jstr "$UNOFFICIAL_UPDATED")"
printf '"default_rating":%s,' "$(jstr "$DEFAULT_RATING")"
printf '"yara_enabled":%s,' "$YARA_ENABLED"
printf '"unofficial_installed":%s,' "$UNOFFICIAL_INSTALLED"
printf '"sources":{'

first=true
[ "$UNOFFICIAL_INSTALLED" = true ] || SOURCES=()
for entry in "${SOURCES[@]}"; do
    key="${entry%%|*}"
    label="${entry#*|}"
    rating=$(src_rating "$key")
    master_en=$(src_master_enabled "$key")
    user_ovr=$(src_user_override "$key")
    [ "$first" = true ] && first=false || printf ','
    printf '"%s":{"label":%s,"master_enabled":%s,"rating":%s,"user_override":%s}' \
        "$key" "$(jstr "$label")" "$master_en" "$(jstr "$rating")" "$user_ovr"
done
printf '}}'
