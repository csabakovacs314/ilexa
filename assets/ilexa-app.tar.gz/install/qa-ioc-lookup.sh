#!/bin/bash
#
# On-demand reputation lookups for the IOC store -- now a shim.
#
# The implementation moved to qa-ioc-lookup.php (see
# docs/superpowers/specs/2026-08-27-ioc-lookup-php-port-design.md): apache
# hands this helper an IOC value that came out of a mail body, and PHP
# builds no command line to quote wrong, needs no jq fork per field, and can
# tell a broken DNS zone from a clean one.
#
# This file keeps the NAME because that is what /etc/sudoers.d grants the web
# user, and nothing reconciles a host's sudoers against
# install/sudoers.example -- the one-click update reinstalls helpers but never
# touches sudo. Repointing the console at the .php would therefore have
# needed a manual edit on every existing host; keeping the granted path
# stable makes this an ordinary file update with an ordinary rollback.
#
# Contract, unchanged: exactly one JSON object on stdout on every path,
# exit 0 on success, 1 on error.
set -uo pipefail

TARGET=/usr/local/sbin/qa-ioc-lookup.php

# Fail inside the contract rather than outside it: an exec that cannot find
# its target prints a shell error to stderr and nothing to stdout, which the
# console reports as "could not reach the service" -- true but useless. This
# says what is actually wrong.
if [ ! -x "$TARGET" ]; then
    printf '{"error":"lookup helper not installed: %s"}\n' "$TARGET"
    exit 1
fi

exec "$TARGET" "$@"
