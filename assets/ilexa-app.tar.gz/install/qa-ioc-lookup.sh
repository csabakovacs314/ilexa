#!/bin/bash
#
# On-demand reputation lookups for the IOC store (VirusTotal, URLhaus, OTX, HRBL, Mailspike, ThreatFox).
#
# apache has no read access to any API key -- this script does the external
# call itself (curl for the API-based services, dig for HRBL/Mailspike's
# DNS-only zones), as root, and prints exactly one JSON object to stdout on
# every path (success or failure) so the caller never has to distinguish
# stdout from stderr to get an error message.
#
# Usage:
#   qa-ioc-lookup.sh <service> <type> <value>
#     service: virustotal | urlhaus | otx | hrbl | mailspike | urlvet | yaraify | threatfox
#     type:    ip | domain | url | hash   (hrbl: ip/domain; mailspike: ip only;
#              urlvet: url/domain; ip IPv4-only)
#
set -uo pipefail

VT_KEY_FILE=/etc/ilexa/secrets/vt_api_key
ABUSE_KEY_FILE=/etc/ilexa/secrets/abuse_api_key
OTX_KEY_FILE=/etc/ilexa/secrets/otx_api_key
TIMEOUT=15
# api.url.vet is public (no key). This is LONGER than the shared TIMEOUT
# because a non-resolving domain takes urlvet ~31s to give up on, and it
# does NOT cache incomplete analyses -- measured 2026-08-15 on
# paypal-secure-login.tk: 31.4s direct, then error at a 12s timeout, then
# error again on an immediate retry. A shorter timeout therefore makes dead
# phishing infrastructure -- the commonest thing in an IOC store --
# permanently uncheckable rather than merely slow. PHP's 30s ceiling is
# lifted at the call site (_ioc_lookup_call) instead of capping this.
# (Complete analyses DO cache: kernel.org re-queried in 0.38s after a
# forced 2s abort. The distinction is completeness, not timing.)
URLVET_TIMEOUT=35
# dig's own budget, deliberately shorter than TIMEOUT: a DNSBL zone either
# answers fast or is not going to. Kept separate so the shared TIMEOUT can
# change without silently tripling every DNS wait.
DIG_TIMEOUT=5

emit_error() {
    local msg="$1"
    msg="${msg//\\/\\\\}"
    msg="${msg//\"/\\\"}"
    printf '{"error":"%s"}\n' "$msg"
    exit 1
}

[[ $# -eq 3 || $# -eq 4 ]] \
    || emit_error "usage: qa-ioc-lookup.sh <service> <type> <value> [timeout_seconds]"
service="$1"; type="$2"; value="$3"; timeout_override="${4:-}"

# An optional per-surface timeout (see IOC_LOOKUP_SERVICE_TIMEOUTS in
# src/ioc_lookup.php). Rejected rather than ignored when malformed: a caller
# that asked for a 6s budget must never silently get a 35s one, because the
# whole point is bounding a page that has a 60s proxy ceiling. 60 is that
# ceiling, so a larger value could only ever be cut off by the proxy anyway.
# Applied to TIMEOUT (curl API services), URLVET_TIMEOUT (url.vet), and
# DIG_TIMEOUT (DNSBL zones).
if [[ -n "$timeout_override" ]]; then
    [[ "$timeout_override" =~ ^[0-9]+$ ]] \
        || emit_error "invalid timeout: must be digits only"
    (( timeout_override >= 1 && timeout_override <= 60 )) \
        || emit_error "invalid timeout: must be between 1 and 60 seconds"
fi

case "$service" in
    virustotal) supported="ip domain url hash" ;;
    urlhaus)    supported="domain url hash" ;;
    otx)        supported="ip domain url hash" ;;
    hrbl)       supported="ip domain" ;;
    mailspike)  supported="ip" ;;
    urlvet)     supported="url domain" ;;
    yaraify)    supported="hash" ;;
    threatfox)  supported="ip domain url hash" ;;
    *)          emit_error "unknown service: $service" ;;
esac
[[ " $supported " == *" $type "* ]] || emit_error "service $service does not support type $type"

case "$type" in
    ip)
        if [[ "$value" =~ ^[0-9]{1,3}(\.[0-9]{1,3}){3}$ ]]; then :;
        elif [[ "$value" == *:* && "$value" =~ ^[0-9a-fA-F:]+$ ]]; then :;
        else emit_error "invalid ip"; fi
        ;;
    domain)
        [[ "$value" =~ ^[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?(\.[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?)+$ ]] \
            || emit_error "invalid domain"
        ;;
    url)
        [[ "$value" =~ ^https?://[^[:space:]]+$ ]] || emit_error "invalid url"
        ;;
    hash)
        [[ "$value" =~ ^[A-Fa-f0-9]{32}$ ]] || [[ "$value" =~ ^[A-Fa-f0-9]{40}$ ]] \
            || [[ "$value" =~ ^[A-Fa-f0-9]{64}$ ]] || emit_error "invalid hash"
        ;;
esac

# Applies to whichever service the caller selected: TIMEOUT covers the API
# services, URLVET_TIMEOUT covers urlvet, and DIG_TIMEOUT covers DNSBL zones.
if [[ -n "$timeout_override" ]]; then
    TIMEOUT="$timeout_override"
    URLVET_TIMEOUT="$timeout_override"
    DIG_TIMEOUT="$timeout_override"
fi

if [[ "$service" == "virustotal" ]]; then
    [[ -r "$VT_KEY_FILE" ]] || emit_error "no api key configured"
    key="$(<"$VT_KEY_FILE")"

    case "$type" in
        ip)     endpoint="ip_addresses/$value" ;;
        domain) endpoint="domains/$value" ;;
        hash)   endpoint="files/$value" ;;
        url)    id="$(printf '%s' "$value" | base64 -w0 | tr -d '=' | tr '/+' '_-')"
                endpoint="urls/$id" ;;
    esac

    resp="$(curl -s -m "$TIMEOUT" -H "x-apikey: $key" "https://www.virustotal.com/api/v3/$endpoint")"
    [[ -n "$resp" ]] || emit_error "no response from virustotal"

    stats="$(printf '%s' "$resp" | jq -c '.data.attributes.last_analysis_stats // empty' 2>/dev/null)"
    if [[ -z "$stats" ]]; then
        errmsg="$(printf '%s' "$resp" | jq -r '.error.message // "not found"' 2>/dev/null)"
        emit_error "virustotal: $errmsg"
    fi

    malicious="$(printf '%s' "$stats" | jq -r '.malicious // 0')"
    suspicious="$(printf '%s' "$stats" | jq -r '.suspicious // 0')"
    harmless="$(printf '%s' "$stats" | jq -r '.harmless // 0')"
    undetected="$(printf '%s' "$stats" | jq -r '.undetected // 0')"
    total=$((malicious + suspicious + harmless + undetected))

    if   (( malicious > 0 ));  then verdict=malicious
    elif (( suspicious > 0 )); then verdict=suspicious
    elif (( total > 0 ));      then verdict=clean
    else                            verdict=unknown
    fi
    detail="${malicious}/${total} engines flagged"

    jq -n --arg verdict "$verdict" --arg detail "$detail" --argjson raw "$resp" \
        '{verdict:$verdict, detail:$detail, raw:$raw}'
    exit 0
fi

if [[ "$service" == "urlhaus" ]]; then
    [[ -r "$ABUSE_KEY_FILE" ]] || emit_error "no api key configured"
    key="$(<"$ABUSE_KEY_FILE")"

    case "$type" in
        domain) url="https://urlhaus-api.abuse.ch/v1/host/";    field="host" ;;
        url)    url="https://urlhaus-api.abuse.ch/v1/url/";     field="url" ;;
        hash)   url="https://urlhaus-api.abuse.ch/v1/payload/"; field="sha256_hash" ;;
    esac

    resp="$(curl -s -m "$TIMEOUT" -H "Auth-Key: $key" -d "${field}=${value}" "$url")"
    [[ -n "$resp" ]] || emit_error "no response from urlhaus"

    status="$(printf '%s' "$resp" | jq -r '.query_status // "error"' 2>/dev/null)"
    case "$status" in
        ok)
            sub_status="$(printf '%s' "$resp" | jq -r '.url_status // .signature // "listed"')"
            verdict=malicious
            detail="listed ($sub_status)"
            ;;
        no_results)
            verdict=clean
            detail="not listed"
            ;;
        *)
            emit_error "urlhaus: $status"
            ;;
    esac

    jq -n --arg verdict "$verdict" --arg detail "$detail" --argjson raw "$resp" \
        '{verdict:$verdict, detail:$detail, raw:$raw}'
    exit 0
fi

if [[ "$service" == "yaraify" ]]; then
    # abuse.ch YARAify: which YARA rules match a known sample. Shares the
    # abuse.ch Auth-Key with urlhaus -- one credential, two services.
    #
    # Hash only, by design. YARAify also exposes a file-SCANNING endpoint, which
    # is deliberately not used here: its own documentation says submitted files
    # are shared by default, and uploading customers' mail attachments to a
    # public malware-sharing platform is not something a mail server should do
    # on an operator's behalf.
    [[ -r "$ABUSE_KEY_FILE" ]] || emit_error "no api key configured"
    key="$(<"$ABUSE_KEY_FILE")"

    resp="$(curl -s -m "$TIMEOUT" -H "Auth-Key: $key" -H 'Content-Type: application/json' \
            -d "{\"query\":\"lookup_hash\",\"search_term\":\"${value}\"}" \
            https://yaraify-api.abuse.ch/api/v1/)"
    [[ -n "$resp" ]] || emit_error "no response from yaraify"

    status="$(printf '%s' "$resp" | jq -r '.query_status // "error"' 2>/dev/null)"
    case "$status" in
        ok)
            # Count the matching YARA rules across every scan task, and name the
            # first few: "which rules matched" is far more actionable than a bare
            # verdict, and it is what an analyst wants next.
            hits="$(printf '%s' "$resp" | jq -r '[.data.tasks[]?.static_results[]?.rule_name] | length' 2>/dev/null)"
            [[ "$hits" =~ ^[0-9]+$ ]] || hits=0
            if [[ "$hits" -gt 0 ]]; then
                names="$(printf '%s' "$resp" \
                    | jq -r '[.data.tasks[]?.static_results[]?.rule_name] | unique | .[0:3] | join(", ")' 2>/dev/null)"
                verdict=malicious
                detail="$hits YARA rule(s): ${names}"
            else
                # Known to YARAify but nothing matched: seen, not condemned.
                verdict=unknown
                detail="known sample, no YARA rule matched"
            fi
            ;;
        no_results)
            verdict=clean
            detail="not known to YARAify"
            ;;
        *)
            emit_error "yaraify: $status"
            ;;
    esac

    jq -n --arg verdict "$verdict" --arg detail "$detail" --argjson raw "$resp" \
        '{verdict:$verdict, detail:$detail, raw:$raw}'
    exit 0
fi

if [[ "$service" == "threatfox" ]]; then
    # abuse.ch ThreatFox: shares the same Auth-Key as urlhaus/yaraify. Unlike
    # the abuse_c2_block ipset (load-abuse-c2.sh), which only pulls the
    # "recent" IP:port export, search_ioc queries ThreatFox's FULL indicator
    # database live -- ip/domain/url/hash all included -- so this can hit on
    # an indicator the ipset feed never saw (older, or a non-IP IOC type).
    #
    # search_term is built with jq -n rather than string-interpolated into
    # the JSON body: ip/domain/hash are already regex-validated above to a
    # safe charset, but url's validation (^https?://[^[:space:]]+$) does not
    # exclude a literal double-quote or backslash, and this is the one branch
    # in this script that would otherwise put unescaped IOC-store content
    # inside a hand-built JSON literal (see ioc.md: "IOC data is untrusted").
    #
    # ThreatFox indexes IP IOCs as "ip:port" but its own search matches a bare
    # IP against those entries (confirmed empirically 2026-08-21 against a
    # live abuse_c2_block entry) -- no port-stripping/reformatting needed here.
    [[ -r "$ABUSE_KEY_FILE" ]] || emit_error "no api key configured"
    key="$(<"$ABUSE_KEY_FILE")"

    payload="$(jq -n --arg term "$value" '{query:"search_ioc", search_term:$term}')"
    resp="$(curl -s -m "$TIMEOUT" -H "Auth-Key: $key" -H 'Content-Type: application/json' \
            -d "$payload" https://threatfox-api.abuse.ch/api/v1/)"
    [[ -n "$resp" ]] || emit_error "no response from threatfox"

    status="$(printf '%s' "$resp" | jq -r '.query_status // "error"' 2>/dev/null)"
    case "$status" in
        ok)
            # Multiple IOCs can share one indicator (re-used C&C infra across
            # campaigns) -- take the highest-confidence submission, same
            # "worst-known-verdict wins" idea as VT's malicious-count check.
            top="$(printf '%s' "$resp" | jq -c '.data | max_by(.confidence_level // 0)')"
            conf="$(printf '%s' "$top" | jq -r '.confidence_level // 0')"
            [[ "$conf" =~ ^[0-9]+$ ]] || conf=0
            malware="$(printf '%s' "$top" | jq -r '.malware_printable // .malware // "unknown malware"')"
            threat="$(printf '%s' "$top" | jq -r '.threat_type // "ioc"')"
            # 50 matches TF_MIN_CONF in load-abuse-c2.sh (the ipset feed's own
            # trust floor) -- a lookup result below that line is "known to
            # ThreatFox" but not confident enough to call malicious outright.
            if (( conf >= 50 )); then verdict=malicious; else verdict=suspicious; fi
            detail="${malware} (${threat}, confidence ${conf})"
            ;;
        no_result)
            verdict=clean
            detail="not listed"
            ;;
        *)
            errmsg="$(printf '%s' "$resp" | jq -r '.data // .query_status // "error"' 2>/dev/null)"
            emit_error "threatfox: $errmsg"
            ;;
    esac

    jq -n --arg verdict "$verdict" --arg detail "$detail" --argjson raw "$resp" \
        '{verdict:$verdict, detail:$detail, raw:$raw}'
    exit 0
fi

if [[ "$service" == "otx" ]]; then
    [[ -r "$OTX_KEY_FILE" ]] || emit_error "no api key configured"
    key="$(<"$OTX_KEY_FILE")"

    case "$type" in
        ip)
            if [[ "$value" == *:* ]]; then otx_type="IPv6"; else otx_type="IPv4"; fi
            ;;
        domain) otx_type="domain" ;;
        url)    otx_type="url"; value="$(printf '%s' "$value" | jq -sRr @uri)" ;;
        hash)   otx_type="file" ;;
    esac

    resp="$(curl -s -m "$TIMEOUT" -H "X-OTX-API-KEY: $key" \
        "https://otx.alienvault.com/api/v1/indicators/${otx_type}/${value}/general")"
    [[ -n "$resp" ]] || emit_error "no response from otx"

    count="$(printf '%s' "$resp" | jq -r '.pulse_info.count // empty' 2>/dev/null)"
    if [[ -z "$count" ]]; then
        errmsg="$(printf '%s' "$resp" | jq -r '.detail // .error // "not found"' 2>/dev/null)"
        emit_error "otx: $errmsg"
    fi

    if   (( count >= 3 )); then verdict=malicious
    elif (( count >= 1 )); then verdict=suspicious
    else                        verdict=clean
    fi
    if (( count > 0 )); then
        detail="referenced in ${count} OTX pulses"
    else
        detail="not referenced in any OTX pulses"
    fi

    # $resp for otx can exceed the shell's single-argument length limit
    # (heavily-pulsed indicators easily produce 200KB+ of JSON), which
    # `--argjson raw "$resp"` would silently fail on ("Argument list too
    # long") -- feed it via stdin instead, which has no such limit.
    printf '%s' "$resp" | jq --arg verdict "$verdict" --arg detail "$detail" \
        '{verdict:$verdict, detail:$detail, raw:.}'
    exit 0
fi

if [[ "$service" == "hrbl" ]]; then
    if [[ "$type" == "ip" ]]; then
        [[ "$value" == *:* ]] && emit_error "hrbl: ipv6 not supported"
        IFS='.' read -r o1 o2 o3 o4 <<<"$value"
        query="${o4}.${o3}.${o2}.${o1}.bl.hrbl.hu"
    else
        query="${value}.uribl.hrbl.hu"
    fi

    a_record="$(dig +short +time="$DIG_TIMEOUT" +tries=1 A "$query" 2>/dev/null)"
    dig_rc=$?
    # A dig failure (unreachable resolver, missing binary, timeout) must
    # never be reported as "clean" -- that result gets cached for 24h
    # (see src/ioc_lookup.php/src/list_lookup.php), so a transient DNS
    # problem would otherwise silently masquerade as a real not-listed
    # verdict until the cache expires. +short does not affect dig's exit
    # status, so a non-zero rc here is a genuine lookup failure, not a
    # normal "no record" result (which exits 0 with empty output).
    if (( dig_rc != 0 )); then
        emit_error "hrbl: dns lookup failed (dig exit $dig_rc)"
    elif [[ -z "$a_record" ]]; then
        verdict=clean
        detail="not listed"
    elif [[ "$a_record" == *"127.0.0.2"* ]]; then
        verdict=malicious
        txt="$(dig +short +time="$DIG_TIMEOUT" +tries=1 TXT "$query" 2>/dev/null | tr -d '"' | head -c 200)"
        detail="${txt:-listed on HRBL}"
    else
        verdict=unknown
        detail="unexpected response: $a_record"
    fi

    jq -n --arg verdict "$verdict" --arg detail "$detail" --arg query "$query" --arg a "$a_record" \
        '{verdict:$verdict, detail:$detail, raw:{query:$query, a_record:$a}}'
    exit 0
fi

if [[ "$service" == "mailspike" ]]; then
    [[ "$value" == *:* ]] && emit_error "mailspike: ipv6 not supported"
    IFS='.' read -r o1 o2 o3 o4 <<<"$value"
    query="${o4}.${o3}.${o2}.${o1}.rep.mailspike.net"

    a_record="$(dig +short +time="$DIG_TIMEOUT" +tries=1 A "$query" 2>/dev/null)"
    dig_rc=$?
    if (( dig_rc != 0 )); then
        emit_error "mailspike: dns lookup failed (dig exit $dig_rc)"
    elif [[ -z "$a_record" ]]; then
        verdict=clean
        detail="not listed"
    else
        case "$a_record" in
            *127.0.0.10*) verdict=malicious;  detail="L5 (worst possible reputation)" ;;
            *127.0.0.11*) verdict=malicious;  detail="L4 (very bad reputation)" ;;
            *127.0.0.12*) verdict=malicious;  detail="L3 (bad reputation)" ;;
            *127.0.0.13*) verdict=suspicious; detail="L2 (suspicious behavior)" ;;
            *127.0.0.14*) verdict=suspicious; detail="L1 (neutral, probably spam)" ;;
            *127.0.0.15*) verdict=unknown;    detail="LHO (neutral)" ;;
            *127.0.0.16*) verdict=unknown;    detail="H1 (neutral, probably legitimate)" ;;
            *127.0.0.17*) verdict=clean;      detail="H2 (possible legitimate sender)" ;;
            *127.0.0.18*) verdict=clean;      detail="H3 (good reputation)" ;;
            *127.0.0.19*) verdict=clean;      detail="H4 (very good reputation)" ;;
            *127.0.0.20*) verdict=clean;      detail="H5 (excellent reputation)" ;;
            *)            verdict=unknown;    detail="unexpected response: $a_record" ;;
        esac
    fi

    jq -n --arg verdict "$verdict" --arg detail "$detail" --arg query "$query" --arg a "$a_record" \
        '{verdict:$verdict, detail:$detail, raw:{query:$query, a_record:$a}}'
    exit 0
fi

if [[ "$service" == "urlvet" ]]; then
    # No API key -- api.url.vet is public. --data-urlencode keeps the value
    # out of the query string unescaped (it may contain &, ?, spaces).
    resp="$(curl -s -m "$URLVET_TIMEOUT" --get --data-urlencode "url=$value" \
        "https://api.url.vet/api/v1/analyze")"
    [[ -n "$resp" ]] || emit_error "urlvet: no response within ${URLVET_TIMEOUT}s (the host may not resolve -- url.vet needs ~31s for those)"

    verdict_raw="$(printf '%s' "$resp" | jq -r '.result.verdict // empty' 2>/dev/null)"
    if [[ -z "$verdict_raw" ]]; then
        # A non-JSON body (a proxy error page, an HTML 502, a rate-limit
        # notice) makes jq fail, leaving errmsg EMPTY and producing a bare
        # {"error":"urlvet: "} that tells the operator nothing. Fall back to
        # a trimmed excerpt of whatever actually came back.
        errmsg="$(printf '%s' "$resp" | jq -r '.error // empty' 2>/dev/null)"
        if [[ -z "$errmsg" ]]; then
            errmsg="unexpected response: $(printf '%s' "$resp" | tr -d '\r\n' | head -c 120)"
        fi
        emit_error "urlvet: $errmsg"
    fi

    score="$(printf '%s' "$resp" | jq -r '.result.final_score // 0' 2>/dev/null)"
    # incomplete == some analyzers errored; the response is partial.
    incomplete="$(printf '%s' "$resp" | jq -r '.incomplete // false' 2>/dev/null)"

    # ASYMMETRIC ON PURPOSE: a partial analysis can still say "bad"
    # confidently (the structural signals that fired are valid), but it can
    # NOT say "good" -- the checks that would have flagged it are exactly
    # the ones that failed. Verdicts cache for 24h, so a partial Safe stored
    # as "clean" would mask a real threat until expiry. Same reasoning as
    # the dig-failure guard in the hrbl branch above.
    case "$verdict_raw" in
        Risky)      verdict=malicious ;;
        Suspicious) verdict=suspicious ;;
        Safe)       if [[ "$incomplete" == "true" ]]; then verdict=unknown; else verdict=clean; fi ;;
        *)          verdict=unknown ;;
    esac

    detail="$(printf '%s' "$resp" | jq -r \
        '(.result.reasons.bad_reasons // []) | if length > 0 then join("; ") else empty end' 2>/dev/null)"
    [[ -n "$detail" ]] || detail="${verdict_raw} (${score}/100)"
    [[ "$incomplete" == "true" ]] && detail="${detail} [partial analysis]"

    # Fed via stdin, not --argjson: the response embeds phishtank's raw
    # reply and can exceed the shell's single-argument length limit, which
    # would fail with "Argument list too long" (same fix as the otx branch).
    printf '%s' "$resp" | jq --arg verdict "$verdict" --arg detail "$detail" \
        '{verdict:$verdict, detail:$detail, raw:.}'
    exit 0
fi
