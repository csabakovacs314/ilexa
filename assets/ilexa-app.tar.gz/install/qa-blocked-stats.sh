#!/bin/bash
#
# Count mail blocked before delivery, per layer, from the Postfix log.
#
# Why a log scraper: the archive (always_bcc) only ever sees mail that was
# ACCEPTED. Everything rejected at SMTP -- virus, blocklist, spam score, DNSBL,
# protocol abuse -- never reaches a mailbox, so the only record is maillog.
# maillog is root-only, hence the sudo helper.
#
# Emits JSON with counts for today and for the trailing 7 days.
#   qa-blocked-stats.sh
set -uo pipefail

# The mail log is not in the same place on every platform: EL writes
# /var/log/maillog, Debian/Ubuntu /var/log/mail.log. Hardcoding the EL path
# meant this exited '{}' on Ubuntu, which the dashboard reads as "no data" and
# hides the whole "Blokkolt levelek" card with no error anywhere.
LOG=""
for _c in /var/log/maillog /var/log/mail.log; do
  [ -r "$_c" ] && { LOG="$_c"; break; }
done
[ -n "$LOG" ] || { echo '{}'; exit 0; }

# Rotated logs matter: the card reports a 7-day column, but reading only the
# CURRENT file made "7 nap" identical to "Ma" on any host that rotates inside
# that window -- which is every host here. The reference host rotates weekly
# with delaycompress, so at the moment of writing 7 of its last 7 days lived in
# maillog-20260816 (15MB, not yet gzipped) while the live maillog held under
# two hours. Ubuntu rotates daily into mail.log.1. Either way the 7-day figures
# were really 1-day figures.
#
# Collect the current file plus siblings touched in the last 8 days (one day of
# slack past the window the awk below filters to anyway), newest last so output
# order is chronological. -mtime bounds the work: without it a host with
# "rotate 12" would decompress a quarter of a year to answer for one week.
_dir="$(dirname "$LOG")"; _base="$(basename "$LOG")"
LOGS=()
while IFS= read -r _f; do [ -r "$_f" ] && LOGS+=("$_f"); done < <(
  find "$_dir" -maxdepth 1 -type f \( -name "$_base" -o -name "${_base}[-.]*" \) \
       -mtime -8 2>/dev/null | sort
)
[ "${#LOGS[@]}" -gt 0 ] || LOGS=("$LOG")

# .gz siblings appear as soon as delaycompress lets go of them.
read_logs() {
  local _l
  for _l in "${LOGS[@]}"; do
    case "$_l" in
      *.gz) zcat -- "$_l" 2>/dev/null || true ;;
      *)    cat  -- "$_l" 2>/dev/null || true ;;
    esac
  done
}

# Timestamp formats differ too, and fixing only the path would still have
# counted nothing. Traditional syslog writes "Aug 16 00:07:48"; Ubuntu 24.04's
# rsyslog defaults to RFC3339, "2026-08-15T14:10:06.959554+00:00". Build day
# prefixes in BOTH shapes and accept either, so one script serves both without
# needing to know which platform it is on.
days=(); days_iso=()
for i in 0 1 2 3 4 5 6; do
  days+=("$(date -d "-$i days" '+%b %e')")
  days_iso+=("$(date -d "-$i days" '+%Y-%m-%d')")
done
today="${days[0]}"; today_iso="${days_iso[0]}"
week_re="$(printf '%s|' "${days[@]}" "${days_iso[@]}")"; week_re="^(${week_re%|})"

# One pass, classifying each line; far cheaper than a grep per category.
awk -v today="$today" -v today_iso="$today_iso" -v weekre="$week_re" '
function bump(cat) { if (isweek) w[cat]++; if (istoday) t[cat]++ }
{
  istoday = (substr($0,1,6) == today || substr($0,1,10) == today_iso)
  isweek  = ($0 ~ weekre)
  if (!isweek) next

  if (index($0, "clamav: virus found"))            { bump("virus"); next }
  if (index($0, "Sender blocked by administrator")) { bump("blocklist"); next }
  if (index($0, "Spam message rejected"))           { bump("spam_reject"); next }
  if (index($0, "blocked using")) {
      bump("dnsbl")
      if (match($0, /blocked using [a-z0-9.]+/)) {
          name = substr($0, RSTART+14, RLENGTH-14); lw[name]++; if (istoday) lt[name]++
      }
      next
  }
  if (index($0, "postscreen") && index($0, "PREGREET"))  { bump("pregreet"); next }
  if (index($0, "postscreen") && index($0, "HANGUP"))    { bump("hangup"); next }
  if (index($0, "Greylisted"))                            { bump("greylist"); next }
}
END {
  split("virus blocklist spam_reject dnsbl pregreet hangup greylist", cats, " ")
  printf "{"
  printf "\"today\":{"
  for (i=1; i<=7; i++) printf "%s\"%s\":%d", (i>1?",":""), cats[i], (cats[i] in t ? t[cats[i]] : 0)
  printf "},\"week\":{"
  for (i=1; i<=7; i++) printf "%s\"%s\":%d", (i>1?",":""), cats[i], (cats[i] in w ? w[cats[i]] : 0)
  printf "},\"dnsbl_lists\":{"
  n=0; for (k in lw) { printf "%s\"%s\":%d", (n++>0?",":""), k, lw[k] }
  printf "}}"
}' < <(read_logs)
