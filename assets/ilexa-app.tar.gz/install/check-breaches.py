#!/usr/bin/env python3
"""
check-breaches.py - Periodic multi-provider exposure sweep over every mailbox
on this server. Writes JSON to /var/cache/quarantine-admin/breach-check.json,
which the dashboard's "Adatvédelmi incidensek" and infostealer cards read.

WHAT THIS SCRIPT DOES NOT DO. It does not talk to any API. Every request goes
through qa-ioc-lookup.php - the same gateway the console's on-demand IOC
lookup uses - so there is one request builder, one response parser and one
budget gate per provider, not two. Two readers of one API drifting apart is
this project's most reliable source of bugs. This script decides WHICH
addresses to ask about, WHICH provider to ask, and what to do with answers.

PROVIDERS ANSWER DIFFERENT QUESTIONS. xposedornot and leakcheck both report
breach-corpus membership and corroborate each other: a breach both name is a
stronger claim than one either makes alone. hudsonrock reports INFOSTEALER
INFECTIONS, which is not the same thing at all - it means credentials for that
mailbox may be in circulation right now, rather than sitting in a 2016 dump.
Its findings are kept in their own key and never merged into the breach list.

WHY THIS RUNS HOURLY AND NOT NIGHTLY. XposedOrNot publishes THREE limits -
2/sec, 25/hour and 100/day - and this sweep used to model only the daily one.
It fired 45 requests inside four minutes at 02:00, hit the HOURLY cap at
request 26, read the 429 as "the daily quota is gone" and stopped. Every night
for months: 25 addresses checked instead of the available 100, a full pass
taking 5.7 days instead of 1.4, and a log line that looked perfectly healthy
while it happened. The budget now lives in qa-quota-lib.php, which models all
three windows, and cron runs this hourly. Each run takes what the hour allows
and stops.

This sweep asks as 'batch', so it is refused once a provider's daily budget is
down to the interactive reserve and an operator clicking a lookup still gets
an answer. Results accumulate per provider; a provider's old result is
preserved until that provider is re-asked.
"""

import json
import fcntl
import os
import re
import subprocess
import sys
import time
from pathlib import Path

CACHE_FILE   = Path('/var/cache/quarantine-admin/breach-check.json')
LOCK_FILE    = Path('/var/lock/check-breaches.lock')
LOOKUP       = '/usr/local/sbin/qa-ioc-lookup.php'
CONFIG_SH    = '/usr/local/sbin/qa-ioclookup-config.sh'
CALL_TIMEOUT = 40      # generous: the gateway's own HTTP budget is 15s
SCHEMA       = 2

# Per-provider sweep policy.
#
#   kind      'breach'  fills breaches[]      'stealer'  fills stealer{}
#   recheck   seconds before an address is asked again. NOT a rate limit - the
#             ledger and the gateway handle those; this is about not spending
#             a request to re-learn something that has not changed. Breach
#             corpora are published in discrete dumps months apart, so a week
#             is generous. An infostealer infection is a LIVE condition, so it
#             is re-checked more often.
#   per_run   cap on requests per provider per run, to keep one cron run
#             short. The ledger is the real gate; this only bounds wall time.
#   spacing   seconds between requests, on top of whatever the ledger enforces.
#
# SPACING MUST EXCEED WHAT THE LEDGER PERMITS, or the sweep paces itself into
# a stop. The ledger counts a hit whose age is EXACTLY the window (deliberate,
# so a free tier is never overspent by one), which makes a [1 second, 1
# request] window mean "one per two seconds" in practice. At 1.5s spacing
# every second LeakCheck request would come back PACED, and PACED ends that
# provider's turn -- so a 143-mailbox sweep would have crawled one address per
# hourly run. Keep these comfortably above the effective rate, not at it.
PROVIDERS = [
    {'name': 'xposedornot', 'kind': 'breach',  'recheck': 7 * 86400, 'per_run': 30, 'spacing': 2.0},
    {'name': 'leakcheck',   'kind': 'breach',  'recheck': 7 * 86400, 'per_run': 60, 'spacing': 2.5},
    {'name': 'hudsonrock',  'kind': 'stealer', 'recheck': 3 * 86400, 'per_run': 60, 'spacing': 0.5},
]

# Explicit outcome per address per provider. The distinction that matters is
# between "we asked and the answer was no" and "we did not get an answer" -
# collapsing the second into the first shows a clean bill of health for a
# mailbox nobody successfully checked.
ST_SUCCESS      = 'SUCCESS'          # found something (breach or infection)
ST_NOT_FOUND    = 'NOT_FOUND'        # asked, nothing known
ST_PACED        = 'PACED'            # our own short window: "not yet"
ST_RATE_LIMITED = 'RATE_LIMITED'     # the PROVIDER pushed back (a real 429)
ST_QUOTA        = 'QUOTA_EXHAUSTED'  # our own ledger: the day's budget is gone
ST_TIMEOUT      = 'TIMEOUT'
ST_NETWORK      = 'NETWORK_ERROR'
ST_INVALID      = 'INVALID_REQUEST'  # not a usable address
ST_PROVIDER     = 'PROVIDER_ERROR'   # answered, but not with anything usable
ST_DISABLED     = 'DISABLED'         # switched off on the Rendszer tab

# These end THIS PROVIDER's turn in this run - there is nothing useful left to
# do for it - but they mean very different things, and conflating them is the
# exact mistake that cost 75% of the XposedOrNot budget:
#
#   PACED           a short window is full. Completely normal; the next hourly
#                   run carries on where this one stopped.
#   QUOTA_EXHAUSTED the day's budget is spent. Also normal, once a day.
#   RATE_LIMITED    the provider refused us even though our own ledger thought
#                   we had room, so the configured limits are wrong.
STOP_STATUSES     = (ST_PACED, ST_QUOTA, ST_RATE_LIMITED)
ALARMING_STATUSES = (ST_RATE_LIMITED,)

_lock_fh = None


def acquire_lock():
    global _lock_fh
    _lock_fh = open(LOCK_FILE, 'w')
    try:
        fcntl.flock(_lock_fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        print('Already running - another instance holds the lock.', file=sys.stderr)
        sys.exit(0)
    _lock_fh.write(str(os.getpid()))
    _lock_fh.flush()


def release_lock():
    global _lock_fh
    if _lock_fh:
        fcntl.flock(_lock_fh, fcntl.LOCK_UN)
        _lock_fh.close()
    LOCK_FILE.unlink(missing_ok=True)


def get_users() -> list[str]:
    result = subprocess.run(
        ['/usr/bin/doveadm', 'user', '*'],
        capture_output=True, text=True,
    )
    return sorted(set(
        u.strip() for u in result.stdout.splitlines()
        if '@' in u and 'archive' not in u.lower() and u.strip()
    ))


def provider_enabled(name: str) -> bool:
    """Whether the operator has this service switched on.

    The sweep respects the same Rendszer toggle as the on-demand lookup. It
    did not always: the toggle used to gate only the console, which meant
    switching a provider "off" left a cron job still calling it every hour.
    That is not what an off switch means, least of all for a service whose
    entire cost is sending mailbox addresses to a third party.
    """
    try:
        return subprocess.run([CONFIG_SH, 'is-enabled', name],
                              capture_output=True, timeout=15).returncode == 0
    except Exception:
        return False


def load_cache() -> dict:
    if not CACHE_FILE.exists():
        return {}
    try:
        return json.loads(CACHE_FILE.read_text())
    except Exception:
        return {}


def save_cache(data: dict):
    tmp = Path(str(CACHE_FILE) + '.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2))
    tmp.rename(CACHE_FILE)
    CACHE_FILE.chmod(0o640)
    try: os.chown(CACHE_FILE, 0, __import__("grp").getgrnam("apache").gr_gid)
    except Exception: pass


# ---------------------------------------------------------------- schema ---

def upgrade_row(row: dict) -> dict:
    """Read a schema-1 row (one flat XposedOrNot result) as a schema-2 row.

    Done on read rather than by a migration script, so the rows already on
    disk keep rendering through the upgrade and gain their per-provider shape
    as they are re-swept. A migration would have to be correct on its first
    and only attempt; this path is exercised on every load until the last old
    row has been replaced.
    """
    if not isinstance(row, dict):
        return {'by_provider': {}}
    if isinstance(row.get('by_provider'), dict):
        return row
    prov = {}
    if row.get('checked_at') or row.get('breaches') or row.get('error'):
        prov['xposedornot'] = {
            'status':     row.get('status') or (ST_PROVIDER if row.get('error') else
                                                (ST_SUCCESS if row.get('exposed') else ST_NOT_FOUND)),
            'checked_at': row.get('checked_at', ''),
            'exposed':    bool(row.get('exposed')),
            'breaches':   row.get('breaches') or [],
            'stealer':    None,
        }
        if row.get('error'):
            prov['xposedornot']['error'] = row['error']
    out = dict(row)
    out['by_provider'] = prov
    return out


# ----------------------------------------------------------------- merge ---

# Suffixes stripped from a breach name before comparing. Only at the END, and
# only this short list: XposedOrNot says "Adobe" where LeakCheck says
# "Adobe.com", and without this every such pair renders twice.
_TLD_SUFFIXES = (
    '.com.au', '.co.uk', '.com.br', '.co.za', '.com.tr',
    '.com', '.net', '.org', '.io', '.ru', '.de', '.fr', '.nl', '.hu', '.pl',
)


def normalize_breach(name: str) -> str:
    """Key used to decide whether two providers mean the same breach.

    Deliberately conservative: lowercase, strip one known TLD suffix from the
    end, drop non-alphanumerics. Nothing fuzzy - no edit distance, no
    substring matching.

    That means near-misses stay separate: LeakCheck's
    "Twitter.com (scraping data)" does not fold into XposedOrNot's "Twitter",
    because the suffix is not at the end. The cost is one extra row. The
    opposite failure - fuzzy matching quietly merging two unrelated breaches -
    would misstate what actually happened to a real person's account and is
    far harder to notice. A duplicate row is visible; a wrong merge is not.
    """
    n = (name or '').strip().lower()
    for suf in _TLD_SUFFIXES:
        if n.endswith(suf) and len(n) > len(suf):
            n = n[:-len(suf)]
            break
    return re.sub(r'[^a-z0-9]+', '', n)


# Words that describe the DUMP rather than the service it came from. Stripping
# them is what lets "Twitter-Scraped" and "Twitter.com (scraping data)" be
# recognised as one service.
_QUALIFIER_TOKENS = {
    'scraped', 'scraping', 'scrape', 'data', 'dump', 'leak', 'leaked',
    'breach', 'breached', 'database', 'db', 'combo', 'combolist', 'list',
    'part', 'full', 'alleged', 'com', 'net', 'org', 'io',
}


def breach_core(name: str) -> frozenset:
    """The set of tokens naming the SERVICE, with dump-describing words removed.

    Used only for the second grouping pass below, never as a merge key on its
    own: two cores in a SUBSET relation are the same service, but two cores
    that merely overlap are not.
    """
    n = (name or '').strip().lower()
    for suf in _TLD_SUFFIXES:
        if n.endswith(suf) and len(n) > len(suf):
            n = n[:-len(suf)]
            break
    toks = [t for t in re.split(r'[^a-z0-9]+', n) if t]
    core = {t for t in toks if t not in _QUALIFIER_TOKENS}
    # Everything was a qualifier ("Combolist") -- fall back to the raw tokens
    # rather than collapsing every such name into one empty-cored group.
    return frozenset(core or toks)


def breach_parts(name: str) -> list:
    """The service cores a single provider name refers to.

    LeakCheck writes a dump that covered several sites as one name joined by a
    separator ("CouponMom / ArmorGames"). Splitting on those separators is what
    tells such a LIST apart from a name that merely has more words in it.
    """
    return [c for c in (breach_core(p)
                        for p in re.split(r'\s*[/+&,]\s*', name or '')) if c]


def same_service(a: str, b: str) -> bool:
    """Whether two provider names refer to the same breached service.

    TWO RULES, both requiring an exact core match somewhere. Neither is fuzzy:
    no edit distance, no prefix matching, no shared-first-token.

      1. The cores are EQUAL once dump-describing words are stripped:
         "Twitter-Scraped" == "Twitter.com (scraping data)".
      2. One name is a separator-joined LIST that contains the other whole:
         "CouponMom" is one part of "CouponMom / ArmorGames".

    WHY NOT A PLAIN SUBSET OF TOKENS. That was the first attempt, and it folded
    "Adobe" into "Adobe Reader Forum" -- a different property of the same
    company, quite possibly a different incident. Extra words joined by a
    SEPARATOR mean "this dump also covered X"; extra words with no separator
    are part of one name. The two look identical to a subset test and are not
    the same claim.

    Also rejected: matching on a shared first token. It would have passed every
    real case here, and it merges Yahoo's genuinely distinct 2013 and 2014
    breaches, and "Last.fm" with "LastPass".
    """
    ca, cb = breach_core(a), breach_core(b)
    if not ca or not cb:
        return False
    if ca == cb:
        return True
    return ca in breach_parts(b) or cb in breach_parts(a)


def group_same_service(breaches: list) -> list:
    """Second pass: fold entries that name the SAME SERVICE differently.

    Stage one keys on the exact normalised name, which catches "Adobe" vs
    "Adobe.com" but not the two cases that actually occur between these
    providers:

        CouponMom        (XposedOrNot)  ==  CouponMom / ArmorGames        (LeakCheck)
        Twitter-Scraped  (XposedOrNot)  ==  Twitter.com (scraping data)   (LeakCheck)

    Left unfolded, those render as two rows for one incident AND inflate the
    "Db" count, which is the number an operator actually reads.

    NOTHING IS DISCARDED. Every provider's exact wording is kept in
    'alias_names' and rendered in the tooltip, so an operator can always see
    what each source said and judge the grouping. The display name is the most
    canonical of the names on offer -- fewest parts, then shortest -- never one
    we invented.
    """
    kept: list = []
    for b in breaches:
        for k in kept:
            if not same_service(b['name'], k['name']):
                continue
            k['_alias'][b['name']] = sorted(set(b.get('sources', [])))
            for sName in b.get('sources', []):
                if sName not in k['sources']:
                    k['sources'].append(sName)
            if b['year'] and (not k['year'] or b['year'] < k['year']):
                k['year'] = b['year']
            if b.get('data') and not k.get('data'):
                k['data'] = b['data']
            if b.get('url_name') and not k.get('url_name'):
                k['url_name'] = b['url_name']
            # Canonical display name: the one naming fewest services, then the
            # shorter. Never a name no provider actually used.
            mine, theirs = len(breach_parts(b['name'])), len(breach_parts(k['name']))
            if mine < theirs or (mine == theirs and len(b['name']) < len(k['name'])):
                k['name'] = b['name']
            break
        else:
            e = dict(b)
            e['_alias']  = {b['name']: sorted(set(b.get('sources', [])))}
            e['sources'] = list(b.get('sources', []))
            kept.append(e)

    out = []
    for k in kept:
        alias = k.pop('_alias', {})
        k['sources'] = sorted(set(k['sources']))
        names = sorted(alias)
        # Only record aliases when there is genuinely more than one wording.
        if len(names) > 1:
            k['alias_names'] = {n: alias[n] for n in names}
        out.append(k)
    return out


def merge_row(by_provider: dict) -> dict:
    """Fold per-provider results into the view the dashboard renders.

    Returns the schema-1-compatible fields (exposed / breaches /
    latest_breach) plus 'stealer', so existing readers keep working unchanged.
    Each merged breach carries a 'sources' list naming every provider that
    reported it - attribution is never lost, because "two independent sources
    agree" is the only thing that makes a multi-provider sweep worth its cost.
    """
    merged: dict = {}
    order: list = []
    latest = 0
    stealer = None

    for pname, res in sorted((by_provider or {}).items()):
        if not isinstance(res, dict):
            continue
        # A provider that FAILED contributes nothing - which is not the same
        # as contributing an empty result. This is the line that stops a
        # timeout being rendered as a clean bill of health.
        if res.get('status') not in (ST_SUCCESS, ST_NOT_FOUND):
            continue

        st = res.get('stealer')
        if isinstance(st, dict) and st.get('infected'):
            st = dict(st)
            st['source'] = pname
            if stealer is None or str(st.get('latest', '')) > str(stealer.get('latest', '')):
                stealer = st

        for b in res.get('breaches') or []:
            if not isinstance(b, dict):
                continue
            name = str(b.get('name') or '').strip()
            if not name:
                continue
            key = normalize_breach(name)
            if not key:
                continue
            year = int(b.get('year') or 0)
            data = str(b.get('data') or '')
            if key not in merged:
                merged[key] = {'name': name, 'year': year, 'data': data, 'sources': [pname]}
                order.append(key)
            else:
                m = merged[key]
                if pname not in m['sources']:
                    m['sources'].append(pname)
                # Keep the earliest non-zero year: providers disagree by a year
                # on when a dump was published, and the earlier date is the
                # more defensible claim about when exposure began.
                if year and (not m['year'] or year < m['year']):
                    m['year'] = year
                # Keep whichever provider actually supplied data classes.
                if data and not m['data']:
                    m['data'] = data
                # Prefer the longer display name ("Adobe.com" over "Adobe"):
                # the more specific of two names for one thing.
                if len(name) > len(m['name']):
                    m['name'] = name
            # XposedOrNot's /breach/<Name> pages use ITS spelling, so the link
            # has to be built from the name IT gave us -- not from the merged
            # display name, which prefers the longer of the two.
            #
            # This was a live 404: the merge preferred LeakCheck's
            # "000webhost.com" over XposedOrNot's "000webhost", and
            # /breach/000webhost.com does not exist (verified: 404 vs 200 for
            # /breach/000webhost). It broke links on exactly the corroborated
            # findings the multi-provider sweep exists to surface.
            if pname == 'xposedornot':
                merged[key]['url_name'] = name
            if merged[key]['year'] > latest:
                latest = merged[key]['year']

    breaches = [merged[k] for k in order]
    # Second pass: fold entries that name the same SERVICE differently. Run
    # after the exact-key merge, never instead of it -- the cheap, certain rule
    # gets first refusal and this only sees what it could not settle.
    breaches = group_same_service(breaches)
    breaches.sort(key=lambda b: (-(b['year'] or 0), b['name'].lower()))
    # latest is recomputed here rather than reused: grouping can drop an entry
    # whose year was the maximum, and a headline year with no row behind it is
    # exactly the kind of small lie that erodes trust in the whole card.
    latest = max((b['year'] or 0 for b in breaches), default=0)
    return {
        'exposed':       bool(breaches),
        'breaches':      breaches,
        'latest_breach': str(latest) if latest else '',
        'stealer':       stealer,
    }


# ---------------------------------------------------------------- lookup ---

def _classify_error(msg: str) -> str:
    """Map the gateway's error string onto an outcome status.

    Matching on message text is not elegant, but the gateway's contract is one
    JSON object with an 'error' string, and adding a machine-readable code
    would change a contract eleven services already satisfy. Everything
    matched here is emitted by qa-ioc-lookup.php; anything unrecognised stays
    PROVIDER_ERROR, the safe bucket, because it neither stops the run nor
    claims a clean result.
    """
    m = msg.lower()
    # Order matters: our own pacing message contains the words "rate limited"
    # too, and it must NOT be read as the provider pushing back.
    if 'by the local' in m:
        return ST_PACED
    if 'budget spent' in m or 'reserved for interactive' in m or 'not permitted' in m:
        return ST_QUOTA
    if 'rate-limited' in m or 'rate limited' in m:
        return ST_RATE_LIMITED
    if 'no response from' in m:
        return ST_TIMEOUT
    if 'invalid email' in m:
        return ST_INVALID
    if 'not installed' in m or 'could not' in m:
        return ST_NETWORK
    return ST_PROVIDER


def check_email(provider: str, email: str) -> dict:
    """One lookup through the shared gateway, for one provider."""
    def fail(status, err):
        return {'status': status, 'error': str(err)[:200], 'exposed': False,
                'breaches': [], 'stealer': None}

    try:
        proc = subprocess.run(
            [LOOKUP, provider, 'email', email, '15', 'batch'],
            capture_output=True, text=True, timeout=CALL_TIMEOUT,
        )
    except subprocess.TimeoutExpired:
        return fail(ST_TIMEOUT, f'lookup exceeded {CALL_TIMEOUT}s')
    except OSError as exc:
        return fail(ST_NETWORK, exc)

    try:
        data = json.loads(proc.stdout)
    except Exception:
        # The gateway prints exactly one JSON object on every path, so this
        # means it died before reaching its own error handler.
        err = (proc.stderr or proc.stdout or 'no output').strip()[:120]
        return fail(ST_PROVIDER, f'lookup helper failed: {err}')

    if not isinstance(data, dict):
        return fail(ST_PROVIDER, 'lookup helper returned an unexpected shape')
    if 'error' in data:
        msg = str(data['error'])[:200]
        return fail(_classify_error(msg), msg)

    raw = data.get('raw')
    if not isinstance(raw, dict):
        raw = {}
    breaches = raw.get('breaches')
    if not isinstance(breaches, list):
        breaches = []
    stealer = raw.get('stealer')
    if not isinstance(stealer, dict):
        stealer = None

    found = bool(breaches) or bool(stealer)
    return {
        'status':   ST_SUCCESS if found else ST_NOT_FOUND,
        'exposed':  bool(breaches),
        'breaches': breaches,
        'stealer':  stealer,
        'records':  raw.get('records'),
    }


def _ok(res) -> bool:
    """True if this per-provider result is a real answer, not a failure."""
    return isinstance(res, dict) and res.get('status') in (ST_SUCCESS, ST_NOT_FOUND)


# ------------------------------------------------------------------ main ---

def sweep_provider(prov: dict, users: list, emails: dict, now: float, flush) -> dict:
    """Ask one provider about as many due addresses as it will allow."""
    name  = prov['name']
    stats = {'checked': 0, 'found': 0, 'errors': 0, 'stopped': None}

    if not provider_enabled(name):
        print(f'  {name}: disabled on the Rendszer tab, skipping.')
        stats['stopped'] = ST_DISABLED
        return stats

    def due(u: str):
        """Sort key: never asked first, then failures, then oldest answer."""
        res = (emails.get(u, {}).get('by_provider') or {}).get(name)
        if not res:
            return (0, '')
        if not _ok(res):
            return (1, res.get('checked_at', ''))
        return (2, res.get('checked_at', ''))

    def fresh(u: str) -> bool:
        res = (emails.get(u, {}).get('by_provider') or {}).get(name)
        if not _ok(res):
            return False
        try:
            age = now - time.mktime(time.strptime(res['checked_at'], '%Y-%m-%d %H:%M:%S'))
        except Exception:
            return False
        return age < prov['recheck']

    todo = [u for u in sorted(users, key=due) if not fresh(u)][:prov['per_run']]
    if not todo:
        print(f'  {name}: nothing due (all checked within '
              f'{prov["recheck"] // 86400} days).')
        return stats

    print(f'  {name}: {len(todo)} due this run...')
    for i, email in enumerate(todo, 1):
        res    = check_email(name, email)
        status = res['status']

        if status in STOP_STATUSES:
            note = ('' if status not in ALARMING_STATUSES else
                    ' THIS IS NOT ROUTINE: the provider refused us while the local'
                    ' ledger still had room, so the limits in qa-quota-lib.php'
                    ' are wrong.')
            print(f'    [{i}/{len(todo)}] {status} - {res.get("error", "")}; '
                  f'ending {name} for this run. Nothing recorded for this '
                  f'address, so it keeps top priority next run.{note}')
            stats['stopped'] = status
            break

        row   = emails.setdefault(email, {})
        bp    = row.setdefault('by_provider', {})
        stamp = time.strftime('%Y-%m-%d %H:%M:%S')

        if not _ok(res):
            stats['errors'] += 1
            print(f'    [{i}/{len(todo)}] {email} ... {status}: {res.get("error", "")}')
            old = bp.get(name)
            if _ok(old):
                # Keep the last good answer; annotate rather than blank it.
                old['last_error']        = res.get('error', '')
                old['last_error_at']     = stamp
                old['last_error_status'] = status
            else:
                res['checked_at'] = stamp
                bp[name] = res
        else:
            res['checked_at'] = stamp
            bp[name] = res
            stats['checked'] += 1
            if status == ST_SUCCESS:
                stats['found'] += 1
                what = (f'{len(res["breaches"])} breaches' if res['breaches']
                        else 'INFOSTEALER')
                print(f'    [{i}/{len(todo)}] {email} ... {what}')
            else:
                print(f'    [{i}/{len(todo)}] {email} ... clean')

        row.update(merge_row(bp))
        flush()

        if i < len(todo):
            time.sleep(prov['spacing'])

    return stats


def main():
    acquire_lock()
    try:
        users = get_users()
        if not users:
            print('No users found', file=sys.stderr)
            sys.exit(1)
        if not os.access(LOOKUP, os.X_OK):
            print(f'Lookup helper not installed or not executable: {LOOKUP}',
                  file=sys.stderr)
            sys.exit(1)

        cache  = load_cache()
        emails = {a: upgrade_row(r) for a, r in (cache.get('emails') or {}).items()}
        # Re-merge on load so a row written before a provider existed picks up
        # its merged shape without waiting to be re-swept.
        for row in emails.values():
            row.update(merge_row(row.get('by_provider') or {}))

        providers_meta = dict(cache.get('providers') or {})
        now = time.time()

        def write():
            exposed = [u for u in users if emails.get(u, {}).get('exposed')]
            stealer = [u for u in users if (emails.get(u, {}) or {}).get('stealer')]
            # "checked" means at least one provider has a real answer.
            checked = [u for u in users
                       if any(_ok(r) for r in (emails.get(u, {}).get('by_provider') or {}).values())]
            save_cache({
                'schema':        SCHEMA,
                'last_run':      time.strftime('%Y-%m-%d %H:%M:%S'),
                'total_users':   len(users),
                'checked_count': len(checked),
                'exposed_count': len(exposed),
                'stealer_count': len(stealer),
                'providers':     providers_meta,
                'emails':        emails,
            })

        print(f'{len(users)} mailboxes; sweeping {len(PROVIDERS)} providers.')
        for prov in PROVIDERS:
            stats = sweep_provider(prov, users, emails, now, write)
            meta  = providers_meta.setdefault(prov['name'], {})
            meta['kind'] = prov['kind']
            if stats['stopped'] != ST_DISABLED:
                meta['last_run'] = time.strftime('%Y-%m-%d %H:%M:%S')
            meta['last_status'] = stats['stopped'] or 'OK'
            meta['errors']      = stats['errors']
            # How many mailboxes this provider currently has a real answer for.
            # This is the number that makes a silently-failing provider visible
            # on the dashboard instead of looking like good news.
            meta['coverage'] = sum(
                1 for u in users
                if _ok((emails.get(u, {}).get('by_provider') or {}).get(prov['name']))
            )
            write()

        exposed = [u for u in users if emails.get(u, {}).get('exposed')]
        stealer = [u for u in users if (emails.get(u, {}) or {}).get('stealer')]
        print(f'\nDone. {len(exposed)} mailboxes with known breaches, '
              f'{len(stealer)} with infostealer records.')
        for p in PROVIDERS:
            m = providers_meta.get(p['name'], {})
            print(f"  {p['name']:<12} coverage {m.get('coverage', 0)}/{len(users)}"
                  f"  last: {m.get('last_status', '-')}")

    finally:
        release_lock()


if __name__ == '__main__':
    main()
