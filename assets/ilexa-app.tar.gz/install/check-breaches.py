#!/usr/bin/env python3
"""
check-breaches.py - Daily email breach check via XposedOrNot free API.
Writes JSON to /var/cache/quarantine-admin/breach-check.json.

Free-tier limit: 100 requests per rolling 24 hours (NOT a per-minute burst
cap). With ~144 users a full sweep takes several nights: each run checks the
DAILY_LIMIT least-recently-checked addresses and results accumulate - old
results are preserved until re-checked.

Because the quota is daily, a 429 means the budget is gone for the window:
retrying cannot succeed, it only spends another request. So on the first 429
this script stops the run immediately and records nothing for that address,
leaving it never-checked so it keeps top priority on the next run.
"""

import json
import fcntl
import os
import subprocess
import sys
import time
import urllib.request
import urllib.error
import urllib.parse
from pathlib import Path

CACHE_FILE  = Path('/var/cache/quarantine-admin/breach-check.json')
LOCK_FILE   = Path('/var/lock/check-breaches.lock')
API_BASE    = 'https://api.xposedornot.com/v1/breach-analytics?email='
DAILY_LIMIT = 45    # 100/24h quota; half the budget, leaving room for a manual run
SLEEP_SEC   = 5.0  # 5s between requests → 12 req/min


_lock_fh = None

def acquire_lock():
    global _lock_fh
    _lock_fh = open(LOCK_FILE, 'w')
    try:
        fcntl.flock(_lock_fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        print('Already running - another instance holds the lock.', file=sys.stderr)
        sys.exit(0)
    _lock_fh.write(str(os.getpid()))
    _lock_fh.flush()

def release_lock():
    global _lock_fh
    if _lock_fh:
        fcntl.flock(_lock_fh, fcntl.LOCK_UN)
        _lock_fh.close()
    LOCK_FILE.unlink(missing_ok=True)

def get_users() -> list[str]:
    result = subprocess.run(
        ['/usr/bin/doveadm', 'user', '*'],
        capture_output=True, text=True,
    )
    return sorted(set(
        u.strip() for u in result.stdout.splitlines()
        if '@' in u and 'archive' not in u.lower() and u.strip()
    ))

def load_cache() -> dict:
    if not CACHE_FILE.exists():
        return {}
    try:
        return json.loads(CACHE_FILE.read_text())
    except Exception:
        return {}

def save_cache(data: dict):
    tmp = Path(str(CACHE_FILE) + '.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2))
    tmp.rename(CACHE_FILE)
    CACHE_FILE.chmod(0o640)
    try: os.chown(CACHE_FILE, 0, __import__("grp").getgrnam("apache").gr_gid)
    except Exception: pass

def _parse_response(data: dict) -> dict:
    """Parse breach-analytics response into our internal format."""
    if not isinstance(data, dict) or data.get('Error') or data.get('status') == 'Not found':
        return {'exposed': False, 'breaches': [], 'latest_breach': ''}

    # Primary location: ExposedBreaches.breaches_details (current API format)
    details = (data.get('ExposedBreaches') or {}).get('breaches_details') or []
    # Fallback: BreachMetrics.breaches_details (older API format)
    if not details:
        details = (data.get('BreachMetrics') or {}).get('breaches_details') or []
    if not details:
        # plain check-email style {"breaches":[["name",...]]}
        raw   = data.get('breaches', [])
        names = raw[0] if raw and isinstance(raw[0], list) else (raw if isinstance(raw, list) else [])
        return {'exposed': bool(names),
                'breaches': [{'name': n, 'year': 0, 'data': ''} for n in names],
                'latest_breach': ''}

    breaches    = []
    latest_year = 0
    for b in details:
        name = b.get('breach') or b.get('name') or ''
        # API uses 'xposed_date' as a year string
        year = int(b.get('xposed_date') or b.get('year') or b.get('YearOfBreach') or 0)
        if name:
            breaches.append({'name': name, 'year': year,
                             'data': b.get('xposed_data') or b.get('details') or b.get('DataClasses') or ''})
        if year > latest_year:
            latest_year = year

    return {'exposed': bool(breaches),
            'breaches': breaches,
            'latest_breach': str(latest_year) if latest_year else ''}


def check_email(email: str) -> dict:
    url = API_BASE + urllib.parse.quote(email, safe='')
    req = urllib.request.Request(url, headers={
        'Accept':     'application/json',
        'User-Agent': 'quarantine-admin/1.0',
    })
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode())
        return _parse_response(data)
    except urllib.error.HTTPError as e:
        if e.code == 429:
            # Daily quota, not a burst throttle - no retry can succeed in this
            # window. Signal the caller to abort the whole run.
            return {'error': 'rate_limited', 'quota_exhausted': True}
        try:
            if json.loads(e.read().decode('utf-8', errors='replace')).get('Error'):
                return {'exposed': False, 'breaches': []}
        except Exception:
            pass
        return {'exposed': False, 'breaches': [], 'error': f'HTTP {e.code}'}
    except Exception as exc:
        return {'exposed': False, 'breaches': [], 'error': str(exc)[:120]}


def _is_clean_result(r: dict) -> bool:
    """True if r is a real API result (not an error/never-checked)."""
    return bool(r) and not r.get('error')


def main():
    acquire_lock()
    try:
        all_users = get_users()
        if not all_users:
            print('No users found', file=sys.stderr)
            sys.exit(1)

        cache = load_cache()
        emails = cache.get('emails', {})

        # Priority order: never-checked first, then errored/rate-limited,
        # then clean results sorted oldest-first.
        def sort_key(u):
            r = emails.get(u, {})
            if not r:
                return ('0', '')          # never checked - highest priority
            if r.get('error'):
                return ('1', r.get('checked_at', ''))  # errored - second priority
            return ('2', r.get('checked_at', ''))      # clean - oldest first

        to_check = sorted(all_users, key=sort_key)[:DAILY_LIMIT]

        total_users   = len(all_users)
        checked_clean = sum(1 for u in all_users if _is_clean_result(emails.get(u, {})))
        print(f'{total_users} total users, {checked_clean} cleanly checked so far.')
        print(f'Checking {len(to_check)} this run (daily limit {DAILY_LIMIT})...')

        errors = 0
        newly_exposed = 0
        quota_hit = False
        done = 0

        for i, email in enumerate(to_check, 1):
            print(f'[{i}/{len(to_check)}] {email} ... ', end='', flush=True)
            result = check_email(email)
            now = time.strftime('%Y-%m-%d %H:%M:%S')

            if result.get('quota_exhausted'):
                print('429 - daily quota exhausted; stopping run. '
                      'Nothing recorded for this address, so it keeps '
                      'top priority next run.')
                quota_hit = True
                break
            done = i

            if result.get('error'):
                print(f"ERROR: {result['error']}")
                errors += 1
                old = emails.get(email, {})
                if _is_clean_result(old):
                    # Preserve the last good result; just annotate the error
                    old['last_error']    = result['error']
                    old['last_error_at'] = now
                    emails[email] = old
                else:
                    result['checked_at'] = now
                    emails[email] = result
            else:
                result['checked_at'] = now
                emails[email] = result
                if result['exposed']:
                    print(f"EXPOSED ({len(result['breaches'])} breaches)")
                    newly_exposed += 1
                else:
                    print('clean')

            # Save after every address so progress survives a kill/crash
            exposed_all   = [u for u in all_users if emails.get(u, {}).get('exposed')]
            checked_clean = sum(1 for u in all_users if _is_clean_result(emails.get(u, {})))
            cache = {
                'last_run':      now,
                'total_users':   total_users,
                'checked_count': checked_clean,
                'exposed_count': len(exposed_all),
                'emails':        emails,
            }
            save_cache(cache)

            if i < len(to_check):
                time.sleep(SLEEP_SEC)

        exposed_all = [u for u in all_users if emails.get(u, {}).get('exposed')]
        checked_clean = sum(1 for u in all_users if _is_clean_result(emails.get(u, {})))
        status = ' (stopped early - quota exhausted)' if quota_hit else ''
        print(f'\nDone. {done} checked this run{status}, '
              f'{checked_clean}/{total_users} users have a result, '
              f'{len(exposed_all)} exposed total, {errors} errors.')

    finally:
        release_lock()


if __name__ == '__main__':
    main()
