# Country flags

257 ISO 3166-1 alpha-2 country flags, 40x30 PNG8 (~89 KB total).

Source: [flag-icons](https://github.com/lipis/flag-icons) v7.2.3, MIT licensed
(see `LICENSE`). Generated from that project's `flags/4x3/*.svg` with:

    convert -background none -resize 40x30 <cc>.svg -strip -colors 64 PNG8:<cc>.png

**Why PNG and not the upstream SVG, or emoji.** The column first shipped using
Unicode regional-indicator emoji (🇭🇺). Windows ships no flag-emoji font at
all, so those render as the bare letters "HU" — which is what the operator
actually saw. Image flags render identically everywhere.

PNG over SVG because at a ~20 px table cell the upstream SVGs cost 2.9 MB
(a few carry detailed coats of arms — Serbia alone is 184 KB), while the same
set as 40 x 30 PNG8 is 89 KB with no visible difference at display size. 40x30
is 2x the rendered size, so it stays crisp on HiDPI screens.

Rendered by `qa_country_flag()` in `src/helpers.php`. A code with no matching
file degrades to the two-letter code via the `<img alt>`, so a country added
to GeoLite2 later shows text rather than a broken image.
